package cern.colt.function.tfcomplex;

public interface FComplexFComplexRealFunction {
    abstract public float apply(float[] x, float[] y);
}
