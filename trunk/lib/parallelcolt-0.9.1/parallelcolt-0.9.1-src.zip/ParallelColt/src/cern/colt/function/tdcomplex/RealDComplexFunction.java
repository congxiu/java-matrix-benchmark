package cern.colt.function.tdcomplex;

public interface RealDComplexFunction {
    abstract public double[] apply(double x);
}
