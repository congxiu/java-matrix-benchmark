package cern.colt.function.tdcomplex;

public interface RealDComplexDComplexFunction {
    abstract public double[] apply(double x, double[] y);
}
