package cern.colt.function.tfcomplex;

public interface RealFComplexFunction {
    abstract public float[] apply(float x);
}
