package cern.colt.function.tdcomplex;

public interface DComplexDComplexRealProcedure {
    abstract public boolean apply(double[] x, double[] y, double tol);
}
