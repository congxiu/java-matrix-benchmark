/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.type;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public final class TimeFilter {

    private static final Date ORIGIN = new Date(0L);

    public static Calendar makeCalendar(final long aTimeInMillis) {
        final GregorianCalendar retVal = new GregorianCalendar();
        retVal.setTimeInMillis(aTimeInMillis);
        return retVal;
    }

    public static Date makeDate(final long aTimeInMillis) {
        return new Date(aTimeInMillis);
    }

    private final Date myReference;
    private final CalendarDateUnit myResolution;

    public TimeFilter(final CalendarDateUnit aResolution) {

        super();

        myReference = ORIGIN;
        myResolution = aResolution;
    }

    public TimeFilter(final Date aReference, final CalendarDateUnit aResolution) {

        super();

        myReference = TimeFilter.makeDate(aReference.getTime());
        myResolution = aResolution;
    }

    @SuppressWarnings("unused")
    private TimeFilter() {
        this(ORIGIN, CalendarDateUnit.MILLIS);
    }

    public final Date convert(final Calendar aCalendar) {
        return TimeFilter.makeDate(this.toTimeInMillis(aCalendar));
    }

    public final Calendar convert(final Date aDate) {
        return TimeFilter.makeCalendar(this.toTimeInMillis(aDate));
    }

    public final Calendar filter(final Calendar aCalendar) {
        return TimeFilter.makeCalendar(this.toTimeInMillis(aCalendar));
    }

    public final Date filter(final Date aDate) {
        return TimeFilter.makeDate(this.toTimeInMillis(aDate));
    }

    public final long getReference() {
        return myReference.getTime();
    }

    public final CalendarDateUnit getResolution() {
        return myResolution;
    }

    public final Calendar step(final Calendar aCalendar) {
        return this.step(aCalendar, 1);
    }

    public final Calendar step(final Calendar aCalendar, final int aStepCount) {

        final Calendar retVal = new GregorianCalendar();
        retVal.setTimeInMillis(this.toTimeInMillis(aCalendar));
        retVal.setLenient(true);

        final CalendarDateUnit tmpResolution = myResolution;

        switch (tmpResolution) {

        case YEAR:

            retVal.set(Calendar.DAY_OF_YEAR, 1);
            retVal.add(Calendar.YEAR, aStepCount + 1);
            retVal.add(Calendar.DAY_OF_YEAR, -1);

            break;

        case MONTH:

            retVal.set(Calendar.DAY_OF_MONTH, 1);
            retVal.add(Calendar.MONTH, aStepCount + 1);
            retVal.add(Calendar.DAY_OF_MONTH, -1);

            break;

        case WEEK:

            retVal.set(Calendar.DAY_OF_WEEK, aCalendar.getFirstDayOfWeek());
            retVal.add(Calendar.WEEK_OF_YEAR, aStepCount + 1);
            retVal.add(Calendar.DAY_OF_WEEK, -1);

            break;

        case DAY:

            retVal.add(Calendar.DAY_OF_MONTH, aStepCount);
            break;

        case HOUR:

            retVal.add(Calendar.HOUR_OF_DAY, aStepCount);
            break;

        case MINUTE:

            retVal.add(Calendar.MINUTE, aStepCount);
            break;

        case SECOND:

            retVal.add(Calendar.SECOND, aStepCount);
            break;

        default:

            break;
        }

        retVal.setTimeInMillis(this.toTimeInMillis(retVal));

        return retVal;
    }

    public final Date step(final Date aDate) {
        return this.step(aDate, 1);
    }

    public final Date step(final Date aDate, final int aStepCount) {
        return new Date(this.toTimeInMillis(aDate) + aStepCount * myResolution.size());
    }

    public final long toTimeInMillis(final Calendar aCalendar) {
        return myResolution.toTimeInMillis(aCalendar);
    }

    public final long toTimeInMillis(final Date aDate) {
        return myResolution.toTimeInMillis(myReference, aDate);
    }

}
