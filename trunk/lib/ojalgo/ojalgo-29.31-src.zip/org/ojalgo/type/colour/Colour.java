/* 
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.type.colour;

import java.awt.Color;
import java.awt.color.ColorSpace;

import org.ojalgo.type.TypeUtils;

/**
 * Colour
 * 
 * @author apete
 */
public class Colour extends Color {

    private static final int LIMIT = 256;

    public static Colour random() {

        int tmpR = (int) Math.floor(LIMIT * Math.random());
        int tmpG = (int) Math.floor(LIMIT * Math.random());
        int tmpB = (int) Math.floor(LIMIT * Math.random());

        return new Colour(tmpR, tmpG, tmpB);
    }

    public static Colour valueOf(String aColourAsHexString) {
        return new Colour(Color.decode(aColourAsHexString));
    }

    public Colour(ColorSpace cspace, float components[], float alpha) {
        super(cspace, components, alpha);
    }

    public Colour(float r, float g, float b) {
        super(r, g, b);
    }

    public Colour(float r, float g, float b, float a) {
        super(r, g, b, a);
    }

    public Colour(int rgb) {
        super(rgb);
    }

    public Colour(Color aColor) {
        super(aColor.getRGB());
    }

    public Colour(int rgba, boolean hasalpha) {
        super(rgba, hasalpha);
    }

    public Colour(int r, int g, int b) {
        super(r, g, b);
    }

    public Colour(int r, int g, int b, int a) {
        super(r, g, b, a);
    }

    public String toHexString() {
        return TypeUtils.toHexString(this);
    }

}