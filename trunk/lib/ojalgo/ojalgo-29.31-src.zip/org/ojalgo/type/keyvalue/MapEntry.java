/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.type.keyvalue;

import java.util.Map;

import org.ojalgo.netio.ASCII;

/**
 * @author apete
 */
public final class MapEntry<K extends Comparable<K>, V extends Object> extends Object implements Map.Entry<K, V>, Comparable<MapEntry<K, V>> {

    private final K myKey;
    private final Map<K, V> myMap;
    private V myValue;

    public MapEntry(final K aKey, final V aValue) {

        super();

        myKey = aKey;
        myMap = null;
        myValue = aValue;
    }

    public MapEntry(final Map.Entry<K, V> anEntry) {

        super();

        myKey = anEntry.getKey();
        myMap = null;
        myValue = anEntry.getValue();
    }

    public MapEntry(final Map<K, V> aMap, final K aKey) {

        super();

        myKey = aKey;
        myMap = aMap;
        myValue = null;
    }

    @SuppressWarnings("unused")
    private MapEntry() {
        this(null);
    }

    public final int compareTo(final MapEntry<K, V> anEntry) {
        return myKey.compareTo(anEntry.getKey());
    }

    public final boolean equals(final Map.Entry<K, V> anEntry) {
        return this.getKey().equals(anEntry.getKey()) && this.getValue().equals(anEntry.getValue());
    }

    @Override
    public final boolean equals(final Object anObj) {
        if (anObj instanceof Map.Entry) {
            return this.equals((Map.Entry<K, V>) anObj);
        } else {
            return false;
        }
    }

    public final K getKey() {
        return myKey;
    }

    public final V getValue() {
        if (myValue != null) {
            return myValue;
        } else if (myMap != null) {
            return myMap.get(myKey);
        } else {
            return null;
        }
    }

    @Override
    public final int hashCode() {
        final V tmpValue = this.getValue();
        return ((myKey == null) ? 0 : myKey.hashCode()) ^ ((tmpValue == null) ? 0 : tmpValue.hashCode());
    }

    public final V setValue(final V aValue) {

        final V retVal = this.getValue();

        myValue = aValue;

        if (myMap != null) {
            myMap.put(myKey, aValue);
        }

        return retVal;
    }

    @Override
    public final String toString() {
        return myKey + String.valueOf(ASCII.EQUALS) + this.getValue();
    }

}
