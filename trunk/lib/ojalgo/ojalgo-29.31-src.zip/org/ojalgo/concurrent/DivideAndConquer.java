/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.concurrent;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public abstract class DivideAndConquer extends Object {

    private final int myAmount;
    private final int myBar;

    public DivideAndConquer(final int amount, final int bar) {

        super();

        myAmount = amount;
        myBar = bar;
    }

    @SuppressWarnings("unused")
    private DivideAndConquer() {
        this(0, 0);
    }

    public abstract void aggregate(final int aFirst, final int aSplit, final int aLimit);

    public final void conquer() {
        this.divide(0, myAmount, myBar, ProcessorCount.RUNTIME);
    }

    public abstract void conquer(final int aFirst, final int aLimit);

    void divide(final int aFirst, final int aLimit, final int aBar, final int availableCPUs) {

        final int tmpCount = aLimit - aFirst;

        if ((availableCPUs > 1) && (tmpCount > aBar)) {

            final int tmpSplit = aFirst + tmpCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    DivideAndConquer.this.divide(aFirst, tmpSplit, aBar, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    DivideAndConquer.this.divide(tmpSplit, aLimit, aBar, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

            this.aggregate(aFirst, tmpSplit, aLimit);

        } else {

            this.conquer(aFirst, aLimit);
        }
    }

}
