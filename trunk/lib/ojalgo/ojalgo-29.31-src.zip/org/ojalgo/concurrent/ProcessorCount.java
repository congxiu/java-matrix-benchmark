/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.concurrent;

public final class ProcessorCount {

    /**
     * @see Runtime#availableProcessors()
     */
    public static int RUNTIME = Runtime.getRuntime().availableProcessors();
    static long CACHE_COUNT = 8L;
    static long CACHE_SIZE = 256L * 1024L * 1024L;
    static long THREADS_PER_CACHE = Math.max(RUNTIME / CACHE_COUNT, 1L);
    static long SIZE_PER_THREAD = CACHE_SIZE / THREADS_PER_CACHE;

    public static ProcessorCount getDecremented() {
        return new ProcessorCount(RUNTIME - 1, false);
    }

    public static ProcessorCount getFree() {
        return new ProcessorCount(DaemonPoolExecutor.INSTANCE.countPotentialDaemons(), false);
    }

    public static ProcessorCount getFull() {
        return new ProcessorCount(RUNTIME, false);
    }

    public static ProcessorCount getHalf() {
        return new ProcessorCount(RUNTIME / 2, false);
    }

    public final int count;
    public final boolean modified;

    @SuppressWarnings("unused")
    private ProcessorCount() {
        this(RUNTIME, false);
    }

    ProcessorCount(final int aCount, final boolean aModified) {

        super();

        count = aCount;
        modified = aModified;
    }

    /**
     * @return count - 1
     */
    public ProcessorCount decrement() {
        return new ProcessorCount(count - 1, true);
    }

    /**
     * @return count / 2
     */
    public ProcessorCount halve() {
        return new ProcessorCount(count / 2, true);
    }

}
