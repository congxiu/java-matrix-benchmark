/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.concurrent;

import java.util.ArrayList;
import java.util.concurrent.Callable;

public abstract class Paralell extends Object {

    private final int myAmount;
    private final int myBar;

    public Paralell(final int amount, final int bar) {

        super();

        myAmount = amount;
        myBar = bar;
    }

    @SuppressWarnings("unused")
    private Paralell() {
        this(0, 0);
    }

    public final void conquer() {

        final int tmpSplitter = Math.min(myAmount, ProcessorCount.RUNTIME);

        final int tmpBatchSize = myAmount / tmpSplitter;

        if (tmpBatchSize > myBar) {

            final int tmpFirst = 0;

            final ArrayList<Callable<Boolean>> tmpList = new ArrayList<Callable<Boolean>>(tmpSplitter);
            for (int i = 0; i < tmpSplitter; i++) {

                final int tmpLimit = myAmount - ((1 + tmpSplitter - i) * tmpBatchSize);

                tmpList.set(i, new Callable<Boolean>() {

                    public Boolean call() throws Exception {
                        Paralell.this.performTask(tmpFirst, tmpLimit);
                        return null;
                    }
                });
            }

            try {
                DaemonPoolExecutor.INSTANCE.invokeAll(tmpList);
            } catch (final InterruptedException anException) {
                // TODO Auto-generated catch block
                anException.printStackTrace();
            }

        } else {

            this.performTask(0, myAmount);
        }
    }

    public abstract void performTask(final int aFirst, final int aLimit);
}
