/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.array;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.AbstractList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.RandomAccess;

import org.ojalgo.access.Access1D;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.ParameterFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;

/**
 * Array1D
 *
 * @author apete
 */
public final class Array1D<N extends Number> extends AbstractList<N> implements Access1D<N>, RandomAccess, Serializable {

    public static Array1D<BigDecimal> makeBig(final BigDecimal[] aRaw) {
        return Array1D.wrapBig(ArrayUtils.copyOf(aRaw));
    }

    public static Array1D<BigDecimal> makeBig(final int aSize) {
        return new BigArray(aSize).asArray1D();
    }

    public static Array1D<ComplexNumber> makeComplex(final ComplexNumber[] aRaw) {
        return Array1D.wrapComplex(ArrayUtils.copyOf(aRaw));
    }

    public static Array1D<ComplexNumber> makeComplex(final double[] aRawReal, final double[] aRawImag) {

        final int tmpLength = Math.min(aRawReal.length, aRawImag.length);

        final ComplexNumber[] tmpRaw = new ComplexNumber[tmpLength];

        for (int i = 0; i < tmpLength; i++) {
            tmpRaw[i] = ComplexNumber.makeRectangular(aRawReal[i], aRawImag[i]);
        }

        return Array1D.wrapComplex(tmpRaw);
    }

    public static Array1D<ComplexNumber> makeComplex(final int aSize) {
        return new ComplexArray(aSize).asArray1D();
    }

    public static Array1D<Double> makePrimitive(final double[] aRaw) {
        return Array1D.wrapPrimitive(ArrayUtils.copyOf(aRaw));
    }

    public static Array1D<Double> makePrimitive(final int aSize) {
        return new PrimitiveArray(aSize).asArray1D();
    }

    public static Array1D<BigDecimal> wrapBig(final BigDecimal[] aRaw) {
        return new BigArray(aRaw).asArray1D();
    }

    public static Array1D<ComplexNumber> wrapComplex(final ComplexNumber[] aRaw) {
        return new ComplexArray(aRaw).asArray1D();
    }

    public static Array1D<Double> wrapPrimitive(final double[] aRaw) {
        return new PrimitiveArray(aRaw).asArray1D();
    }

    @SuppressWarnings("unchecked")
    private static <T extends Number> T[] copyAndSort(final Array1D<T> anArray) {

        final int tmpLength = anArray.length;
        final T[] retVal = (T[]) new Number[tmpLength];

        for (int i = 0; i < tmpLength; i++) {
            retVal[i] = anArray.get(i);
        }

        Arrays.sort(retVal);

        return retVal;
    }

    public final int length;

    private final BasicArray<N> myDelegate;

    private final int myFirst;
    private final int myLimit;
    private final int myStep;

    @SuppressWarnings("unused")
    private Array1D() {
        this(null);
    }

    Array1D(final BasicArray<N> aDelegate) {
        this(aDelegate, 0, aDelegate.length, 1);
    }

    Array1D(final BasicArray<N> aDelegate, final int aFirst, final int aLimit, final int aStep) {

        super();

        myDelegate = aDelegate;

        myFirst = aFirst;
        myLimit = aLimit;
        myStep = aStep;

        length = (myLimit - myFirst) / myStep;
    }

    @Override
    public boolean contains(final Object anObj) {
        return this.indexOf(anObj) != -1;
    }

    public double doubleValue(final int anInd) {
        return myDelegate.doubleValue(myFirst + myStep * anInd);
    }

    public void fillAll(final N aNmbr) {
        myDelegate.fill(myFirst, myLimit, myStep, aNmbr);
    }

    public void fillRange(final int aFirst, final int aLimit, final N aNmbr) {
        myDelegate.fill(myFirst + myStep * aFirst, myFirst + myStep * aLimit, myStep, aNmbr);
    }

    @Override
    public N get(final int anInd) {
        return myDelegate.get(myFirst + myStep * anInd);
    }

    public int getIndexOfLargestInRange(final int aFirst, final int aLimit) {
        return (myDelegate.getIndexOfLargest(myFirst + myStep * aFirst, myFirst + myStep * aLimit, myStep) - myFirst) / myStep;
    }

    @Override
    public int indexOf(final Object anObj) {
        final int tmpLength = length;
        if (anObj == null) {
            for (int i = 0; i < tmpLength; i++) {
                if (this.get(i) == null) {
                    return i;
                }
            }
        } else if (anObj instanceof Number) {
            for (int i = 0; i < tmpLength; i++) {
                if (anObj.equals(this.get(i))) {
                    return i;
                }
            }
        }
        return -1;
    }

    /**
     * @see Scalar#isAbsolute()
     */
    public boolean isAbsolute(final int anInd) {
        return myDelegate.isAbsolute(myFirst + myStep * anInd);
    }

    public boolean isAllZeros() {
        return myDelegate.isZeros(myFirst, myLimit, myStep);
    }

    @Override
    public boolean isEmpty() {
        return length == 0;
    }

    public boolean isRangeZeros(final int aFirst, final int aLimit) {
        return myDelegate.isZeros(myFirst + myStep * aFirst, myFirst + myStep * aLimit, myStep);
    }

    /**
     * @see Scalar#isReal()
     */
    public boolean isReal(final int anInd) {
        return myDelegate.isReal(myFirst + myStep * anInd);
    }

    /**
     * @see Scalar#isZero()
     */
    public boolean isZero(final int anInd) {
        return myDelegate.isZero(myFirst + myStep * anInd);
    }

    @Override
    public Iterator<N> iterator() {
        return new Iterator<N>() {

            private int cursor = 0;

            public boolean hasNext() {
                return cursor < length;
            }

            public N next() {
                return myDelegate.get(myFirst + myStep * cursor++);
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    public void modifyAll(final BinaryFunction<N> aFunc, final N aNmbr) {
        myDelegate.modify(myFirst, myLimit, myStep, aFunc, aNmbr);
    }

    public void modifyAll(final N aNmbr, final BinaryFunction<N> aFunc) {
        myDelegate.modify(myFirst, myLimit, myStep, aNmbr, aFunc);
    }

    public void modifyAll(final ParameterFunction<N> aFunc, final int aParam) {
        myDelegate.modify(myFirst, myLimit, myStep, aFunc, aParam);
    }

    public void modifyAll(final UnaryFunction<N> aFunc) {
        myDelegate.modify(myFirst, myLimit, myStep, aFunc);
    }

    public void modifyMatching(final Array1D<N> anArray, final BinaryFunction<N> aFunc) {
        final int tmpLength = length;
        if (myDelegate instanceof PrimitiveArray) {
            for (int i = 0; i < tmpLength; i++) {
                this.set(i, aFunc.invoke(anArray.doubleValue(i), this.doubleValue(i)));
            }
        } else {
            for (int i = 0; i < tmpLength; i++) {
                this.set(i, aFunc.invoke(anArray.get(i), this.get(i)));
            }
        }
    }

    public void modifyMatching(final BinaryFunction<N> aFunc, final Array1D<N> anArray) {
        final int tmpLength = length;
        if (myDelegate instanceof PrimitiveArray) {
            for (int i = 0; i < tmpLength; i++) {
                this.set(i, aFunc.invoke(this.doubleValue(i), anArray.doubleValue(i)));
            }
        } else {
            for (int i = 0; i < tmpLength; i++) {
                this.set(i, aFunc.invoke(this.get(i), anArray.get(i)));
            }
        }
    }

    public void modifyRange(final int aFirst, final int aLimit, final BinaryFunction<N> aFunc, final N aNmbr) {
        myDelegate.modify(myFirst + myStep * aFirst, myFirst + myStep * aLimit, myStep, aFunc, aNmbr);
    }

    public void modifyRange(final int aFirst, final int aLimit, final N aNmbr, final BinaryFunction<N> aFunc) {
        myDelegate.modify(myFirst + myStep * aFirst, myFirst + myStep * aLimit, myStep, aNmbr, aFunc);
    }

    public void modifyRange(final int aFirst, final int aLimit, final ParameterFunction<N> aFunc, final int aParam) {
        myDelegate.modify(myFirst + myStep * aFirst, myFirst + myStep * aLimit, myStep, aFunc, aParam);
    }

    public void modifyRange(final int aFirst, final int aLimit, final UnaryFunction<N> aFunc) {
        myDelegate.modify(myFirst + myStep * aFirst, myFirst + myStep * aLimit, myStep, aFunc);
    }

    /**
     * Asssumes you have first called {@linkplain #sortAscending()}.
     */
    public int searchAscending(final N aKey) {

        final int tmpLength = length;
        if (tmpLength != myDelegate.length) {

            final Number[] tmpArray = new Number[tmpLength];

            for (int i = 0; i < tmpLength; i++) {
                tmpArray[i] = this.get(i);
            }

            return Arrays.binarySearch(tmpArray, aKey);

        } else {
            return myDelegate.searchAscending(aKey);
        }
    }

    /**
     * Asssumes you have first called {@linkplain #sortDescending()}.
     */
    public int searchDescending(final N aKey) {

        final int tmpLength = length;
        final Number[] tmpArray = new Number[tmpLength];

        for (int i = 0; i < tmpLength; i++) {
            tmpArray[i] = this.get(tmpLength - 1 - i);
        }

        final int tmpInd = Arrays.binarySearch(tmpArray, aKey);

        if (tmpInd >= 0) {
            return tmpLength - 1 - tmpInd;
        } else if (tmpInd < -1) {
            return -tmpLength - tmpInd - 1;
        } else {
            return -1;
        }
    }

    public void set(final int anInd, final double aNmbr) {
        myDelegate.set(myFirst + myStep * anInd, aNmbr);
    }

    @Override
    public N set(final int anInd, final N aNmbr) {
        final int tmpIndex = myFirst + myStep * anInd;
        final N retVal = myDelegate.get(tmpIndex);
        myDelegate.set(tmpIndex, aNmbr);
        return retVal;
    }

    @Override
    public int size() {
        return length;
    }

    public void sortAscending() {

        final int tmpLength = length;
        if (tmpLength != myDelegate.length) {

            final N[] tmpArray = Array1D.copyAndSort(this);

            for (int i = 0; i < tmpLength; i++) {
                this.set(i, tmpArray[i]);
            }
        } else {
            myDelegate.sortAscending();
        }
    }

    public void sortDescending() {

        final N[] tmpArray = Array1D.copyAndSort(this);

        final int tmpLength = length;
        for (int i = 0; i < tmpLength; i++) {
            this.set(i, tmpArray[tmpLength - 1 - i]);
        }
    }

    @Override
    public Array1D<N> subList(final int aFirst, final int aLimit) {
        return new Array1D<N>(myDelegate, myFirst + myStep * aFirst, myFirst + myStep * aLimit, myStep);
    }

    public double[] toRawCopy() {

        final int tmpLength = length;
        final double[] retVal = new double[tmpLength];

        for (int i = 0; i < tmpLength; i++) {
            retVal[i] = this.doubleValue(i);
        }

        return retVal;
    }

    public Scalar<N> toScalar(final int anInd) {
        return myDelegate.toScalar(myFirst + myStep * anInd);
    }

    public void visitAll(final AggregatorFunction<N> aVisitor) {
        myDelegate.visit(myFirst, myLimit, myStep, aVisitor);
    }

    public void visitRange(final int aFirst, final int aLimit, final AggregatorFunction<N> aVisitor) {
        myDelegate.visit(myFirst + myStep * aFirst, myFirst + myStep * aLimit, myStep, aVisitor);
    }

    BasicArray<N> getDelegate() {
        return myDelegate;
    }

}
