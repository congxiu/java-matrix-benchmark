/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.random;

import java.util.Arrays;

import org.ojalgo.ProgrammingError;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.ArrayUtils;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.series.BasicSeries;
import org.ojalgo.series.primitive.DataSeries;
import org.ojalgo.series.primitive.PrimitiveSeries;

public class SampleSet {

    /**
     * @param aSumOfValues The sum of all values in a sample set
     * @param aSumOfSquaredValues The sum of all squared values, in a sample set
     * @param aValuesCount The number of values in the sample set
     * @return The sample set's variance
     */
    public static double calculateVariance(final double aSumOfValues, final double aSumOfSquaredValues, final int aValuesCount) {
        return (aValuesCount * aSumOfSquaredValues - aSumOfValues * aSumOfValues) / (aValuesCount * (aValuesCount - 1));
    }

    public static SampleSet make(final RandomNumber aRndmNmbr, final int aSize) {

        final double[] retVal = new double[aSize];

        for (int i = 0; i < retVal.length; i++) {
            retVal[i] = aRndmNmbr.doubleValue();
        }

        return new SampleSet(retVal);
    }

    /**
     * @return a SampleSet with one less item than in the series where
     * each sample is log(x<sub>i</sub>) with the first value omitted
     * (it is assumed to be 1.0).
     */
    public static SampleSet makeAssumingGeometricChanges(final BasicSeries<?, ?> aSeries) {
        return SampleSet.makeAssumingGeometricChanges(aSeries.getPrimitiveValues());
    }

    public static SampleSet makeAssumingGeometricChanges(final PrimitiveSeries aSeries) {
        return SampleSet.makeAssumingGeometricChanges(aSeries.values());
    }

    /**
     * @return a SampleSet with one less item than in the series
     * where each sample is x<sub>i+1</sub> - x<sub>i</sub>.
     */
    public static SampleSet makeUsingDifferences(final BasicSeries<?, ?> aSeries) {
        return SampleSet.makeUsingDifferences(aSeries.getPrimitiveValues());
    }

    /**
     * @return a SampleSet with one less item than in the series
     * where each sample is x<sub>i+1</sub> - x<sub>i</sub>.
     */
    public static SampleSet makeUsingDifferences(final PrimitiveSeries aSeries) {
        return SampleSet.makeUsingDifferences(aSeries.values());
    }

    /**
     * @return a SampleSet with one less item than in the series
     * where each sample is log(x<sub>i+1</sub>) - log(x<sub>i</sub>) or
     * log(x<sub>i+1</sub> / x<sub>i</sub>).
     */
    public static SampleSet makeUsingLogarithmicChanges(final BasicSeries<?, ?> aSeries) {
        return SampleSet.makeUsingLogarithmicChanges(aSeries.getPrimitiveValues());
    }

    /**
     * @return a SampleSet with one less item than in the series
     * where each sample is log(x<sub>i+1</sub>) - log(x<sub>i</sub>) or
     * log(x<sub>i+1</sub> / x<sub>i</sub>).
     */
    public static SampleSet makeUsingLogarithmicChanges(final PrimitiveSeries aSeries) {
        return SampleSet.makeUsingLogarithmicChanges(aSeries.values());
    }

    /**
     * @return a SampleSet with one less item than in the series
     * where each sample is x<sub>i+1</sub> / x<sub>i</sub>.
     */
    public static SampleSet makeUsingQuotients(final BasicSeries<?, ?> aSeries) {
        return SampleSet.makeUsingQuotients(aSeries.getPrimitiveValues());
    }

    /**
     * @return a SampleSet with one less item than in the series
     * where each sample is x<sub>i+1</sub> / x<sub>i</sub>.
     */
    public static SampleSet makeUsingQuotients(final PrimitiveSeries aSeries) {
        return SampleSet.makeUsingQuotients(aSeries.values());
    }

    static SampleSet makeAssumingGeometricChanges(final double[] someValues) {

        final int tmpSize = someValues.length - 1;

        final double[] retVal = new double[tmpSize];

        for (int i = 0; i < tmpSize; i++) {
            retVal[i] = Math.log(someValues[i + 1]);
        }

        return new SampleSet(retVal);
    }

    static SampleSet makeUsingDifferences(final double[] someValues) {

        final int tmpSize = someValues.length - 1;

        final double[] retVal = new double[tmpSize];

        for (int i = 0; i < tmpSize; i++) {
            retVal[i] = someValues[i + 1] - someValues[i];
        }

        return new SampleSet(retVal);
    }

    static SampleSet makeUsingLogarithmicChanges(final double[] someValues) {

        final int tmpSize = someValues.length - 1;

        final double[] retVal = new double[tmpSize];

        for (int i = 0; i < tmpSize; i++) {
            retVal[i] = Math.log(someValues[i + 1] / someValues[i]);
        }

        return new SampleSet(retVal);
    }

    static SampleSet makeUsingQuotients(final double[] someValues) {

        final int tmpSize = someValues.length - 1;

        final double[] retVal = new double[tmpSize];

        for (int i = 0; i < tmpSize; i++) {
            retVal[i] = someValues[i + 1] / someValues[i];
        }

        return new SampleSet(retVal);
    }

    private transient double myMean = Double.NaN;
    private transient double myMedian = Double.NaN;
    private final double[] myValues;
    private transient double myVariance = Double.NaN;

    public SampleSet(final Array1D<?> anArray) {

        super();

        myValues = anArray.toRawCopy();
    }

    public SampleSet(final BasicSeries<?, ?> aSeries) {

        super();

        myValues = aSeries.getPrimitiveValues();
    }

    public SampleSet(final PrimitiveSeries aSeries) {

        super();

        myValues = aSeries.values();
    }

    @SuppressWarnings("unused")
    private SampleSet() {

        super();

        myValues = new double[0];

        ProgrammingError.throwForIllegalInvocation();
    }

    SampleSet(final double[] someValues) {

        super();

        myValues = someValues;
    }

    public PrimitiveSeries asPrimitiveSeries() {
        return DataSeries.wrap(myValues);
    }

    public double getCorrelation(final SampleSet aSet) {

        double retVal = PrimitiveMath.ZERO;

        final double tmpCovar = this.getCovariance(aSet);

        if (tmpCovar != PrimitiveMath.ZERO) {

            final double tmpThisStdDev = this.getStandardDeviation();
            final double tmpThatStdDev = aSet.getStandardDeviation();

            retVal = tmpCovar / (tmpThisStdDev * tmpThatStdDev);
        }

        return retVal;
    }

    public double getCovariance(final SampleSet aSet) {

        double retVal = PrimitiveMath.ZERO;

        final double tmpThisMean = this.getMean();
        final double tmpThatMean = aSet.getMean();

        final int tmpCount = Math.min(myValues.length, aSet.size());

        final double[] tmpValues = aSet.getValues();

        for (int i = 0; i < tmpCount; i++) {
            retVal += (myValues[i] - tmpThisMean) * (tmpValues[i] - tmpThatMean);
        }

        retVal /= (tmpCount - 1);

        return retVal;
    }

    public double getFirst() {
        return myValues[0];
    }

    /**
     * max(abs(value))
     */
    public double getLargest() {

        double retVal = PrimitiveMath.ZERO;

        for (int i = 0; i < myValues.length; i++) {
            retVal = Math.max(retVal, Math.abs(myValues[i]));
        }

        return retVal;
    }

    public double getLast() {
        return myValues[myValues.length - 1];
    }

    /**
     * max(value)
     */
    public double getMaximum() {

        double retVal = PrimitiveMath.NEGATIVE_INFINITY;

        for (int i = 0; i < myValues.length; i++) {
            retVal = Math.max(retVal, myValues[i]);
        }

        return retVal;
    }

    public double getMean() {

        if (Double.isNaN(myMean)) {

            myMean = PrimitiveMath.ZERO;

            for (int i = 0; i < myValues.length; i++) {
                myMean += myValues[i];
            }

            myMean /= myValues.length;
        }

        return myMean;
    }

    public double getMedian() {

        if (Double.isNaN(myMedian)) {

            final double[] tmpCopy = ArrayUtils.copyOf(myValues);

            Arrays.sort(tmpCopy);

            myMedian = tmpCopy[myValues.length / 2];
        }

        return myMedian;
    }

    /**
     * min(value)
     */
    public double getMinimum() {

        double retVal = PrimitiveMath.POSITIVE_INFINITY;

        for (int i = 0; i < myValues.length; i++) {
            retVal = Math.min(retVal, myValues[i]);
        }

        return retVal;
    }

    /**
     * min(abs(value))
     */
    public double getSmallest() {

        double retVal = PrimitiveMath.POSITIVE_INFINITY;

        for (int i = 0; i < myValues.length; i++) {
            retVal = Math.min(retVal, Math.abs(myValues[i]));
        }

        return retVal;
    }

    public double getStandardDeviation() {
        return Math.sqrt(this.getVariance());
    }

    /**
     * <p>&quot;Sum of squares is a concept that permeates much of inferential
     * statistics and descriptive statistics. More properly, it is "the
     * sum of the squared deviations". Mathematically, it is an unscaled,
     * or unadjusted measure of dispersion (also called variability). When
     * scaled for the number of degrees of freedom, it estimates the variance,
     * or spread of the observations about their mean value.&quot;</p>
     * <a href="http://en.wikipedia.org/wiki/Sum_of_squares">Wikipedia</a>
     */
    public double getSumOfSquares() {

        double retVal = PrimitiveMath.ZERO;

        final double tmpMean = this.getMean();
        double tmpVal;
        for (int i = 0; i < myValues.length; i++) {
            tmpVal = myValues[i] - tmpMean;
            retVal += (tmpVal * tmpVal);
        }

        return retVal;
    }

    public double getVariance() {

        if (Double.isNaN(myVariance)) {
            myVariance = this.getCovariance(this);
        }

        return myVariance;
    }

    public int size() {
        return myValues.length;
    }

    @Override
    public String toString() {
        return "Sample set size: " + this.size() + ", Mean: " + this.getMean() + ", Variance: " + this.getVariance();
    }

    double[] getValues() {
        return myValues;
    }

}
