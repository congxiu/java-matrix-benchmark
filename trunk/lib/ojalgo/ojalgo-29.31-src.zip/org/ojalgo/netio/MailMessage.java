/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.netio;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import sun.net.smtp.SmtpClient;

/**
 * @author apete
 */
public class MailMessage {

    private static String BCC = "Bcc: ";
    private static String CC = "Cc: ";
    private static String FROM = "From: ";
    private static String NEW_LINE = "\n";
    private static String SEP = ", ";
    private static String SUBJECT = "Subject: ";
    private static String TO = "To: ";

    public static SmtpClient getClient(final String aServer) {

        SmtpClient retVal = null;

        try {
            retVal = new SmtpClient(aServer);
        } catch (final IOException anException) {
            anException.printStackTrace();
        }

        return retVal;
    }

    private final List<String> myBCC = new ArrayList<String>();
    private final List<String> myCC = new ArrayList<String>();
    private final SmtpClient myClient;
    private final StringBuilder myContents = new StringBuilder();
    private String mySender;
    private String mySubject;
    private final List<String> myTO = new ArrayList<String>();

    public MailMessage(final SmtpClient aClient) {

        super();

        myClient = aClient;
    }

    public MailMessage(final String aServer) {
        this(MailMessage.getClient(aServer));
    }

    @SuppressWarnings("unused")
    private MailMessage() {

        super();

        myClient = null;
    }

    public boolean addAddressee(final String anAddress) {
        return myTO.add(anAddress);
    }

    public boolean addCopyReceiver(final String anAddress) {
        return myCC.add(anAddress);
    }

    public boolean addHiddenCopyReceiver(final String anAddress) {
        return myBCC.add(anAddress);
    }

    public void appendContentLine(final String someStr) {
        myContents.append(someStr);
        myContents.append('\n');
    }

    public boolean send() {

        final String tmpMailString = this.buildMailString();

        try {

            myClient.from(mySender);

            myClient.to(this.buildToString());

            final PrintStream tmpStream = myClient.startMessage();

            tmpStream.print(tmpMailString);

            myClient.closeServer();

        } catch (final IOException anException) {
            anException.printStackTrace();
        }

        return false;
    }

    public void setSender(final String anAddress) {
        mySender = anAddress;
    }

    public void setSubject(final String newSubject) {
        mySubject = newSubject;
    }

    private String buildMailString() {

        final StringBuilder retVal = new StringBuilder();

        retVal.append(FROM);
        retVal.append(mySender);

        retVal.append(NEW_LINE);

        retVal.append(TO);
        for (final String tmpTO : myTO) {
            retVal.append(tmpTO);
            retVal.append(SEP);
        }

        retVal.append(NEW_LINE);

        retVal.append(CC);
        for (final String tmpCC : myCC) {
            retVal.append(tmpCC);
            retVal.append(SEP);
        }

        retVal.append(NEW_LINE);

        retVal.append(BCC);
        for (final String tmpBCC : myBCC) {
            retVal.append(tmpBCC);
            retVal.append(SEP);
        }

        retVal.append(NEW_LINE);

        retVal.append(SUBJECT);
        retVal.append(mySubject);

        retVal.append(NEW_LINE);

        retVal.append(myContents);

        return retVal.toString();
    }

    private String buildToString() {

        final List<String> tmpTotal = new ArrayList<String>();
        tmpTotal.addAll(myTO);
        tmpTotal.addAll(myCC);
        tmpTotal.addAll(myBCC);

        final StringBuilder retVal = new StringBuilder();

        for (final String tmpAddress : tmpTotal) {
            retVal.append(tmpAddress);
            retVal.append(SEP);
        }

        return retVal.toString();
    }

}
