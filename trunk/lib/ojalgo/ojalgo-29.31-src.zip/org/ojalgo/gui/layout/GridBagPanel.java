/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.gui.layout;

import java.awt.Component;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.LayoutManager;

import javax.swing.JPanel;

public abstract class GridBagPanel extends JPanel implements GridBagComponent {

    private final ConstraintsBuilder myConstraintsFactory = new ConstraintsBuilder();

    @SuppressWarnings("unused")
    private GridBagPanel(final boolean isDoubleBuffered) {
        super(isDoubleBuffered);
    }

    @SuppressWarnings("unused")
    private GridBagPanel(final LayoutManager aLayout) {
        super(aLayout);
    }

    @SuppressWarnings("unused")
    private GridBagPanel(final LayoutManager aLayout, final boolean isDoubleBuffered) {
        super(aLayout, isDoubleBuffered);
    }

    protected GridBagPanel(final int aRowDim, final int aColDim) {

        super(new GridBagLayout(), true);

        GridBagComponent.ConstraintsBuilder.initialiseLayout(this, aRowDim, aColDim, true);
    }

    protected GridBagPanel(final int[] someRowHeights, final int[] someColWidths) {

        super(new GridBagLayout(), true);

        GridBagComponent.ConstraintsBuilder.initialiseLayout(this, someRowHeights, someColWidths, true);
    }

    public void add(final Component aComponent, final int gridx, final int gridy) {
        this.add(aComponent, myConstraintsFactory.build(gridx, gridy));
    }

    public void add(final Component aComponent, final int gridx, final int gridy, final int gridwidth, final int gridheight) {
        this.add(aComponent, myConstraintsFactory.build(gridx, gridy, gridwidth, gridheight));
    }

    public GridBagPanel anchor(final int anchor) {
        myConstraintsFactory.anchor(anchor);
        return this;
    }

    public GridBagPanel fill(final int fill) {
        myConstraintsFactory.fill(fill);
        return this;
    }

    public GridBagLayout getGridBagLayout() {
        return (GridBagLayout) this.getLayout();
    }

    public GridBagPanel insets(final Insets insets) {
        myConstraintsFactory.insets(insets);
        return this;
    }

    public void makeColumnHeavyweight(final int aCol) {
        GridBagComponent.ConstraintsBuilder.makeColumnHeavyweight(this, aCol);
    }

    public void makeRowHeavyweight(final int aRow) {
        GridBagComponent.ConstraintsBuilder.makeRowHeavyweight(this, aRow);
    }

}
