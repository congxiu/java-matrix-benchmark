/* 
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
package org.ojalgo.series.primitive;

import java.util.Calendar;

import org.ojalgo.type.CalendarDateUnit;
import org.ojalgo.type.TimeFilter;

public final class ImplicitTimeSeries extends PrimitiveTimeSeries {

    private final TimeFilter myFilter;
    private final Calendar myFirst;
    private final PrimitiveSeries myValues;

    public ImplicitTimeSeries(final Calendar aFirst, final CalendarDateUnit aResolution, final PrimitiveSeries aSeries) {

        super();

        myFirst = aFirst;
        myFilter = new TimeFilter(aResolution);

        myValues = aSeries;
    }

    @Override
    public final ImplicitTimeSeries differences() {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.differences());
    }

    @Override
    public final Calendar first() {
        return myFirst;
    }

    @Override
    public final PrimitiveSeries getValueSeries() {
        return myValues;
    }

    @Override
    public final long[] keys() {

        final long[] retVal = new long[myValues.size()];

        Calendar tmpCal = myFirst;
        retVal[0] = tmpCal.getTimeInMillis();
        for (int t = 1; t < retVal.length; t++) {
            tmpCal = myFilter.step(tmpCal);
            retVal[t] = tmpCal.getTimeInMillis();
        }
        return retVal;
    }

    @Override
    public final Calendar last() {
        return myFilter.step(myFirst, this.size() - 1);
    }

    @Override
    public final ImplicitTimeSeries quotients() {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.quotients());
    }

    public final CalendarDateUnit resolution() {
        return myFilter.getResolution();
    }

    @Override
    public final ImplicitTimeSeries runningProduct() {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.runningProduct());
    }

    @Override
    public final ImplicitTimeSeries runningSum() {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.runningSum());
    }

    @Override
    public final ImplicitTimeSeries scale(final double aFactor) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.scale(aFactor));
    }

    public final int size() {
        return myValues.size();
    }

    @Override
    public final ImplicitTimeSeries superimpose(final PrimitiveSeries aSeries) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.superimpose(aSeries));
    }

    @Override
    public final double value(final int index) {
        return myValues.value(index);
    }

}
