package org.ojalgo.matrix.decomposition;

import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.concurrent.DaemonPoolExecutor;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PhysicalStore.Factory;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

abstract class SVDnew2<N extends Number & Comparable<N>> extends SingularValueDecomposition<N> {

    static final class Primitive extends SVDnew2<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY, new BidiagonalDecomposition.Primitive());
        }

        private void doCase1(final double[] s, final double[] e, final int p, final int k) {

            double f = e[p - 2];
            e[p - 2] = PrimitiveMath.ZERO;

            double t;
            double cs;
            double sn;

            for (int j = p - 2; j >= k; j--) {

                t = Math.hypot(s[j], f);
                cs = s[j] / t;
                sn = f / t;

                s[j] = t;
                if (j != k) {
                    f = -sn * e[j - 1];
                    e[j - 1] = cs * e[j - 1];
                }

                this.addQ2rotation(new Rotation<Double>(p - 1, j, cs, sn));
            }
        }

        private void doCase2(final double[] s, final double[] e, final int p, final int k) {

            double f = e[k - 1];
            e[k - 1] = PrimitiveMath.ZERO;

            double t;
            double cs;
            double sn;

            for (int j = k; j < p; j++) {

                t = Math.hypot(s[j], f);
                cs = s[j] / t;
                sn = f / t;

                s[j] = t;
                f = -sn * e[j];
                e[j] = cs * e[j];

                this.addQ1rotation(new Rotation<Double>(k - 1, j, cs, sn));
            }
        }

        private void doCase3(final double[] s, final double[] e, final int p, final int k) {

            final int indPm1 = p - 1;
            final int indPm2 = p - 2;

            // Calculate the shift.
            final double scale = Math.max(Math.max(Math.max(Math.max(Math.abs(s[indPm1]), Math.abs(s[indPm2])), Math.abs(e[indPm2])), Math.abs(s[k])), Math.abs(e[k]));

            final double sPm1 = s[indPm1] / scale;
            final double sPm2 = s[indPm2] / scale;
            final double ePm2 = e[indPm2] / scale;
            final double sK = s[k] / scale;
            final double eK = e[k] / scale;

            final double b = ((sPm2 + sPm1) * (sPm2 - sPm1) + ePm2 * ePm2) / PrimitiveMath.TWO;
            final double c = (sPm1 * ePm2) * (sPm1 * ePm2);

            double shift = PrimitiveMath.ZERO;
            if ((b != PrimitiveMath.ZERO) || (c != PrimitiveMath.ZERO)) {
                shift = Math.sqrt(b * b + c);
                if (b < PrimitiveMath.ZERO) {
                    shift = -shift;
                }
                shift = c / (b + shift);
            }

            double f = (sK + sPm1) * (sK - sPm1) + shift;
            double g = sK * eK;

            double t;
            double cs;
            double sn;

            // Chase zeros.
            for (int j = k; j < indPm1; j++) {

                t = Math.hypot(f, g);
                cs = f / t;
                sn = g / t;
                if (j != k) {
                    e[j - 1] = t;
                }
                f = cs * s[j] + sn * e[j];
                e[j] = cs * e[j] - sn * s[j];
                g = sn * s[j + 1];
                s[j + 1] = cs * s[j + 1];

                this.addQ2rotation(new Rotation<Double>(j + 1, j, cs, sn));

                t = Math.hypot(f, g);
                cs = f / t;
                sn = g / t;
                s[j] = t;
                f = cs * e[j] + sn * s[j + 1];
                s[j + 1] = -sn * e[j] + cs * s[j + 1];
                g = sn * e[j + 1];
                e[j + 1] = cs * e[j + 1];

                this.addQ1rotation(new Rotation<Double>(j + 1, j, cs, sn));
            }

            e[indPm2] = f;
        }

        private void doCase4(final double[] s, final int k) {

            final int tmpDiagDim = s.length;

            // Make the singular values positive.
            final double tmpSk = s[k];
            if (tmpSk < PrimitiveMath.ZERO) {
                s[k] = -tmpSk;
                this.addQ2rotation(new Rotation<Double>(k, k, null, null));
            } else if (tmpSk == PrimitiveMath.ZERO) {
                s[k] = PrimitiveMath.ZERO; // To get rid of negative zeros
            }

            // Order the singular values.
            int tmpK = k;

            while (tmpK < (tmpDiagDim - 1)) {
                if (s[tmpK] >= s[tmpK + 1]) {
                    break;
                }
                final double t = s[tmpK];
                s[tmpK] = s[tmpK + 1];
                s[tmpK + 1] = t;

                this.addQ1rotation(new Rotation<Double>(tmpK + 1, tmpK, null, null));
                this.addQ2rotation(new Rotation<Double>(tmpK + 1, tmpK, null, null));

                tmpK++;
            }
        }

        @Override
        Array1D<Double> compute(final Array1D<Double> mainDiagonal, final Array1D<Double> offDiagonal) {

            final int tmpDiagDim = mainDiagonal.length;

            final double[] s = mainDiagonal.toRawCopy(); // s
            final double[] e = new double[tmpDiagDim]; // e
            final int tmpOffLength = offDiagonal.length;
            for (int i = 0; i < tmpOffLength; i++) {
                e[i] = offDiagonal.doubleValue(i);
            }

            // Main iteration loop for the singular values.
            int kase;
            int k;
            int p = tmpDiagDim;
            while (p > 0) {

                //
                // This section of the program inspects for negligible elements in the s and e arrays.
                // On completion the variables kase and k are set as follows:
                //
                // kase = 1     if s[p] and e[k-1] are negligible and k<p                           => deflate negligible s[p]
                // kase = 2     if s[k] is negligible and k<p                                       => split at negligible s[k]
                // kase = 3     if e[k-1] is negligible, k<p, and s(k)...s(p) are not negligible    => perform QR-step
                // kase = 4     if e[p-1] is negligible                                             => convergence.
                //

                kase = 0;
                k = 0;

                for (k = p - 2; k >= -1; k--) {
                    if (k == -1) {
                        break;
                    }
                    if (Math.abs(e[k]) <= PrimitiveMath.MACHINE_DOUBLE_ERROR * (Math.abs(s[k]) + Math.abs(s[k + 1]))) {
                        e[k] = PrimitiveMath.ZERO;
                        break;
                    }
                }
                if (k == p - 2) {
                    kase = 4;
                } else {
                    int ks;
                    for (ks = p - 1; ks >= k; ks--) {
                        if (ks == k) {
                            break;
                        }
                        final double t = (ks != p ? Math.abs(e[ks]) : PrimitiveMath.ZERO) + (ks != k + 1 ? Math.abs(e[ks - 1]) : PrimitiveMath.ZERO);
                        if (Math.abs(s[ks]) <= PrimitiveMath.MACHINE_DOUBLE_ERROR * t) {
                            s[ks] = PrimitiveMath.ZERO;
                            break;
                        }
                    }
                    if (ks == k) {
                        kase = 3;
                    } else if (ks == p - 1) {
                        kase = 1;
                    } else {
                        kase = 2;
                        k = ks;
                    }
                }
                k++;

                switch (kase) { // Perform the task indicated by kase.

                case 1: // Deflate negligible s[p]

                    this.doCase1(s, e, p, k);
                    break;

                case 2: // Split at negligible s[k]

                    this.doCase2(s, e, p, k);
                    break;

                case 3: // Perform QR-step.

                    this.doCase3(s, e, p, k);
                    break;

                case 4: // Convergence

                    this.doCase4(s, k);
                    p--;
                    break;

                default:

                    throw new IllegalStateException();

                } // switch
            } // while

            return Array1D.wrapPrimitive(s);
        }
    }

    private transient MatrixStore<N> myD;

    private Array1D<Double> mySingularValues;

    private transient Future<MatrixStore<N>> myFutureQ1;
    private transient Future<MatrixStore<N>> myFutureQ2;

    private final ArrayList<Rotation<N>> myRotationsQ1 = new ArrayList<Rotation<N>>();
    private final ArrayList<Rotation<N>> myRotationsQ2 = new ArrayList<Rotation<N>>();

    protected SVDnew2(final Factory<N> aFactory, final BidiagonalDecomposition<N> aBidiagonal) {
        super(aFactory, aBidiagonal);
    }

    public boolean compute(final Access2D<N> aMtrx) {

        this.reset();

        this.computeBidiagonal(aMtrx);

        final boolean tmpAspectRatioNormal = this.isAspectRatioNormal();

        final DiagonalAccess<N> tmpBidiagonal = this.getBidiagonalAccessD();

        if (tmpAspectRatioNormal) {
            mySingularValues = this.compute(tmpBidiagonal.mainDiagonal, tmpBidiagonal.superdiagonal);
        } else {
            mySingularValues = this.compute(tmpBidiagonal.mainDiagonal, tmpBidiagonal.subdiagonal);
        }

        return this.computed(true);
    }

    public boolean equals(final MatrixStore<N> aMtrx, final NumberContext aCntxt) {
        return MatrixUtils.equals(aMtrx, this, TypeUtils.EQUALS_NUMBER_CONTEXT);
    }

    public final MatrixStore<N> getD() {
        if (myD == null) {
            myD = this.makeD();
        }
        return myD;
    }

    public Array1D<Double> getSingularValues() {
        return mySingularValues;
    }

    public boolean isFullSize() {
        return false;
    }

    public boolean isOrdered() {
        return true;
    }

    public boolean isSolvable() {
        return this.isComputed();
    }

    @Override
    public void reset() {

        super.reset();

        mySingularValues = null;

        myD = null;
        myFutureQ1 = null;
        myFutureQ2 = null;

        myRotationsQ1.clear();
        myRotationsQ2.clear();
    }

    @Override
    public final MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        return this.getInverse().multiplyRight(aRHS);
    }

    private final void setupQ1andQ2calculations() {

        myFutureQ1 = DaemonPoolExecutor.INSTANCE.submit(new Callable<MatrixStore<N>>() {

            public MatrixStore<N> call() throws Exception {

                final PhysicalStore<N> retVal = SVDnew2.this.getBidiagonalQ1();

                if (SVDnew2.this.isAspectRatioNormal()) {
                    for (final Rotation<N> tmpRot : myRotationsQ1) {
                        retVal.transformRight(tmpRot);
                    }
                } else {
                    for (final Rotation<N> tmpRot : myRotationsQ2) {
                        retVal.transformRight(tmpRot);
                    }
                }

                return retVal;
            }
        });

        myFutureQ2 = DaemonPoolExecutor.INSTANCE.submit(new Callable<MatrixStore<N>>() {

            public MatrixStore<N> call() throws Exception {

                final PhysicalStore<N> retVal = SVDnew2.this.getBidiagonalQ2();

                if (SVDnew2.this.isAspectRatioNormal()) {
                    for (final Rotation<N> tmpRot : myRotationsQ2) {
                        retVal.transformRight(tmpRot);
                    }
                } else {
                    for (final Rotation<N> tmpRot : myRotationsQ1) {
                        retVal.transformRight(tmpRot);
                    }
                }

                return retVal;
            }

        });

    }

    protected final boolean isTransposed() {
        return !this.isAspectRatioNormal();
    }

    final boolean addQ1rotation(final Rotation<N> aRotation) {
        return myRotationsQ1.add(aRotation);
    }

    final boolean addQ2rotation(final Rotation<N> aRotation) {
        return myRotationsQ2.add(aRotation);
    }

    abstract Array1D<Double> compute(Array1D<N> mainDiagonal, Array1D<N> offDiagonal);

    final MatrixStore<N> makeD() {

        final int tmpLength = mySingularValues.length;

        final PhysicalStore<N> retVal = this.makeZero(tmpLength, tmpLength);

        for (int ij = 0; ij < tmpLength; ij++) {
            retVal.set(ij, ij, mySingularValues.get(ij));
        }

        return retVal;
    }

    @Override
    final MatrixStore<N> makeQ1() {

        if (myFutureQ1 == null) {
            this.setupQ1andQ2calculations();
        }

        try {
            return myFutureQ1.get();
        } catch (final InterruptedException anException) {
            anException.printStackTrace();
            return null;
        } catch (final ExecutionException anException) {
            anException.printStackTrace();
            return null;
        }
    }

    @Override
    final MatrixStore<N> makeQ2() {

        if (myFutureQ2 == null) {
            this.setupQ1andQ2calculations();
        }

        try {
            return myFutureQ2.get();
        } catch (final InterruptedException anException) {
            anException.printStackTrace();
            return null;
        } catch (final ExecutionException anException) {
            anException.printStackTrace();
            return null;
        }
    }

}
