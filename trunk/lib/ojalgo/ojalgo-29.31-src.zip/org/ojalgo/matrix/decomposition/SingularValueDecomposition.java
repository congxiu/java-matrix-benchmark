/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.jama.JamaSingularValue;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PhysicalStore.Factory;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.TypeUtils;

/**
 * SingularValueDecomposition
 * 
 *
 * @author apete
 */
public abstract class SingularValueDecomposition<N extends Number & Comparable<N>> extends AbstractDecomposition<N> implements SingularValue<N> {

    @SuppressWarnings("unchecked")
    public static final SingularValue<Double>[] getAllPrimitiveImplementations() {
        return (SingularValue<Double>[]) new SingularValue<?>[] { new JamaSingularValue(), new SVDold2.Primitive(), new SVDnew2.Primitive() };
    }

    public static final SingularValue<Double> makeAlternative() {
        return new SVDold2.Primitive();
    }

    public static final SingularValue<BigDecimal> makeBig() {
        return new SVDold2.Big();
    }

    public static final SingularValue<ComplexNumber> makeComplex() {
        return new SVDold2.Complex();
    }

    public static final SingularValue<Double> makeJama() {
        return new JamaSingularValue();
    }

    public static final SingularValue<Double> makePrimitive() {
        return new SVDnew2.Primitive();
    }

    private final BidiagonalDecomposition<N> myBidiagonal;

    private transient MatrixStore<N> myQ1;
    private transient MatrixStore<N> myQ2;

    @SuppressWarnings("unused")
    private SingularValueDecomposition(final Factory<N> aFactory) {
        this(aFactory, null);
    }

    protected SingularValueDecomposition(final Factory<N> aFactory, final BidiagonalDecomposition<N> aBidiagonal) {

        super(aFactory);

        myBidiagonal = aBidiagonal;
    }

    public final double getCondition() {

        final Array1D<Double> tmpSingularValues = this.getSingularValues();

        return tmpSingularValues.doubleValue(0) / tmpSingularValues.doubleValue(tmpSingularValues.length - 1);
    }

    public final double getFrobeniusNorm() {

        double retVal = PrimitiveMath.ZERO;

        final Array1D<Double> tmpSingularValues = this.getSingularValues();
        double tmpVal;

        for (int i = tmpSingularValues.size() - 1; i >= 0; i--) {
            tmpVal = tmpSingularValues.doubleValue(i);
            retVal += tmpVal * tmpVal;
        }

        return Math.sqrt(retVal);
    }

    public final double getKyFanNorm(final int k) {

        final Array1D<Double> tmpSingularValues = this.getSingularValues();

        double retVal = PrimitiveMath.ZERO;

        for (int i = Math.min(tmpSingularValues.size(), k) - 1; i >= 0; i--) {
            retVal += tmpSingularValues.doubleValue(i);
        }

        return retVal;
    }

    public final double getOperatorNorm() {
        return this.getSingularValues().doubleValue(0);
    }

    public final MatrixStore<N> getQ1() {
        if (myQ1 == null) {
            myQ1 = this.makeQ1();
        }
        return myQ1;
    }

    public final MatrixStore<N> getQ2() {
        if (myQ2 == null) {
            myQ2 = this.makeQ2();
        }
        return myQ2;
    }

    public final int getRank() {

        final Array1D<Double> tmpSingularValues = this.getSingularValues();
        int retVal = tmpSingularValues.length;

        // Tolerance based on min-dim but should be max-dim
        final double tmpTolerance = retVal * tmpSingularValues.doubleValue(0) * PrimitiveMath.MACHINE_DOUBLE_ERROR;

        for (int i = retVal - 1; i >= 0; i--) {
            if (TypeUtils.isZero(tmpSingularValues.doubleValue(i), tmpTolerance)) {
                retVal--;
            } else {
                return retVal;
            }
        }

        return retVal;
    }

    public final double getTraceNorm() {
        return this.getKyFanNorm(this.getSingularValues().length);
    }

    @Override
    public final boolean isAspectRatioNormal() {
        return super.aspectRatioNormal(myBidiagonal.isAspectRatioNormal());
    }

    public MatrixStore<N> reconstruct() {
        return MatrixUtils.reconstruct(this);
    }

    @Override
    public void reset() {

        super.reset();

        myBidiagonal.reset();

        myQ1 = null;
        myQ2 = null;
    }

    protected final boolean computeBidiagonal(final Access2D<N> aStore) {
        return myBidiagonal.compute(aStore);
    }

    protected final DiagonalAccess<N> getBidiagonalAccessD() {
        return myBidiagonal.getDiagonalAccessD();
    }

    protected final PhysicalStore<N> getBidiagonalQ1() {
        return (PhysicalStore<N>) myBidiagonal.getQ1();
    }

    protected final PhysicalStore<N> getBidiagonalQ2() {
        return (PhysicalStore<N>) myBidiagonal.getQ2();
    }

    @Override
    final MatrixStore<N> makeInverse() {

        final MatrixStore<N> tmpQ1 = this.getQ1();
        final MatrixStore<N> tmpD = this.getD();

        final int tmpRowDim = tmpD.getRowDim();
        final int tmpColDim = tmpQ1.getRowDim();

        final PhysicalStore<N> tmpMtrx = this.makeEmpty(tmpRowDim, tmpColDim);

        final N tmpZero = this.getStaticZero();

        N tmpSingularValue;
        for (int i = 0; i < tmpRowDim; i++) {
            if (tmpD.isZero(i, i)) {
                tmpMtrx.fillRow(i, 0, tmpZero);
            } else {
                tmpSingularValue = tmpD.get(i, i);
                for (int j = 0; j < tmpColDim; j++) {
                    tmpMtrx.set(i, j, tmpQ1.toScalar(j, i).divide(tmpSingularValue).getNumber());
                }
            }
        }

        return tmpMtrx.multiplyLeft(this.getQ2());
    }

    abstract MatrixStore<N> makeQ1();

    abstract MatrixStore<N> makeQ2();

}
