/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.PreconfiguredSecond;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.ComplexAggregator;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.PhysicalStore.Factory;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

public abstract class SymmetricEvD1<N extends Number> extends EigenvalueDecomposition<N> {

    /** Eigenvalues and eigenvectors of a real matrix. 
     <P>
     If A is symmetric, then A = V*D*V' where the eigenvalue matrix D is
     diagonal and the eigenvector matrix V is orthogonal.
     I.e. A = V.times(D.times(V.transpose())) and 
     V.times(V.transpose()) equals the identity matrix.
     <P>
     If A is not symmetric, then the eigenvalue matrix D is block diagonal
     with the real eigenvalues in 1-by-1 blocks and any complex eigenvalues,
     lambda + i*mu, in 2-by-2 blocks, [lambda, mu; -mu, lambda].  The
     columns of V represent the eigenvectors in the sense that A*V = V*D,
     i.e. A.times(V) equals V.times(D).  The matrix V may be badly
     conditioned, or even singular, so the validity of the equation
     A = V*D*inverse(V) depends upon V.cond().
     **/
    static final class Primitive extends SymmetricEvD1<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

        @Override
        protected TridiagonalDecomposition<Double> getTridiagonalDelegate() {
            return new TridiagonalDecomposition.Primitive();
        }

        @Override
        protected DiagonalAccess<Double> toDiagonal(final DiagonalAccess<Double> aTridiagonal, final PhysicalStore<Double> aV) {

            final double[] tmpMainDiagonal = aTridiagonal.mainDiagonal.toRawCopy();

            final int tmpDim = tmpMainDiagonal.length;
            final int tmpLim = tmpDim - 1;

            final double[] tmpOffDiagonal = new double[tmpDim];
            final Array1D<Double> tmpSuperdiagonal = aTridiagonal.superdiagonal;
            for (int i = 0; i < tmpLim; i++) {
                tmpOffDiagonal[i] = tmpSuperdiagonal.doubleValue(i);
            }

            //                BasicLogger.logDebug("BEGIN diagonalize");
            //                BasicLogger.logDebug("Main D: {}", Arrays.toString(tmpMainDiagonal));
            //                BasicLogger.logDebug("Seco D: {}", Arrays.toString(tmpOffDiagonal));
            //                BasicLogger.logDebug("V", aV);
            //                BasicLogger.logDebug();

            double tmpShift = PrimitiveMath.ZERO;
            double tmpShiftIncr;

            double tmpMagnitude = PrimitiveMath.ZERO;
            double tmpLocalEpsilon;

            int m;
            // Main loop
            for (int l = 0; l < tmpDim; l++) {

                //  EigenvalueDecomposition.log("Loop l=" + l, tmpMainDiagonal, tmpOffDiagonal);

                // Find small subdiagonal element
                tmpMagnitude = Math.max(tmpMagnitude, Math.abs(tmpMainDiagonal[l]) + Math.abs(tmpOffDiagonal[l]));
                tmpLocalEpsilon = PrimitiveMath.MACHINE_DOUBLE_ERROR * tmpMagnitude;

                m = l;
                while (m < tmpDim) {
                    if (Math.abs(tmpOffDiagonal[m]) <= tmpLocalEpsilon) {
                        break;
                    }
                    m++;
                }

                // If m == l, aMainDiagonal[l] is an eigenvalue, otherwise, iterate.
                if (m > l) {

                    do {

                        final double tmp1Ml0 = tmpMainDiagonal[l];
                        final double tmp1Ml1 = tmpMainDiagonal[l + 1];
                        final double tmp1Sl0 = tmpOffDiagonal[l];

                        // Compute implicit shift

                        double p = (tmp1Ml1 - tmp1Ml0) / (tmp1Sl0 + tmp1Sl0);
                        double r = Math.hypot(p, PrimitiveMath.ONE);
                        if (p < 0) {
                            r = -r;
                        }

                        final double tmp2Ml0 = tmpMainDiagonal[l] = tmp1Sl0 / (p + r);
                        final double tmp2Ml1 = tmpMainDiagonal[l + 1] = tmp1Sl0 * (p + r);
                        final double tmp2Sl1 = tmpOffDiagonal[l + 1];

                        tmpShiftIncr = tmp1Ml0 - tmp2Ml0;
                        for (int i = l + 2; i < tmpDim; i++) {
                            tmpMainDiagonal[i] -= tmpShiftIncr;
                        }
                        tmpShift += tmpShiftIncr;

                        //     EigenvalueDecomposition.log("New shift =" + tmpShift, tmpMainDiagonal, tmpOffDiagonal);

                        // Implicit QL transformation

                        double tmpRotCos = PrimitiveMath.ONE;
                        double tmpRotSin = PrimitiveMath.ZERO;

                        double tmpRotCos2 = tmpRotCos;
                        double tmpRotSin2 = PrimitiveMath.ZERO;

                        double tmpRotCos3 = tmpRotCos;

                        p = tmpMainDiagonal[m]; // Initiate p
                        for (int i = m - 1; i >= l; i--) {

                            final double tmp1Mi0 = tmpMainDiagonal[i];
                            final double tmp1Si0 = tmpOffDiagonal[i];

                            r = Math.hypot(p, tmp1Si0);

                            tmpRotCos3 = tmpRotCos2;

                            tmpRotCos2 = tmpRotCos;
                            tmpRotSin2 = tmpRotSin;

                            tmpRotCos = p / r;
                            tmpRotSin = tmp1Si0 / r;

                            tmpMainDiagonal[i + 1] = tmpRotCos2 * p + tmpRotSin * (tmpRotCos * tmpRotCos2 * tmp1Si0 + tmpRotSin * tmp1Mi0);
                            tmpOffDiagonal[i + 1] = tmpRotSin2 * r;

                            p = tmpRotCos * tmp1Mi0 - tmpRotSin * tmpRotCos2 * tmp1Si0; // Next p

                            // Accumulate transformation - rotate the eigenvector matrix
                            aV.transformRight(new Rotation<Double>(i, i + 1, tmpRotCos, tmpRotSin));

                            //          EigenvalueDecomposition.log("QL step done i=" + i, tmpMainDiagonal, tmpOffDiagonal);

                        }

                        p = -tmpRotSin * tmpRotSin2 * tmpRotCos3 * tmp2Sl1 * tmpOffDiagonal[l] / tmp2Ml1; // Final p

                        tmpMainDiagonal[l] = tmpRotCos * p;
                        tmpOffDiagonal[l] = tmpRotSin * p;

                    } while (Math.abs(tmpOffDiagonal[l]) > tmpLocalEpsilon); // Check for convergence
                } // End if (m > l)

                final double tmpEigenvalue = tmpMainDiagonal[l] + tmpShift;
                if (TypeUtils.isZero(tmpEigenvalue)) {
                    tmpMainDiagonal[l] = PrimitiveMath.ZERO;
                } else {
                    tmpMainDiagonal[l] = tmpEigenvalue;
                }
                tmpOffDiagonal[l] = PrimitiveMath.ZERO;
            } // End main loop - l

            //                BasicLogger.logDebug("END diagonalize");
            //                BasicLogger.logDebug("Main D: {}", Arrays.toString(tmpMainDiagonal));
            //                BasicLogger.logDebug("Seco D: {}", Arrays.toString(tmpOffDiagonal));
            //                BasicLogger.logDebug("V", aV);
            //                BasicLogger.logDebug();

            return DiagonalAccess.makePrimitive(Array1D.wrapPrimitive(tmpMainDiagonal), null, null);
        }

    }

    private MatrixStore<N> myD = null;
    private Array1D<ComplexNumber> myEigenvalues = null;
    private MatrixStore<N> myV = null;

    protected SymmetricEvD1(final Factory<N> aFactory) {
        super(aFactory);
    }

    /**
     * Will check for symmetry and then call either
     * {@link #computeSymmetric(Access2D)}
     * or
     * {@link #computeNonsymmetric(Access2D)}.
     * 
     * @see org.ojalgo.matrix.decomposition.MatrixDecomposition#compute(Access2D)
     */
    public final boolean compute(final Access2D<N> aMtrx) {
        return this.computeSymmetric(aMtrx);
    }

    public boolean computeNonsymmetric(final Access2D<N> aNonsymmetric) {
        throw new UnsupportedOperationException();
    }

    public boolean computeSymmetric(final Access2D<N> aSymmetric) {

        final TridiagonalDecomposition<N> tmpDelegate = this.getTridiagonalDelegate();
        tmpDelegate.compute(aSymmetric);

        return this.compute3D(tmpDelegate.getDiagonalAccessD(), tmpDelegate.getPhysicalQ());
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public final MatrixStore<N> getD() {
        return myD;
    }

    public final ComplexNumber getDeterminant() {

        final AggregatorFunction<ComplexNumber> tmpVisitor = ComplexAggregator.getCollection().product();

        this.getEigenvalues().visitAll(tmpVisitor);

        return tmpVisitor.getNumber();
    }

    public final Array1D<ComplexNumber> getEigenvalues() {
        return myEigenvalues;
    }

    public final ComplexNumber getTrace() {

        final AggregatorFunction<ComplexNumber> tmpVisitor = ComplexAggregator.getCollection().sum();

        this.getEigenvalues().visitAll(tmpVisitor);

        return tmpVisitor.getNumber();
    }

    public final MatrixStore<N> getV() {
        return myV;
    }

    public final boolean isFullSize() {
        return true;
    }

    public final boolean isOrdered() {
        return true;
    }

    public final boolean isSolvable() {
        return this.isComputed() && this.isSymmetric();
    }

    public final boolean isSymmetric() {
        return true;
    }

    @Override
    public void reset() {

        super.reset();

        myD = null;
        myEigenvalues = null;
        myV = null;
    }

    @Override
    public final MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        return this.getInverse().multiplyRight(aRHS);
    }

    private final boolean compute3D(final DiagonalAccess<N> aTridiagonal, final PhysicalStore<N> aV) {

        final int tmpDim = aTridiagonal.getMinDim();

        final DiagonalAccess<N> tmpDiagonal = this.toDiagonal(aTridiagonal, aV);
        final Array1D<N> tmpMainDiagonal = tmpDiagonal.mainDiagonal;
        this.sort(tmpMainDiagonal, aV);

        final Array1D<ComplexNumber> tmpEigenvalues = Array1D.makeComplex(tmpDim);
        final PhysicalStore<N> tmpD = this.makeZero(tmpDim, tmpDim);

        N tmpDiagonalElement;
        for (int ij = 0; ij < tmpDim; ij++) {
            tmpDiagonalElement = tmpMainDiagonal.get(ij);
            tmpEigenvalues.set(ij, TypeUtils.toComplexNumber(tmpDiagonalElement));
            tmpD.set(ij, ij, tmpDiagonalElement);
        }

        this.setEigenvalues(tmpEigenvalues);
        this.setD(tmpD);
        this.setV(aV);

        return this.computed(true);
    }

    protected abstract TridiagonalDecomposition<N> getTridiagonalDelegate();

    protected final void setD(final MatrixStore<N> aD) {
        myD = aD;
    }

    protected final void setEigenvalues(final Array1D<ComplexNumber> anEigenvalues) {
        myEigenvalues = anEigenvalues;
    }

    protected final void setV(final MatrixStore<N> aV) {
        myV = aV;
    }

    protected final void sort(final Array1D<N> eigenvalues, final PhysicalStore<N> eigenvectors) {

        final int tmpDim = eigenvalues.length;
        final int tmpLim = tmpDim - 1;

        for (int j1 = 0; j1 < tmpLim; j1++) {

            double tmpValue = eigenvalues.doubleValue(j1);
            int j2 = j1;

            for (int ij = j1 + 1; ij < tmpDim; ij++) {

                if (Math.abs(eigenvalues.doubleValue(ij)) > Math.abs(tmpValue)) {

                    tmpValue = eigenvalues.doubleValue(ij);
                    j2 = ij;
                }
            }

            if (j2 != j1) {
                eigenvalues.set(j2, eigenvalues.doubleValue(j1));
                eigenvalues.set(j1, tmpValue);
                eigenvectors.exchangeColumns(j1, j2);
            }
        }
    }

    protected abstract DiagonalAccess<N> toDiagonal(final DiagonalAccess<N> aTridiagonalSymmetric, final PhysicalStore<N> aMtrxV);

    boolean computeTridiagonal(final DiagonalAccess<N> aTridiagonal) {

        final int tmpDim = aTridiagonal.getRowDim();

        final PhysicalStore<N> tmpMtrxV = this.makeEye(tmpDim, tmpDim);

        return this.compute3D(aTridiagonal, tmpMtrxV);
    }

    @Override
    final MatrixStore<N> makeInverse() {

        final MatrixStore<N> tmpV = this.getV();
        final MatrixStore<N> tmpD = this.getD();

        final int tmpDim = tmpD.getRowDim();

        final PhysicalStore<N> tmpMtrx = tmpV.transpose();

        final N tmpZero = this.getStaticZero();
        final BinaryFunction<N> tmpDivide = this.getFunctionSet().divide();

        for (int i = 0; i < tmpDim; i++) {
            if (tmpD.isZero(i, i)) {
                tmpMtrx.fillRow(i, 0, tmpZero);
            } else {
                tmpMtrx.modifyRow(i, 0, new PreconfiguredSecond<N>(tmpDivide, tmpD.get(i, i)));
            }
        }

        return tmpMtrx.multiplyLeft(tmpV);
    }

}
