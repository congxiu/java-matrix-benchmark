/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.context.NumberContext;

public abstract class TridiagonalDecomposition<N extends Number> extends InPlaceDecomposition<N> implements Tridiagonal<N> {

    static final class Big extends TridiagonalDecomposition<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }
    }

    static final class Complex extends TridiagonalDecomposition<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }
    }

    static final class Primitive extends TridiagonalDecomposition<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }
    }

    public static final Tridiagonal<BigDecimal> makeBig() {
        return new TridiagonalDecomposition.Big();
    }

    public static final Tridiagonal<ComplexNumber> makeComplex() {
        return new TridiagonalDecomposition.Complex();
    }

    public static final Tridiagonal<Double> makePrimitive() {
        return new TridiagonalDecomposition.Primitive();
    }

    protected TridiagonalDecomposition(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public final boolean compute(final Access2D<N> aStore) {

        this.setInPlace(aStore).computeInPlaceTridiagonal();

        return this.computed(true);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(this.reconstruct(), aStore, aCntxt);
    }

    public final MatrixStore<N> getD() {
        return this.wrap(this.getDiagonalAccessD());
    }

    public final MatrixStore<N> getQ() {
        return this.getPhysicalQ();
    }

    public final List<Householder<N>> getTransformations() {

        final DecompositionStore<N> tmpStore = this.getInPlace();
        final int tmpLength = tmpStore.getMinDim() - 2;

        final ArrayList<Householder<N>> retVal = new ArrayList<Householder<N>>(tmpLength);

        final DecompositionStore.HouseholderReference<N> tmpReference = new DecompositionStore.HouseholderReference<N>(tmpStore, true);
        for (int ij = 0; ij < tmpLength; ij++) {
            tmpReference.row = ij + 1;
            tmpReference.col = ij;
            retVal.add(tmpReference.extract());
        }

        return retVal;
    }

    public final boolean isFullSize() {
        return true;
    }

    public final boolean isSolvable() {
        return this.isComputed();
    }

    public MatrixStore<N> reconstruct() {
        return MatrixUtils.reconstruct(this);
    }

    @Override
    public final MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        throw new UnsupportedOperationException();
    }

    final DiagonalAccess<N> getDiagonalAccessD() {

        final Array2D<N> tmpArray2D = this.getInPlace().asArray2D();

        final Array1D<N> tmpMain = tmpArray2D.sliceDiagonal(0, 0);
        final Array1D<N> tmpSub = tmpArray2D.sliceDiagonal(1, 0);

        return new DiagonalAccess<N>(tmpMain, tmpSub, tmpSub, this.getStaticZero());
    }

    final DecompositionStore<N> getPhysicalQ() {

        final DecompositionStore<N> tmpStore = this.getInPlace();
        final int tmpDim = tmpStore.getMinDim();

        final DecompositionStore<N> retVal = this.makeEye(tmpDim, tmpDim);

        final DecompositionStore.HouseholderReference<N> tmpHouseholderReference = new DecompositionStore.HouseholderReference<N>(tmpStore);

        for (int ij = tmpDim - 3; ij >= 0; ij--) {
            tmpHouseholderReference.row = ij + 1;
            tmpHouseholderReference.col = ij;
            retVal.transformLeft(tmpHouseholderReference, ij);
        }

        return retVal;
    }

}
