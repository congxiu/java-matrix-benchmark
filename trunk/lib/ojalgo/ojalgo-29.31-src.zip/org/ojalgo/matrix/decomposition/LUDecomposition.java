/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.access.Access2D;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.jama.JamaLU;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.LowerTriangularStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.SelectedRowsStore;
import org.ojalgo.matrix.store.UpperTriangularStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.context.NumberContext;

public abstract class LUDecomposition<N extends Number> extends InPlaceDecomposition<N> implements LU<N> {

    public static final class Pivot {

        private final int[] myOrder;
        private int mySign;
        private boolean myModified = false;

        public Pivot(final int aRowDim) {

            super();

            myOrder = MatrixUtils.makeIncreasingRange(0, aRowDim);
            mySign = 1;
        }

        public void change(final int aRow1, final int aRow2) {

            if (aRow1 != aRow2) {

                final int temp = myOrder[aRow1];
                myOrder[aRow1] = myOrder[aRow2];
                myOrder[aRow2] = temp;

                mySign = -mySign;

                myModified = true;

            } else {
                // Why?!
            }
        }

        public int[] getOrder() {
            return myOrder;
        }

        public final boolean isModified() {
            return myModified;
        }

        public int signum() {
            return mySign;
        }

    }

    static final class Big extends LUDecomposition<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

    }

    static final class Complex extends LUDecomposition<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

    }

    static final class Primitive extends LUDecomposition<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

    }

    public static final LU<BigDecimal> makeBig() {
        return new Big();
    }

    public static final LU<ComplexNumber> makeComplex() {
        return new Complex();
    }

    public static final LU<Double> makeJama() {
        return new JamaLU();
    }

    public static final LU<Double> makePrimitive() {
        return new Primitive();
    }

    private Pivot myPivot;

    protected LUDecomposition(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public boolean compute(final Access2D<N> aStore) {
        return this.compute(aStore, false);
    }

    public boolean computeWithoutPivoting(final MatrixStore<N> aStore) {
        return this.compute(aStore, true);
    }

    public boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public N getDeterminant() {

        final AggregatorFunction<N> tmpAggrFunc = this.getAggregatorCollection().product();

        this.getInPlace().visitDiagonal(0, 0, tmpAggrFunc);

        if (myPivot.signum() == -1) {
            return tmpAggrFunc.toScalar().negate().getNumber();
        } else {
            return tmpAggrFunc.getNumber();
        }
    }

    public MatrixStore<N> getL() {
        return new LowerTriangularStore<N>(this.getInPlace(), true);
    }

    public int[] getPivotOrder() {
        return myPivot.getOrder();
    }

    public int getRank() {

        int retVal = 0;

        final DecompositionStore<N> tmpStore = this.getInPlace();

        final int tmpMinDim = tmpStore.getMinDim();
        for (int ij = 0; ij < tmpMinDim; ij++) {
            if (!tmpStore.isZero(ij, ij)) {
                retVal++;
            }
        }

        return retVal;
    }

    public MatrixStore<N> getU() {
        return new UpperTriangularStore<N>(this.getInPlace(), false);
    }

    public final boolean isFullSize() {
        return false;
    }

    public boolean isSolvable() {
        return this.isComputed() && this.isSquareAndNotSingular();
    }

    public final boolean isSquareAndNotSingular() {

        boolean retVal = this.getRowDim() == this.getColDim();

        final DecompositionStore<N> tmpStore = this.getInPlace();
        final int tmpMinDim = tmpStore.getMinDim();

        for (int ij = 0; retVal && (ij < tmpMinDim); ij++) {
            retVal &= !tmpStore.isZero(ij, ij);
        }

        return retVal;
    }

    public MatrixStore<N> reconstruct() {
        return MatrixUtils.reconstruct(this);
    }

    @Override
    public void reset() {

        super.reset();

        myPivot = null;
    }

    /**
     * Solves [this][X] = [aRHS] by first solving
     * <pre>[L][Y] = [aRHS]</pre>
     * and then
     * <pre>[U][X] = [Y]</pre>.
     * 
     * @param aRHS The right hand side
     * @return [X]
     */
    @Override
    public MatrixStore<N> solve(final MatrixStore<N> aRHS) {

        final DecompositionStore<N> retVal = this.makeZero(aRHS.getRowDim(), aRHS.getColDim());

        final DecompositionStore<N> tmpBody = this.getInPlace();
        final SelectedRowsStore<N> tmpRHS = new SelectedRowsStore<N>(aRHS, myPivot.getOrder());

        retVal.substituteForwards(tmpBody, true, tmpRHS, false);
        retVal.substituteBackwards(tmpBody, false);

        return retVal;
    }

    private final boolean compute(final Access2D<N> aStore, final boolean assumeNoPivotingRequired) {

        myPivot = this.setInPlace(aStore).computeInPlaceLU(assumeNoPivotingRequired);

        return this.computed(true);
    }

    @Override
    final MatrixStore<N> makeInverse() {

        final DecompositionStore<N> retVal = this.makeEye(this.getColDim(), this.getRowDim());

        final DecompositionStore<N> tmpBody = this.getInPlace();
        final SelectedRowsStore<N> tmpRHS = new SelectedRowsStore<N>(retVal, myPivot.getOrder());

        retVal.substituteForwards(tmpBody, true, tmpRHS, !myPivot.isModified());
        retVal.substituteBackwards(tmpBody, false);

        return retVal;
    }

}
