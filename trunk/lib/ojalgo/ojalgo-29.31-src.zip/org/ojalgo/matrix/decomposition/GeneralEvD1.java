/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.PhysicalStore.Factory;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

public abstract class GeneralEvD1<N extends Number> extends EigenvalueDecomposition<N> {

    static final class Primitive extends GeneralEvD1<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY, new SymmetricEvD1.Primitive(), new NonsymmetricEvD1.Primitive());
        }

    }

    private final SymmetricEvD1<N> myDelegateSymmetric;

    private final NonsymmetricEvD1<N> myDelegateNonsymmetric;
    private boolean mySymmetric = false;

    protected GeneralEvD1(final Factory<N> aFactory, final SymmetricEvD1<N> aDelegateSymmetric, final NonsymmetricEvD1<N> aDelegateNonsymmetric) {

        super(aFactory);

        myDelegateSymmetric = aDelegateSymmetric;
        myDelegateNonsymmetric = aDelegateNonsymmetric;
    }

    public boolean compute(final Access2D<N> aMtrx) {

        final int tmpDim = aMtrx.getRowDim();

        boolean tmpSymmetric = true;

        for (int j = 0; tmpSymmetric && (j < tmpDim); j++) {
            for (int i = j + 1; tmpSymmetric && (i < tmpDim); i++) {
                tmpSymmetric &= TypeUtils.isZero(aMtrx.doubleValue(i, j) - aMtrx.doubleValue(j, i));
            }
        }

        if (tmpSymmetric) {
            return this.computeSymmetric(aMtrx);
        } else {
            return this.computeNonsymmetric(aMtrx);
        }
    }

    public boolean computeNonsymmetric(final Access2D<N> aNonsymmetric) {
        mySymmetric = false;
        return this.computed(myDelegateNonsymmetric.computeNonsymmetric(aNonsymmetric));
    }

    public boolean computeSymmetric(final Access2D<N> aSymmetric) {
        mySymmetric = true;
        return this.computed(myDelegateSymmetric.computeSymmetric(aSymmetric));
    }

    public boolean equals(final MatrixStore<N> aMtrx, final NumberContext aCntxt) {
        if (mySymmetric) {
            return myDelegateSymmetric.equals(aMtrx, aCntxt);
        } else {
            return myDelegateNonsymmetric.equals(aMtrx, aCntxt);
        }
    }

    public MatrixStore<N> getD() {
        if (mySymmetric) {
            return myDelegateSymmetric.getD();
        } else {
            return myDelegateNonsymmetric.getD();
        }
    }

    public ComplexNumber getDeterminant() {
        if (mySymmetric) {
            return myDelegateSymmetric.getDeterminant();
        } else {
            return myDelegateNonsymmetric.getDeterminant();
        }
    }

    public Array1D<ComplexNumber> getEigenvalues() {
        if (mySymmetric) {
            return myDelegateSymmetric.getEigenvalues();
        } else {
            return myDelegateNonsymmetric.getEigenvalues();
        }
    }

    public ComplexNumber getTrace() {
        if (mySymmetric) {
            return myDelegateSymmetric.getTrace();
        } else {
            return myDelegateNonsymmetric.getTrace();
        }
    }

    public MatrixStore<N> getV() {
        if (mySymmetric) {
            return myDelegateSymmetric.getV();
        } else {
            return myDelegateNonsymmetric.getV();
        }
    }

    public boolean isFullSize() {
        if (mySymmetric) {
            return myDelegateSymmetric.isFullSize();
        } else {
            return myDelegateNonsymmetric.isFullSize();
        }
    }

    public boolean isOrdered() {
        if (mySymmetric) {
            return myDelegateSymmetric.isOrdered();
        } else {
            return myDelegateNonsymmetric.isOrdered();
        }
    }

    public boolean isSolvable() {
        if (mySymmetric) {
            return myDelegateSymmetric.isSolvable();
        } else {
            return myDelegateNonsymmetric.isSolvable();
        }
    }

    public boolean isSymmetric() {
        if (mySymmetric) {
            return myDelegateSymmetric.isSymmetric();
        } else {
            return myDelegateNonsymmetric.isSymmetric();
        }
    }

    @Override
    public void reset() {

        super.reset();

        myDelegateNonsymmetric.reset();
        myDelegateSymmetric.reset();

        mySymmetric = false;
    }

    public MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        if (mySymmetric) {
            return myDelegateSymmetric.solve(aRHS);
        } else {
            return myDelegateNonsymmetric.solve(aRHS);
        }
    }

    @Override
    MatrixStore<N> makeInverse() {
        if (mySymmetric) {
            return myDelegateSymmetric.makeInverse();
        } else {
            return myDelegateNonsymmetric.makeInverse();
        }
    }
}
