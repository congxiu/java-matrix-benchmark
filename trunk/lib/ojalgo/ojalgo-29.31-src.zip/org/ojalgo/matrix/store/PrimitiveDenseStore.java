/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.store;

import static org.ojalgo.constant.PrimitiveMath.*;
import static org.ojalgo.function.implementation.PrimitiveFunction.*;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.ojalgo.access.Access1D;
import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.array.ArrayUtils;
import org.ojalgo.array.PrimitiveArray;
import org.ojalgo.concurrent.DaemonPoolExecutor;
import org.ojalgo.concurrent.ProcessorCount;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.AggregatorCollection;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.ChainableAggregator;
import org.ojalgo.function.aggregator.CollectableAggregator;
import org.ojalgo.function.aggregator.PrimitiveAggregator;
import org.ojalgo.function.implementation.FunctionSet;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.decomposition.DecompositionStore;
import org.ojalgo.matrix.decomposition.LUDecomposition.Pivot;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.PrimitiveScalar;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * A {@linkplain Double} (actually double) implementation of {@linkplain PhysicalStore}.
 *
 * @author apete
 */
public final class PrimitiveDenseStore extends PrimitiveArray implements PhysicalStore<Double>, DecompositionStore<Double> {

    public static final PhysicalStore.Factory<Double> FACTORY = new PhysicalStore.Factory<Double>() {

        public PrimitiveDenseStore conjugate(final Access2D<? extends Number> aSource) {
            return this.transpose(aSource);
        }

        public PrimitiveDenseStore copy(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getRowDim();
            final int tmpColDim = aSource.getColDim();

            final double[] retValData = new double[tmpRowDim * tmpColDim];
            final PrimitiveDenseStore retVal = new PrimitiveDenseStore(tmpRowDim, tmpColDim, retValData);

            PrimitiveDenseStore.copy(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return retVal;
        }

        public PrimitiveDenseStore copy(final double[][] aSource) {

            final int tmpRowDim = aSource.length;
            final int tmpColDim = aSource[0].length;

            final double[] retValData = new double[tmpRowDim * tmpColDim];
            final PrimitiveDenseStore retVal = new PrimitiveDenseStore(tmpRowDim, tmpColDim, retValData);

            PrimitiveDenseStore.copy(retValData, tmpRowDim, 0, tmpColDim, ArrayUtils.wrapAccess2D(aSource), ProcessorCount.RUNTIME);

            return retVal;
        }

        public AggregatorCollection<Double> getAggregatorCollection() {
            return PrimitiveAggregator.getCollection();
        }

        public FunctionSet<Double> getFunctionSet() {
            return PrimitiveFunction.getSet();
        }

        public Double getNumber(final double aNmbr) {
            return aNmbr;
        }

        public Double getNumber(final Number aNmbr) {
            return aNmbr.doubleValue();
        }

        public PrimitiveScalar getStaticOne() {
            return PrimitiveScalar.ONE;
        }

        public PrimitiveScalar getStaticZero() {
            return PrimitiveScalar.ZERO;
        }

        public PhysicalStore<Double> makeColumn(final Access1D<? extends Number> aColumn) {

            final int tmpRowDim = aColumn.size();
            final double[] retValData = new double[tmpRowDim];

            for (int i = 0; i < tmpRowDim; i++) {
                retValData[i] = aColumn.doubleValue(i);
            }

            return new PrimitiveDenseStore(tmpRowDim, 1, retValData);
        }

        public PrimitiveDenseStore makeColumn(final double[] aColumn) {
            return new PrimitiveDenseStore(aColumn.length, 1, ArrayUtils.copyOf(aColumn));
        }

        public PrimitiveDenseStore makeColumn(final Double[] aColumn) {

            final int tmpRowDim = aColumn.length;
            final double[] retValData = new double[tmpRowDim];

            for (int i = 0; i < tmpRowDim; i++) {
                retValData[i] = aColumn[i];
            }

            return new PrimitiveDenseStore(tmpRowDim, 1, retValData);
        }

        public PrimitiveDenseStore makeColumn(final List<Double> aColumn) {

            final int tmpRowDim = aColumn.size();
            final double[] retValData = new double[tmpRowDim];

            for (int i = 0; i < tmpRowDim; i++) {
                retValData[i] = aColumn.get(i);
            }

            return new PrimitiveDenseStore(tmpRowDim, 1, retValData);
        }

        public PrimitiveDenseStore makeEmpty(final int aRowDim, final int aColDim) {
            return new PrimitiveDenseStore(aRowDim, aColDim, new double[aRowDim * aColDim]);
        }

        public PrimitiveDenseStore makeEye(final int aRowDim, final int aColDim) {

            final PrimitiveDenseStore retVal = this.makeZero(aRowDim, aColDim);

            retVal.myUtility.fillDiagonal(0, 0, this.getStaticOne().getNumber());

            return retVal;
        }

        public PrimitiveDenseStore makeZero(final int aRowDim, final int aColDim) {
            return new PrimitiveDenseStore(aRowDim, aColDim);
        }

        public PrimitiveScalar toScalar(final double aNmbr) {
            return new PrimitiveScalar(aNmbr);
        }

        public PrimitiveScalar toScalar(final Number aNmbr) {
            return new PrimitiveScalar(aNmbr.doubleValue());
        }

        public PrimitiveDenseStore transpose(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getColDim();
            final int tmpColDim = aSource.getRowDim();

            final double[] retValData = new double[tmpRowDim * tmpColDim];

            PrimitiveDenseStore.transpose(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return new PrimitiveDenseStore(tmpRowDim, tmpColDim, retValData);
        }
    };

    private static void multiply(final double[] aProductArray, final MatrixStore<Double> aLeftStore, final MatrixStore<Double> aRightStore) {

        final int tmpRowDim = aLeftStore.getRowDim();
        final int tmpCalcSize = aRightStore.getRowDim();
        final int tmpColDim = aRightStore.getColDim();

        final boolean tmpLL = false; //aLeftStore.isLowerLeftShaded();
        final boolean tmpLU = false; //aLeftStore.isUpperRightShaded();
        final boolean tmpRL = false; //aRightStore.isLowerLeftShaded();
        final boolean tmpRU = false; //aRightStore.isUpperRightShaded();
        int tmpFirst;
        int tmpLimit;

        final double[] tmpLeftRow = new double[tmpCalcSize];
        double tmpVal;

        for (int i = 0; i < tmpRowDim; i++) {
            for (int c = 0; c < tmpCalcSize; c++) {
                tmpLeftRow[c] = aLeftStore.doubleValue(i, c);
            }
            for (int j = 0; j < tmpColDim; j++) {
                tmpFirst = MatrixUtils.max(tmpLL ? i - 1 : 0, tmpRU ? j - 1 : 0, 0);
                tmpLimit = MatrixUtils.min(tmpLU ? i + 2 : tmpCalcSize, tmpRL ? j + 2 : tmpCalcSize, tmpCalcSize);
                tmpVal = ZERO;
                for (int c = tmpFirst; c < tmpLimit; c++) {
                    tmpVal += tmpLeftRow[c] * aRightStore.doubleValue(c, j);
                }
                aProductArray[i + j * tmpRowDim] = tmpVal;
            }
        }
    }

    static Double aggregateAll(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final ChainableAggregator aVisitor, final int availableCPUs) {

        final AggregatorFunction<Double> tmpAggrFunc = aVisitor.getPrimitiveFunction();

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<Double> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Callable<Double>() {

                public Double call() throws Exception {
                    return PrimitiveDenseStore.aggregateAll(aData, aRowDim, aFirstCol, tmpSplit, aVisitor, tmpCPUs);
                }
            });

            final Future<Double> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Callable<Double>() {

                public Double call() throws Exception {
                    return PrimitiveDenseStore.aggregateAll(aData, aRowDim, tmpSplit, aColLimit, aVisitor, tmpCPUs);
                }
            });

            try {

                tmpAggrFunc.invoke(tmpFirstPart.get());
                tmpAggrFunc.invoke(tmpSecondPart.get());

            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.visit(aRowDim * aFirstCol, aRowDim * aColLimit, 1, tmpAggrFunc);
        }

        return tmpAggrFunc.getNumber();
    }

    static Double aggregateAll(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final CollectableAggregator aVisitor, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<Double> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Callable<Double>() {

                public Double call() throws Exception {
                    return PrimitiveDenseStore.aggregateAll(aData, aRowDim, aFirstCol, tmpSplit, aVisitor, tmpCPUs);
                }
            });

            final Future<Double> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Callable<Double>() {

                public Double call() throws Exception {
                    return PrimitiveDenseStore.aggregateAll(aData, aRowDim, tmpSplit, aColLimit, aVisitor, tmpCPUs);
                }
            });

            try {

                return tmpFirstPart.get() + tmpSecondPart.get();

            } catch (final InterruptedException anException) {
                anException.printStackTrace();
                return NaN;
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
                return NaN;
            }

        } else {

            final AggregatorFunction<Double> tmpAggrFunc = aVisitor.getPrimitiveFunction();

            aData.visit(aRowDim * aFirstCol, aRowDim * aColLimit, 1, tmpAggrFunc);

            return tmpAggrFunc.doubleValue();
        }
    }

    static void caxpy(final double factorA, final double[] arrayX, final int colX, final double[] arrayY, final int colY, final int aFirstRow, final int aRowDim) {

        int tmpIndexX = aFirstRow + colX * aRowDim;
        int tmpIndexY = aFirstRow + colY * aRowDim;

        for (int i = aFirstRow; i < aRowDim; i++) {
            arrayY[tmpIndexY++] += factorA * arrayX[tmpIndexX++];
        }
    }

    static void copy(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<? extends Number> aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.copy(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.copy(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aSource.doubleValue(i, j);
                }
            }
        }
    }

    static void doAfter(final double[] aMtrxH, final double[] aMtrxV, final double[] tmpMainDiagonal, final double[] tmpOffDiagonal, double r, double s, double z, final double aNorm1) {

        final int tmpDiagDim = (int) Math.sqrt(aMtrxH.length);
        final int tmpDiagDimMinusOne = tmpDiagDim - 1;

        //        BasicLogger.logDebug("r={}, s={}, z={}", r, s, z);

        double p;
        double q;
        double t;
        double w;
        double x;
        double y;

        for (int ij = tmpDiagDimMinusOne; ij >= 0; ij--) {

            p = tmpMainDiagonal[ij];
            q = tmpOffDiagonal[ij];

            // Real vector
            if (q == 0) {
                int l = ij;
                aMtrxH[ij + tmpDiagDim * ij] = 1.0;
                for (int i = ij - 1; i >= 0; i--) {
                    w = aMtrxH[i + tmpDiagDim * i] - p;
                    r = PrimitiveMath.ZERO;
                    for (int j = l; j <= ij; j++) {
                        r = r + aMtrxH[i + tmpDiagDim * j] * aMtrxH[j + tmpDiagDim * ij];
                    }
                    if (tmpOffDiagonal[i] < PrimitiveMath.ZERO) {
                        z = w;
                        s = r;
                    } else {
                        l = i;
                        if (tmpOffDiagonal[i] == PrimitiveMath.ZERO) {
                            if (w != PrimitiveMath.ZERO) {
                                aMtrxH[i + tmpDiagDim * ij] = -r / w;
                            } else {
                                aMtrxH[i + tmpDiagDim * ij] = -r / (PrimitiveMath.MACHINE_DOUBLE_ERROR * aNorm1);
                            }

                            // Solve real equations
                        } else {
                            x = aMtrxH[i + tmpDiagDim * (i + 1)];
                            y = aMtrxH[(i + 1) + tmpDiagDim * i];
                            q = (tmpMainDiagonal[i] - p) * (tmpMainDiagonal[i] - p) + tmpOffDiagonal[i] * tmpOffDiagonal[i];
                            t = (x * s - z * r) / q;
                            aMtrxH[i + tmpDiagDim * ij] = t;
                            if (Math.abs(x) > Math.abs(z)) {
                                aMtrxH[(i + 1) + tmpDiagDim * ij] = (-r - w * t) / x;
                            } else {
                                aMtrxH[(i + 1) + tmpDiagDim * ij] = (-s - y * t) / z;
                            }
                        }

                        // Overflow control
                        t = Math.abs(aMtrxH[i + tmpDiagDim * ij]);
                        if ((PrimitiveMath.MACHINE_DOUBLE_ERROR * t) * t > 1) {
                            for (int j = i; j <= ij; j++) {
                                aMtrxH[j + tmpDiagDim * ij] = aMtrxH[j + tmpDiagDim * ij] / t;
                            }
                        }
                    }
                }

                // Complex vector
            } else if (q < 0) {
                int l = ij - 1;

                // Last vector component imaginary so matrix is triangular
                if (Math.abs(aMtrxH[ij + tmpDiagDim * (ij - 1)]) > Math.abs(aMtrxH[(ij - 1) + tmpDiagDim * ij])) {
                    aMtrxH[(ij - 1) + tmpDiagDim * (ij - 1)] = q / aMtrxH[ij + tmpDiagDim * (ij - 1)];
                    aMtrxH[(ij - 1) + tmpDiagDim * ij] = -(aMtrxH[ij + tmpDiagDim * ij] - p) / aMtrxH[ij + tmpDiagDim * (ij - 1)];
                } else {

                    final ComplexNumber tmpX = ComplexNumber.makeRectangular(PrimitiveMath.ZERO, (-aMtrxH[(ij - 1) + tmpDiagDim * ij]));
                    final ComplexNumber tmpY = ComplexNumber.makeRectangular((aMtrxH[(ij - 1) + tmpDiagDim * (ij - 1)] - p), q);

                    final ComplexNumber tmpZ = tmpX.divide(tmpY);

                    aMtrxH[(ij - 1) + tmpDiagDim * (ij - 1)] = tmpZ.getReal();
                    aMtrxH[(ij - 1) + tmpDiagDim * ij] = tmpZ.getImaginary();
                }
                aMtrxH[ij + tmpDiagDim * (ij - 1)] = PrimitiveMath.ZERO;
                aMtrxH[ij + tmpDiagDim * ij] = 1.0;
                for (int i = ij - 2; i >= 0; i--) {
                    double ra, sa, vr, vi;
                    ra = PrimitiveMath.ZERO;
                    sa = PrimitiveMath.ZERO;
                    for (int j = l; j <= ij; j++) {
                        ra = ra + aMtrxH[i + tmpDiagDim * j] * aMtrxH[j + tmpDiagDim * (ij - 1)];
                        sa = sa + aMtrxH[i + tmpDiagDim * j] * aMtrxH[j + tmpDiagDim * ij];
                    }
                    w = aMtrxH[i + tmpDiagDim * i] - p;

                    if (tmpOffDiagonal[i] < PrimitiveMath.ZERO) {
                        z = w;
                        r = ra;
                        s = sa;
                    } else {
                        l = i;
                        if (tmpOffDiagonal[i] == 0) {
                            final ComplexNumber tmpX = ComplexNumber.makeRectangular((-ra), (-sa));
                            final ComplexNumber tmpY = ComplexNumber.makeRectangular(w, q);

                            final ComplexNumber tmpZ = tmpX.divide(tmpY);

                            aMtrxH[i + tmpDiagDim * (ij - 1)] = tmpZ.getReal();
                            aMtrxH[i + tmpDiagDim * ij] = tmpZ.getImaginary();
                        } else {

                            // Solve complex equations
                            x = aMtrxH[i + tmpDiagDim * (i + 1)];
                            y = aMtrxH[(i + 1) + tmpDiagDim * i];
                            vr = (tmpMainDiagonal[i] - p) * (tmpMainDiagonal[i] - p) + tmpOffDiagonal[i] * tmpOffDiagonal[i] - q * q;
                            vi = (tmpMainDiagonal[i] - p) * 2.0 * q;
                            if ((vr == PrimitiveMath.ZERO) & (vi == PrimitiveMath.ZERO)) {
                                vr = PrimitiveMath.MACHINE_DOUBLE_ERROR * aNorm1 * (Math.abs(w) + Math.abs(q) + Math.abs(x) + Math.abs(y) + Math.abs(z));
                            }

                            final ComplexNumber tmpX = ComplexNumber.makeRectangular((x * r - z * ra + q * sa), (x * s - z * sa - q * ra));
                            final ComplexNumber tmpY = ComplexNumber.makeRectangular(vr, vi);

                            final ComplexNumber tmpZ = tmpX.divide(tmpY);

                            aMtrxH[i + tmpDiagDim * (ij - 1)] = tmpZ.getReal();
                            aMtrxH[i + tmpDiagDim * ij] = tmpZ.getImaginary();

                            if (Math.abs(x) > (Math.abs(z) + Math.abs(q))) {
                                aMtrxH[(i + 1) + tmpDiagDim * (ij - 1)] = (-ra - w * aMtrxH[i + tmpDiagDim * (ij - 1)] + q * aMtrxH[i + tmpDiagDim * ij]) / x;
                                aMtrxH[(i + 1) + tmpDiagDim * ij] = (-sa - w * aMtrxH[i + tmpDiagDim * ij] - q * aMtrxH[i + tmpDiagDim * (ij - 1)]) / x;
                            } else {
                                final ComplexNumber tmpX1 = ComplexNumber.makeRectangular((-r - y * aMtrxH[i + tmpDiagDim * (ij - 1)]), (-s - y * aMtrxH[i + tmpDiagDim * ij]));
                                final ComplexNumber tmpY1 = ComplexNumber.makeRectangular(z, q);

                                final ComplexNumber tmpZ1 = tmpX1.divide(tmpY1);

                                aMtrxH[(i + 1) + tmpDiagDim * (ij - 1)] = tmpZ1.getReal();
                                aMtrxH[(i + 1) + tmpDiagDim * ij] = tmpZ1.getImaginary();
                            }
                        }

                        // Overflow control
                        t = Math.max(Math.abs(aMtrxH[i + tmpDiagDim * (ij - 1)]), Math.abs(aMtrxH[i + tmpDiagDim * ij]));
                        if ((PrimitiveMath.MACHINE_DOUBLE_ERROR * t) * t > 1) {
                            for (int j = i; j <= ij; j++) {
                                aMtrxH[j + tmpDiagDim * (ij - 1)] = aMtrxH[j + tmpDiagDim * (ij - 1)] / t;
                                aMtrxH[j + tmpDiagDim * ij] = aMtrxH[j + tmpDiagDim * ij] / t;
                            }
                        }
                    }
                }
            }
        }

        // Back transformation to get eigenvectors of original matrix
        for (int j = tmpDiagDimMinusOne; j >= 0; j--) {
            for (int i = 0; i <= tmpDiagDimMinusOne; i++) {
                z = PrimitiveMath.ZERO;
                for (int k = 0; k <= j; k++) {
                    z += aMtrxV[i + tmpDiagDim * k] * aMtrxH[k + tmpDiagDim * j];
                }
                aMtrxV[i + tmpDiagDim * j] = z;
            }
        }
    }

    static void doCholeskyStep(final double[] aData, final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColLimit, final double[] aMultipliers, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 3;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doCholeskyStep(aData, aPivotRow, aRowDim, aFirstCol, tmpSplit, aMultipliers, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doCholeskyStep(aData, aPivotRow, aRowDim, tmpSplit, aColLimit, aMultipliers, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            double tmpVal;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {
                tmpVal = aMultipliers[j];
                tmpIndex = j + j * aRowDim;
                for (int i = j; i < aRowDim; i++) {
                    aData[tmpIndex++] -= aMultipliers[i] * tmpVal;
                }
            }
        }
    }

    static int doHessenberg(final double[] aMtrxH, final double[] aMtrxV) {

        final int tmpDiagDim = (int) Math.sqrt(aMtrxH.length);
        final int tmpDiagDimMinusTwo = tmpDiagDim - 2;

        final double[] tmpWorkCopy = new double[tmpDiagDim];

        for (int ij = 0; ij < tmpDiagDimMinusTwo; ij++) {

            // Scale column.
            double tmpColNorm1 = PrimitiveMath.ZERO;
            for (int i = ij + 1; i < tmpDiagDim; i++) {
                tmpColNorm1 += Math.abs(aMtrxH[i + tmpDiagDim * ij]);
            }

            if (tmpColNorm1 != PrimitiveMath.ZERO) {

                // Compute Householder transformation.
                double tmpInvBeta = PrimitiveMath.ZERO;
                for (int i = tmpDiagDim - 1; i >= ij + 1; i--) {
                    tmpWorkCopy[i] = aMtrxH[i + tmpDiagDim * ij] / tmpColNorm1;
                    tmpInvBeta += tmpWorkCopy[i] * tmpWorkCopy[i];
                }
                double g = Math.sqrt(tmpInvBeta);
                if (tmpWorkCopy[ij + 1] > 0) {
                    g = -g;
                }
                tmpInvBeta = tmpInvBeta - tmpWorkCopy[ij + 1] * g;
                tmpWorkCopy[ij + 1] = tmpWorkCopy[ij + 1] - g;

                // Apply Householder similarity transformation
                // H = (I-u*u'/h)*H*(I-u*u')/h)
                for (int j = ij + 1; j < tmpDiagDim; j++) {
                    double f = PrimitiveMath.ZERO;
                    for (int i = tmpDiagDim - 1; i >= ij + 1; i--) {
                        f += tmpWorkCopy[i] * aMtrxH[i + tmpDiagDim * j];
                    }
                    f = f / tmpInvBeta;
                    for (int i = ij + 1; i <= tmpDiagDim - 1; i++) {
                        aMtrxH[i + tmpDiagDim * j] -= f * tmpWorkCopy[i];
                    }
                }

                for (int i = 0; i < tmpDiagDim; i++) {
                    double f = PrimitiveMath.ZERO;
                    for (int j = tmpDiagDim - 1; j >= ij + 1; j--) {
                        f += tmpWorkCopy[j] * aMtrxH[i + tmpDiagDim * j];
                    }
                    f = f / tmpInvBeta;
                    for (int j = ij + 1; j < tmpDiagDim; j++) {
                        aMtrxH[i + tmpDiagDim * j] -= f * tmpWorkCopy[j];
                    }
                }

                tmpWorkCopy[ij + 1] = tmpColNorm1 * tmpWorkCopy[ij + 1];
                aMtrxH[(ij + 1) + tmpDiagDim * ij] = tmpColNorm1 * g;
            }
        }

        //  BasicLogger.logDebug("Jama H", new PrimitiveDenseStore(tmpDiagDim, tmpDiagDim, aMtrxH));

        // Här borde Hessenberg vara klar
        // Nedan börjar uträkningen av Q

        // Accumulate transformations (Algol's ortran).
        for (int ij = tmpDiagDimMinusTwo; ij >= 1; ij--) {
            final int tmpIndex = ij + tmpDiagDim * (ij - 1);
            if (aMtrxH[tmpIndex] != PrimitiveMath.ZERO) {
                for (int i = ij + 1; i <= tmpDiagDim - 1; i++) {
                    tmpWorkCopy[i] = aMtrxH[i + tmpDiagDim * (ij - 1)];
                }
                for (int j = ij; j <= tmpDiagDim - 1; j++) {
                    double g = PrimitiveMath.ZERO;
                    for (int i = ij; i <= tmpDiagDim - 1; i++) {
                        g += tmpWorkCopy[i] * aMtrxV[i + tmpDiagDim * j];
                    }
                    // Double division avoids possible underflow
                    g = (g / tmpWorkCopy[ij]) / aMtrxH[tmpIndex];
                    for (int i = ij; i <= tmpDiagDim - 1; i++) {
                        aMtrxV[i + tmpDiagDim * j] += g * tmpWorkCopy[i];
                    }
                }
            } else {
                //                BasicLogger.logDebug("Iter V", new PrimitiveDenseStore(tmpDiagDim, tmpDiagDim, aMtrxV));
            }
        }

        //      BasicLogger.logDebug("Jama V", new PrimitiveDenseStore(tmpDiagDim, tmpDiagDim, aMtrxV));

        return tmpDiagDim;
    }

    static void doHouseholderBoth1Derive(final double[] aData, final int aFirstCol, final int aColLimit, final Householder.Primitive aHouseholder, final double[] aDerived, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > 100)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderBoth1Derive(aData, aFirstCol, tmpSplit, aHouseholder, aDerived, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderBoth1Derive(aData, tmpSplit, aColLimit, aHouseholder, aDerived, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final double[] tmpVector = aHouseholder.vector;
            final int tmpFirst = aHouseholder.first;
            final int tmpLength = tmpVector.length;

            double tmpVal;
            for (int i = aFirstCol; i < aColLimit; i++) {
                tmpVal = ZERO;
                for (int c = tmpFirst; c < i; c++) {
                    tmpVal += aData[i + c * tmpLength] * tmpVector[c];
                }
                for (int c = i; c < tmpLength; c++) {
                    tmpVal += aData[c + i * tmpLength] * tmpVector[c];
                }
                aDerived[i] = tmpVal;
            }
        }
    }

    static void doHouseholderBoth2Scale(final Householder.Primitive aHouseholder, final double[] aDerived) {

        final double[] tmpVector = aHouseholder.vector;
        final int tmpFirst = aHouseholder.first;
        final int tmpLength = tmpVector.length;
        final double tmpBeta = aHouseholder.beta;

        double tmpVal = ZERO;
        for (int c = tmpFirst; c < tmpLength; c++) {
            tmpVal += tmpVector[c] * aDerived[c];
        }
        tmpVal *= (tmpBeta / TWO);

        for (int c = tmpFirst; c < tmpLength; c++) {
            aDerived[c] = tmpBeta * (aDerived[c] - (tmpVal * tmpVector[c]));
        }
    }

    static void doHouseholderBoth3Update(final double[] aData, final int aFirstCol, final int aColLimit, final Householder.Primitive tmpHouseholder, final double[] aDerived, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > 100)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderBoth3Update(aData, aFirstCol, tmpSplit, tmpHouseholder, aDerived, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderBoth3Update(aData, tmpSplit, aColLimit, tmpHouseholder, aDerived, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final double[] tmpVector = tmpHouseholder.vector;
            final int tmpLength = tmpVector.length;

            double tmpHouseJ;
            double tmpDerivJ;

            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {

                tmpHouseJ = tmpVector[j];
                tmpDerivJ = aDerived[j];

                tmpIndex = j + j * tmpLength;
                for (int i = j; i < tmpLength; i++) {
                    aData[tmpIndex++] -= (aDerived[i] * tmpHouseJ + tmpVector[i] * tmpDerivJ);
                }
            }
        }
    }

    static void doHouseholderLeft(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Householder.Primitive aHouseholder, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderLeft(aData, aRowDim, aFirstCol, tmpSplit, aHouseholder, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderLeft(aData, aRowDim, tmpSplit, aColLimit, aHouseholder, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final double[] tmpHouseholderVector = aHouseholder.vector;
            final int tmpFirstNonZero = aHouseholder.first;
            final double tmpBeta = aHouseholder.beta;

            double tmpScale;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {
                tmpScale = ZERO;
                tmpIndex = tmpFirstNonZero + j * aRowDim;
                for (int i = tmpFirstNonZero; i < aRowDim; i++) {
                    tmpScale += tmpHouseholderVector[i] * aData[tmpIndex++];
                }
                tmpScale *= tmpBeta;
                tmpIndex = tmpFirstNonZero + j * aRowDim;
                for (int i = tmpFirstNonZero; i < aRowDim; i++) {
                    aData[tmpIndex++] -= tmpScale * tmpHouseholderVector[i];
                }
            }
        }
    }

    static void doHouseholderRight(final double[] aData, final int aFirstRow, final int aRowLimit, final int aColDim, final Householder.Primitive aHouseholder, final int availableCPUs) {

        final int tmpRowCount = aRowLimit - aFirstRow;

        if ((availableCPUs > 1) && (tmpRowCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstRow + tmpRowCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderRight(aData, aFirstRow, tmpSplit, aColDim, aHouseholder, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderRight(aData, tmpSplit, aRowLimit, aColDim, aHouseholder, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final double[] tmpHouseholderVector = aHouseholder.vector;
            final int tmpFirstNonZero = aHouseholder.first;
            final double tmpBeta = aHouseholder.beta;

            final int tmpRowDim = aData.length / aColDim;

            double tmpScale;
            int tmpIndex;
            for (int i = aFirstRow; i < aRowLimit; i++) {
                tmpScale = ZERO;
                tmpIndex = i + tmpFirstNonZero * tmpRowDim;
                for (int j = tmpFirstNonZero; j < aColDim; j++) {
                    tmpScale += tmpHouseholderVector[j] * aData[tmpIndex];
                    tmpIndex += tmpRowDim;
                }
                tmpScale *= tmpBeta;
                tmpIndex = i + tmpFirstNonZero * tmpRowDim;
                for (int j = tmpFirstNonZero; j < aColDim; j++) {
                    aData[tmpIndex] -= tmpScale * tmpHouseholderVector[j];
                    tmpIndex += tmpRowDim;
                }
            }
        }
    }

    static void doRotateLeft(final double[] aData, final int aColDim, final int aRowA, final int aRowB, final double aCos, final double aSin) {

        double tmpOldA;
        double tmpOldB;

        int tmpIndexA = aRowA;
        int tmpIndexB = aRowB;
        final int tmpIndexStep = aData.length / aColDim;

        for (int j = 0; j < aColDim; j++) {

            tmpOldA = aData[tmpIndexA];
            tmpOldB = aData[tmpIndexB];

            aData[tmpIndexA] = aCos * tmpOldA + aSin * tmpOldB;
            aData[tmpIndexB] = aCos * tmpOldB - aSin * tmpOldA;

            tmpIndexA += tmpIndexStep;
            tmpIndexB += tmpIndexStep;
        }
    }

    static void doRotateRight(final double[] aData, final int aRowDim, final int aColA, final int aColB, final double aCos, final double aSin) {

        double tmpOldA;
        double tmpOldB;

        int tmpIndexA = aColA * aRowDim;
        int tmpIndexB = aColB * aRowDim;

        for (int i = 0; i < aRowDim; i++) {

            tmpOldA = aData[tmpIndexA];
            tmpOldB = aData[tmpIndexB];

            aData[tmpIndexA] = aCos * tmpOldA - aSin * tmpOldB;
            aData[tmpIndexB] = aCos * tmpOldB + aSin * tmpOldA;

            tmpIndexA++;
            tmpIndexB++;
        }
    }

    static double[][] doSchur(final double[] aMtrxH, final double[] aMtrxV, final boolean allTheWay) {

        final int tmpDiagDim = (int) Math.sqrt(aMtrxH.length);
        final int tmpDiagDimMinusOne = tmpDiagDim - 1;

        // Store roots isolated by balanc and compute matrix norm
        double tmpVal = PrimitiveMath.ZERO;
        for (int j = 0; j < tmpDiagDim; j++) {
            for (int i = Math.min(j + 1, tmpDiagDim - 1); i >= 0; i--) {
                tmpVal += Math.abs(aMtrxH[i + tmpDiagDim * j]);
            }
        }
        final double tmpNorm1 = tmpVal;

        final double[] tmpMainDiagonal = new double[tmpDiagDim];
        final double[] tmpOffDiagonal = new double[tmpDiagDim];

        double exshift = PrimitiveMath.ZERO;
        double p = 0, q = 0, r = 0, s = 0, z = 0;

        double w, x, y;
        // Outer loop over eigenvalue index
        int tmpIterCount = 0;
        int tmpMainIterIndex = tmpDiagDimMinusOne;
        while (tmpMainIterIndex >= 0) {

            // Look for single small sub-diagonal element
            int l = tmpMainIterIndex;
            while (l > 0) {
                s = Math.abs(aMtrxH[(l - 1) + tmpDiagDim * (l - 1)]) + Math.abs(aMtrxH[l + tmpDiagDim * l]);
                if (s == PrimitiveMath.ZERO) {
                    s = tmpNorm1;
                }
                if (Math.abs(aMtrxH[l + tmpDiagDim * (l - 1)]) < PrimitiveMath.MACHINE_DOUBLE_ERROR * s) {
                    break;
                }
                l--;
            }

            // Check for convergence
            // One root found
            if (l == tmpMainIterIndex) {
                aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex] = aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex] + exshift;
                tmpMainDiagonal[tmpMainIterIndex] = aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex];
                tmpOffDiagonal[tmpMainIterIndex] = PrimitiveMath.ZERO;
                tmpMainIterIndex--;
                tmpIterCount = 0;

                // Two roots found
            } else if (l == tmpMainIterIndex - 1) {
                w = aMtrxH[tmpMainIterIndex + tmpDiagDim * (tmpMainIterIndex - 1)] * aMtrxH[(tmpMainIterIndex - 1) + tmpDiagDim * tmpMainIterIndex];
                p = (aMtrxH[(tmpMainIterIndex - 1) + tmpDiagDim * (tmpMainIterIndex - 1)] - aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex]) / 2.0;
                q = p * p + w;
                z = Math.sqrt(Math.abs(q));
                aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex] = aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex] + exshift;
                aMtrxH[(tmpMainIterIndex - 1) + tmpDiagDim * (tmpMainIterIndex - 1)] = aMtrxH[(tmpMainIterIndex - 1) + tmpDiagDim * (tmpMainIterIndex - 1)] + exshift;
                x = aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex];

                // Real pair
                if (q >= 0) {
                    if (p >= 0) {
                        z = p + z;
                    } else {
                        z = p - z;
                    }
                    tmpMainDiagonal[tmpMainIterIndex - 1] = x + z;
                    tmpMainDiagonal[tmpMainIterIndex] = tmpMainDiagonal[tmpMainIterIndex - 1];
                    if (z != PrimitiveMath.ZERO) {
                        tmpMainDiagonal[tmpMainIterIndex] = x - w / z;
                    }
                    tmpOffDiagonal[tmpMainIterIndex - 1] = PrimitiveMath.ZERO;
                    tmpOffDiagonal[tmpMainIterIndex] = PrimitiveMath.ZERO;
                    x = aMtrxH[tmpMainIterIndex + tmpDiagDim * (tmpMainIterIndex - 1)];
                    s = Math.abs(x) + Math.abs(z);
                    p = x / s;
                    q = z / s;
                    r = Math.sqrt(p * p + q * q);
                    p = p / r;
                    q = q / r;

                    // Row modification
                    for (int j = tmpMainIterIndex - 1; j < tmpDiagDim; j++) {
                        z = aMtrxH[(tmpMainIterIndex - 1) + tmpDiagDim * j];
                        aMtrxH[(tmpMainIterIndex - 1) + tmpDiagDim * j] = q * z + p * aMtrxH[tmpMainIterIndex + tmpDiagDim * j];
                        aMtrxH[tmpMainIterIndex + tmpDiagDim * j] = q * aMtrxH[tmpMainIterIndex + tmpDiagDim * j] - p * z;
                    }

                    // Column modification
                    for (int i = 0; i <= tmpMainIterIndex; i++) {
                        z = aMtrxH[i + tmpDiagDim * (tmpMainIterIndex - 1)];
                        aMtrxH[i + tmpDiagDim * (tmpMainIterIndex - 1)] = q * z + p * aMtrxH[i + tmpDiagDim * tmpMainIterIndex];
                        aMtrxH[i + tmpDiagDim * tmpMainIterIndex] = q * aMtrxH[i + tmpDiagDim * tmpMainIterIndex] - p * z;
                    }

                    // Accumulate transformations
                    for (int i = 0; i <= tmpDiagDimMinusOne; i++) {
                        z = aMtrxV[i + tmpDiagDim * (tmpMainIterIndex - 1)];
                        aMtrxV[i + tmpDiagDim * (tmpMainIterIndex - 1)] = q * z + p * aMtrxV[i + tmpDiagDim * tmpMainIterIndex];
                        aMtrxV[i + tmpDiagDim * tmpMainIterIndex] = q * aMtrxV[i + tmpDiagDim * tmpMainIterIndex] - p * z;
                    }

                    // Complex pair
                } else {
                    tmpMainDiagonal[tmpMainIterIndex - 1] = x + p;
                    tmpMainDiagonal[tmpMainIterIndex] = x + p;
                    tmpOffDiagonal[tmpMainIterIndex - 1] = z;
                    tmpOffDiagonal[tmpMainIterIndex] = -z;
                }
                tmpMainIterIndex = tmpMainIterIndex - 2;
                tmpIterCount = 0;

                // No convergence yet
            } else {

                // Form shift
                x = aMtrxH[tmpMainIterIndex + tmpDiagDim * tmpMainIterIndex];
                y = PrimitiveMath.ZERO;
                w = PrimitiveMath.ZERO;
                if (l < tmpMainIterIndex) {
                    y = aMtrxH[(tmpMainIterIndex - 1) + tmpDiagDim * (tmpMainIterIndex - 1)];
                    w = aMtrxH[tmpMainIterIndex + tmpDiagDim * (tmpMainIterIndex - 1)] * aMtrxH[(tmpMainIterIndex - 1) + tmpDiagDim * tmpMainIterIndex];
                }

                // Wilkinson's original ad hoc shift
                if (tmpIterCount == 10) {
                    exshift += x;
                    for (int i = 0; i <= tmpMainIterIndex; i++) {
                        aMtrxH[i + tmpDiagDim * i] -= x;
                    }
                    s = Math.abs(aMtrxH[tmpMainIterIndex + tmpDiagDim * (tmpMainIterIndex - 1)]) + Math.abs(aMtrxH[(tmpMainIterIndex - 1) + tmpDiagDim * (tmpMainIterIndex - 2)]);
                    x = y = 0.75 * s;
                    w = -0.4375 * s * s;
                }

                // MATLAB's new ad hoc shift
                if (tmpIterCount == 30) {
                    s = (y - x) / 2.0;
                    s = s * s + w;
                    if (s > 0) {
                        s = Math.sqrt(s);
                        if (y < x) {
                            s = -s;
                        }
                        s = x - w / ((y - x) / 2.0 + s);
                        for (int i = 0; i <= tmpMainIterIndex; i++) {
                            aMtrxH[i + tmpDiagDim * i] -= s;
                        }
                        exshift += s;
                        x = y = w = 0.964;
                    }
                }

                tmpIterCount++; // (Could check iteration count here.)

                // Look for two consecutive small sub-diagonal elements
                int m = tmpMainIterIndex - 2;
                while (m >= l) {
                    z = aMtrxH[m + tmpDiagDim * m];
                    r = x - z;
                    s = y - z;
                    p = (r * s - w) / aMtrxH[(m + 1) + tmpDiagDim * m] + aMtrxH[m + tmpDiagDim * (m + 1)];
                    q = aMtrxH[(m + 1) + tmpDiagDim * (m + 1)] - z - r - s;
                    r = aMtrxH[(m + 2) + tmpDiagDim * (m + 1)];
                    s = Math.abs(p) + Math.abs(q) + Math.abs(r);
                    p = p / s;
                    q = q / s;
                    r = r / s;
                    if (m == l) {
                        break;
                    }
                    if (Math.abs(aMtrxH[m + tmpDiagDim * (m - 1)]) * (Math.abs(q) + Math.abs(r)) < PrimitiveMath.MACHINE_DOUBLE_ERROR * (Math.abs(p) * (Math.abs(aMtrxH[(m - 1) + tmpDiagDim * (m - 1)]) + Math.abs(z) + Math.abs(aMtrxH[(m + 1) + tmpDiagDim * (m + 1)])))) {
                        break;
                    }
                    m--;
                }

                for (int i = m + 2; i <= tmpMainIterIndex; i++) {
                    aMtrxH[i + tmpDiagDim * (i - 2)] = PrimitiveMath.ZERO;
                    if (i > m + 2) {
                        aMtrxH[i + tmpDiagDim * (i - 3)] = PrimitiveMath.ZERO;
                    }
                }

                // Double QR step involving rows l:n and columns m:n
                for (int k = m; k <= tmpMainIterIndex - 1; k++) {
                    final boolean notlast = (k != tmpMainIterIndex - 1);
                    if (k != m) {
                        p = aMtrxH[k + tmpDiagDim * (k - 1)];
                        q = aMtrxH[(k + 1) + tmpDiagDim * (k - 1)];
                        r = (notlast ? aMtrxH[(k + 2) + tmpDiagDim * (k - 1)] : PrimitiveMath.ZERO);
                        x = Math.abs(p) + Math.abs(q) + Math.abs(r);
                        if (x != PrimitiveMath.ZERO) {
                            p = p / x;
                            q = q / x;
                            r = r / x;
                        }
                    }
                    if (x == PrimitiveMath.ZERO) {
                        break;
                    }
                    s = Math.sqrt(p * p + q * q + r * r);
                    if (p < 0) {
                        s = -s;
                    }
                    if (s != 0) {
                        if (k != m) {
                            aMtrxH[k + tmpDiagDim * (k - 1)] = -s * x;
                        } else if (l != m) {
                            aMtrxH[k + tmpDiagDim * (k - 1)] = -aMtrxH[k + tmpDiagDim * (k - 1)];
                        }
                        p = p + s;
                        x = p / s;
                        y = q / s;
                        z = r / s;
                        q = q / p;
                        r = r / p;

                        // Row modification
                        for (int j = k; j < tmpDiagDim; j++) {
                            p = aMtrxH[k + tmpDiagDim * j] + q * aMtrxH[(k + 1) + tmpDiagDim * j];
                            if (notlast) {
                                p = p + r * aMtrxH[(k + 2) + tmpDiagDim * j];
                                aMtrxH[(k + 2) + tmpDiagDim * j] = aMtrxH[(k + 2) + tmpDiagDim * j] - p * z;
                            }
                            aMtrxH[k + tmpDiagDim * j] = aMtrxH[k + tmpDiagDim * j] - p * x;
                            aMtrxH[(k + 1) + tmpDiagDim * j] = aMtrxH[(k + 1) + tmpDiagDim * j] - p * y;
                        }

                        // Column modification
                        for (int i = 0; i <= Math.min(tmpMainIterIndex, k + 3); i++) {
                            p = x * aMtrxH[i + tmpDiagDim * k] + y * aMtrxH[i + tmpDiagDim * (k + 1)];
                            if (notlast) {
                                p = p + z * aMtrxH[i + tmpDiagDim * (k + 2)];
                                aMtrxH[i + tmpDiagDim * (k + 2)] = aMtrxH[i + tmpDiagDim * (k + 2)] - p * r;
                            }
                            aMtrxH[i + tmpDiagDim * k] = aMtrxH[i + tmpDiagDim * k] - p;
                            aMtrxH[i + tmpDiagDim * (k + 1)] = aMtrxH[i + tmpDiagDim * (k + 1)] - p * q;
                        }

                        // Accumulate transformations
                        for (int i = 0; i <= tmpDiagDimMinusOne; i++) {
                            p = x * aMtrxV[i + tmpDiagDim * k] + y * aMtrxV[i + tmpDiagDim * (k + 1)];
                            if (notlast) {
                                p = p + z * aMtrxV[i + tmpDiagDim * (k + 2)];
                                aMtrxV[i + tmpDiagDim * (k + 2)] = aMtrxV[i + tmpDiagDim * (k + 2)] - p * r;
                            }
                            aMtrxV[i + tmpDiagDim * k] = aMtrxV[i + tmpDiagDim * k] - p;
                            aMtrxV[i + tmpDiagDim * (k + 1)] = aMtrxV[i + tmpDiagDim * (k + 1)] - p * q;
                        }
                    } // (s != 0)
                } // k loop
            } // check convergence
        } // while (n >= low)

        // Backsubstitute to find vectors of upper triangular form
        if (allTheWay && (tmpNorm1 != PrimitiveMath.ZERO)) {
            PrimitiveDenseStore.doAfter(aMtrxH, aMtrxV, tmpMainDiagonal, tmpOffDiagonal, r, s, z, tmpNorm1);
        }

        return new double[][] { tmpMainDiagonal, tmpOffDiagonal };
    }

    static void fillMatching(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final double aLeftArg, final BinaryFunction<Double> aFunc, final MatrixStore<Double> aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg, aRightArg.doubleValue(i, j));
                }
            }
        }
    }

    static void fillMatching(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final MatrixStore<Double> aLeftArg, final BinaryFunction<Double> aFunc, final double aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg.doubleValue(i, j), aRightArg);
                }
            }
        }
    }

    static void fillMatching(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final MatrixStore<Double> aLeftArg, final BinaryFunction<Double> aFunc, final MatrixStore<Double> aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg.doubleValue(i, j), aRightArg.doubleValue(i, j));
                }
            }
        }
    }

    static void fillMatching(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final double aLeftArg, final BinaryFunction<Double> aFunc, final PrimitiveArray aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void fillMatching(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final PrimitiveArray aLeftArg, final BinaryFunction<Double> aFunc, final double aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void fillMatching(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final PrimitiveArray aLeftArg, final BinaryFunction<Double> aFunc, final PrimitiveArray aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void maxpy(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final double aScale, final MatrixStore<Double> aStore, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.maxpy(aData, aRowDim, aFirstCol, tmpSplit, aScale, aStore, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.maxpy(aData, aRowDim, tmpSplit, aColLimit, aScale, aStore, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] += aScale * aStore.doubleValue(i, j);
                }
            }
        }
    }

    static void modifyAll(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final UnaryFunction<Double> aFunc, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.modifyAll(aData, aRowDim, aFirstCol, tmpSplit, aFunc, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.modifyAll(aData, aRowDim, tmpSplit, aColLimit, aFunc, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.modify(aRowDim * aFirstCol, aRowDim * aColLimit, 1, aFunc);
        }
    }

    static void multiplyLeft(final double[] aProductArray, final int aFirstRow, final int aRowLimit, final MatrixStore<Double> aLeftStore, final double[] aRightArray, final int availableCPUs) {

        final int tmpRowCount = aRowLimit - aFirstRow;

        if ((availableCPUs > 1) && (tmpRowCount > BranchLimit.MULTIPLY)) {

            final int tmpSplit = aFirstRow + tmpRowCount / 2;
            final int tmpAvailableCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.multiplyLeft(aProductArray, aFirstRow, tmpSplit, aLeftStore, aRightArray, tmpAvailableCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.multiplyLeft(aProductArray, tmpSplit, aRowLimit, aLeftStore, aRightArray, tmpAvailableCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpRowDim = aLeftStore.getRowDim();
            final int tmpCalcSize = aLeftStore.getColDim();
            final int tmpColDim = aRightArray.length / tmpCalcSize;

            final double[] tmpLeftRow = new double[tmpCalcSize];
            int tmpIndex;
            double tmpVal;

            for (int i = aFirstRow; i < aRowLimit; i++) {
                for (int c = 0; c < tmpCalcSize; c++) {
                    tmpLeftRow[c] = aLeftStore.doubleValue(i, c);
                }
                for (int j = 0; j < tmpColDim; j++) {
                    tmpIndex = j * tmpCalcSize;
                    tmpVal = ZERO;
                    for (int c = 0; c < tmpCalcSize; c++) {
                        tmpVal += tmpLeftRow[c] * aRightArray[tmpIndex++];
                    }
                    aProductArray[i + j * tmpRowDim] = tmpVal;
                }
            }
        }
    }

    static void multiplyLeft2(final double[] aProductArray, final int aFirstRow, final int aRowLimit, final int aFirstCol, final int aColLimit, final MatrixStore<Double> aLeftStore, final double[] aRightArray, final int availableCPUs) {

        final int tmpRowCount = aRowLimit - aFirstRow;

        if ((availableCPUs > 1) && (tmpRowCount > BranchLimit.MULTIPLY)) {

            final int tmpAvailableCPUs = availableCPUs / 2;

            final int tmpColCount = aColLimit - aFirstCol;

            if (tmpColCount > tmpRowCount) {

                final int tmpColSplit = aFirstCol + tmpColCount / 2;

                final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                    public void run() {
                        PrimitiveDenseStore.multiplyLeft2(aProductArray, aFirstRow, aRowLimit, aFirstCol, tmpColSplit, aLeftStore, aRightArray, tmpAvailableCPUs);
                    }
                });

                final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                    public void run() {
                        PrimitiveDenseStore.multiplyLeft2(aProductArray, aFirstRow, aRowLimit, tmpColSplit, aColLimit, aLeftStore, aRightArray, tmpAvailableCPUs);
                    }
                });

                try {
                    tmpFirstPart.get();
                    tmpSecondPart.get();
                } catch (final InterruptedException anException) {
                    anException.printStackTrace();
                } catch (final ExecutionException anException) {
                    anException.printStackTrace();
                }

            } else {

                final int tmpRowSplit = aFirstRow + tmpRowCount / 2;

                final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                    public void run() {
                        PrimitiveDenseStore.multiplyLeft2(aProductArray, aFirstRow, tmpRowSplit, aFirstCol, aColLimit, aLeftStore, aRightArray, tmpAvailableCPUs);
                    }
                });

                final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                    public void run() {
                        PrimitiveDenseStore.multiplyLeft2(aProductArray, tmpRowSplit, aRowLimit, aFirstCol, aColLimit, aLeftStore, aRightArray, tmpAvailableCPUs);
                    }
                });

                try {
                    tmpFirstPart.get();
                    tmpSecondPart.get();
                } catch (final InterruptedException anException) {
                    anException.printStackTrace();
                } catch (final ExecutionException anException) {
                    anException.printStackTrace();
                }
            }

        } else {

            final int tmpRowDim = aLeftStore.getRowDim();
            final int tmpCalcSize = aLeftStore.getColDim();
            //final int tmpColDim = aRightArray.length / tmpCalcSize;

            final double[] tmpLeftRow = new double[tmpCalcSize];
            int tmpIndex;
            double tmpVal;

            for (int i = aFirstRow; i < aRowLimit; i++) {
                for (int c = 0; c < tmpCalcSize; c++) {
                    tmpLeftRow[c] = aLeftStore.doubleValue(i, c);
                }
                for (int j = aFirstCol; j < aColLimit; j++) {
                    tmpIndex = j * tmpCalcSize;
                    tmpVal = ZERO;
                    for (int c = 0; c < tmpCalcSize; c++) {
                        tmpVal += tmpLeftRow[c] * aRightArray[tmpIndex++];
                    }
                    aProductArray[i + j * tmpRowDim] = tmpVal;
                }
            }
        }
    }

    static void multiplyLeft3(final double[] aProductArray, final int aFirstRow, final int aRowLimit, final MatrixStore<Double> aLeftStore, final double[] aRightArray, final int availableCPUs) {

        final int tmpRowCount = aRowLimit - aFirstRow;

        if ((availableCPUs > 1) && (tmpRowCount > BranchLimit.MULTIPLY)) {

            final int tmpSplit = aFirstRow + tmpRowCount / 2;
            final int tmpAvailableCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.multiplyLeft3(aProductArray, aFirstRow, tmpSplit, aLeftStore, aRightArray, tmpAvailableCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.multiplyLeft3(aProductArray, tmpSplit, aRowLimit, aLeftStore, aRightArray, tmpAvailableCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpRowDim = aLeftStore.getRowDim();
            final int tmpCalcSize = aLeftStore.getColDim();
            final int tmpColDim = aRightArray.length / tmpCalcSize;

            final double[] tmpLeftRow = new double[tmpCalcSize];
            final double[] tmpProdRow = new double[tmpColDim];
            int tmpIndex;
            double tmpVal;

            for (int i = aFirstRow; i < aRowLimit; i++) {
                for (int c = 0; c < tmpCalcSize; c++) {
                    tmpLeftRow[c] = aLeftStore.doubleValue(i, c);
                }
                for (int j = 0; j < tmpColDim; j++) {
                    tmpIndex = j * tmpCalcSize;
                    tmpVal = ZERO;
                    for (int c = 0; c < tmpCalcSize; c++) {
                        tmpVal += tmpLeftRow[c] * aRightArray[tmpIndex++];
                    }
                    tmpProdRow[j] = tmpVal;
                }
                tmpIndex = i;
                for (int j = 0; j < tmpColDim; j++) {
                    aProductArray[tmpIndex] = tmpProdRow[j];
                    tmpIndex += tmpRowDim;
                }
            }
        }
    }

    static void multiplyRight(final double[] aProductArray, final int aFirstCol, final int aColLimit, final double[] aLeftArray, final MatrixStore<Double> aRightStore, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.MULTIPLY)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpAvailableCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.multiplyRight(aProductArray, aFirstCol, tmpSplit, aLeftArray, aRightStore, tmpAvailableCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.multiplyRight(aProductArray, tmpSplit, aColLimit, aLeftArray, aRightStore, tmpAvailableCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            //final int tmpColDim = aRightStore.getColDim();
            final int tmpCalcSize = aRightStore.getRowDim();
            final int tmpRowDim = aLeftArray.length / tmpCalcSize;

            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int c = 0; c < tmpCalcSize; c++) {
                    PrimitiveDenseStore.caxpy(aRightStore.doubleValue(c, j), aLeftArray, c, aProductArray, j, 0, tmpRowDim);
                }
            }
        }
    }

    static void multiplyRight2(final double[] aProductArray, final int aFirstCol, final int aColLimit, final double[] aLeftArray, final MatrixStore<Double> aRightStore, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        //final int tmpColDim = aRightStore.getColDim();
        final int tmpCalcSize = aRightStore.getRowDim();
        final int tmpRowDim = aLeftArray.length / tmpCalcSize;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.MULTIPLY)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpAvailableCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.multiplyRight2(aProductArray, aFirstCol, tmpSplit, aLeftArray, aRightStore, tmpAvailableCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.multiplyRight2(aProductArray, tmpSplit, aColLimit, aLeftArray, aRightStore, tmpAvailableCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int c = 0; c < tmpCalcSize; c++) {
                    for (int i = 0; i < tmpRowDim; i++) {
                        aProductArray[i + j * tmpRowDim] += aLeftArray[i + c * tmpRowDim] * aRightStore.doubleValue(c, j);
                    }
                }
            }
        }
    }

    static void raxpy(final double factorA, final double[] arrayX, final int rowX, final double[] arrayY, final int rowY, final int aFirstCol, final int aColDim) {

        final int tmpRowDim = arrayY.length / aColDim;

        int tmpIndexX = rowX + aFirstCol * tmpRowDim;
        int tmpIndexY = rowY + aFirstCol * tmpRowDim;

        for (int i = aFirstCol; i < aColDim; i++) {
            arrayY[tmpIndexY] += factorA * arrayX[tmpIndexX];
            tmpIndexX += tmpRowDim;
            tmpIndexY += tmpRowDim;
        }
    }

    static void substituteBackwards(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<Double> aBody, final boolean transposed, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.substituteBackwards(aData, aRowDim, aFirstCol, tmpSplit, aBody, transposed, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.substituteBackwards(aData, aRowDim, tmpSplit, aColLimit, aBody, transposed, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpDiagDim = Math.min(aBody.getRowDim(), aBody.getColDim());

            final double[] tmpBodyRow = new double[tmpDiagDim];
            double tmpVal;
            int tmpColBaseIndex;

            for (int i = tmpDiagDim - 1; i >= 0; i--) {

                for (int j = i; j < tmpDiagDim; j++) {
                    tmpBodyRow[j] = transposed ? aBody.doubleValue(j, i) : aBody.doubleValue(i, j);
                }

                for (int s = aFirstCol; s < aColLimit; s++) {
                    tmpColBaseIndex = s * aRowDim;

                    tmpVal = ZERO;
                    for (int j = i + 1; j < tmpDiagDim; j++) {
                        tmpVal += tmpBodyRow[j] * aData[j + tmpColBaseIndex];
                    }
                    tmpVal = aData[i + tmpColBaseIndex] - tmpVal;

                    aData[i + tmpColBaseIndex] = tmpVal / tmpBodyRow[i];
                }
            }
        }
    }

    static void substituteForwards(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<Double> aBody, final boolean onesOnDiagonal, final Access2D<Double> aRHS, final boolean zerosAboveDiagonal, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.substituteForwards(aData, aRowDim, aFirstCol, tmpSplit, aBody, onesOnDiagonal, aRHS, zerosAboveDiagonal, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.substituteForwards(aData, aRowDim, tmpSplit, aColLimit, aBody, onesOnDiagonal, aRHS, zerosAboveDiagonal, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpDiagDim = Math.min(aBody.getRowDim(), aBody.getColDim());
            final double[] tmpBodyRow = new double[tmpDiagDim];
            double tmpVal;
            int tmpColBaseIndex;

            for (int i = 0; i < tmpDiagDim; i++) {

                for (int j = 0; j <= i; j++) {
                    tmpBodyRow[j] = aBody.doubleValue(i, j);
                }

                for (int s = aFirstCol; s < aColLimit; s++) {
                    tmpColBaseIndex = s * aRowDim;

                    tmpVal = ZERO;
                    for (int j = zerosAboveDiagonal ? s : 0; j < i; j++) {
                        tmpVal += tmpBodyRow[j] * aData[j + tmpColBaseIndex];
                    }
                    tmpVal = aRHS.doubleValue(i, s) - tmpVal;
                    if (!onesOnDiagonal) {
                        tmpVal /= tmpBodyRow[i];
                    }

                    aData[i + tmpColBaseIndex] = tmpVal;
                }
            }
        }
    }

    static void transpose(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<? extends Number> aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.transpose(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.transpose(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aSource.doubleValue(j, i);
                }
            }
        }
    }

    static void updateLU(final double[] aData, final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColLimit, final double[] aMultipliers, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.updateLU(aData, aPivotRow, aRowDim, aFirstCol, tmpSplit, aMultipliers, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = DaemonPoolExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.updateLU(aData, aPivotRow, aRowDim, tmpSplit, aColLimit, aMultipliers, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            double tmpVal;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {
                tmpVal = aData[tmpIndex = aPivotRow + j * aRowDim];
                for (int i = aPivotRow + 1; i < aRowDim; i++) {
                    aData[++tmpIndex] -= aMultipliers[i] * tmpVal;
                }
            }
        }
    }

    private final int myColDim;

    private final int myRowDim;

    private final Array2D<Double> myUtility;

    PrimitiveDenseStore(final double[] anArray) {

        super(anArray);

        myRowDim = anArray.length;
        myColDim = 1;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    PrimitiveDenseStore(final int aLength) {

        super(aLength);

        myRowDim = aLength;
        myColDim = 1;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    PrimitiveDenseStore(final int aRowDim, final int aColDim) {

        super(aRowDim * aColDim);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    PrimitiveDenseStore(final int aRowDim, final int aColDim, final double[] anArray) {

        super(anArray);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    public Double aggregateAll(final ChainableAggregator aVisitor) {
        return PrimitiveDenseStore.aggregateAll(this, myRowDim, 0, myColDim, aVisitor, ProcessorCount.RUNTIME);
    }

    public Double aggregateAll(final CollectableAggregator aVisitor) {
        return PrimitiveDenseStore.aggregateAll(this, myRowDim, 0, myColDim, aVisitor, ProcessorCount.RUNTIME);
    }

    public Array2D<Double> asArray2D() {
        return myUtility;
    }

    public Array1D<Double> asList() {
        return myUtility.asArray1D();
    }

    public final MatrixStore.Builder<Double> builder() {
        return new MatrixStore.Builder<Double>(this);
    }

    public void caxpy(final Double aSclrA, final int aColX, final int aColY, final int aFirstRow) {
        final double[] tmpData = this.data();
        PrimitiveDenseStore.caxpy(aSclrA.doubleValue(), tmpData, aColX, tmpData, aColY, aFirstRow, myRowDim);
    }

    public void computeInPlaceBidiagonal(final boolean upper) {

        final double[] tmpData = this.data();
        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        final Householder.Primitive tmpHouseholderCol = new Householder.Primitive(tmpRowDim);
        final Householder.Primitive tmpHouseholderRow = new Householder.Primitive(tmpColDim);

        if (upper) {

            final int tmpLimit = Math.min(tmpRowDim, tmpColDim);
            for (int ij = 0; ij < tmpLimit; ij++) {

                if ((ij + 1 < tmpRowDim) && this.generateApplyAndCopyHouseholderColumn(ij, ij, tmpHouseholderCol)) {
                    PrimitiveDenseStore.doHouseholderLeft(tmpData, tmpRowDim, ij + 1, tmpColDim, tmpHouseholderCol, ProcessorCount.RUNTIME);
                }

                if ((ij + 2 < tmpColDim) && this.generateApplyAndCopyHouseholderRow(ij, ij + 1, tmpHouseholderRow)) {
                    PrimitiveDenseStore.doHouseholderRight(tmpData, ij + 1, tmpRowDim, tmpColDim, tmpHouseholderRow, ProcessorCount.RUNTIME);
                }
            }

        } else {

            final int tmpLimit = Math.min(tmpRowDim, tmpColDim);
            for (int ij = 0; ij < tmpLimit; ij++) {

                if ((ij + 1 < tmpColDim) && this.generateApplyAndCopyHouseholderRow(ij, ij, tmpHouseholderRow)) {
                    PrimitiveDenseStore.doHouseholderRight(tmpData, ij + 1, tmpRowDim, tmpColDim, tmpHouseholderRow, ProcessorCount.RUNTIME);
                }

                if ((ij + 2 < tmpRowDim) && this.generateApplyAndCopyHouseholderColumn(ij + 1, ij, tmpHouseholderCol)) {
                    PrimitiveDenseStore.doHouseholderLeft(tmpData, tmpRowDim, ij + 1, tmpColDim, tmpHouseholderCol, ProcessorCount.RUNTIME);
                }
            }
        }
    }

    public boolean computeInPlaceCholesky(final boolean checkForSPD) {

        // true if (Symmetric) Positive Definite 
        boolean retVal = myRowDim == myColDim;

        final int tmpDim = myRowDim;

        final double[] tmpData = this.data();
        int tmpDataIndex;

        // Check for symmetry, maybe
        if (retVal && checkForSPD) {
            for (int j = 0; retVal && (j < tmpDim); j++) {
                for (int i = j + 1; retVal && (i < tmpDim); i++) {
                    retVal &= TypeUtils.isZero(tmpData[i + j * tmpDim] - tmpData[j + i * tmpDim]);
                }
            }
        }

        final double[] tmpColumn = new double[tmpDim];
        double tmpVal;

        // Main loop - along the diagonal
        for (int ij = 0; retVal && (ij < tmpDim); ij++) {

            // "Pivot" element
            tmpVal = tmpData[tmpDataIndex = ij + ij * tmpDim];

            if (tmpVal > ZERO) {

                tmpColumn[ij] = tmpData[tmpDataIndex] = tmpVal = Math.sqrt(tmpVal);

                // Calculate multipliers and copy to local column
                // Current column, below the diagonal
                for (int i = ij + 1; i < tmpDim; i++) {
                    tmpColumn[i] = tmpData[++tmpDataIndex] /= tmpVal;
                }

                // Remaining columns, below the diagonal
                PrimitiveDenseStore.doCholeskyStep(tmpData, ij, tmpDim, ij + 1, tmpDim, tmpColumn, ProcessorCount.RUNTIME);

            } else {

                retVal = false;
            }
        }

        return retVal;
    }

    public void computeInPlaceHessenberg(final boolean upper) {

        final double[] tmpData = this.data();
        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (upper) {

            final Householder.Primitive tmpHouseholderCol = new Householder.Primitive(tmpRowDim);

            final int tmpLimit = Math.min(tmpRowDim, tmpColDim) - 2;
            for (int ij = 0; ij < tmpLimit; ij++) {
                if (this.generateApplyAndCopyHouseholderColumn(ij + 1, ij, tmpHouseholderCol)) {
                    PrimitiveDenseStore.doHouseholderLeft(tmpData, tmpRowDim, ij + 1, tmpColDim, tmpHouseholderCol, ProcessorCount.RUNTIME);
                    PrimitiveDenseStore.doHouseholderRight(tmpData, 0, tmpRowDim, tmpColDim, tmpHouseholderCol, ProcessorCount.RUNTIME);
                }
            }

        } else {

            final Householder.Primitive tmpHouseholderRow = new Householder.Primitive(tmpColDim);

            final int tmpLimit = Math.min(tmpRowDim, tmpColDim) - 2;
            for (int ij = 0; ij < tmpLimit; ij++) {
                if (this.generateApplyAndCopyHouseholderRow(ij, ij + 1, tmpHouseholderRow)) {
                    PrimitiveDenseStore.doHouseholderRight(tmpData, ij + 1, tmpRowDim, tmpColDim, tmpHouseholderRow, ProcessorCount.RUNTIME);
                    PrimitiveDenseStore.doHouseholderLeft(tmpData, tmpRowDim, 0, tmpColDim, tmpHouseholderRow, ProcessorCount.RUNTIME);
                }
            }
        }
    }

    public Pivot computeInPlaceLU(final boolean assumeNoPivotingRequired) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;
        final int tmpMinDim = Math.min(tmpRowDim, tmpColDim);

        final Pivot retVal = new Pivot(tmpRowDim);

        final double[] tmpData = this.data();
        int tmpDataIndex;

        int tmpPivotRowIndex;

        final double[] tmpColumn = new double[tmpRowDim];
        double tmpVal;

        // Main loop - along the diagonal
        for (int ij = 0; ij < tmpMinDim; ij++) {

            if (!assumeNoPivotingRequired) {
                // Find next pivot row, stop searching when something good enough is found
                tmpVal = Math.abs(tmpData[tmpDataIndex = ij + tmpRowDim * ij]);
                tmpPivotRowIndex = ij;
                for (int i = ij + 1; (i < tmpRowDim) && (tmpVal < HALF); i++) {
                    if (Math.abs(tmpData[++tmpDataIndex]) > tmpVal) {
                        tmpVal = Math.abs(tmpData[tmpDataIndex]);
                        tmpPivotRowIndex = i;
                    }
                }
                // Pivot?
                if (tmpPivotRowIndex != ij) {
                    myUtility.exchangeRows(tmpPivotRowIndex, ij);
                    retVal.change(tmpPivotRowIndex, ij);
                }
            }

            // Do the calculations...

            // "Pivot" element
            tmpVal = tmpData[tmpDataIndex = ij + ij * tmpRowDim];
            if (!TypeUtils.isZero(tmpVal)) {

                // Calculate multipliers and copy to local column
                // Current column, below the diagonal
                for (int i = ij + 1; i < tmpRowDim; i++) {
                    tmpColumn[i] = tmpData[++tmpDataIndex] /= tmpVal;
                }

                // Apply transformations to everything below and to the right of the pivot element
                PrimitiveDenseStore.updateLU(tmpData, ij, tmpRowDim, ij + 1, tmpColDim, tmpColumn, ProcessorCount.RUNTIME);

            } else {

                tmpData[tmpDataIndex] = ZERO;
            }
        }

        return retVal;
    }

    public void computeInPlaceQR() {

        final double[] tmpData = this.data();
        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        final Householder.Primitive tmpHouseholder = new Householder.Primitive(tmpRowDim);

        final int tmpLimit = Math.min(tmpRowDim, tmpColDim);
        for (int ij = 0; ij < tmpLimit; ij++) {
            if ((ij + 1 < tmpRowDim) && this.generateApplyAndCopyHouseholderColumn(ij, ij, tmpHouseholder)) {
                PrimitiveDenseStore.doHouseholderLeft(tmpData, tmpRowDim, ij + 1, tmpColDim, tmpHouseholder, ProcessorCount.RUNTIME);
            }
        }
    }

    public Array1D<ComplexNumber> computeInPlaceSchur(final PhysicalStore<Double> aTransformationCollector, final boolean eigenvalue) {

        //        final PrimitiveDenseStore tmpThisCopy = this.copy();
        //        final PrimitiveDenseStore tmpCollCopy = (PrimitiveDenseStore) aTransformationCollector.copy();
        //
        //        tmpThisCopy.computeInPlaceHessenberg(true);

        // Actual

        final double[] tmpData = this.data();

        final double[] tmpCollectorData = ((PrimitiveDenseStore) aTransformationCollector).data();

        PrimitiveDenseStore.doHessenberg(tmpData, tmpCollectorData);

        //        BasicLogger.logDebug("Schur Step", this);
        //        BasicLogger.logDebug("Hessenberg", tmpThisCopy);

        final double[][] tmpDiags = PrimitiveDenseStore.doSchur(tmpData, tmpCollectorData, eigenvalue);
        return Array1D.makeComplex(tmpDiags[0], tmpDiags[1]);
    }

    public void computeInPlaceTridiagonal() {

        final double[] tmpData = this.data();
        final int tmpRowDim = myRowDim; // Which is also the col-dim.

        final Householder.Primitive tmpHouseholder = new Householder.Primitive(tmpRowDim);
        final double[] tmpDerived = new double[tmpRowDim];

        final int tmpLimit = tmpRowDim - 2;
        for (int ij = 0; ij < tmpLimit; ij++) {

            if (this.generateApplyAndCopyHouseholderColumn(ij + 1, ij, tmpHouseholder)) {

                PrimitiveDenseStore.doHouseholderBoth1Derive(tmpData, tmpHouseholder.first, tmpRowDim, tmpHouseholder, tmpDerived, ProcessorCount.RUNTIME);

                PrimitiveDenseStore.doHouseholderBoth2Scale(tmpHouseholder, tmpDerived);

                PrimitiveDenseStore.doHouseholderBoth3Update(tmpData, tmpHouseholder.first, tmpRowDim, tmpHouseholder, tmpDerived, ProcessorCount.RUNTIME);
            }
        }
    }

    public PrimitiveDenseStore conjugate() {
        return this.transpose();
    }

    public PrimitiveDenseStore copy() {
        return new PrimitiveDenseStore(myRowDim, myColDim, this.copyOfData());
    }

    public double doubleValue(final int aRow, final int aCol) {
        return myUtility.doubleValue(aRow, aCol);
    }

    public boolean equals(final MatrixStore<Double> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(this, aStore, aCntxt);
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(final Object anObj) {
        if (anObj instanceof MatrixStore) {
            return this.equals((MatrixStore<Double>) anObj, TypeUtils.EQUALS_NUMBER_CONTEXT);
        } else {
            return super.equals(anObj);
        }
    }

    public void exchangeColumns(final int aColA, final int aColB) {
        myUtility.exchangeColumns(aColA, aColB);
    }

    public void exchangeRows(final int aRowA, final int aRowB) {
        myUtility.exchangeRows(aRowA, aRowB);
    }

    public void fillAll(final Double aNmbr) {
        myUtility.fillAll(aNmbr);
    }

    public void fillByMultiplying(final MatrixStore<Double> aLeftArg, final MatrixStore<Double> aRightArg) {
        if ((aLeftArg instanceof PrimitiveDenseStore) && !(aRightArg instanceof PrimitiveDenseStore)) {
            PrimitiveDenseStore.multiplyRight(this.data(), 0, myColDim, this.cast(aLeftArg).data(), aRightArg, ProcessorCount.RUNTIME);
        } else {
            PrimitiveDenseStore.multiplyLeft(this.data(), 0, myRowDim, aLeftArg, this.cast(aRightArg).data(), ProcessorCount.RUNTIME);
        }
    }

    public void fillColumn(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.fillColumn(aRow, aCol, aNmbr);
    }

    public void fillDiagonal(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.fillDiagonal(aRow, aCol, aNmbr);
    }

    public void fillMatching(final Access2D<Double> aSource2D) {
        PrimitiveDenseStore.copy(this.data(), myRowDim, 0, myColDim, aSource2D, ProcessorCount.RUNTIME);
    }

    public void fillMatching(final Double aLeftArg, final BinaryFunction<Double> aFunc, final MatrixStore<Double> aRightArg) {
        if (aRightArg instanceof PrimitiveArray) {
            PrimitiveDenseStore.fillMatching(this, myRowDim, 0, myColDim, aLeftArg, aFunc, (PrimitiveArray) aRightArg, ProcessorCount.RUNTIME);
        } else {
            PrimitiveDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillMatching(final MatrixStore<Double> aLeftArg, final BinaryFunction<Double> aFunc, final Double aRightArg) {
        if (aLeftArg instanceof PrimitiveArray) {
            PrimitiveDenseStore.fillMatching(this, myRowDim, 0, myColDim, (PrimitiveArray) aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        } else {
            PrimitiveDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillMatching(final MatrixStore<Double> aLeftArg, final BinaryFunction<Double> aFunc, final MatrixStore<Double> aRightArg) {
        if ((aLeftArg instanceof PrimitiveArray) && (aRightArg instanceof PrimitiveArray)) {
            PrimitiveDenseStore.fillMatching(this, myRowDim, 0, myColDim, (PrimitiveArray) aLeftArg, aFunc, (PrimitiveArray) aRightArg, ProcessorCount.RUNTIME);
        } else {
            PrimitiveDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillRow(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.fillRow(aRow, aCol, aNmbr);
    }

    public Double get(final int aRow, final int aCol) {
        return myUtility.get(aRow, aCol);
    }

    public int getColDim() {
        return myColDim;
    }

    public PhysicalStore.Factory<Double> getFactory() {
        return FACTORY;
    }

    public int getIndexOfLargestInColumn(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInColumn(aRow, aCol);
    }

    public int getIndexOfLargestInRow(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInRow(aRow, aCol);
    }

    public int getMinDim() {
        return Math.min(myRowDim, myColDim);
    }

    public int getRowDim() {
        return myRowDim;
    }

    @Override
    public int hashCode() {
        return MatrixUtils.hashCode(this);
    }

    public boolean isAbsolute(final int aRow, final int aCol) {
        return myUtility.isAbsolute(aRow, aCol);
    }

    public boolean isReal(final int aRow, final int aCol) {
        return myUtility.isReal(aRow, aCol);
    }

    public boolean isZero(final int aRow, final int aCol) {
        return this.isZero(aRow + aCol * myRowDim);
    }

    public void maxpy(final Double aSclrA, final MatrixStore<Double> aMtrxX) {
        PrimitiveDenseStore.maxpy(this.data(), myRowDim, 0, myColDim, aSclrA, aMtrxX, ProcessorCount.RUNTIME);
    }

    public void modifyAll(final UnaryFunction<Double> aFunc) {
        PrimitiveDenseStore.modifyAll(this, myRowDim, 0, myColDim, aFunc, ProcessorCount.RUNTIME);
    }

    public void modifyColumn(final int aRow, final int aCol, final UnaryFunction<Double> aFunc) {
        myUtility.modifyColumn(aRow, aCol, aFunc);
    }

    public void modifyDiagonal(final int aRow, final int aCol, final UnaryFunction<Double> aFunc) {
        myUtility.modifyDiagonal(aRow, aCol, aFunc);
    }

    public void modifyRow(final int aRow, final int aCol, final UnaryFunction<Double> aFunc) {
        myUtility.modifyRow(aRow, aCol, aFunc);
    }

    public MatrixStore<Double> multiplyLeft(final MatrixStore<Double> aStore) {

        final int tmpRowDim = aStore.getRowDim();
        final int tmpColDim = myColDim;

        final double[] retVal = new double[tmpRowDim * tmpColDim];

        PrimitiveDenseStore.multiplyLeft(retVal, 0, tmpRowDim, aStore, this.data(), ProcessorCount.RUNTIME);

        return new PrimitiveDenseStore(tmpRowDim, tmpColDim, retVal);
    }

    public MatrixStore<Double> multiplyRight(final MatrixStore<Double> aStore) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = aStore.getColDim();

        final double[] retVal = new double[tmpRowDim * tmpColDim];

        PrimitiveDenseStore.multiplyRight(retVal, 0, tmpColDim, this.data(), aStore, ProcessorCount.RUNTIME);

        return new PrimitiveDenseStore(tmpRowDim, tmpColDim, retVal);
    }

    public void raxpy(final Double aSclrA, final int aRowX, final int aRowY, final int aFirstCol) {
        final double[] tmpData = this.data();
        PrimitiveDenseStore.raxpy(aSclrA.doubleValue(), tmpData, aRowX, tmpData, aRowY, aFirstCol, myColDim);
    }

    public void set(final int aRow, final int aCol, final double aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void set(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void substituteBackwards(final Access2D<Double> aBody, final boolean transposed) {
        PrimitiveDenseStore.substituteBackwards(this.data(), myRowDim, 0, myColDim, aBody, transposed, ProcessorCount.RUNTIME);
    }

    public void substituteForwards(final Access2D<Double> aBody, final boolean onesOnDiagonal, final Access2D<Double> aRHS, final boolean zerosAboveDiagonal) {
        PrimitiveDenseStore.substituteForwards(this.data(), myRowDim, 0, myColDim, aBody, onesOnDiagonal, aRHS, zerosAboveDiagonal, ProcessorCount.RUNTIME);
    }

    public PrimitiveScalar toScalar(final int aRow, final int aCol) {
        return new PrimitiveScalar(this.doubleValue(aRow + aCol * myRowDim));
    }

    public void transformLeft(final DecompositionStore.HouseholderReference<Double> aTransf, final int aFirstCol) {
        if (!aTransf.isZero()) {
            PrimitiveDenseStore.doHouseholderLeft(this.data(), myRowDim, aFirstCol, myColDim, aTransf.getPrimitiveWorkCopy().copy(aTransf), ProcessorCount.RUNTIME);
        }
    }

    public void transformLeft(final Householder<Double> aTransf, final int aFirstCol) {
        PrimitiveDenseStore.doHouseholderLeft(this.data(), myRowDim, aFirstCol, myColDim, new Householder.Primitive(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformLeft(final Rotation<Double> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {
            if ((aTransf.cos != null) && (aTransf.sin != null)) {
                PrimitiveDenseStore.doRotateLeft(this.data(), myColDim, tmpLow, tmpHigh, aTransf.cos, aTransf.sin);
            } else {
                myUtility.exchangeRows(tmpLow, tmpHigh);
            }
        } else {
            if (aTransf.cos != null) {
                myUtility.modifyRow(tmpLow, 0, MULTIPLY, aTransf.cos);
            } else if (aTransf.sin != null) {
                myUtility.modifyRow(tmpLow, 0, DIVIDE, aTransf.sin);
            } else {
                myUtility.modifyRow(tmpLow, 0, NEGATE);
            }
        }
    }

    public void transformRight(final DecompositionStore.HouseholderReference<Double> aTransf, final int aFirstRow) {
        if (!aTransf.isZero()) {
            PrimitiveDenseStore.doHouseholderRight(this.data(), aFirstRow, myRowDim, myColDim, aTransf.getPrimitiveWorkCopy().copy(aTransf), ProcessorCount.RUNTIME);
        }
    }

    public void transformRight(final Householder<Double> aTransf, final int aFirstRow) {
        PrimitiveDenseStore.doHouseholderRight(this.data(), aFirstRow, myRowDim, myColDim, new Householder.Primitive(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformRight(final Rotation<Double> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {
            if ((aTransf.cos != null) && (aTransf.sin != null)) {
                PrimitiveDenseStore.doRotateRight(this.data(), myRowDim, tmpLow, tmpHigh, aTransf.cos, aTransf.sin);
            } else {
                myUtility.exchangeColumns(tmpLow, tmpHigh);
            }
        } else {
            if (aTransf.cos != null) {
                myUtility.modifyColumn(0, tmpHigh, MULTIPLY, aTransf.cos);
            } else if (aTransf.sin != null) {
                myUtility.modifyColumn(0, tmpHigh, DIVIDE, aTransf.sin);
            } else {
                myUtility.modifyColumn(0, tmpHigh, NEGATE);
            }
        }
    }

    public PrimitiveDenseStore transpose() {
        return (PrimitiveDenseStore) FACTORY.transpose(this);
    }

    public void visitAll(final AggregatorFunction<Double> aVisitor) {
        myUtility.visitAll(aVisitor);
    }

    public void visitColumn(final int aRow, final int aCol, final AggregatorFunction<Double> aVisitor) {
        myUtility.visitColumn(aRow, aCol, aVisitor);
    }

    public void visitDiagonal(final int aRow, final int aCol, final AggregatorFunction<Double> aVisitor) {
        myUtility.visitDiagonal(aRow, aCol, aVisitor);
    }

    public void visitRow(final int aRow, final int aCol, final AggregatorFunction<Double> aVisitor) {
        myUtility.visitRow(aRow, aCol, aVisitor);
    }

    private final PrimitiveDenseStore cast(final MatrixStore<Double> aStore) {
        if (aStore instanceof PrimitiveDenseStore) {
            return (PrimitiveDenseStore) aStore;
        } else {
            return (PrimitiveDenseStore) FACTORY.copy(aStore);
        }
    }

    private final boolean generateApplyAndCopyHouseholderColumn(final int aRow, final int aCol, final Householder.Primitive aDestination) {

        final double[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColBase = aCol * tmpRowDim;

        final double[] tmpVector = aDestination.vector;
        aDestination.first = aRow;

        double tmpNormInf = ZERO; // Copy column and calculate its infinity-norm.
        for (int i = aRow; i < tmpRowDim; i++) {
            tmpNormInf = Math.max(tmpNormInf, Math.abs(tmpVector[i] = tmpData[i + tmpColBase]));
        }

        boolean retVal = tmpNormInf != ZERO;
        double tmpVal;
        double tmpNorm2 = ZERO;

        if (retVal) {
            for (int i = aRow + 1; i < tmpRowDim; i++) {
                tmpVal = tmpVector[i] /= tmpNormInf;
                tmpNorm2 += tmpVal * tmpVal;
            }
            retVal = !TypeUtils.isZero(tmpNorm2);
        }

        if (retVal) {

            double tmpScale = tmpVector[aRow] / tmpNormInf;
            tmpNorm2 += tmpScale * tmpScale;
            tmpNorm2 = Math.sqrt(tmpNorm2); // 2-norm of the vector to transform (scaled by inf-norm)

            if (tmpScale <= ZERO) {
                tmpScale -= tmpNorm2;
                tmpData[(aRow + tmpColBase)] = tmpNorm2 * tmpNormInf;
            } else {
                tmpScale += tmpNorm2;
                tmpData[(aRow + tmpColBase)] = -tmpNorm2 * tmpNormInf;
            }
            tmpVector[aRow] = ONE;

            for (int i = aRow + 1; i < tmpRowDim; i++) {
                tmpData[i + tmpColBase] = tmpVector[i] /= tmpScale;
            }

            aDestination.beta = Math.abs(tmpScale) / tmpNorm2;
        }

        return retVal;
    }

    private final boolean generateApplyAndCopyHouseholderRow(final int aRow, final int aCol, final Householder.Primitive aDestination) {

        final double[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        final double[] tmpVector = aDestination.vector;
        aDestination.first = aCol;

        double tmpNormInf = ZERO; // Copy row and calculate its infinity-norm.
        for (int j = aCol; j < tmpColDim; j++) {
            tmpNormInf = Math.max(tmpNormInf, Math.abs(tmpVector[j] = tmpData[aRow + j * tmpRowDim]));
        }

        boolean retVal = tmpNormInf != ZERO;
        double tmpVal;
        double tmpNorm2 = ZERO;

        if (retVal) {
            for (int j = aCol + 1; j < tmpColDim; j++) {
                tmpVal = tmpVector[j] /= tmpNormInf;
                tmpNorm2 += tmpVal * tmpVal;
            }
            retVal = !TypeUtils.isZero(tmpNorm2);
        }

        if (retVal) {

            double tmpScale = tmpVector[aCol] / tmpNormInf;
            tmpNorm2 += tmpScale * tmpScale;
            tmpNorm2 = Math.sqrt(tmpNorm2); // 2-norm of the vector to transform (scaled by inf-norm)

            if (tmpScale <= ZERO) {
                tmpScale -= tmpNorm2;
                tmpData[(aRow + aCol * tmpRowDim)] = tmpNorm2 * tmpNormInf;
            } else {
                tmpScale += tmpNorm2;
                tmpData[(aRow + aCol * tmpRowDim)] = -tmpNorm2 * tmpNormInf;
            }
            tmpVector[aCol] = ONE;

            for (int j = aCol + 1; j < tmpColDim; j++) {
                tmpData[aRow + j * tmpRowDim] = tmpVector[j] /= tmpScale;
            }

            aDestination.beta = Math.abs(tmpScale) / tmpNorm2;
        }

        return retVal;
    }

}
