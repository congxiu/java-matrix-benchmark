package org.ojalgo.matrix.transformation;

import org.ojalgo.access.Access1D;

public interface IHouseholder<N extends Number> extends Access1D<N> {

    /**
     * Regardless of what is actually returned by {@linkplain #doubleValue(int)}
     * or {@linkplain #get(int)} vector elements with indeces less than
     * 'first' should be assumed to be, and treated as if they are zero.
     */
    int first();

}
