/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.scalar;

import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.type.TypeUtils;

abstract class AbstractScalar<N extends Number> extends Number implements Scalar<N> {

    public AbstractScalar() {
        super();
    }

    @Override
    public final boolean equals(final Object someObj) {
        if (someObj instanceof Scalar) {
            return this.equals((Scalar<?>) someObj);
        } else {
            return super.equals(someObj);
        }
    }

    @Override
    public final int hashCode() {
        return new Double(this.getReal()).hashCode();
    }

    public final boolean isAbsolute() {
        return this.isReal() && (this.getReal() >= PrimitiveMath.ZERO);
    }

    public final boolean isZero() {
        return TypeUtils.isZero(this.getModulus());
    }

}
