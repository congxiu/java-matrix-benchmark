/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.List;

import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.PrimitiveMatrix;
import org.ojalgo.matrix.BasicMatrix.Factory;
import org.ojalgo.type.StandardType;
import org.ojalgo.type.context.NumberContext;

public abstract class CovarianceBasedModel extends MeanVarianceAsset {

    protected static final NumberContext CONTEXT = StandardType.PERCENT;
    protected static final Factory FACTORY = PrimitiveMatrix.FACTORY;

    private transient BasicMatrix myInstrumentReturns;
    private transient BasicMatrix myInstrumentWeights;
    private final MarketEquilibrium myMarketEquilibrium;
    private transient BigDecimal myMeanReturn;
    private transient BigDecimal myReturnVariance;

    protected CovarianceBasedModel(final CovarianceBasedModel aMarketEquilibrium) {
        this(aMarketEquilibrium.getMarketEquilibrium());
    }

    protected CovarianceBasedModel(final MarketEquilibrium aMarketEquilibrium) {

        super();

        myMarketEquilibrium = aMarketEquilibrium.copy();
    }

    public final BasicMatrix getCovariances() {
        return myMarketEquilibrium.getCovariances();
    }

    public final BigDecimal getImpliedRiskAversion(final BasicMatrix aWeightsVctr, final BasicMatrix aReturnsVctr) {
        return myMarketEquilibrium.getImpliedRiskAversion(aWeightsVctr, aReturnsVctr);
    }

    public final BasicMatrix getInstrumentReturns() {
        if (myInstrumentReturns == null) {
            myInstrumentReturns = this.calculateInstrumentReturns().round(CONTEXT);
        }
        return myInstrumentReturns;
    }

    public final BasicMatrix getInstrumentWeights() {
        if (myInstrumentWeights == null) {
            final BasicMatrix tmpCalculateInstrumentWeights = this.calculateInstrumentWeights();
            if (tmpCalculateInstrumentWeights != null) {
                myInstrumentWeights = tmpCalculateInstrumentWeights.round(CONTEXT);
            }
        }
        return myInstrumentWeights;
    }

    @Override
    public final BigDecimal getMeanReturn() {
        if (myMeanReturn == null) {
            final BasicMatrix tmpInstrumentWeights = this.getInstrumentWeights();
            final BasicMatrix tmpInstrumentReturns = this.getInstrumentReturns();
            if ((tmpInstrumentWeights != null) && (tmpInstrumentReturns != null)) {
                myMeanReturn = this.calculatePortfolioReturn(tmpInstrumentWeights, tmpInstrumentReturns);
            }
        }
        return myMeanReturn;
    }

    @Override
    public final BigDecimal getReturnVariance() {
        if (myReturnVariance == null) {
            myReturnVariance = this.calculatePortfolioVariance(this.getInstrumentWeights());
        }
        return myReturnVariance;
    }

    public final BigDecimal getRiskAversion() {
        return myMarketEquilibrium.getRiskAversion();
    }

    public final String[] getSymbols() {
        return myMarketEquilibrium.getSymbols();
    }

    @Override
    public final List<BigDecimal> getWeights() {

        final BasicMatrix tmpInstrumentWeights = this.getInstrumentWeights();

        if (tmpInstrumentWeights != null) {

            return tmpInstrumentWeights.toBigStore().asList();

        } else {

            return null;
        }
    }

    public final void setRiskAversion(final BigDecimal aFactor) {

        myMarketEquilibrium.setRiskAversion(aFactor);

        this.reset();
    }

    protected final BasicMatrix buildColumnVector(final List<BigDecimal> aColumn) {
        return FACTORY.makeColumnVector(aColumn);
    }

    protected final BasicMatrix calculateEquilibriumReturns(final BasicMatrix aWeightsVctr) {
        return myMarketEquilibrium.calculateReturns(aWeightsVctr);
    }

    protected final BasicMatrix calculateEquilibriumWeights(final BasicMatrix aReturnsVctr) {
        return myMarketEquilibrium.calculateWeights(aReturnsVctr);
    }

    protected abstract BasicMatrix calculateInstrumentReturns();

    protected abstract BasicMatrix calculateInstrumentWeights();

    protected final BigDecimal calculatePortfolioReturn(final BasicMatrix aWeightsVctr, final BasicMatrix aReturnsVctr) {
        return MarketEquilibrium.calculatePortfolioReturn(aWeightsVctr, aReturnsVctr);
    }

    protected final BigDecimal calculatePortfolioVariance(final BasicMatrix aWeightsVctr) {
        return myMarketEquilibrium.calculatePortfolioVariance(aWeightsVctr);
    }

    protected void reset() {
        myInstrumentWeights = null;
        myInstrumentReturns = null;
        myMeanReturn = null;
        myReturnVariance = null;
    }

    protected final void setRiskAversion(final BasicMatrix aWeightsVctr, final BasicMatrix aReturnsVctr) {

        myMarketEquilibrium.setRiskAversion(aWeightsVctr, aReturnsVctr);

        this.reset();
    }

    final MarketEquilibrium getMarketEquilibrium() {
        return myMarketEquilibrium;
    }

}
