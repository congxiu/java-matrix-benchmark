/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import static org.ojalgo.constant.PrimitiveMath.*;

import java.math.BigDecimal;
import java.util.List;

import org.ojalgo.finance.FinanceUtils;
import org.ojalgo.function.implementation.BigFunction;

/**
 * <p>
 * An asset is a financial instrument that can be bought and sold.
 * </p><p>
 * A portfolio is a collection/combination of assets as well as an asset
 * itself.
 * </p><p>
 * (Any asset can be viewed as a portfolio containing only itself.)
 * </p>
 *
 * @author apete
 */
public abstract class MeanVarianceAsset implements FinancePortfolio {

    protected MeanVarianceAsset() {
        super();
    }

    /**
     * The mean/expected return of this asset. 
     * May return either the absolute or excess return of the asset. 
     * The context in which an instance is used should make it clear 
     * which.
     */
    public abstract BigDecimal getMeanReturn();

    /**
     * The asset's return variance.
     * 
     * Subclasses must override either {@linkplain #getReturnVariance()} or {@linkplain #getVolatility()}.
     */
    public BigDecimal getReturnVariance() {
        return BigFunction.POWER.invoke(this.getVolatility(), 2);
    }

    public final BigDecimal getSharpeRation() {
        return BigFunction.DIVIDE.invoke(this.getMeanReturn(), this.getVolatility());
    }

    public final BigDecimal getVaR90() {
        return this.getValueAtRisk(90);
    }

    public final BigDecimal getVaR95() {
        return this.getValueAtRisk(95);
    }

    public final BigDecimal getVaR98() {
        return this.getValueAtRisk(98);
    }

    public final BigDecimal getVaR99() {
        return this.getValueAtRisk(99);
    }

    /**
     * Volatility refers to the standard deviation of 
     * the change in value of an asset with a specific 
     * time horizon. It is often used to quantify the risk of the 
     * asset over that time period.
     * 
     * Subclasses must override either {@linkplain #getReturnVariance()} or {@linkplain #getVolatility()}.
     */
    public BigDecimal getVolatility() {
        return BigFunction.SQRT.invoke(this.getReturnVariance());
    }

    /**
     * This method returns a list of the weights of the Portfolio's contained
     * assets.
     */
    public abstract List<BigDecimal> getWeights();

    /**
     * Value at Risk (VaR) is the maximum loss not exceeded with a 
     * given probability defined as the confidence level, over a given 
     * period of time.
     */
    private final BigDecimal getValueAtRisk(final double aConfidenceLevel) {
        return new BigDecimal(FinanceUtils.calculateValueAtRisk(this.getMeanReturn().doubleValue(), this.getVolatility().doubleValue(), aConfidenceLevel, ONE));
    }

}
