/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.List;

import org.ojalgo.function.PreconfiguredSecond;
import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.BigMatrix;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.PhysicalStore;

public final class SimplePortfolio extends CovarianceBasedModel {

    public static SimplePortfolio make(final BasicMatrix aCorrelationsMatrix, final List<SimpleInstrument> someInstruments) {

        final int tmpSize = someInstruments.size();

        final PhysicalStore<BigDecimal> tmpCovarianceMatrix = aCorrelationsMatrix.toBigStore();
        final PhysicalStore<BigDecimal> tmpReturnsMatrix = BigDenseStore.FACTORY.makeEmpty(tmpSize, 1);
        final PhysicalStore<BigDecimal> tmpWeightsMatrix = BigDenseStore.FACTORY.makeEmpty(tmpSize, 1);

        SimpleInstrument tmpInstrument;
        for (int ij = 0; ij < tmpSize; ij++) {

            tmpInstrument = someInstruments.get(ij);

            tmpReturnsMatrix.set(ij, 0, tmpInstrument.getMeanReturn());
            tmpWeightsMatrix.set(ij, 0, tmpInstrument.getWeight());

            final PreconfiguredSecond<BigDecimal> tmpFunc = new PreconfiguredSecond<BigDecimal>(BigFunction.MULTIPLY, tmpInstrument.getVolatility());
            tmpCovarianceMatrix.modifyRow(ij, 0, tmpFunc);
            tmpCovarianceMatrix.modifyColumn(0, ij, tmpFunc);
        }

        final MarketEquilibrium tmpME = new MarketEquilibrium(new BigMatrix(tmpCovarianceMatrix));

        return new SimplePortfolio(tmpME, new BigMatrix(tmpReturnsMatrix), new BigMatrix(tmpWeightsMatrix));
    }

    private final BasicMatrix myReturnsMatrx;
    private final BasicMatrix myWeightsMatrix;

    @SuppressWarnings("unused")
    private SimplePortfolio(final CovarianceBasedModel aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myReturnsMatrx = null;
        myWeightsMatrix = null;
    }

    @SuppressWarnings("unused")
    private SimplePortfolio(final MarketEquilibrium aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myReturnsMatrx = null;
        myWeightsMatrix = null;
    }

    SimplePortfolio(final MarketEquilibrium aMarketEquilibrium, final BasicMatrix aReturnsMatrx, final BasicMatrix aWeightsMatrix) {

        super(aMarketEquilibrium);

        myReturnsMatrx = aReturnsMatrx;
        myWeightsMatrix = aWeightsMatrix;
    }

    @Override
    protected BasicMatrix calculateInstrumentReturns() {
        return myReturnsMatrx;
    }

    @Override
    protected BasicMatrix calculateInstrumentWeights() {
        return myWeightsMatrix;
    }

}
