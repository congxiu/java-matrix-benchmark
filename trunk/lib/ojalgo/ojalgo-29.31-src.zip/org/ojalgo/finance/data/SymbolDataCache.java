/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.ojalgo.series.DateSeries;
import org.ojalgo.type.CalendarDateUnit;
import org.ojalgo.type.colour.Colour;

public final class SymbolDataCache {

    public static enum Source {
        Google, Yahoo;
    }

    private static final SymbolDataCache INSTANCE = new SymbolDataCache();

    public static SymbolDataCache getInstance() {
        return INSTANCE;
    }

    private final Map<String, Date> myDates = new HashMap<String, Date>();
    private final Map<String, DateSeries<BigDecimal>> mySeries = new HashMap<String, DateSeries<BigDecimal>>();

    private SymbolDataCache() {
        super();
    }

    public void clear() {
        mySeries.clear();
        myDates.clear();
    }

    public DateSeries<BigDecimal> getPriceSeries(final Source aSource, final String aSymbol, final CalendarDateUnit aTimeUnit) {

        DateSeries<BigDecimal> retVal = mySeries.get(aSymbol);

        if (retVal != null) {
            if (System.currentTimeMillis() - myDates.get(aSymbol).getTime() > CalendarDateUnit.DAY.size()) {
                retVal.clear();
            }
            if (retVal.getResolution() != aTimeUnit) {
                retVal.clear();
            }
        } else {
            retVal = new DateSeries<BigDecimal>(aTimeUnit);
            retVal.name(aSymbol).colour(Colour.random());
            mySeries.put(aSymbol, retVal);
        }

        if (retVal.size() == 0) {

            DataSource tmpDataSource;
            switch (aSource) {
            case Google:
                tmpDataSource = new GoogleSymbol(aSymbol, aTimeUnit);
                break;
            case Yahoo:
                tmpDataSource = new YahooSymbol(aSymbol, aTimeUnit);
                break;
            default:
                tmpDataSource = new YahooSymbol(aSymbol, aTimeUnit);
                break;
            }

            DataSource.copy(tmpDataSource.getHistoricalPrices(), retVal);

            myDates.put(aSymbol, new Date());
        }

        return retVal;
    }

    public DateSeries<BigDecimal> getPriceSeries(final String aSymbol) {
        return this.getPriceSeries(Source.Yahoo, aSymbol, CalendarDateUnit.DAY);
    }

}
