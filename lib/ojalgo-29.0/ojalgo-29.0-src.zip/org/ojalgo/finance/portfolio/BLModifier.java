/*
 * Copyright © 2008 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.List;

import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.matrix.BasicMatrix;

/**
 * Black-Litterman Modifier
 *
 * @author apete
 */
abstract class BLModifier extends CovarianceBasedModel {

    private final BlackLittermanModel myBlackLittermanModel;
    private final BasicMatrix myStrategicWeights;

    @SuppressWarnings("unused")
    private BLModifier(CovarianceBasedModel aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myBlackLittermanModel = null;
        myStrategicWeights = null;
    }

    @SuppressWarnings("unused")
    private BLModifier(MarketEquilibrium aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myBlackLittermanModel = null;
        myStrategicWeights = null;
    }

    protected BLModifier(BlackLittermanModel aBlackLittermanModel, BasicMatrix someStrategicWeights) {

        super(aBlackLittermanModel);

        myBlackLittermanModel = aBlackLittermanModel;
        myStrategicWeights = someStrategicWeights;
        this.setRiskAversion(myStrategicWeights, myBlackLittermanModel.getOriginalReturns());
    }

    protected BLModifier(BlackLittermanModel aBlackLittermanModel, List<BigDecimal> someStrategicWeights) {
        this(aBlackLittermanModel, FACTORY.makeColumnVector(someStrategicWeights));
    }

    protected BLModifier(BlackLittermanModel aBlackLittermanModel, FinancePortfolio aStrategicPortfolio) {
        this(aBlackLittermanModel, aStrategicPortfolio.getWeights());
    }

    /**
     * Inverse Risk Aversion Conversion Factor
     */
    public final BigDecimal getChangeMultiplier() {
        return BigFunction.DIVIDE.invoke(myBlackLittermanModel.getRiskAversion(), this.getRiskAversion());
    }

    public final BigDecimal getConformance() {

        BasicMatrix tmpTheoreticalStrategicWeights = this.calculateEquilibriumWeights(myBlackLittermanModel.getOriginalReturns());

        BigDecimal retVal = myStrategicWeights.multiplyVectors(tmpTheoreticalStrategicWeights).toBigDecimal();
        retVal = BigFunction.DIVIDE.invoke(retVal, myStrategicWeights.getFrobeniusNorm().toBigDecimal());
        retVal = BigFunction.DIVIDE.invoke(retVal, tmpTheoreticalStrategicWeights.getFrobeniusNorm().toBigDecimal());

        return retVal;
    }

    @Override
    protected final BasicMatrix calculateInstrumentReturns() {
        return myBlackLittermanModel.calculateInstrumentReturns();
    }

    final BlackLittermanModel getBlackLittermanModel() {
        return myBlackLittermanModel;
    }

    final BasicMatrix getStrategicWeights() {
        return myStrategicWeights;
    }

}
