/*
 * Copyright © 2005 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.util.concurrent.Future;

import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.type.context.NumberContext;

/**
 * Some standard matrix names:
 * <ul>
 * <li>[A] could be any matrix.</li>
 * <li>[I] is an identity matrix.</li>
 * <li>[P] is a permutation matrix - an identity matrix with interchanged
 * rows or columns. [P]<sup>-1</sup>=[P]<sup>T</sup></li>
 * <li>[L] is a lower (left) triangular matrix.</li>
 * <li>[D] is a diagonal matrix. Possibly bi-, tri- or block-diagonal.</li>
 * <li>[U] is an upper (right) triangular matrix. It is equivalent to [R].</li>
 * <li>[Q] is an orthogonal, or unitary, matrix. [Q][Q]<sup>T</sup>=[I].</li>
 * <li>[R] is a right (upper) tringular matrix. It is equivalent to [U].</li>
 * <li>[V] is an eigenvector matrix.</il>
 * </ul>
 * With the above definitions we can express various decompositions as:
 * <ul>
 * <li>LU: [A] = [L][U] ([P][L][U] with pivoting)</li>
 * <li>Cholesky: [A] = [L][L]<sup>T</sup></li>
 * <li>QR: [A] = [Q][R]</li>
 * <li>Singular Value: [A] = [Q1][D][Q2]<sup>T</sup></li>
 * <li>Eigenvalue: [A] = [V][D][V]<sup>-1</sup></li>
 * </ul>
 * 
 * @author apete
 */
public interface MatrixDecomposition<N extends Number> {

    /**
     * @param aStore A matrix to decompose
     * @return true if the computation suceeded; false if not
     */
    boolean compute(MatrixStore<N> aStore);

    boolean equals(MatrixDecomposition<N> aDecomp, NumberContext aCntxt);

    boolean equals(MatrixStore<N> aStore, NumberContext aCntxt);

    /**
     * The output must be a "right inverse" and a "generalised inverse".
     * 
     * @see BasicMatrix#invert()
     */
    MatrixStore<N> getInverse();

    /**
     * A convenience method that produces exactly the same result as if
     * you first call {@linkplain #compute(MatrixStore)} and then {@linkplain #getInverse()}.
     */
    MatrixStore<N> invert(MatrixStore<N> aStore);

    /**
     * @return true if computation has been attemped; false if not.
     * @see #compute(MatrixStore)
     * @see #isSolvable()
     */
    boolean isComputed();

    /**
     * @return True if the implementation generates a full sized decomposition.
     */
    boolean isFullSize();

    /**
     * @return true if it is ok to call {@linkplain #solve(MatrixStore)}
     * (computation was successful); false if not
     * @see #solve(MatrixStore)
     * @see #isComputed()
     */
    boolean isSolvable();

    MatrixStore<N> reconstruct();

    void reset();

    MatrixStore<N> solve(MatrixStore<N> aRHS);

    /**
     * Will solve [aBody][X]=[aRHS] concurrently by first calling 
     * {@linkplain #compute(MatrixStore)} using [aBody], and then
     * {@linkplain #solve(MatrixStore)} using [aRHS]. If either of the input [aBody]
     * or [aRHS] is set to null the corresponing calculation is skipped.
     * 
     * @param aBody The equation system body
     * @param aRHS The equation system right hand side
     * @return The matrix decomposition and the equation system solution, [X]
     */
    Future<DecomposeAndSolve<N>> solve(MatrixStore<N> aBody, MatrixStore<N> aRHS);
}
