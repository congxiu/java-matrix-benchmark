/*
 * Copyright © 2007 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.ojalgo.array.Array1D;
import org.ojalgo.concurrent.ConcurrentExecutor;
import org.ojalgo.constant.BigMath;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.function.implementation.ComplexFunction;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * The original ojAlgo implementation.
 *
 * @author apete
 */
abstract class SVD0<N extends Number & Comparable<N>> extends SingularValueDecomposition<N> {

    public static final class RotateRight<N extends Number> implements Callable<PhysicalStore<N>> {

        private final List<Rotation<N>> myRightRotations;
        private final PhysicalStore<N> myStore;

        RotateRight(final PhysicalStore<N> aStore, final List<Rotation<N>> someRightRotations) {

            super();

            myStore = aStore;
            myRightRotations = someRightRotations;
        }

        public PhysicalStore<N> call() throws Exception {

            for (final Rotation<N> tmpRotation : myRightRotations) {
                myStore.transformRight(tmpRotation);
            }
            myRightRotations.clear();

            return myStore;
        }
    }

    static final class Big extends SVD0<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

        @Override
        protected QRDecomposition<BigDecimal> makeDelegateQR() {
            return (QRDecomposition<BigDecimal>) QRDecomposition.makeBig();
        }

        protected Array1D<BigDecimal> makeWarkCopyArray(final int aDim) {
            return Array1D.makeBig(aDim);
        }

        @Override
        protected Rotation<BigDecimal>[] rotations(final PhysicalStore<BigDecimal> aStore, final int aLowInd, final int aHighInd, final Rotation<BigDecimal>[] retVal) {

            final BigDecimal a00 = aStore.get(aLowInd, aLowInd);
            final BigDecimal a01 = aStore.get(aLowInd, aHighInd);
            final BigDecimal a10 = aStore.get(aHighInd, aLowInd);
            final BigDecimal a11 = aStore.get(aHighInd, aHighInd);

            final BigDecimal x = a00.add(a11);
            final BigDecimal y = a10.subtract(a01);

            BigDecimal t; // tan, cot or something temporary

            // Symmetrise - Givens
            final BigDecimal cg; // cos Givens
            final BigDecimal sg; // sin Givens

            if (y.signum() == 0) {
                cg = BigFunction.SIGNUM.invoke(x);
                sg = BigMath.ZERO;
            } else if (x.signum() == 0) {
                sg = BigFunction.SIGNUM.invoke(y);
                cg = BigMath.ZERO;
            } else if (y.abs().compareTo(x.abs()) == 1) {
                t = BigFunction.DIVIDE.invoke(x, y); // cot
                sg = BigFunction.DIVIDE.invoke(BigFunction.SIGNUM.invoke(y), BigFunction.SQRT1PX2.invoke(t));
                cg = sg.multiply(t);
            } else {
                t = BigFunction.DIVIDE.invoke(y, x); // tan
                cg = BigFunction.DIVIDE.invoke(BigFunction.SIGNUM.invoke(x), BigFunction.SQRT1PX2.invoke(t));
                sg = cg.multiply(t);
            }

            final BigDecimal b00 = cg.multiply(a00).add(sg.multiply(a10));
            final BigDecimal b11 = cg.multiply(a11).subtract(sg.multiply(a01));
            final BigDecimal b2 = cg.multiply(a01.add(a10)).add(sg.multiply(a11.subtract(a00))); // b01 + b10

            t = BigFunction.DIVIDE.invoke(b11.subtract(b00), b2);
            t = BigFunction.DIVIDE.invoke(BigFunction.SIGNUM.invoke(t), BigFunction.SQRT1PX2.invoke(t).add(t.abs()));

            // Annihilate - Jacobi
            final BigDecimal cj = BigFunction.DIVIDE.invoke(BigMath.ONE, BigFunction.SQRT1PX2.invoke(t)); // Cos Jacobi
            final BigDecimal sj = cj.multiply(t); // Sin Jacobi

            retVal[1] = new Rotation<BigDecimal>(aLowInd, aHighInd, cj, sj); // Jacobi
            retVal[0] = new Rotation<BigDecimal>(aLowInd, aHighInd, cj.multiply(cg).add(sj.multiply(sg)), cj.multiply(sg).subtract(sj.multiply(cg))); // Givens - Jacobi

            return retVal;
        }

    }

    static final class Complex extends SVD0<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

        @Override
        protected QRDecomposition<ComplexNumber> makeDelegateQR() {
            return (QRDecomposition<ComplexNumber>) QRDecomposition.makeComplex();
        }

        protected Array1D<ComplexNumber> makeWarkCopyArray(final int aDim) {
            return Array1D.makeComplex(aDim);
        }

        @Override
        protected Rotation<ComplexNumber>[] rotations(final PhysicalStore<ComplexNumber> aStore, final int aLowInd, final int aHighInd, final Rotation<ComplexNumber>[] retVal) {

            final ComplexNumber a00 = aStore.get(aLowInd, aLowInd);
            final ComplexNumber a01 = aStore.get(aLowInd, aHighInd);
            final ComplexNumber a10 = aStore.get(aHighInd, aLowInd);
            final ComplexNumber a11 = aStore.get(aHighInd, aHighInd);

            final ComplexNumber x = a00.add(a11);
            final ComplexNumber y = a10.subtract(a01);

            ComplexNumber t; // tan, cot or something temporary

            // Symmetrise - Givens
            final ComplexNumber cg; // cos Givens
            final ComplexNumber sg; // sin Givens

            if (y.isZero()) {
                cg = x.signum();
                sg = ComplexNumber.ZERO;
            } else if (x.isZero()) {
                sg = y.signum();
                cg = ComplexNumber.ZERO;
            } else if (y.compareTo(x) == 1) {
                t = x.divide(y); // cot
                sg = y.signum().divide(ComplexFunction.SQRT1PX2.invoke(t));
                cg = sg.multiply(t);
            } else {
                t = y.divide(x); // tan
                cg = x.signum().divide(ComplexFunction.SQRT1PX2.invoke(t));
                sg = cg.multiply(t);
            }

            final ComplexNumber b00 = cg.multiply(a00).add(sg.multiply(a10));
            final ComplexNumber b11 = cg.multiply(a11).subtract(sg.multiply(a01));
            final ComplexNumber b2 = cg.multiply(a01.add(a10)).add(sg.multiply(a11.subtract(a00))); // b01 + b10

            t = b11.subtract(b00).divide(b2);
            t = t.signum().divide(ComplexFunction.SQRT1PX2.invoke(t).add(t.getModulus()));

            // Annihilate - Jacobi
            final ComplexNumber cj = ComplexFunction.SQRT1PX2.invoke(t).invert(); // Cos Jacobi
            final ComplexNumber sj = cj.multiply(t); // Sin Jacobi

            retVal[1] = new Rotation<ComplexNumber>(aLowInd, aHighInd, cj, sj); // Jacobi
            retVal[0] = new Rotation<ComplexNumber>(aLowInd, aHighInd, cj.multiply(cg).add(sj.multiply(sg)), cj.multiply(sg).subtract(sj.multiply(cg))); // Givens - Jacobi

            return retVal;
        }

    }

    static final class Primitive extends SVD0<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

        @Override
        protected QRDecomposition<Double> makeDelegateQR() {
            return (QRDecomposition<Double>) QRDecomposition.makePrimitive();
        }

        protected Array1D<Double> makeWarkCopyArray(final int aDim) {
            return Array1D.makePrimitive(aDim);
        }

        @Override
        protected Rotation<Double>[] rotations(final PhysicalStore<Double> aStore, final int aLowInd, final int aHighInd, final Rotation<Double>[] retVal) {

            final double a00 = aStore.doubleValue(aLowInd, aLowInd);
            final double a01 = aStore.doubleValue(aLowInd, aHighInd);
            final double a10 = aStore.doubleValue(aHighInd, aLowInd);
            final double a11 = aStore.doubleValue(aHighInd, aHighInd);

            final double x = a00 + a11;
            final double y = a10 - a01;

            double t; // tan, cot or something temporary

            // Symmetrise - Givens
            final double cg; // cos Givens
            final double sg; // sin Givens

            if (TypeUtils.isZero(y)) {
                cg = Math.signum(x);
                sg = PrimitiveMath.ZERO;
            } else if (TypeUtils.isZero(x)) {
                sg = Math.signum(y);
                cg = PrimitiveMath.ZERO;
            } else if (Math.abs(y) > Math.abs(x)) {
                t = x / y; // cot
                sg = Math.signum(y) / PrimitiveFunction.SQRT1PX2.invoke(t);
                cg = sg * t;
            } else {
                t = y / x; // tan
                cg = Math.signum(x) / PrimitiveFunction.SQRT1PX2.invoke(t);
                sg = cg * t;
            }

            final double b00 = cg * a00 + sg * a10;
            final double b11 = cg * a11 - sg * a01;
            final double b2 = cg * (a01 + a10) + sg * (a11 - a00); // b01 + b10

            t = (b11 - b00) / b2;
            t = Math.signum(t) / (PrimitiveFunction.SQRT1PX2.invoke(t) + Math.abs(t)); // tan Jacobi

            // Annihilate - Jacobi
            final double cj = PrimitiveMath.ONE / PrimitiveFunction.SQRT1PX2.invoke(t); // cos Jacobi
            final double sj = cj * t; // sin Jacobi

            retVal[1] = new Rotation<Double>(aLowInd, aHighInd, cj, sj); // Jacobi
            retVal[0] = new Rotation<Double>(aLowInd, aHighInd, (cj * cg + sj * sg), (cj * sg - sj * cg)); // Givens - Jacobi

            return retVal;
        }

    }

    private final QRDecomposition<N> myDelegateQR;
    private Future<PhysicalStore<N>> myFutureQ1;
    private Future<PhysicalStore<N>> myFutureQ2;
    private PhysicalStore<N> myQ1;
    private final List<Rotation<N>> myQ1Rotations = new ArrayList<Rotation<N>>();
    private PhysicalStore<N> myQ2;
    private final List<Rotation<N>> myQ2Rotations = new ArrayList<Rotation<N>>();
    private Array1D<Double> mySingularValues;
    private final N myZero;
    private PhysicalStore<N> myD;

    protected SVD0(final PhysicalStore.Factory<N> aFactory) {

        super(aFactory);

        myDelegateQR = this.makeDelegateQR();

        myZero = aFactory.getStaticZero().getNumber();
    }

    @SuppressWarnings("unchecked")
    public final boolean compute(final MatrixStore<N> aStore) {

        this.reset();

        final int tmpMinDim = aStore.getMinDim();

        myDelegateQR.compute(aStore);
        myQ1 = (PhysicalStore<N>) myDelegateQR.getQ();
        myDelegateQR.compute((DecompositionStore<N>) myDelegateQR.getL());
        myD = myDelegateQR.getL();
        myQ2 = (PhysicalStore<N>) myDelegateQR.getQ();
        myDelegateQR.reset();

        mySingularValues = Array1D.makePrimitive(tmpMinDim);

        Rotation<N>[] tmpRotations = new Rotation[2]; // [Givens - Jacobi, Jacobi]

        int iter = 0;
        if (DEBUG) {
            BasicLogger.logDebug("Org Init D", myD);
        }

        boolean tmpNotAllZeros = true;
        for (int l = 0; tmpNotAllZeros && (l < tmpMinDim); l++) {

            tmpNotAllZeros = false;

            int i;
            for (int i0 = tmpMinDim - 1; i0 > 0; i0--) {
                for (int j = 0; j < (tmpMinDim - i0); j++) {
                    i = i0 + j;

                    if (!myD.isZero(i, j) || !myD.isZero(j, i)) {

                        tmpNotAllZeros = true;

                        tmpRotations = this.rotations(myD, j, i, tmpRotations);

                        myD.transformLeft(tmpRotations[0]);
                        myD.transformRight(tmpRotations[1]);

                        myQ1Rotations.add(tmpRotations[0].invert());
                        myQ2Rotations.add(tmpRotations[1]);

                        if (DEBUG) {
                            BasicLogger.logDebug("Org Iter D " + ++iter, myD);
                        }
                    }

                    myD.set(i, j, myZero);
                    myD.set(j, i, myZero);
                }
            }
        }

        double tmpSingularValue;
        for (int ij = 0; ij < tmpMinDim; ij++) {

            if (myD.isZero(ij, ij)) {

                tmpSingularValue = PrimitiveMath.ZERO;

            } else if (myD.isAbsolute(ij, ij)) {

                tmpSingularValue = myD.doubleValue(ij, ij);

            } else {

                final Scalar<N> tmpDiagSclr = myD.toScalar(ij, ij);
                final N tmpSignum = tmpDiagSclr.signum().getNumber();
                tmpSingularValue = tmpDiagSclr.divide(tmpSignum).getModulus();

                myD.set(ij, ij, tmpSingularValue);
                myQ2Rotations.add(new Rotation<N>(ij, ij, tmpSignum, tmpSignum));
            }

            mySingularValues.set(ij, tmpSingularValue);
        }

        mySingularValues.sortDescending();

        myFutureQ1 = ConcurrentExecutor.INSTANCE.submit(new RotateRight<N>(myQ1, myQ1Rotations));
        myFutureQ2 = ConcurrentExecutor.INSTANCE.submit(new RotateRight<N>(myQ2, myQ2Rotations));

        return this.computed(!tmpNotAllZeros);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public final MatrixStore<N> getD() {

        final int tmpMinDim = myD.getMinDim();

        final PhysicalStore<N> retVal = this.getFactory().makeZero(tmpMinDim, tmpMinDim);

        for (int ij = 0; ij < tmpMinDim; ij++) {
            retVal.set(ij, ij, myD.get(ij, ij));
        }

        return retVal;
    }

    public final MatrixStore<N> getQ1() {

        try {
            myFutureQ1.get();
        } catch (final InterruptedException anException) {
            anException.printStackTrace();
        } catch (final ExecutionException anException) {
            anException.printStackTrace();
        }

        return myQ1;
    }

    public final MatrixStore<N> getQ2() {

        try {
            myFutureQ2.get();
        } catch (final InterruptedException anException) {
            anException.printStackTrace();
        } catch (final ExecutionException anException) {
            anException.printStackTrace();
        }

        return myQ2;
    }

    public final Array1D<Double> getSingularValues() {
        return mySingularValues;
    }

    public final boolean isFullSize() {
        return false;
    }

    public boolean isOrdered() {
        return false;
    }

    public boolean isSolvable() {
        return this.isComputed();
    }

    /**
     * @deprecated Use {@link #isOrdered()} instead
     */
    @Deprecated
    public boolean isSorted() {
        return this.isOrdered();
    }

    @Override
    public final void reset() {

        super.reset();

        myDelegateQR.reset();

        myQ1 = null;
        myD = null;
        myQ2 = null;

        mySingularValues = null;

        myQ1Rotations.clear();
        myQ2Rotations.clear();

        myFutureQ1 = null;
        myFutureQ2 = null;
    }

    public final MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        return this.getInverse().multiplyRight(aRHS);
    }

    protected abstract QRDecomposition<N> makeDelegateQR();

    protected abstract Rotation<N>[] rotations(PhysicalStore<N> aStore, int aLowInd, int aHighInd, Rotation<N>[] retVal);
}
