/*
 * Copyright © 2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;
import java.util.concurrent.Future;

import org.ojalgo.ProgrammingError;
import org.ojalgo.array.Array1D;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.PreconfiguredSecond;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.ComplexAggregator;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.jama.JamaEigenvalue;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.PhysicalStore.Factory;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

public abstract class EigenvalueDecomposition<N extends Number> extends AbstractDecomposition<N> implements Eigenvalue<N> {

    /**
     * @return A BigDecimal adapter to PrimitiveEigenvalue.
     */
    public static final Eigenvalue<BigDecimal> makeBig() {
        return new Eigenvalue<BigDecimal>() {

            private final Eigenvalue<Double> myDelegate = EigenvalueDecomposition.makePrimitive();

            public boolean compute(final MatrixStore<BigDecimal> aStore) {
                return myDelegate.compute(PrimitiveDenseStore.FACTORY.copy(aStore));
            }

            public boolean computeNonsymmetric(final MatrixStore<BigDecimal> aNonsymmetricStore) {
                return myDelegate.computeNonsymmetric(PrimitiveDenseStore.FACTORY.copy(aNonsymmetricStore));
            }

            public boolean computeSymmetric(final MatrixStore<BigDecimal> aSymmetricStore) {
                return myDelegate.computeSymmetric(PrimitiveDenseStore.FACTORY.copy(aSymmetricStore));
            }

            public boolean equals(final MatrixDecomposition<BigDecimal> aDecomp, final NumberContext aCntxt) {
                return false;
            }

            public boolean equals(final MatrixStore<BigDecimal> aStore, final NumberContext aCntxt) {
                return MatrixUtils.equals(aStore, this, aCntxt);
            }

            public MatrixStore<BigDecimal> getD() {
                return BigDenseStore.FACTORY.copy(myDelegate.getD());
            }

            public ComplexNumber getDeterminant() {
                return myDelegate.getDeterminant();
            }

            public Array1D<ComplexNumber> getEigenvalues() {
                return myDelegate.getEigenvalues();
            }

            public MatrixStore<BigDecimal> getInverse() {
                return BigDenseStore.FACTORY.copy(myDelegate.getInverse());
            }

            public ComplexNumber getTrace() {
                return myDelegate.getTrace();
            }

            public MatrixStore<BigDecimal> getV() {
                return BigDenseStore.FACTORY.copy(myDelegate.getV());
            }

            public MatrixStore<BigDecimal> invert(final MatrixStore<BigDecimal> aStore) {
                return BigDenseStore.FACTORY.copy(myDelegate.invert(PrimitiveDenseStore.FACTORY.copy(aStore)));
            }

            public boolean isComputed() {
                return myDelegate.isComputed();
            }

            public boolean isFullSize() {
                return myDelegate.isFullSize();
            }

            public boolean isOrdered() {
                return myDelegate.isOrdered();
            }

            public boolean isSolvable() {
                return myDelegate.isSolvable();
            }

            public boolean isSymmetric() {
                return myDelegate.isSymmetric();
            }

            public MatrixStore<BigDecimal> reconstruct() {
                return BigDenseStore.FACTORY.copy(myDelegate.reconstruct());
            }

            public void reset() {
                myDelegate.reset();
            }

            public MatrixStore<BigDecimal> solve(final MatrixStore<BigDecimal> aRHS) {
                return BigDenseStore.FACTORY.copy(myDelegate.solve(PrimitiveDenseStore.FACTORY.copy(aRHS)));
            }

            public Future<DecomposeAndSolve<BigDecimal>> solve(final MatrixStore<BigDecimal> aBody, final MatrixStore<BigDecimal> aRHS) {
                ProgrammingError.throwForIllegalInvocation();
                return null;
            }
        };
    }

    public static final Eigenvalue<Double> makeJama() {
        return new JamaEigenvalue();
    }

    public static final Eigenvalue<Double> makePrimitive() {
        return new EvD1.Primitive();
    }

    private MatrixStore<N> myD = null;
    private Array1D<ComplexNumber> myEigenvalues = null;
    private transient MatrixStore<N> myInverse = null;
    private boolean mySymmetric;
    private MatrixStore<N> myV = null;

    protected EigenvalueDecomposition(final Factory<N> aFactory) {
        super(aFactory);
    }

    /**
     * Will check for symmetry and then call either
     * {@link #computeSymmetric(MatrixStore)}
     * or
     * {@link #computeNonsymmetric(MatrixStore)}.
     * 
     * @see org.ojalgo.matrix.decomposition.MatrixDecomposition#compute(org.ojalgo.matrix.store.MatrixStore)
     */
    public final boolean compute(final MatrixStore<N> aStore) {

        final int tmpDim = aStore.getRowDim();

        boolean tmpSymmetric = true;

        for (int j = 0; tmpSymmetric && (j < tmpDim); j++) {
            for (int i = j + 1; tmpSymmetric && (i < tmpDim); i++) {
                tmpSymmetric &= aStore.toScalar(i, j).subtract(aStore.get(j, i)).isZero();
            }
        }

        if (tmpSymmetric) {
            return this.computeSymmetric(aStore);
        } else {
            return this.computeNonsymmetric(aStore);
        }
    }

    public boolean computeNonsymmetric(final MatrixStore<N> aSymmetric) {

        this.setSymmetric(true);

        final int tmpDim = aSymmetric.getRowDim();

        final PhysicalStore<N> tmpV = this.getFactory().makeEye(tmpDim, tmpDim);

        final PhysicalStore<N> tmpHessenberg = this.toHessenberg(aSymmetric.copy(), tmpV);

        final DiagonalAccess<N> tmpSchur = this.toSchur(tmpHessenberg, tmpV);

        final Array1D<N> tmpMainDiagonal = tmpSchur.mainDiagonal;

        final Array1D<ComplexNumber> tmpEigenvalues = Array1D.makeComplex(tmpDim);
        final PhysicalStore<N> tmpD = this.getFactory().makeZero(tmpDim, tmpDim);

        N tmpDiagonalElement;
        for (int ij = 0; ij < tmpDim; ij++) {
            tmpDiagonalElement = tmpMainDiagonal.get(ij);
            tmpEigenvalues.set(ij, TypeUtils.toComplexNumber(tmpDiagonalElement));
            tmpD.set(ij, ij, tmpDiagonalElement);
        }

        this.setEigenvalues(tmpEigenvalues);
        this.setD(tmpD);
        this.setV(tmpV);

        return this.computed(false);
    }

    public boolean computeSymmetric(final MatrixStore<N> aSymmetric) {

        this.setSymmetric(true);

        final int tmpDim = aSymmetric.getRowDim();

        final PhysicalStore<N> tmpV = this.getFactory().makeEye(tmpDim, tmpDim);

        final DiagonalAccess<N> tmpTridiagonal = this.toTridiagonal((DecompositionStore<N>) aSymmetric.copy(), (DecompositionStore<N>) tmpV);

        return this.compute3D(tmpTridiagonal, tmpV);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public final MatrixStore<N> getD() {
        return myD;
    }

    public final ComplexNumber getDeterminant() {

        final AggregatorFunction<ComplexNumber> tmpVisitor = ComplexAggregator.getCollection().product();

        this.getEigenvalues().visitAll(tmpVisitor);

        return tmpVisitor.getNumber();
    }

    public final Array1D<ComplexNumber> getEigenvalues() {
        return myEigenvalues;
    }

    public final MatrixStore<N> getInverse() {

        if (myInverse == null) {

            final MatrixStore<N> tmpV = this.getV();
            final MatrixStore<N> tmpD = this.getD();

            final int tmpDim = tmpD.getRowDim();

            final PhysicalStore<N> tmpMtrx = tmpV.transpose();

            final N tmpZero = this.getFactory().getStaticZero().getNumber();
            final BinaryFunction<N> tmpDivide = this.getFactory().getFunctionSet().divide();

            for (int i = 0; i < tmpDim; i++) {
                if (tmpD.isZero(i, i)) {
                    tmpMtrx.fillRow(i, 0, tmpZero);
                } else {
                    tmpMtrx.modifyRow(i, 0, new PreconfiguredSecond<N>(tmpDivide, tmpD.get(i, i)));
                }
            }

            myInverse = tmpMtrx.multiplyLeft(tmpV);
        }

        return myInverse;
    }

    public final ComplexNumber getTrace() {

        final AggregatorFunction<ComplexNumber> tmpVisitor = ComplexAggregator.getCollection().sum();

        this.getEigenvalues().visitAll(tmpVisitor);

        return tmpVisitor.getNumber();
    }

    public final MatrixStore<N> getV() {
        return myV;
    }

    public final boolean isFullSize() {
        return true;
    }

    public final boolean isOrdered() {
        return true;
    }

    public final boolean isSolvable() {
        return this.isComputed() && this.isSymmetric();
    }

    public final boolean isSymmetric() {
        return mySymmetric;
    }

    public MatrixStore<N> reconstruct() {
        return MatrixUtils.reconstruct(this);
    }

    @Override
    public void reset() {

        super.reset();

        myInverse = null;
        myD = null;
        myEigenvalues = null;
        myV = null;
    }

    public final MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        return this.getInverse().multiplyRight(aRHS);
    }

    private final boolean compute3D(final DiagonalAccess<N> aTridiagonal, final PhysicalStore<N> aV) {

        final int tmpDim = aTridiagonal.getMinDim();

        final DiagonalAccess<N> tmpDiagonal = this.toDiagonal(aTridiagonal, aV);
        final Array1D<N> tmpMainDiagonal = tmpDiagonal.mainDiagonal;
        this.sort(tmpMainDiagonal, aV);

        final Array1D<ComplexNumber> tmpEigenvalues = Array1D.makeComplex(tmpDim);
        final PhysicalStore<N> tmpD = this.getFactory().makeZero(tmpDim, tmpDim);

        N tmpDiagonalElement;
        for (int ij = 0; ij < tmpDim; ij++) {
            tmpDiagonalElement = tmpMainDiagonal.get(ij);
            tmpEigenvalues.set(ij, TypeUtils.toComplexNumber(tmpDiagonalElement));
            tmpD.set(ij, ij, tmpDiagonalElement);
        }

        this.setEigenvalues(tmpEigenvalues);
        this.setD(tmpD);
        this.setV(aV);

        return this.computed(true);
    }

    protected abstract DiagonalAccess<N> extractTridiagonal(final PhysicalStore<N> aMtrxD);

    protected final void setD(final MatrixStore<N> aD) {
        myD = aD;
    }

    protected final void setEigenvalues(final Array1D<ComplexNumber> anEigenvalues) {
        myEigenvalues = anEigenvalues;
    }

    protected final void setSymmetric(final boolean aSymmetric) {
        mySymmetric = aSymmetric;
    }

    protected final void setV(final MatrixStore<N> aV) {
        myV = aV;
    }

    protected final void sort(final Array1D<N> eigenvalues, final PhysicalStore<N> eigenvectors) {

        final int tmpDim = eigenvalues.length;
        final int tmpLim = tmpDim - 1;

        for (int j1 = 0; j1 < tmpLim; j1++) {

            double tmpValue = eigenvalues.doubleValue(j1);
            int j2 = j1;

            for (int ij = j1 + 1; ij < tmpDim; ij++) {

                if (Math.abs(eigenvalues.doubleValue(ij)) > Math.abs(tmpValue)) {

                    tmpValue = eigenvalues.doubleValue(ij);
                    j2 = ij;
                }
            }

            if (j2 != j1) {
                eigenvalues.set(j2, eigenvalues.doubleValue(j1));
                eigenvalues.set(j1, tmpValue);
                eigenvectors.exchangeColumns(j1, j2);
            }
        }
    }

    protected abstract DiagonalAccess<N> toDiagonal(final DiagonalAccess<N> aTridiagonalSymmetric, final PhysicalStore<N> aMtrxV);

    @SuppressWarnings("unchecked")
    protected final PhysicalStore<N> toHessenberg(final PhysicalStore<N> aMtrxA, final PhysicalStore<N> aMtrxV) {

        final int tmpDim = aMtrxA.getRowDim();

        final Householder<N>[] tmpHouseholderColumns = new Householder[tmpDim];

        final N tmpZero = this.getFactory().getStaticZero().getNumber();

        Householder<N> tmpHouseholder;
        for (int ij = 0; ij < tmpDim; ij++) {

            tmpHouseholder = aMtrxA.generateHouseholderColumn(ij + 1, ij);

            aMtrxA.transformLeft(tmpHouseholder, ij + 1);

            tmpHouseholderColumns[ij] = tmpHouseholder;
        }

        for (int j = tmpDim - 1; j >= 0; j--) {
            aMtrxV.transformLeft(tmpHouseholderColumns[j], j);
            aMtrxA.fillColumn(j + 2, j, tmpZero);
        }

        return aMtrxA;
    }

    protected abstract DiagonalAccess<N> toSchur(final PhysicalStore<N> aHessenberg, final PhysicalStore<N> aMtrxV);

    @SuppressWarnings("unchecked")
    protected DiagonalAccess<N> toTridiagonal(final DecompositionStore<N> aMtrxA, final DecompositionStore<N> aMtrxV) {

        final int tmpDim = aMtrxA.getRowDim();

        final Householder<N>[] tmpHouseholderColumns = new Householder[tmpDim];

        Householder<N> tmpHouseholder;
        for (int ij = 0; ij < tmpDim; ij++) {

            tmpHouseholder = aMtrxA.generateHouseholderColumn(ij + 1, ij);

            aMtrxA.transformLeft(tmpHouseholder, ij + 1);
            aMtrxA.transformRight(tmpHouseholder, ij + 1);

            tmpHouseholderColumns[ij] = tmpHouseholder;
        }

        for (int j = tmpDim - 1; j >= 0; j--) {
            aMtrxV.transformLeft(tmpHouseholderColumns[j], j);
        }

        return this.extractTridiagonal(aMtrxA);
    }

    boolean computeTridiagonal(final DiagonalAccess<N> aTridiagonal) {

        this.setSymmetric(true);

        final int tmpDim = aTridiagonal.getRowDim();

        final PhysicalStore<N> tmpMtrxV = this.getFactory().makeEye(tmpDim, tmpDim);

        return this.compute3D(aTridiagonal, tmpMtrxV);
    }

}
