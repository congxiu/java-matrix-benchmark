/*
 * Copyright © 2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.implementation.FunctionSet;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.PhysicalStore.Factory;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.type.TypeUtils;

/**
 * Re-implemented
 *
 * @author apete
 */
abstract class EvD2<N extends Number> extends EigenvalueDecomposition<N> {

    static final class Primitive extends EvD2<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

        @Override
        protected DiagonalAccess<Double> extractTridiagonal(final PhysicalStore<Double> aMtrxD) {

            final Array2D<Double> tmpArray2D = ((PrimitiveDenseStore) aMtrxD).asArray2D();

            final Array1D<Double> tmpMain = tmpArray2D.sliceDiagonal(0, 0);
            //final Array1D<Double> tmpSuper = tmpArray2D.sliceDiagonal(0, 1); All elements un super has not been correctly calculated, but sub and super shouldbe the same.
            final Array1D<Double> tmpSub = tmpArray2D.sliceDiagonal(1, 0);

            return DiagonalAccess.makePrimitive(tmpMain, tmpSub, tmpSub);
        }

        protected Array1D<Double> makeWarkCopyArray(final int aDim) {
            return Array1D.makePrimitive(aDim);
        }

    }

    protected EvD2(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    @Override
    public final boolean computeNonsymmetric(final MatrixStore<N> aNonsymmetricStore) {

        final int tmpDim = aNonsymmetricStore.getMinDim();

        final PhysicalStore<N> tmpMtrxV = this.getFactory().makeEye(tmpDim, tmpDim);

        final PhysicalStore<N> tmpSimilar = this.toHessenberg(aNonsymmetricStore.copy(), tmpMtrxV);

        final DiagonalAccess<N> tmpValues = this.toSchur(tmpSimilar, tmpMtrxV);

        // TODO Auto-generated method stub

        return false;
    }

    @Override
    protected final DiagonalAccess<N> toDiagonal(final DiagonalAccess<N> aTridiagonalSymmetric, final PhysicalStore<N> aMtrxV) {

        final Factory<N> tmpFactory = this.getFactory();
        final FunctionSet<N> tmpFunctionSet = tmpFactory.getFunctionSet();

        final int tmpDim = aTridiagonalSymmetric.getRowDim();
        final int tmpLim = tmpDim - 1;

        final Array1D<N> tmpMainD = aTridiagonalSymmetric.mainDiagonal;
        final Array1D<N> tmpOffD = aTridiagonalSymmetric.superdiagonal;

        double tmpShift = PrimitiveMath.ZERO;
        double tmpShiftIncr;

        int z; // Index of first zero super/subdiagonal element after l.
        // Main loop, along the main diagonal.
        for (int l = 0; l < tmpLim; l++) {

            // Find first zero super/subdiagonal element.
            z = l;
            while (z < tmpLim) {
                if (TypeUtils.isZero(tmpOffD.doubleValue(z))) {
                    break;
                }
                z++;
            }

            // If z == l, tmpMainD[l] is an eigenvalue, otherwise, iterate.
            if (z > l) {

                do {

                    final double tmp1Al00 = tmpMainD.doubleValue(l);
                    final double tmp1Al01 = tmpOffD.doubleValue(l);
                    final double tmp1Al10 = tmp1Al01;
                    final double tmp1Al11 = tmpMainD.doubleValue(l + 1);

                    // Compute implicit shift

                    final double y = tmp1Al11 - tmp1Al00;
                    final double x = -(tmp1Al01 + tmp1Al10);

                    double t; // tan, cot or something temporary

                    final double cg; // cos Givens
                    final double sg; // sin Givens

                    if (TypeUtils.isZero(y)) {
                        cg = Math.signum(x);
                        sg = PrimitiveMath.ZERO;
                    } else if (TypeUtils.isZero(x)) {
                        sg = Math.signum(y);
                        cg = PrimitiveMath.ZERO;
                    } else if (Math.abs(y) > Math.abs(x)) {
                        t = x / y; // cot
                        sg = Math.signum(y) / PrimitiveFunction.SQRT1PX2.invoke(t);
                        cg = sg * t;
                    } else {
                        t = y / x; // tan
                        cg = Math.signum(x) / PrimitiveFunction.SQRT1PX2.invoke(t);
                        sg = cg * t;
                    }

                    final double tmp2Al00 = cg * tmp1Al00 + sg * tmp1Al10;
                    final double tmp2Al01 = (cg * (tmp1Al01 + tmp1Al10) + sg * (tmp1Al11 - tmp1Al00)) / PrimitiveMath.TWO;
                    final double tmp2Al10 = tmp2Al01;
                    final double tmp2Al11 = cg * tmp1Al11 - sg * tmp1Al01;

                    tmpMainD.set(l, tmp2Al00);
                    tmpMainD.set(l + 1, tmp2Al11);

                    tmpShiftIncr = tmp1Al00 - tmp2Al00;
                    tmpMainD.modifyRange(l + 2, tmpDim, tmpFunctionSet.subtract(), tmpFactory.getNumber(tmpShiftIncr));
                    tmpShift += tmpShiftIncr;

                    // Implicit QL transformation

                    double tmpRotCos1 = PrimitiveMath.ONE;
                    double tmpRotSin1 = PrimitiveMath.ZERO;

                    double tmpRotCos2 = PrimitiveMath.ONE;
                    double tmpRotSin2 = PrimitiveMath.ZERO;

                    double tmpRotCos3 = PrimitiveMath.ONE;
                    double tmpRotSin3 = PrimitiveMath.ZERO;

                    double p = tmpMainD.doubleValue(z); // Initiate p
                    double r;
                    for (int i = z - 1; i >= l; i--) {

                        final double tmpAi00 = tmpMainD.doubleValue(i);
                        final double tmpAi01 = tmpOffD.doubleValue(i);
                        final double tmpAi10 = tmpAi01;
                        final double tmpAi11 = tmpMainD.doubleValue(i + 1);

                        if (TypeUtils.isZero(tmpAi10)) {
                            tmpRotCos1 = Math.signum(tmpAi00);
                            tmpRotSin1 = PrimitiveMath.ZERO;
                        } else if (TypeUtils.isZero(tmpAi00)) {
                            tmpRotSin1 = Math.signum(tmpAi10);
                            tmpRotCos1 = PrimitiveMath.ZERO;
                        } else if (Math.abs(tmpAi10) > Math.abs(tmpAi00)) {
                            t = tmpAi00 / tmpAi10; // cot
                            tmpRotSin1 = Math.signum(tmpAi10) / PrimitiveFunction.SQRT1PX2.invoke(t);
                            tmpRotCos1 = tmpRotSin1 * t;
                        } else {
                            t = tmpAi10 / tmpAi00; // tan
                            tmpRotCos1 = Math.signum(tmpAi00) / PrimitiveFunction.SQRT1PX2.invoke(t);
                            tmpRotSin1 = tmpRotCos1 * t;
                        }

                        r = Math.hypot(p, tmpAi01);

                        tmpRotCos3 = tmpRotCos2;
                        tmpRotSin3 = tmpRotSin2;

                        tmpRotCos2 = tmpRotCos1;
                        tmpRotSin2 = tmpRotSin1;

                        tmpRotCos1 = p / r;
                        tmpRotSin1 = tmpAi01 / r;

                        tmpMainD.set(i + 1, tmpRotCos2 * p + tmpRotSin1 * (tmpRotCos1 * tmpRotCos2 * tmpAi01 + tmpRotSin1 * tmpAi00));
                        tmpOffD.set(i + 1, tmpRotSin2 * r);

                        p = tmpRotCos1 * tmpAi00 - tmpRotSin1 * tmpRotCos2 * tmpAi01; // Next p

                        // Accumulate transformation - rotate the eigenvector matrix
                        aMtrxV.transformRight(new Rotation<N>(i, i + 1, tmpFactory.getNumber(tmpRotCos1), tmpFactory.getNumber(tmpRotSin1)));
                    }

                    p = -tmpRotSin1 * tmpRotSin2 * tmpRotCos3 * tmpOffD.doubleValue(l + 1) * tmpOffD.doubleValue(l) / tmp2Al11; // Final p

                    tmpMainD.set(l, tmpRotCos1 * p);
                    tmpOffD.set(l, tmpRotSin1 * p);

                } while (TypeUtils.isZero(tmpOffD.doubleValue(l))); // Check for convergence
            } // End if (z > l)

            final double tmpEigenvalue = tmpMainD.doubleValue(l) + tmpShift;
            if (TypeUtils.isZero(tmpEigenvalue)) {
                tmpMainD.set(l, PrimitiveMath.ZERO);
            } else {
                tmpMainD.set(l, tmpEigenvalue);
            }
            tmpOffD.set(l, PrimitiveMath.ZERO);
        } // End main loop - l

        return aTridiagonalSymmetric; // It is now diagonal
    }

    @Override
    protected final DiagonalAccess<N> toSchur(final PhysicalStore<N> aHessenberg, final PhysicalStore<N> aMtrxV) {
        return null;
    }

}
