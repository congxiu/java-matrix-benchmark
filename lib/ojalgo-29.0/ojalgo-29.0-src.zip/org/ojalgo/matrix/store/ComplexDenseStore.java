/*
 * Copyright © 2005 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.store;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.array.ArrayUtils;
import org.ojalgo.array.ComplexArray;
import org.ojalgo.concurrent.ConcurrentExecutor;
import org.ojalgo.concurrent.ProcessorCount;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.AggregatorCollection;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.ChainableAggregator;
import org.ojalgo.function.aggregator.CollectableAggregator;
import org.ojalgo.function.aggregator.ComplexAggregator;
import org.ojalgo.function.implementation.ComplexFunction;
import org.ojalgo.function.implementation.FunctionSet;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.decomposition.DecompositionStore;
import org.ojalgo.matrix.decomposition.LUDecomposition.Pivot;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * A {@linkplain ComplexNumber} implementation of {@linkplain PhysicalStore}.
 *
 * @author apete
 */
public final class ComplexDenseStore extends ComplexArray implements PhysicalStore<ComplexNumber>, DecompositionStore<ComplexNumber> {

    public static final PhysicalStore.Factory<ComplexNumber> FACTORY = new PhysicalStore.Factory<ComplexNumber>() {

        public ComplexDenseStore conjugate(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getColDim();
            final int tmpColDim = aSource.getRowDim();

            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim * tmpColDim];

            ComplexDenseStore.conjugate(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return new ComplexDenseStore(tmpRowDim, tmpColDim, retValData);
        }

        public ComplexDenseStore copy(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getRowDim();
            final int tmpColDim = aSource.getColDim();

            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim * tmpColDim];
            final ComplexDenseStore retVal = new ComplexDenseStore(tmpRowDim, tmpColDim, retValData);

            ComplexDenseStore.copy(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return retVal;
        }

        public ComplexDenseStore copy(final double[][] aSource) {

            final int tmpRowDim = aSource.length;
            final int tmpColDim = aSource[0].length;

            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim * tmpColDim];
            final ComplexDenseStore retVal = new ComplexDenseStore(tmpRowDim, tmpColDim, retValData);

            ComplexDenseStore.copy(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return retVal;
        }

        /**
         * @deprecated v29 Use {@link #copy(Access2D)} instead
         */
        @Deprecated
        public ComplexDenseStore copyArray(final Array2D<? extends Number> aSource) {
            return this.copy(aSource);
        }

        public ComplexDenseStore copyMatrix(final BasicMatrix aSource) {

            final int tmpRowDim = aSource.getRowDim();
            final int tmpColDim = aSource.getColDim();

            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim * tmpColDim];
            final ComplexDenseStore retVal = new ComplexDenseStore(tmpRowDim, tmpColDim, retValData);

            ComplexDenseStore.copy(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return retVal;
        }

        /**
         * @deprecated Use {@link #copy(double[][])} instead
         */
        @Deprecated
        public ComplexDenseStore copyRaw(final double[][] aSource) {
            return this.copy(aSource);
        }

        /**
         * @deprecated v29 Use {@link #copy(Access2D)} instead
         */
        @Deprecated
        public ComplexDenseStore copyStore(final MatrixStore<? extends Number> aSource) {
            return this.copy(aSource);
        }

        public AggregatorCollection<ComplexNumber> getAggregatorCollection() {
            return ComplexAggregator.getCollection();
        }

        public FunctionSet<ComplexNumber> getFunctionSet() {
            return ComplexFunction.getSet();
        }

        public ComplexNumber getNumber(final double aNmbr) {
            return new ComplexNumber(aNmbr);
        }

        public ComplexNumber getNumber(final Number aNmbr) {
            return TypeUtils.toComplexNumber(aNmbr);
        }

        public ComplexNumber getStaticOne() {
            return ComplexNumber.ONE;
        }

        public ComplexNumber getStaticZero() {
            return ComplexNumber.ZERO;
        }

        public ComplexDenseStore makeColumn(final ComplexNumber[] aColumn) {
            return new ComplexDenseStore(aColumn.length, 1, ArrayUtils.copyOf(aColumn));
        }

        public ComplexDenseStore makeColumn(final double[] aColumn) {

            final int tmpRowDim = aColumn.length;
            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim];

            for (int i = 0; i < tmpRowDim; i++) {
                retValData[i] = new ComplexNumber(aColumn[i]);
            }

            return new ComplexDenseStore(tmpRowDim, 1, retValData);
        }

        public ComplexDenseStore makeColumn(final List<ComplexNumber> aColumn) {

            final int tmpRowDim = aColumn.size();
            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim];

            for (int i = 0; i < tmpRowDim; i++) {
                retValData[i] = aColumn.get(i);
            }

            return new ComplexDenseStore(tmpRowDim, 1, retValData);
        }

        public ComplexDenseStore makeEmpty(final int aRowDim, final int aColDim) {
            return new ComplexDenseStore(aRowDim, aColDim, new ComplexNumber[aRowDim * aColDim]);
        }

        public ComplexDenseStore makeEye(final int aRowDim, final int aColDim) {

            final ComplexDenseStore retVal = this.makeZero(aRowDim, aColDim);

            retVal.myUtility.fillDiagonal(0, 0, this.getStaticOne().getNumber());

            return retVal;
        }

        public ComplexDenseStore makeZero(final int aRowDim, final int aColDim) {
            return new ComplexDenseStore(aRowDim, aColDim);
        }

        public ComplexNumber toScalar(final double aNmbr) {
            return new ComplexNumber(aNmbr);
        }

        public ComplexNumber toScalar(final Number aNmbr) {
            return TypeUtils.toComplexNumber(aNmbr);
        }

        public ComplexDenseStore transpose(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getColDim();
            final int tmpColDim = aSource.getRowDim();

            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim * tmpColDim];

            ComplexDenseStore.transpose(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return new ComplexDenseStore(tmpRowDim, tmpColDim, retValData);
        }
    };

    static ComplexNumber aggregateAll(final ComplexArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final ChainableAggregator aVisitor, final int availableCPUs) {

        final AggregatorFunction<ComplexNumber> tmpAggrFunc = aVisitor.getComplexFunction();

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<ComplexNumber> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Callable<ComplexNumber>() {

                public ComplexNumber call() throws Exception {
                    return ComplexDenseStore.aggregateAll(aData, aRowDim, aFirstCol, tmpSplit, aVisitor, tmpCPUs);
                }
            });

            final Future<ComplexNumber> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Callable<ComplexNumber>() {

                public ComplexNumber call() throws Exception {
                    return ComplexDenseStore.aggregateAll(aData, aRowDim, tmpSplit, aColLimit, aVisitor, tmpCPUs);
                }
            });

            try {

                tmpAggrFunc.invoke(tmpFirstPart.get());
                tmpAggrFunc.invoke(tmpSecondPart.get());

            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.visit(aRowDim * aFirstCol, aRowDim * aColLimit, 1, tmpAggrFunc);
        }

        return tmpAggrFunc.getNumber();
    }

    static ComplexNumber aggregateAll(final ComplexArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final CollectableAggregator aVisitor, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<ComplexNumber> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Callable<ComplexNumber>() {

                public ComplexNumber call() throws Exception {
                    return ComplexDenseStore.aggregateAll(aData, aRowDim, aFirstCol, tmpSplit, aVisitor, tmpCPUs);
                }
            });

            final Future<ComplexNumber> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Callable<ComplexNumber>() {

                public ComplexNumber call() throws Exception {
                    return ComplexDenseStore.aggregateAll(aData, aRowDim, tmpSplit, aColLimit, aVisitor, tmpCPUs);
                }
            });

            try {

                return tmpFirstPart.get().add(tmpSecondPart.get());

            } catch (final InterruptedException anException) {
                anException.printStackTrace();
                return null;
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
                return null;
            }

        } else {

            final AggregatorFunction<ComplexNumber> tmpAggrFunc = aVisitor.getComplexFunction();

            aData.visit(aRowDim * aFirstCol, aRowDim * aColLimit, 1, tmpAggrFunc);

            return tmpAggrFunc.getNumber();
        }
    }

    static void conjugate(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<? extends Number> aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.conjugate(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.conjugate(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = TypeUtils.toComplexNumber(aSource.get(j, i)).conjugate();
                }
            }
        }
    }

    static void copy(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<? extends Number> aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.copy(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.copy(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = TypeUtils.toComplexNumber(aSource.get(i, j));
                }
            }
        }
    }

    static void copy(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final BasicMatrix aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.copy(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.copy(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aSource.toComplexNumber(i, j);
                }
            }
        }
    }

    static void copy(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final double[][] aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.copy(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.copy(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = new ComplexNumber(aSource[i][j]);
                }
            }
        }
    }

    static void daxpyCholesky(final ComplexNumber[] aData, final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColLimit, final ComplexNumber[] aMultipliers, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.daxpyCholesky(aData, aPivotRow, aRowDim, aFirstCol, tmpSplit, aMultipliers, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.daxpyCholesky(aData, aPivotRow, aRowDim, tmpSplit, aColLimit, aMultipliers, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            ComplexNumber tmpVal;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {

                tmpIndex = j + j * aRowDim;
                tmpVal = aMultipliers[j].divide(aMultipliers[aPivotRow]);

                // For each row below the diagonal
                for (int i = j; i < aRowDim; i++) {
                    aData[tmpIndex] = aData[tmpIndex].subtract(tmpVal.multiply(aMultipliers[i]));
                    tmpIndex++;
                }
            }
        }
    }

    static void daxpyLU(final ComplexNumber[] aData, final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColLimit, final ComplexNumber[] aMultipliers, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.daxpyLU(aData, aPivotRow, aRowDim, aFirstCol, tmpSplit, aMultipliers, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.daxpyLU(aData, aPivotRow, aRowDim, tmpSplit, aColLimit, aMultipliers, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            ComplexNumber tmpVal;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {
                tmpIndex = aPivotRow + j * aRowDim;
                tmpVal = aData[tmpIndex];
                for (int i = aPivotRow + 1; i < aRowDim; i++) {
                    tmpIndex++;
                    aData[tmpIndex] = aData[tmpIndex].subtract(aMultipliers[i].multiply(tmpVal));
                }
            }
        }
    }

    static void doHouseholderLeft(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Householder.Complex aHouseholder, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.doHouseholderLeft(aData, aRowDim, aFirstCol, tmpSplit, aHouseholder, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.doHouseholderLeft(aData, aRowDim, tmpSplit, aColLimit, aHouseholder, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final ComplexNumber[] tmpHouseholderVector = aHouseholder.vector;
            final int tmpFirstNonZero = aHouseholder.first;
            final ComplexNumber tmpBeta = aHouseholder.beta;

            ComplexNumber tmpScale;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {
                tmpScale = ComplexNumber.ZERO;
                tmpIndex = tmpFirstNonZero + j * aRowDim;
                for (int i = tmpFirstNonZero; i < aRowDim; i++) {
                    tmpScale = tmpScale.add(tmpHouseholderVector[i].multiply(aData[tmpIndex++]));
                }
                tmpScale = tmpScale.multiply(tmpBeta);
                tmpIndex = tmpFirstNonZero + j * aRowDim;
                for (int i = tmpFirstNonZero; i < aRowDim; i++) {
                    aData[tmpIndex] = aData[tmpIndex].subtract(tmpScale.multiply(tmpHouseholderVector[i]));
                    tmpIndex++;
                }
            }
        }
    }

    static void doHouseholderRight(final ComplexNumber[] aData, final int aFirstRow, final int aRowLimit, final int aColDim, final Householder.Complex aHouseholder, final int availableCPUs) {

        final int tmpRowCount = aRowLimit - aFirstRow;

        if ((availableCPUs > 1) && (tmpRowCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstRow + tmpRowCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.doHouseholderRight(aData, aFirstRow, tmpSplit, aColDim, aHouseholder, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.doHouseholderRight(aData, tmpSplit, aRowLimit, aColDim, aHouseholder, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final ComplexNumber[] tmpHouseholderVector = aHouseholder.vector;
            final int tmpFirstNonZero = aHouseholder.first;
            final ComplexNumber tmpBeta = aHouseholder.beta;

            final int tmpRowDim = aData.length / aColDim;

            ComplexNumber tmpScale;
            int tmpIndex;
            for (int i = aFirstRow; i < aRowLimit; i++) {
                tmpScale = ComplexNumber.ZERO;
                tmpIndex = i + tmpFirstNonZero * tmpRowDim;
                for (int j = tmpFirstNonZero; j < aColDim; j++) {
                    tmpScale = tmpScale.add(tmpHouseholderVector[j].multiply(aData[tmpIndex]));
                    tmpIndex += tmpRowDim;
                }
                tmpScale = tmpScale.multiply(tmpBeta);
                tmpIndex = i + tmpFirstNonZero * tmpRowDim;
                for (int j = tmpFirstNonZero; j < aColDim; j++) {
                    aData[tmpIndex] = aData[tmpIndex].subtract(tmpScale.multiply(tmpHouseholderVector[j]));
                    tmpIndex += tmpRowDim;
                }
            }
        }
    }

    static void doRotateLeft(final ComplexNumber[] aData, final int aColDim, final int aRowA, final int aRowB, final ComplexNumber aCos, final ComplexNumber aSin) {

        ComplexNumber tmpOldA;
        ComplexNumber tmpOldB;

        int tmpIndexA = aRowA;
        int tmpIndexB = aRowB;
        final int tmpIndexStep = aData.length / aColDim;

        for (int j = 0; j < aColDim; j++) {

            tmpOldA = aData[tmpIndexA];
            tmpOldB = aData[tmpIndexB];

            aData[tmpIndexA] = aCos.multiply(tmpOldA).add(aSin.multiply(tmpOldB));
            aData[tmpIndexB] = aCos.multiply(tmpOldB).subtract(aSin.multiply(tmpOldA));

            tmpIndexA += tmpIndexStep;
            tmpIndexB += tmpIndexStep;
        }
    }

    static void doRotateRight(final ComplexNumber[] aData, final int aRowDim, final int aColA, final int aColB, final ComplexNumber aCos, final ComplexNumber aSin) {

        ComplexNumber tmpOldA;
        ComplexNumber tmpOldB;

        int tmpIndexA = aColA * aRowDim;
        int tmpIndexB = aColB * aRowDim;

        for (int i = 0; i < aRowDim; i++) {

            tmpOldA = aData[tmpIndexA];
            tmpOldB = aData[tmpIndexB];

            aData[tmpIndexA] = aCos.multiply(tmpOldA).subtract(aSin.multiply(tmpOldB));
            aData[tmpIndexB] = aCos.multiply(tmpOldB).add(aSin.multiply(tmpOldA));

            tmpIndexA++;
            tmpIndexB++;
        }
    }

    static void fillMatching(final ComplexArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final ComplexArray aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexArray aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void fillMatching(final ComplexArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final ComplexArray aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexNumber aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void fillMatching(final ComplexArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final ComplexNumber aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexArray aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void fillMatching(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final ComplexNumber aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final MatrixStore<ComplexNumber> aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg, aRightArg.get(i, j));
                }
            }
        }
    }

    static void fillMatching(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final MatrixStore<ComplexNumber> aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexNumber aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg.get(i, j), aRightArg);
                }
            }
        }
    }

    static void fillMatching(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final MatrixStore<ComplexNumber> aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final MatrixStore<ComplexNumber> aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg.get(i, j), aRightArg.get(i, j));
                }
            }
        }
    }

    static void maxpy(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final ComplexNumber aScale, final MatrixStore<ComplexNumber> aStore, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.maxpy(aData, aRowDim, aFirstCol, tmpSplit, aScale, aStore, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.maxpy(aData, aRowDim, tmpSplit, aColLimit, aScale, aStore, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex] = aScale.multiply(aStore.get(i, j)).add(aData[tmpIndex]);
                    tmpIndex++;
                }
            }
        }
    }

    static void modifyAll(final ComplexArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final UnaryFunction<ComplexNumber> aFunc, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.modifyAll(aData, aRowDim, aFirstCol, tmpSplit, aFunc, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.modifyAll(aData, aRowDim, tmpSplit, aColLimit, aFunc, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.modify(aRowDim * aFirstCol, aRowDim * aColLimit, 1, aFunc);
        }
    }

    static void multiply(final ComplexNumber[] aProductArray, final int aFirstRow, final int aRowLimit, final int aColDim, final ComplexNumber[] aLeftArray, final ComplexNumber[] aRightArray, final int availableCPUs) {

        final int tmpRowCount = aRowLimit - aFirstRow;

        if ((availableCPUs > 1) && (tmpRowCount > BranchLimit.MULTIPLY)) {

            final int tmpSplit = aFirstRow + tmpRowCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.multiply(aProductArray, aFirstRow, tmpSplit, aColDim, aLeftArray, aRightArray, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.multiply(aProductArray, tmpSplit, aRowLimit, aColDim, aLeftArray, aRightArray, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpCalcSize = aRightArray.length / aColDim;
            final int tmpRowDim = aLeftArray.length / tmpCalcSize;

            final ComplexNumber[] tmpLeftRow = new ComplexNumber[tmpCalcSize];
            int tmpIndex;
            ComplexNumber tmpVal;

            for (int i = aFirstRow; i < aRowLimit; i++) {
                for (int c = 0; c < tmpCalcSize; c++) {
                    tmpLeftRow[c] = aLeftArray[i + c * tmpRowDim];
                }
                for (int j = 0; j < aColDim; j++) {
                    tmpIndex = j * tmpCalcSize;
                    tmpVal = ComplexNumber.ZERO;
                    for (int c = 0; c < tmpCalcSize; c++) {
                        tmpVal = tmpVal.add(tmpLeftRow[c].multiply(aRightArray[tmpIndex++]));
                    }
                    aProductArray[i + j * tmpRowDim] = tmpVal;
                }
            }
        }
    }

    static void multiply(final ComplexNumber[] aProductArray, final MatrixStore<ComplexNumber> aLeftStore, final MatrixStore<ComplexNumber> aRightStore) {

        final int tmpRowDim = aLeftStore.getRowDim();
        final int tmpCalcSize = aRightStore.getRowDim();
        final int tmpColDim = aRightStore.getColDim();

        final boolean tmpLL = aLeftStore.isLowerLeftShaded();
        final boolean tmpLU = aLeftStore.isUpperRightShaded();
        final boolean tmpRL = aRightStore.isLowerLeftShaded();
        final boolean tmpRU = aRightStore.isUpperRightShaded();
        int tmpFirst;
        int tmpLimit;

        final ComplexNumber[] tmpLeftRow = new ComplexNumber[tmpCalcSize];
        ComplexNumber tmpVal;

        for (int i = 0; i < tmpRowDim; i++) {
            for (int c = 0; c < tmpCalcSize; c++) {
                tmpLeftRow[c] = aLeftStore.get(i, c);
            }
            for (int j = 0; j < tmpColDim; j++) {
                tmpFirst = MatrixUtils.max(tmpLL ? i - 1 : 0, tmpRU ? j - 1 : 0, 0);
                tmpLimit = MatrixUtils.min(tmpLU ? i + 2 : tmpCalcSize, tmpRL ? j + 2 : tmpCalcSize, tmpCalcSize);
                tmpVal = ComplexNumber.ZERO;
                for (int c = tmpFirst; c < tmpLimit; c++) {
                    tmpVal = tmpVal.add(tmpLeftRow[c].multiply(aRightStore.get(c, j)));
                }
                aProductArray[i + j * tmpRowDim] = tmpVal;
            }
        }
    }

    static void substituteBackwards(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<ComplexNumber> aBody, final boolean assumeOne, final boolean transposed, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.substituteBackwards(aData, aRowDim, aFirstCol, tmpSplit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.substituteBackwards(aData, aRowDim, tmpSplit, aColLimit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpDiagDim = aBody.getMinDim();

            final ComplexNumber[] tmpRow = new ComplexNumber[tmpDiagDim];
            ComplexNumber tmpVal;
            int tmpColBaseIndex;

            for (int i = tmpDiagDim - 1; i >= 0; i--) {

                for (int j = i; j < tmpDiagDim; j++) {
                    tmpRow[j] = transposed ? aBody.get(j, i) : aBody.get(i, j);
                }

                for (int s = aFirstCol; s < aColLimit; s++) {

                    tmpColBaseIndex = s * aRowDim;

                    tmpVal = ComplexNumber.ZERO;
                    for (int j = i + 1; j < tmpDiagDim; j++) {
                        tmpVal = tmpVal.add(tmpRow[j].multiply(aData[j + tmpColBaseIndex]));
                    }
                    aData[i + tmpColBaseIndex] = aData[i + tmpColBaseIndex].subtract(tmpVal);

                    if (!assumeOne) {
                        aData[i + tmpColBaseIndex] = aData[i + tmpColBaseIndex].divide(tmpRow[i]);
                    }
                }
            }
        }
    }

    static void substituteForwards(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<ComplexNumber> aBody, final boolean assumeOne, final boolean transposed, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.substituteForwards(aData, aRowDim, aFirstCol, tmpSplit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.substituteForwards(aData, aRowDim, tmpSplit, aColLimit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpDiagDim = aBody.getMinDim();

            final ComplexNumber[] tmpRow = new ComplexNumber[tmpDiagDim];
            ComplexNumber tmpVal;
            int tmpColBaseIndex;

            for (int i = 0; i < tmpDiagDim; i++) {

                for (int j = 0; j <= i; j++) {
                    tmpRow[j] = transposed ? aBody.get(j, i) : aBody.get(i, j);
                }

                for (int s = aFirstCol; s < aColLimit; s++) {

                    tmpColBaseIndex = s * aRowDim;

                    tmpVal = ComplexNumber.ZERO;
                    for (int j = 0; j < i; j++) {
                        tmpVal = tmpVal.add(tmpRow[j].multiply(aData[j + tmpColBaseIndex]));
                    }
                    aData[i + tmpColBaseIndex] = aData[i + tmpColBaseIndex].subtract(tmpVal);

                    if (!assumeOne) {
                        aData[i + tmpColBaseIndex] = aData[i + tmpColBaseIndex].divide(tmpRow[i]);
                    }
                }
            }
        }
    }

    static void transpose(final ComplexNumber[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<? extends Number> aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.transpose(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    ComplexDenseStore.transpose(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = TypeUtils.toComplexNumber(aSource.get(j, i));
                }
            }
        }
    }

    private final int myColDim;

    private final int myRowDim;

    private final Array2D<ComplexNumber> myUtility;

    ComplexDenseStore(final ComplexNumber[] anArray) {

        super(anArray);

        myRowDim = anArray.length;
        myColDim = 1;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    ComplexDenseStore(final int aLength) {

        super(aLength);

        myRowDim = aLength;
        myColDim = 1;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    ComplexDenseStore(final int aRowDim, final int aColDim) {

        super(aRowDim * aColDim);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    ComplexDenseStore(final int aRowDim, final int aColDim, final ComplexNumber[] anArray) {

        super(anArray);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    public ComplexNumber aggregateAll(final ChainableAggregator aVisitor) {
        return ComplexDenseStore.aggregateAll(this, myRowDim, 0, myColDim, aVisitor, ProcessorCount.RUNTIME);
    }

    public ComplexNumber aggregateAll(final CollectableAggregator aVisitor) {
        return ComplexDenseStore.aggregateAll(this, myRowDim, 0, myColDim, aVisitor, ProcessorCount.RUNTIME);
    }

    public Array2D<ComplexNumber> asArray2D() {
        return myUtility;
    }

    public Array1D<ComplexNumber> asList() {
        return myUtility.asArray1D();
    }

    public final MatrixStore.Builder<ComplexNumber> builder() {
        return new MatrixStore.Builder<ComplexNumber>(this);
    }

    public void caxpy(final ComplexNumber aSclrA, final int aColX, final int aColY, final int aFirstRow) {

        final ComplexNumber[] tmpData = this.data();

        final int tmpRowDim = myRowDim;

        int tmpIndX = aFirstRow + aColX * tmpRowDim;
        int tmpIndY = aFirstRow + aColY * tmpRowDim;

        for (int i = aFirstRow; i < tmpRowDim; i++) {
            tmpData[tmpIndY] = aSclrA.multiply(tmpData[tmpIndX]).add(tmpData[tmpIndY]);
            tmpIndX++;
            tmpIndY++;
        }
    }

    public boolean computeInPlaceCholesky(final boolean checkForSPD) {

        // True if Positive Definite (does not check for symmetry)
        boolean tmpPD = myRowDim == myColDim;
        final int tmpDim = myRowDim;
        final ComplexNumber[] tmpArray = this.data();

        int tmpIndex;
        final ComplexNumber[] tmpLocal = new ComplexNumber[tmpDim];
        ComplexNumber tmpVal;

        // Along the main diagonal
        for (int ij = 0; tmpPD && (ij < tmpDim); ij++) {

            // Pivot element
            tmpIndex = ij + ij * tmpDim;
            tmpLocal[ij] = tmpArray[tmpIndex];

            if ((tmpLocal[ij].getReal() > PrimitiveMath.ZERO) && (tmpLocal[ij].getImaginary() == PrimitiveMath.ZERO)) {

                // Current column below the diagonal
                tmpVal = ComplexFunction.SQRT.invoke(tmpLocal[ij]);
                tmpArray[tmpIndex] = tmpVal;
                for (int j = ij + 1; j < tmpLocal.length; j++) {
                    tmpIndex++;
                    tmpLocal[j] = tmpArray[tmpIndex];
                    tmpArray[tmpIndex] = tmpArray[tmpIndex].divide(tmpVal);
                }

                // For each of the remining columns
                ComplexDenseStore.daxpyCholesky(tmpArray, ij, tmpDim, ij + 1, tmpDim, tmpLocal, ProcessorCount.RUNTIME);

                //                for (int j = ij + 1; j < tmpDim; j++) {
                //
                //                    tmpIndex = j + j * tmpDim;
                //                    tmpVal = tmpLocal[j].divide(tmpLocal[ij]);
                //
                //                    // For each row below the diagonal
                //                    for (int i = j; i < tmpDim; i++) {
                //                        tmpArray[tmpIndex] = tmpArray[tmpIndex].subtract(tmpVal.multiply(tmpLocal[i]));
                //                        tmpIndex++;
                //                    }
                //                }
            } else {
                tmpPD = false;
            }
        }

        return tmpPD;
    }

    public Pivot computeInPlaceLU(final boolean assumeNoPivotingRequired) {

        final Pivot retVal = new Pivot(myRowDim);

        final ComplexNumber[] tmpData = this.data();
        final ComplexNumber[] tmpMultiplierColumn = new ComplexNumber[myRowDim];

        final int tmpMinDim = Math.min(myRowDim, myColDim);

        int tmpPivotRowIndex, tmpDataIndex;
        double tmpVal;
        ComplexNumber tmpNmbr;

        // Main loop - along the diagonal
        for (int ij = 0; ij < tmpMinDim; ij++) {

            if (!assumeNoPivotingRequired) {
                // Find next pivot row, stop searching when something good enough is found
                tmpVal = tmpData[tmpDataIndex = ij + myRowDim * ij].getModulus();
                tmpPivotRowIndex = ij;
                for (int i = ij + 1; (i < myRowDim) && (tmpVal < PrimitiveMath.HALF); i++) {
                    if (tmpData[++tmpDataIndex].getModulus() > tmpVal) {
                        tmpVal = tmpData[tmpDataIndex].getModulus();
                        tmpPivotRowIndex = i;
                    }
                }
                // Pivot?
                if (tmpPivotRowIndex != ij) {
                    myUtility.exchangeRows(tmpPivotRowIndex, ij);
                    retVal.change(tmpPivotRowIndex, ij);
                }
            }

            // Do the calculations...
            tmpNmbr = tmpData[tmpDataIndex = ij + myRowDim * ij];
            if (!tmpNmbr.isZero()) {

                // Calculate multipliers and copy to local column
                for (int i = ij + 1; i < myRowDim; i++) {
                    tmpDataIndex++;
                    tmpData[tmpDataIndex] = tmpData[tmpDataIndex].divide(tmpNmbr);
                    tmpMultiplierColumn[i] = tmpData[tmpDataIndex];
                }

                // Apply transformations to everything below and to the right of the pivot element
                ComplexDenseStore.daxpyLU(tmpData, ij, myRowDim, ij + 1, myColDim, tmpMultiplierColumn, ProcessorCount.RUNTIME);

            } else {

                tmpData[tmpDataIndex] = ComplexNumber.ZERO;
            }
        }

        return retVal;
    }

    public void computeInPlaceQR() {

        //        final Householder.Complex tmpWorkCopy = new Householder.Complex(myRowDim);
        //
        //        for (int j = 0; j < myColDim; j++) {
        //            if (this.generateHouseholder(j)) {
        //                this.extractAndTransform(this, j, j + 1, tmpWorkCopy);
        //            }
        //        }

        final ComplexNumber[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        final Householder.Complex tmpWorkCopy = new Householder.Complex(tmpRowDim);

        for (int j = 0; j < tmpColDim; j++) {
            if (this.generateApplyAndCopyHouseholderColumn(j, j, tmpWorkCopy)) {
                ComplexDenseStore.doHouseholderLeft(tmpData, tmpRowDim, j + 1, tmpColDim, tmpWorkCopy, ProcessorCount.RUNTIME);
            }
        }
    }

    public void computeInPlaceTridiagonal() {

        final int tmpDim = myRowDim;
        final int tmpLim = tmpDim - 2;

        final ComplexNumber[] tmpData = this.data();

        final Householder.Complex tmpHousehoulder = new Householder.Complex(tmpDim);

        int tmpNext;
        for (int ij = 0; ij < tmpLim; ij++) {

            tmpNext = ij + 1;

            if (this.generateApplyAndCopyHouseholderColumn(tmpNext, ij, tmpHousehoulder)) {
                ComplexDenseStore.doHouseholderLeft(tmpData, tmpDim, tmpNext, tmpDim, tmpHousehoulder, ProcessorCount.RUNTIME);
                ComplexDenseStore.doHouseholderRight(tmpData, tmpNext, tmpDim, tmpDim, tmpHousehoulder, ProcessorCount.RUNTIME);
            }
        }
    }

    public ComplexDenseStore conjugate() {
        return (ComplexDenseStore) FACTORY.conjugate(this);
    }

    public ComplexDenseStore copy() {
        return new ComplexDenseStore(myRowDim, myColDim, this.copyOfData());
    }

    public double doubleValue(final int aRow, final int aCol) {
        return this.doubleValue(aRow + aCol * myRowDim);
    }

    public boolean equals(final MatrixStore<ComplexNumber> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(this, aStore, aCntxt);
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(final Object anObj) {
        if (anObj instanceof MatrixStore) {
            return this.equals((MatrixStore<ComplexNumber>) anObj, TypeUtils.EQUALS_NUMBER_CONTEXT);
        } else {
            return super.equals(anObj);
        }
    }

    public void exchangeColumns(final int aColA, final int aColB) {
        myUtility.exchangeColumns(aColA, aColB);
    }

    public void exchangeRows(final int aRowA, final int aRowB) {
        myUtility.exchangeRows(aRowA, aRowB);
    }

    public void fillAll(final ComplexNumber aNmbr) {
        myUtility.fillAll(aNmbr);
    }

    public void fillByMultiplying(final MatrixStore<ComplexNumber> aLeftArg, final MatrixStore<ComplexNumber> aRightArg) {
        ComplexDenseStore.multiply(this.data(), 0, myRowDim, myColDim, this.cast(aLeftArg).data(), this.cast(aRightArg).data(), ProcessorCount.RUNTIME);
    }

    public void fillColumn(final int aRow, final int aCol, final ComplexNumber aNmbr) {
        myUtility.fillColumn(aRow, aCol, aNmbr);
    }

    public void fillDiagonal(final int aRow, final int aCol, final ComplexNumber aNmbr) {
        myUtility.fillDiagonal(aRow, aCol, aNmbr);
    }

    public void fillMatching(final Access2D<ComplexNumber> aSource2D) {
        ComplexDenseStore.copy(this.data(), myRowDim, 0, myColDim, aSource2D, ProcessorCount.RUNTIME);
    }

    public void fillMatching(final ComplexNumber aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final MatrixStore<ComplexNumber> aRightArg) {
        if (aRightArg instanceof ComplexArray) {
            ComplexDenseStore.fillMatching(this, myRowDim, 0, myColDim, aLeftArg, aFunc, (ComplexArray) aRightArg, ProcessorCount.RUNTIME);
        } else {
            ComplexDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillMatching(final MatrixStore<ComplexNumber> aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexNumber aRightArg) {
        if (aLeftArg instanceof ComplexArray) {
            ComplexDenseStore.fillMatching(this, myRowDim, 0, myColDim, (ComplexArray) aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        } else {
            ComplexDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillMatching(final MatrixStore<ComplexNumber> aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final MatrixStore<ComplexNumber> aRightArg) {
        if ((aLeftArg instanceof ComplexArray) && (aRightArg instanceof ComplexArray)) {
            ComplexDenseStore.fillMatching(this, myRowDim, 0, myColDim, (ComplexArray) aLeftArg, aFunc, (ComplexArray) aRightArg, ProcessorCount.RUNTIME);
        } else {
            ComplexDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillRow(final int aRow, final int aCol, final ComplexNumber aNmbr) {
        myUtility.fillRow(aRow, aCol, aNmbr);
    }

    public Householder<ComplexNumber> generateHouseholderColumn(final int newI, final int newIj) {
        // TODO Auto-generated method stub
        return null;
    }

    public Householder<ComplexNumber> generateHouseholderRow(final int newIj, final int newI) {
        // TODO Auto-generated method stub
        return null;
    }

    public ComplexNumber get(final int aRow, final int aCol) {
        return myUtility.get(aRow, aCol);
    }

    public int getColDim() {
        return myColDim;
    }

    public PhysicalStore.Factory<ComplexNumber> getFactory() {
        return FACTORY;
    }

    public int getIndexOfLargestInColumn(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInColumn(aRow, aCol);
    }

    public int getIndexOfLargestInRow(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInRow(aRow, aCol);
    }

    public int getMinDim() {
        return Math.min(myRowDim, myColDim);
    }

    /**
     * @deprecated Use {@link #get(int,int)} instead
     */
    @Deprecated
    public ComplexNumber getNumber(final int aRow, final int aCol) {
        return this.get(aRow, aCol);
    }

    public int getRowDim() {
        return myRowDim;
    }

    @Override
    public int hashCode() {
        return MatrixUtils.hashCode(this);
    }

    public boolean isAbsolute(final int aRow, final int aCol) {
        return myUtility.isAbsolute(aRow, aCol);
    }

    public boolean isLowerLeftShaded() {
        return false;
    }

    public boolean isReal(final int aRow, final int aCol) {
        return myUtility.isReal(aRow, aCol);
    }

    public boolean isShaded() {
        return false;
    }

    public boolean isUpperRightShaded() {
        return false;
    }

    public boolean isZero(final int aRow, final int aCol) {
        return myUtility.isZero(aRow, aCol);
    }

    public void maxpy(final ComplexNumber aSclrA, final MatrixStore<ComplexNumber> aMtrxX) {
        ComplexDenseStore.maxpy(this.data(), myRowDim, 0, myColDim, aSclrA, aMtrxX, ProcessorCount.RUNTIME);
    }

    public void modifyAll(final UnaryFunction<ComplexNumber> aFunc) {
        ComplexDenseStore.modifyAll(this, myRowDim, 0, myColDim, aFunc, ProcessorCount.RUNTIME);
    }

    public void modifyColumn(final int aRow, final int aCol, final UnaryFunction<ComplexNumber> aFunc) {
        myUtility.modifyColumn(aRow, aCol, aFunc);
    }

    public void modifyDiagonal(final int aRow, final int aCol, final UnaryFunction<ComplexNumber> aFunc) {
        myUtility.modifyDiagonal(aRow, aCol, aFunc);
    }

    public void modifyRow(final int aRow, final int aCol, final UnaryFunction<ComplexNumber> aFunc) {
        myUtility.modifyRow(aRow, aCol, aFunc);
    }

    public MatrixStore<ComplexNumber> multiplyLeft(final MatrixStore<ComplexNumber> aStore) {

        final int tmpRowDim = aStore.getRowDim();
        final int tmpColDim = myColDim;

        final ComplexNumber[] retVal = new ComplexNumber[tmpRowDim * tmpColDim];

        ComplexDenseStore.multiply(retVal, 0, tmpRowDim, tmpColDim, this.cast(aStore).data(), this.data(), ProcessorCount.RUNTIME);

        return new ComplexDenseStore(tmpRowDim, tmpColDim, retVal);
    }

    public MatrixStore<ComplexNumber> multiplyRight(final MatrixStore<ComplexNumber> aStore) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = aStore.getColDim();

        final ComplexNumber[] retVal = new ComplexNumber[tmpRowDim * tmpColDim];

        ComplexDenseStore.multiply(retVal, 0, tmpRowDim, tmpColDim, this.data(), this.cast(aStore).data(), ProcessorCount.RUNTIME);

        return new ComplexDenseStore(tmpRowDim, tmpColDim, retVal);
    }

    public void raxpy(final ComplexNumber aSclrA, final int aRowX, final int aRowY, final int aFirstCol) {

        final ComplexNumber[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        int tmpIndX = aRowX + aFirstCol * tmpRowDim;
        int tmpIndY = aRowY + aFirstCol * tmpRowDim;

        for (int j = aFirstCol; j < tmpColDim; j++) {
            tmpData[tmpIndY] = aSclrA.multiply(tmpData[tmpIndX]).add(tmpData[tmpIndY]);
            tmpIndX += tmpRowDim;
            tmpIndY += tmpRowDim;
        }
    }

    public void set(final int aRow, final int aCol, final ComplexNumber aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void set(final int aRow, final int aCol, final double aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void shadeLowerLeft() {
        ;
    }

    public void shadeUpperRight() {
        ;
    }

    public void substituteBackwards(final Access2D<ComplexNumber> aBody, final boolean assumeOne, final boolean transposed) {
        ComplexDenseStore.substituteBackwards(this.data(), myRowDim, 0, myColDim, aBody, assumeOne, transposed, ProcessorCount.RUNTIME);
    }

    public void substituteForwards(final Access2D<ComplexNumber> aBody, final boolean assumeOne, final boolean transposed) {
        ComplexDenseStore.substituteForwards(this.data(), myRowDim, 0, myColDim, aBody, assumeOne, transposed, ProcessorCount.RUNTIME);
    }

    public double[][] toRawCopy() {
        return myUtility.toRawCopy();
    }

    public Scalar<ComplexNumber> toScalar(final int aRow, final int aCol) {
        return myUtility.toScalar(aRow, aCol);
    }

    public void transformLeft(final Householder.Reference<ComplexNumber> aTransf, final int aFirstCol) {
        ComplexDenseStore.doHouseholderLeft(this.data(), myRowDim, aFirstCol, myColDim, aTransf.getComplexWorkCopy().copy(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformLeft(final Householder<ComplexNumber> aTransf) {
        this.transformLeft(aTransf, 0);
    }

    public void transformLeft(final Householder<ComplexNumber> aTransf, final int aFirstCol) {
        ComplexDenseStore.doHouseholderLeft(this.data(), myRowDim, aFirstCol, myColDim, new Householder.Complex(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformLeft(final Rotation<ComplexNumber> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {

            ComplexDenseStore.doRotateLeft(this.data(), myColDim, tmpLow, tmpHigh, aTransf.cos, aTransf.sin);

        } else if ((aTransf.cos != null) && (aTransf.cos.compareTo(aTransf.sin) == 0)) {

            myUtility.modifyRow(tmpLow, 0, ComplexFunction.MULTIPLY, aTransf.cos);

        } else {

            myUtility.modifyRow(tmpLow, 0, ComplexFunction.NEGATE);
        }
    }

    public void transformRight(final Householder.Reference<ComplexNumber> aTransf, final int aFirstRow) {
        ComplexDenseStore.doHouseholderRight(this.data(), aFirstRow, myRowDim, myColDim, aTransf.getComplexWorkCopy().copy(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformRight(final Householder<ComplexNumber> aTransf) {
        this.transformRight(aTransf, 0);
    }

    public void transformRight(final Householder<ComplexNumber> aTransf, final int aFirstRow) {
        ComplexDenseStore.doHouseholderRight(this.data(), aFirstRow, myRowDim, myColDim, new Householder.Complex(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformRight(final Rotation<ComplexNumber> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {

            ComplexDenseStore.doRotateRight(this.data(), myRowDim, tmpLow, tmpHigh, aTransf.cos, aTransf.sin);

        } else if ((aTransf.cos != null) && (aTransf.cos.compareTo(aTransf.sin) == 0)) {

            myUtility.modifyColumn(0, tmpHigh, ComplexFunction.MULTIPLY, aTransf.cos);

        } else {

            myUtility.modifyColumn(0, tmpHigh, ComplexFunction.NEGATE);
        }
    }

    public ComplexDenseStore transpose() {
        return (ComplexDenseStore) FACTORY.transpose(this);
    }

    public void unshade() {
        ;
    }

    public void visitAll(final AggregatorFunction<ComplexNumber> aVisitor) {
        myUtility.visitAll(aVisitor);
    }

    public void visitColumn(final int aRow, final int aCol, final AggregatorFunction<ComplexNumber> aVisitor) {
        myUtility.visitColumn(aRow, aCol, aVisitor);
    }

    public void visitDiagonal(final int aRow, final int aCol, final AggregatorFunction<ComplexNumber> aVisitor) {
        myUtility.visitDiagonal(aRow, aCol, aVisitor);
    }

    public void visitRow(final int aRow, final int aCol, final AggregatorFunction<ComplexNumber> aVisitor) {
        myUtility.visitRow(aRow, aCol, aVisitor);
    }

    private ComplexDenseStore cast(final MatrixStore<ComplexNumber> aStore) {
        if (aStore instanceof ComplexDenseStore) {
            return (ComplexDenseStore) aStore;
        } else {
            return (ComplexDenseStore) FACTORY.copy(aStore);
        }
    }

    private boolean generateApplyAndCopyHouseholderColumn(final int aRow, final int aCol, final Householder.Complex aDestination) {

        final ComplexNumber[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColBaseIndex = tmpRowDim * aCol;

        ComplexNumber tmpNmbr;
        double tmpVal;
        double tmpVal2 = PrimitiveMath.ZERO;
        for (int i = aRow; i < tmpRowDim; i++) {
            tmpNmbr = tmpData[i + tmpColBaseIndex];
            tmpVal = tmpNmbr.getModulus();
            tmpVal2 += tmpVal * tmpVal;
        }
        tmpVal2 = Math.sqrt(tmpVal2);

        final boolean retVal = !TypeUtils.isZero(tmpVal2);

        if (retVal) {

            ComplexNumber tmpScale = tmpData[aRow + tmpColBaseIndex];

            if (tmpScale.getReal() <= PrimitiveMath.ZERO) {
                tmpScale = tmpScale.subtract(tmpVal2);
                tmpData[aRow + tmpColBaseIndex] = new ComplexNumber(tmpVal2);
            } else {
                tmpScale = tmpScale.add(tmpVal2);
                tmpData[aRow + tmpColBaseIndex] = new ComplexNumber(-tmpVal2);
            }

            final ComplexNumber[] tmpVector = aDestination.vector;

            tmpVal2 = PrimitiveMath.ONE;
            tmpVector[aRow] = ComplexNumber.ONE;
            for (int i = aRow + 1; i < tmpRowDim; i++) {
                tmpNmbr = tmpData[i + tmpColBaseIndex] = ComplexFunction.DIVIDE.invoke(tmpData[i + tmpColBaseIndex], tmpScale);
                tmpVal = tmpNmbr.getModulus();
                tmpVal2 += tmpVal * tmpVal;
                tmpVector[i] = tmpNmbr;
            }

            aDestination.beta = new ComplexNumber(PrimitiveMath.TWO / tmpVal2);

            aDestination.first = aRow;
        }

        return retVal;
    }

    private boolean generateHouseholder(final int aCol) {

        final AggregatorFunction<ComplexNumber> tmpNormAggr = ComplexAggregator.getCollection().norm2();
        myUtility.visitColumn(aCol, aCol, tmpNormAggr);
        final ComplexNumber tmpNorm = tmpNormAggr.getNumber();

        final boolean retVal = !TypeUtils.isZero(tmpNorm.doubleValue());

        if (retVal) {

            ComplexNumber tmpScale = this.get(aCol, aCol);

            if (tmpScale.getReal() <= PrimitiveMath.ZERO) {
                tmpScale = tmpScale.subtract(tmpNorm);
                this.set(aCol, aCol, tmpNorm);
            } else {
                tmpScale = tmpScale.add(tmpNorm);
                this.set(aCol, aCol, tmpNorm.negate());
            }

            myUtility.modifyColumn(aCol + 1, aCol, ComplexFunction.DIVIDE, tmpScale);
        }

        return retVal;
    }

}
