/*
 * Copyright © 2005 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.store;

import static org.ojalgo.constant.PrimitiveMath.*;
import static org.ojalgo.function.implementation.PrimitiveFunction.*;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.array.ArrayUtils;
import org.ojalgo.array.PrimitiveArray;
import org.ojalgo.concurrent.ConcurrentExecutor;
import org.ojalgo.concurrent.ProcessorCount;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.AggregatorCollection;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.ChainableAggregator;
import org.ojalgo.function.aggregator.CollectableAggregator;
import org.ojalgo.function.aggregator.PrimitiveAggregator;
import org.ojalgo.function.implementation.FunctionSet;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.decomposition.DecompositionStore;
import org.ojalgo.matrix.decomposition.LUDecomposition.Pivot;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.scalar.PrimitiveScalar;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * A {@linkplain Double} (actually double) implementation of {@linkplain PhysicalStore}.
 *
 * @author apete
 */
public final class PrimitiveDenseStore extends PrimitiveArray implements PhysicalStore<Double>, DecompositionStore<Double> {

    public static final PhysicalStore.Factory<Double> FACTORY = new PhysicalStore.Factory<Double>() {

        public PrimitiveDenseStore conjugate(final Access2D<? extends Number> aSource) {
            return this.transpose(aSource);
        }

        public PrimitiveDenseStore copy(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getRowDim();
            final int tmpColDim = aSource.getColDim();

            final double[] retValData = new double[tmpRowDim * tmpColDim];
            final PrimitiveDenseStore retVal = new PrimitiveDenseStore(tmpRowDim, tmpColDim, retValData);

            PrimitiveDenseStore.copy(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return retVal;
        }

        public PrimitiveDenseStore copy(final double[][] aSource) {

            final int tmpRowDim = aSource.length;
            final int tmpColDim = aSource[0].length;

            final double[] retValData = new double[tmpRowDim * tmpColDim];
            final PrimitiveDenseStore retVal = new PrimitiveDenseStore(tmpRowDim, tmpColDim, retValData);

            PrimitiveDenseStore.copy(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return retVal;
        }

        /**
         * @deprecated v29 Use {@link #copy(Access2D)} instead
         */
        @Deprecated
        public PrimitiveDenseStore copyArray(final Array2D<? extends Number> aSource) {
            return this.copy(aSource);
        }

        public PrimitiveDenseStore copyMatrix(final BasicMatrix aSource) {

            final int tmpRowDim = aSource.getRowDim();
            final int tmpColDim = aSource.getColDim();

            final double[] retValData = new double[tmpRowDim * tmpColDim];
            final PrimitiveDenseStore retVal = new PrimitiveDenseStore(tmpRowDim, tmpColDim, retValData);

            PrimitiveDenseStore.copy(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return retVal;
        }

        /**
         * @deprecated Use {@link #copy(double[][])} instead
         */
        @Deprecated
        public PrimitiveDenseStore copyRaw(final double[][] aSource) {
            return this.copy(aSource);
        }

        /**
         * @deprecated v29 Use {@link #copy(Access2D)} instead
         */
        @Deprecated
        public PrimitiveDenseStore copyStore(final MatrixStore<? extends Number> aSource) {
            return this.copy(aSource);
        }

        public AggregatorCollection<Double> getAggregatorCollection() {
            return PrimitiveAggregator.getCollection();
        }

        public FunctionSet<Double> getFunctionSet() {
            return PrimitiveFunction.getSet();
        }

        public Double getNumber(final double aNmbr) {
            return aNmbr;
        }

        public Double getNumber(final Number aNmbr) {
            return aNmbr.doubleValue();
        }

        public PrimitiveScalar getStaticOne() {
            return PrimitiveScalar.ONE;
        }

        public PrimitiveScalar getStaticZero() {
            return PrimitiveScalar.ZERO;
        }

        public PrimitiveDenseStore makeColumn(final double[] aColumn) {
            return new PrimitiveDenseStore(aColumn.length, 1, ArrayUtils.copyOf(aColumn));
        }

        public PrimitiveDenseStore makeColumn(final Double[] aColumn) {

            final int tmpRowDim = aColumn.length;
            final double[] retValData = new double[tmpRowDim];

            for (int i = 0; i < tmpRowDim; i++) {
                retValData[i] = aColumn[i];
            }

            return new PrimitiveDenseStore(tmpRowDim, 1, retValData);
        }

        public PrimitiveDenseStore makeColumn(final List<Double> aColumn) {

            final int tmpRowDim = aColumn.size();
            final double[] retValData = new double[tmpRowDim];

            for (int i = 0; i < tmpRowDim; i++) {
                retValData[i] = aColumn.get(i);
            }

            return new PrimitiveDenseStore(tmpRowDim, 1, retValData);
        }

        public PrimitiveDenseStore makeEmpty(final int aRowDim, final int aColDim) {
            return new PrimitiveDenseStore(aRowDim, aColDim, new double[aRowDim * aColDim]);
        }

        public PrimitiveDenseStore makeEye(final int aRowDim, final int aColDim) {

            final PrimitiveDenseStore retVal = this.makeZero(aRowDim, aColDim);

            retVal.myUtility.fillDiagonal(0, 0, this.getStaticOne().getNumber());

            return retVal;
        }

        public PrimitiveDenseStore makeZero(final int aRowDim, final int aColDim) {
            return new PrimitiveDenseStore(aRowDim, aColDim);
        }

        public PrimitiveScalar toScalar(final double aNmbr) {
            return new PrimitiveScalar(aNmbr);
        }

        public PrimitiveScalar toScalar(final Number aNmbr) {
            return new PrimitiveScalar(aNmbr.doubleValue());
        }

        public PrimitiveDenseStore transpose(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getColDim();
            final int tmpColDim = aSource.getRowDim();

            final double[] retValData = new double[tmpRowDim * tmpColDim];

            PrimitiveDenseStore.transpose(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return new PrimitiveDenseStore(tmpRowDim, tmpColDim, retValData);
        }
    };

    static Double aggregateAll(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final ChainableAggregator aVisitor, final int availableCPUs) {

        final AggregatorFunction<Double> tmpAggrFunc = aVisitor.getPrimitiveFunction();

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<Double> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Callable<Double>() {

                public Double call() throws Exception {
                    return PrimitiveDenseStore.aggregateAll(aData, aRowDim, aFirstCol, tmpSplit, aVisitor, tmpCPUs);
                }
            });

            final Future<Double> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Callable<Double>() {

                public Double call() throws Exception {
                    return PrimitiveDenseStore.aggregateAll(aData, aRowDim, tmpSplit, aColLimit, aVisitor, tmpCPUs);
                }
            });

            try {

                tmpAggrFunc.invoke(tmpFirstPart.get());
                tmpAggrFunc.invoke(tmpSecondPart.get());

            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.visit(aRowDim * aFirstCol, aRowDim * aColLimit, 1, tmpAggrFunc);
        }

        return tmpAggrFunc.getNumber();
    }

    static Double aggregateAll(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final CollectableAggregator aVisitor, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<Double> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Callable<Double>() {

                public Double call() throws Exception {
                    return PrimitiveDenseStore.aggregateAll(aData, aRowDim, aFirstCol, tmpSplit, aVisitor, tmpCPUs);
                }
            });

            final Future<Double> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Callable<Double>() {

                public Double call() throws Exception {
                    return PrimitiveDenseStore.aggregateAll(aData, aRowDim, tmpSplit, aColLimit, aVisitor, tmpCPUs);
                }
            });

            try {

                return tmpFirstPart.get() + tmpSecondPart.get();

            } catch (final InterruptedException anException) {
                anException.printStackTrace();
                return NaN;
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
                return NaN;
            }

        } else {

            final AggregatorFunction<Double> tmpAggrFunc = aVisitor.getPrimitiveFunction();

            aData.visit(aRowDim * aFirstCol, aRowDim * aColLimit, 1, tmpAggrFunc);

            return tmpAggrFunc.doubleValue();
        }
    }

    static void copy(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<? extends Number> aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.copy(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.copy(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aSource.doubleValue(i, j);
                }
            }
        }
    }

    static void copy(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final BasicMatrix aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.copy(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.copy(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aSource.doubleValue(i, j);
                }
            }
        }
    }

    static void copy(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final double[][] aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.copy(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.copy(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aSource[i][j];
                }
            }
        }
    }

    static void doCholeskyStep(final double[] aData, final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColLimit, final double[] aMultipliers, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 3;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doCholeskyStep(aData, aPivotRow, aRowDim, aFirstCol, tmpSplit, aMultipliers, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doCholeskyStep(aData, aPivotRow, aRowDim, tmpSplit, aColLimit, aMultipliers, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            double tmpVal;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {
                tmpVal = aMultipliers[j];
                tmpIndex = j + j * aRowDim;
                for (int i = j; i < aRowDim; i++) {
                    aData[tmpIndex++] -= aMultipliers[i] * tmpVal;
                }
            }
        }
    }

    static void doHouseholderLeft(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Householder.Primitive aHouseholder, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderLeft(aData, aRowDim, aFirstCol, tmpSplit, aHouseholder, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderLeft(aData, aRowDim, tmpSplit, aColLimit, aHouseholder, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final double[] tmpHouseholderVector = aHouseholder.vector;
            final int tmpFirstNonZero = aHouseholder.first;
            final double tmpBeta = aHouseholder.beta;

            double tmpScale;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {
                tmpScale = ZERO;
                tmpIndex = tmpFirstNonZero + j * aRowDim;
                for (int i = tmpFirstNonZero; i < aRowDim; i++) {
                    tmpScale += tmpHouseholderVector[i] * aData[tmpIndex++];
                }
                tmpScale *= tmpBeta;
                tmpIndex = tmpFirstNonZero + j * aRowDim;
                for (int i = tmpFirstNonZero; i < aRowDim; i++) {
                    aData[tmpIndex++] -= tmpScale * tmpHouseholderVector[i];
                }
            }
        }
    }

    static void doHouseholderRight(final double[] aData, final int aFirstRow, final int aRowLimit, final int aColDim, final Householder.Primitive aHouseholder, final int availableCPUs) {

        final int tmpRowCount = aRowLimit - aFirstRow;

        if ((availableCPUs > 1) && (tmpRowCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstRow + tmpRowCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderRight(aData, aFirstRow, tmpSplit, aColDim, aHouseholder, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doHouseholderRight(aData, tmpSplit, aRowLimit, aColDim, aHouseholder, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final double[] tmpHouseholderVector = aHouseholder.vector;
            final int tmpFirstNonZero = aHouseholder.first;
            final double tmpBeta = aHouseholder.beta;

            final int tmpRowDim = aData.length / aColDim;

            double tmpScale;
            int tmpIndex;
            for (int i = aFirstRow; i < aRowLimit; i++) {
                tmpScale = ZERO;
                tmpIndex = i + tmpFirstNonZero * tmpRowDim;
                for (int j = tmpFirstNonZero; j < aColDim; j++) {
                    tmpScale += tmpHouseholderVector[j] * aData[tmpIndex];
                    tmpIndex += tmpRowDim;
                }
                tmpScale *= tmpBeta;
                tmpIndex = i + tmpFirstNonZero * tmpRowDim;
                for (int j = tmpFirstNonZero; j < aColDim; j++) {
                    aData[tmpIndex] -= tmpScale * tmpHouseholderVector[j];
                    tmpIndex += tmpRowDim;
                }
            }
        }
    }

    static void doLUStep(final double[] aData, final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColLimit, final double[] aMultipliers, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doLUStep(aData, aPivotRow, aRowDim, aFirstCol, tmpSplit, aMultipliers, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.doLUStep(aData, aPivotRow, aRowDim, tmpSplit, aColLimit, aMultipliers, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            double tmpVal;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {
                tmpVal = aData[tmpIndex = aPivotRow + j * aRowDim];
                for (int i = aPivotRow + 1; i < aRowDim; i++) {
                    aData[++tmpIndex] -= aMultipliers[i] * tmpVal;
                }
            }
        }
    }

    static void doRotateLeft(final double[] aData, final int aColDim, final int aRowA, final int aRowB, final double aCos, final double aSin) {

        double tmpOldA;
        double tmpOldB;

        int tmpIndexA = aRowA;
        int tmpIndexB = aRowB;
        final int tmpIndexStep = aData.length / aColDim;

        for (int j = 0; j < aColDim; j++) {

            tmpOldA = aData[tmpIndexA];
            tmpOldB = aData[tmpIndexB];

            aData[tmpIndexA] = aCos * tmpOldA + aSin * tmpOldB;
            aData[tmpIndexB] = aCos * tmpOldB - aSin * tmpOldA;

            tmpIndexA += tmpIndexStep;
            tmpIndexB += tmpIndexStep;
        }
    }

    static void doRotateRight(final double[] aData, final int aRowDim, final int aColA, final int aColB, final double aCos, final double aSin) {

        double tmpOldA;
        double tmpOldB;

        int tmpIndexA = aColA * aRowDim;
        int tmpIndexB = aColB * aRowDim;

        for (int i = 0; i < aRowDim; i++) {

            tmpOldA = aData[tmpIndexA];
            tmpOldB = aData[tmpIndexB];

            aData[tmpIndexA] = aCos * tmpOldA - aSin * tmpOldB;
            aData[tmpIndexB] = aCos * tmpOldB + aSin * tmpOldA;

            tmpIndexA++;
            tmpIndexB++;
        }
    }

    static void fillMatching(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final double aLeftArg, final BinaryFunction<Double> aFunc, final MatrixStore<Double> aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg, aRightArg.doubleValue(i, j));
                }
            }
        }
    }

    static void fillMatching(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final MatrixStore<Double> aLeftArg, final BinaryFunction<Double> aFunc, final double aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg.doubleValue(i, j), aRightArg);
                }
            }
        }
    }

    static void fillMatching(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final MatrixStore<Double> aLeftArg, final BinaryFunction<Double> aFunc, final MatrixStore<Double> aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg.doubleValue(i, j), aRightArg.doubleValue(i, j));
                }
            }
        }
    }

    static void fillMatching(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final double aLeftArg, final BinaryFunction<Double> aFunc, final PrimitiveArray aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void fillMatching(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final PrimitiveArray aLeftArg, final BinaryFunction<Double> aFunc, final double aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void fillMatching(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final PrimitiveArray aLeftArg, final BinaryFunction<Double> aFunc, final PrimitiveArray aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void maxpy(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final double aScale, final MatrixStore<Double> aStore, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.maxpy(aData, aRowDim, aFirstCol, tmpSplit, aScale, aStore, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.maxpy(aData, aRowDim, tmpSplit, aColLimit, aScale, aStore, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] += aScale * aStore.doubleValue(i, j);
                }
            }
        }
    }

    static void modifyAll(final PrimitiveArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final UnaryFunction<Double> aFunc, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.modifyAll(aData, aRowDim, aFirstCol, tmpSplit, aFunc, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.modifyAll(aData, aRowDim, tmpSplit, aColLimit, aFunc, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.modify(aRowDim * aFirstCol, aRowDim * aColLimit, 1, aFunc);
        }
    }

    static void multiply(final double[] aProductArray, final int aFirstRow, final int aRowLimit, final int aColDim, final double[] aLeftArray, final double[] aRightArray, final int availableCPUs) {

        final int tmpRowCount = aRowLimit - aFirstRow;

        if ((availableCPUs > 1) && (tmpRowCount > BranchLimit.MULTIPLY)) {

            final int tmpSplit = aFirstRow + tmpRowCount / 2;
            final int tmpAvailableCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.multiply(aProductArray, aFirstRow, tmpSplit, aColDim, aLeftArray, aRightArray, tmpAvailableCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.multiply(aProductArray, tmpSplit, aRowLimit, aColDim, aLeftArray, aRightArray, tmpAvailableCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpCalcSize = aRightArray.length / aColDim;
            final int tmpRowDim = aLeftArray.length / tmpCalcSize;

            final double[] tmpLeftRow = new double[tmpCalcSize];
            int tmpIndex;
            double tmpVal;

            for (int i = aFirstRow; i < aRowLimit; i++) {
                for (int c = 0; c < tmpCalcSize; c++) {
                    tmpLeftRow[c] = aLeftArray[i + c * tmpRowDim];
                }
                for (int j = 0; j < aColDim; j++) {
                    tmpIndex = j * tmpCalcSize;
                    tmpVal = ZERO;
                    for (int c = 0; c < tmpCalcSize; c++) {
                        tmpVal += tmpLeftRow[c] * aRightArray[tmpIndex++];
                    }
                    aProductArray[i + j * tmpRowDim] = tmpVal;
                }
            }
        }
    }

    static void multiply(final double[] aProductArray, final MatrixStore<Double> aLeftStore, final MatrixStore<Double> aRightStore) {

        final int tmpRowDim = aLeftStore.getRowDim();
        final int tmpCalcSize = aRightStore.getRowDim();
        final int tmpColDim = aRightStore.getColDim();

        final boolean tmpLL = aLeftStore.isLowerLeftShaded();
        final boolean tmpLU = aLeftStore.isUpperRightShaded();
        final boolean tmpRL = aRightStore.isLowerLeftShaded();
        final boolean tmpRU = aRightStore.isUpperRightShaded();
        int tmpFirst;
        int tmpLimit;

        final double[] tmpLeftRow = new double[tmpCalcSize];
        double tmpVal;

        for (int i = 0; i < tmpRowDim; i++) {
            for (int c = 0; c < tmpCalcSize; c++) {
                tmpLeftRow[c] = aLeftStore.doubleValue(i, c);
            }
            for (int j = 0; j < tmpColDim; j++) {
                tmpFirst = MatrixUtils.max(tmpLL ? i - 1 : 0, tmpRU ? j - 1 : 0, 0);
                tmpLimit = MatrixUtils.min(tmpLU ? i + 2 : tmpCalcSize, tmpRL ? j + 2 : tmpCalcSize, tmpCalcSize);
                tmpVal = ZERO;
                for (int c = tmpFirst; c < tmpLimit; c++) {
                    tmpVal += tmpLeftRow[c] * aRightStore.doubleValue(c, j);
                }
                aProductArray[i + j * tmpRowDim] = tmpVal;
            }
        }
    }

    static void substituteBackwards(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<Double> aBody, final boolean assumeOne, final boolean transposed, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.substituteBackwards(aData, aRowDim, aFirstCol, tmpSplit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.substituteBackwards(aData, aRowDim, tmpSplit, aColLimit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpDiagDim = aBody.getMinDim();

            final double[] tmpRow = new double[tmpDiagDim];
            double tmpVal;
            int tmpColBaseIndex;

            for (int i = tmpDiagDim - 1; i >= 0; i--) {

                for (int j = i; j < tmpDiagDim; j++) {
                    tmpRow[j] = transposed ? aBody.doubleValue(j, i) : aBody.doubleValue(i, j);
                }

                for (int s = aFirstCol; s < aColLimit; s++) {

                    tmpColBaseIndex = s * aRowDim;

                    tmpVal = ZERO;
                    for (int j = i + 1; j < tmpDiagDim; j++) {
                        tmpVal += tmpRow[j] * aData[j + tmpColBaseIndex];
                    }
                    aData[i + tmpColBaseIndex] -= tmpVal;

                    if (!assumeOne) {
                        aData[i + tmpColBaseIndex] /= tmpRow[i];
                    }
                }
            }
        }
    }

    static void substituteForwards(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<Double> aBody, final boolean assumeOne, final boolean transposed, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.substituteForwards(aData, aRowDim, aFirstCol, tmpSplit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.substituteForwards(aData, aRowDim, tmpSplit, aColLimit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpDiagDim = aBody.getMinDim();

            final double[] tmpRow = new double[tmpDiagDim];
            double tmpVal;
            int tmpColBaseIndex;

            for (int i = 0; i < tmpDiagDim; i++) {

                for (int j = 0; j <= i; j++) {
                    tmpRow[j] = transposed ? aBody.doubleValue(j, i) : aBody.doubleValue(i, j);
                }

                for (int s = aFirstCol; s < aColLimit; s++) {

                    tmpColBaseIndex = s * aRowDim;

                    tmpVal = ZERO;
                    for (int j = 0; j < i; j++) {
                        tmpVal += tmpRow[j] * aData[j + tmpColBaseIndex];
                    }
                    aData[i + tmpColBaseIndex] -= tmpVal;

                    if (!assumeOne) {
                        aData[i + tmpColBaseIndex] /= tmpRow[i];
                    }
                }
            }
        }
    }

    static void transpose(final double[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<? extends Number> aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.transpose(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    PrimitiveDenseStore.transpose(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aSource.doubleValue(j, i);
                }
            }
        }
    }

    private final int myColDim;

    private final int myRowDim;

    private final Array2D<Double> myUtility;

    PrimitiveDenseStore(final double[] anArray) {

        super(anArray);

        myRowDim = anArray.length;
        myColDim = 1;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    PrimitiveDenseStore(final int aLength) {

        super(aLength);

        myRowDim = aLength;
        myColDim = 1;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    PrimitiveDenseStore(final int aRowDim, final int aColDim) {

        super(aRowDim * aColDim);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    PrimitiveDenseStore(final int aRowDim, final int aColDim, final double[] anArray) {

        super(anArray);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    public Double aggregateAll(final ChainableAggregator aVisitor) {
        return PrimitiveDenseStore.aggregateAll(this, myRowDim, 0, myColDim, aVisitor, ProcessorCount.RUNTIME);
    }

    public Double aggregateAll(final CollectableAggregator aVisitor) {
        return PrimitiveDenseStore.aggregateAll(this, myRowDim, 0, myColDim, aVisitor, ProcessorCount.RUNTIME);
    }

    public Array2D<Double> asArray2D() {
        return myUtility;
    }

    public Array1D<Double> asList() {
        return myUtility.asArray1D();
    }

    public final MatrixStore.Builder<Double> builder() {
        return new MatrixStore.Builder<Double>(this);
    }

    public void caxpy(final Double aSclrA, final int aColX, final int aColY, final int aFirstRow) {

        final double tmpValA = aSclrA.doubleValue();
        final double[] tmpData = this.data();

        final int tmpRowDim = myRowDim;

        int tmpIndX = aFirstRow + aColX * tmpRowDim;
        int tmpIndY = aFirstRow + aColY * tmpRowDim;

        for (int i = aFirstRow; i < tmpRowDim; i++) {
            tmpData[tmpIndY++] += tmpValA * tmpData[tmpIndX++];
        }
    }

    public boolean computeInPlaceCholesky(final boolean checkForSPD) {

        // true if (Symmetric) Positive Definite 
        boolean retVal = myRowDim == myColDim;

        final int tmpDim = myRowDim;

        final double[] tmpData = this.data();
        int tmpDataIndex;

        // Check for symmetry, maybe
        if (retVal && checkForSPD) {
            for (int j = 0; retVal && (j < tmpDim); j++) {
                for (int i = j + 1; retVal && (i < tmpDim); i++) {
                    retVal &= TypeUtils.isZero(tmpData[i + j * tmpDim] - tmpData[j + i * tmpDim]);
                }
            }
        }

        final double[] tmpColumn = new double[tmpDim];
        double tmpVal;

        // Main loop - along the diagonal
        for (int ij = 0; retVal && (ij < tmpDim); ij++) {

            // "Pivot" element
            tmpVal = tmpData[tmpDataIndex = ij + ij * tmpDim];

            if (tmpVal > ZERO) {

                tmpColumn[ij] = tmpData[tmpDataIndex] = tmpVal = Math.sqrt(tmpVal);

                // Calculate multipliers and copy to local column
                // Current column, below the diagonal
                for (int i = ij + 1; i < tmpDim; i++) {
                    tmpColumn[i] = tmpData[++tmpDataIndex] /= tmpVal;
                }

                // Remaining columns, below the diagonal
                PrimitiveDenseStore.doCholeskyStep(tmpData, ij, tmpDim, ij + 1, tmpDim, tmpColumn, ProcessorCount.RUNTIME);

            } else {

                retVal = false;
            }
        }

        return retVal;
    }

    public Pivot computeInPlaceLU(final boolean assumeNoPivotingRequired) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;
        final int tmpMinDim = Math.min(tmpRowDim, tmpColDim);

        final Pivot retVal = new Pivot(tmpRowDim);

        final double[] tmpData = this.data();
        int tmpDataIndex;

        int tmpPivotRowIndex;

        final double[] tmpColumn = new double[tmpRowDim];
        double tmpVal;

        // Main loop - along the diagonal
        for (int ij = 0; ij < tmpMinDim; ij++) {

            if (!assumeNoPivotingRequired) {
                // Find next pivot row, stop searching when something good enough is found
                tmpVal = Math.abs(tmpData[tmpDataIndex = ij + tmpRowDim * ij]);
                tmpPivotRowIndex = ij;
                for (int i = ij + 1; (i < tmpRowDim) && (tmpVal < HALF); i++) {
                    if (Math.abs(tmpData[++tmpDataIndex]) > tmpVal) {
                        tmpVal = Math.abs(tmpData[tmpDataIndex]);
                        tmpPivotRowIndex = i;
                    }
                }
                // Pivot?
                if (tmpPivotRowIndex != ij) {
                    myUtility.exchangeRows(tmpPivotRowIndex, ij);
                    retVal.change(tmpPivotRowIndex, ij);
                }
            }

            // Do the calculations...

            // "Pivot" element
            tmpVal = tmpData[tmpDataIndex = ij + ij * tmpRowDim];
            if (!TypeUtils.isZero(tmpVal)) {

                // Calculate multipliers and copy to local column
                // Current column, below the diagonal
                for (int i = ij + 1; i < tmpRowDim; i++) {
                    tmpColumn[i] = tmpData[++tmpDataIndex] /= tmpVal;
                }

                // Apply transformations to everything below and to the right of the pivot element
                PrimitiveDenseStore.doLUStep(tmpData, ij, tmpRowDim, ij + 1, tmpColDim, tmpColumn, ProcessorCount.RUNTIME);

            } else {

                tmpData[tmpDataIndex] = ZERO;
            }
        }

        return retVal;
    }

    public void computeInPlaceQR() {

        final double[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        final Householder.Primitive tmpWorkCopy = new Householder.Primitive(tmpRowDim);

        for (int j = 0; j < tmpColDim; j++) {
            if (this.generateApplyAndCopyHouseholderColumn(j, j, tmpWorkCopy)) {
                PrimitiveDenseStore.doHouseholderLeft(tmpData, tmpRowDim, j + 1, tmpColDim, tmpWorkCopy, ProcessorCount.RUNTIME);
            }
        }
    }

    public void computeInPlaceTridiagonal() {

        final int tmpDim = myRowDim;
        final int tmpLim = tmpDim - 2;

        final double[] tmpData = this.data();

        final Householder.Primitive tmpHousehoulder = new Householder.Primitive(tmpDim);

        int tmpNext;
        for (int ij = 0; ij < tmpLim; ij++) {

            tmpNext = ij + 1;

            if (this.generateApplyAndCopyHouseholderColumn(tmpNext, ij, tmpHousehoulder)) {
                PrimitiveDenseStore.doHouseholderLeft(tmpData, tmpDim, tmpNext, tmpDim, tmpHousehoulder, ProcessorCount.RUNTIME);
                PrimitiveDenseStore.doHouseholderRight(tmpData, tmpNext, tmpDim, tmpDim, tmpHousehoulder, ProcessorCount.RUNTIME);
            }
        }
    }

    public PrimitiveDenseStore conjugate() {
        return this.transpose();
    }

    public PrimitiveDenseStore copy() {
        return new PrimitiveDenseStore(myRowDim, myColDim, this.copyOfData());
    }

    public double doubleValue(final int aRow, final int aCol) {
        return myUtility.doubleValue(aRow, aCol);
    }

    public boolean equals(final MatrixStore<Double> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(this, aStore, aCntxt);
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(final Object anObj) {
        if (anObj instanceof MatrixStore) {
            return this.equals((MatrixStore<Double>) anObj, TypeUtils.EQUALS_NUMBER_CONTEXT);
        } else {
            return super.equals(anObj);
        }
    }

    public void exchangeColumns(final int aColA, final int aColB) {
        myUtility.exchangeColumns(aColA, aColB);
    }

    public void exchangeRows(final int aRowA, final int aRowB) {
        myUtility.exchangeRows(aRowA, aRowB);
    }

    public void fillAll(final Double aNmbr) {
        myUtility.fillAll(aNmbr);
    }

    public void fillByMultiplying(final MatrixStore<Double> aLeftArg, final MatrixStore<Double> aRightArg) {
        PrimitiveDenseStore.multiply(this.data(), 0, myRowDim, myColDim, this.cast(aLeftArg).data(), this.cast(aRightArg).data(), ProcessorCount.RUNTIME);
    }

    public void fillColumn(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.fillColumn(aRow, aCol, aNmbr);
    }

    public void fillDiagonal(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.fillDiagonal(aRow, aCol, aNmbr);
    }

    public void fillMatching(final Access2D<Double> aSource2D) {
        PrimitiveDenseStore.copy(this.data(), myRowDim, 0, myColDim, aSource2D, ProcessorCount.RUNTIME);
    }

    public void fillMatching(final Double aLeftArg, final BinaryFunction<Double> aFunc, final MatrixStore<Double> aRightArg) {
        if (aRightArg instanceof PrimitiveArray) {
            PrimitiveDenseStore.fillMatching(this, myRowDim, 0, myColDim, aLeftArg, aFunc, (PrimitiveArray) aRightArg, ProcessorCount.RUNTIME);
        } else {
            PrimitiveDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillMatching(final MatrixStore<Double> aLeftArg, final BinaryFunction<Double> aFunc, final Double aRightArg) {
        if (aLeftArg instanceof PrimitiveArray) {
            PrimitiveDenseStore.fillMatching(this, myRowDim, 0, myColDim, (PrimitiveArray) aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        } else {
            PrimitiveDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillMatching(final MatrixStore<Double> aLeftArg, final BinaryFunction<Double> aFunc, final MatrixStore<Double> aRightArg) {
        if ((aLeftArg instanceof PrimitiveArray) && (aRightArg instanceof PrimitiveArray)) {
            PrimitiveDenseStore.fillMatching(this, myRowDim, 0, myColDim, (PrimitiveArray) aLeftArg, aFunc, (PrimitiveArray) aRightArg, ProcessorCount.RUNTIME);
        } else {
            PrimitiveDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillRow(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.fillRow(aRow, aCol, aNmbr);
    }

    public Householder<Double> generateHouseholderColumn(final int aRow, final int aCol) {

        final AggregatorFunction<Double> tmpNorm2Aggr = ChainableAggregator.NORM2.getPrimitiveFunction();
        myUtility.visitColumn(aRow, aCol, tmpNorm2Aggr);
        final double tmpNorm2 = tmpNorm2Aggr.doubleValue();

        if (!TypeUtils.isZero(tmpNorm2)) {

            double tmpScale = this.doubleValue(aRow, aCol);

            if (tmpScale <= ZERO) {
                tmpScale -= tmpNorm2;
                myUtility.set(aRow, aCol, tmpNorm2);
            } else {
                tmpScale += tmpNorm2;
                myUtility.set(aRow, aCol, -tmpNorm2);
            }

            myUtility.modifyColumn(aRow + 1, aCol, DIVIDE, tmpScale);
        }

        return new Householder<Double>(aRow, true, myUtility.sliceColumn(aRow + 1, aCol));
    }

    public Householder<Double> generateHouseholderRow(final int aRow, final int aCol) {

        final AggregatorFunction<Double> tmpNorm2Aggr = ChainableAggregator.NORM2.getPrimitiveFunction();
        myUtility.visitRow(aRow, aCol, tmpNorm2Aggr);
        final double tmpNorm2 = tmpNorm2Aggr.doubleValue();

        if (!TypeUtils.isZero(tmpNorm2)) {

            double tmpScale = this.doubleValue(aRow, aCol);

            if (tmpScale <= ZERO) {
                tmpScale -= tmpNorm2;
                myUtility.set(aRow, aCol, tmpNorm2);
            } else {
                tmpScale += tmpNorm2;
                myUtility.set(aRow, aCol, -tmpNorm2);
            }

            myUtility.modifyRow(aRow, aCol + 1, DIVIDE, tmpScale);
        }

        return new Householder<Double>(aCol, true, myUtility.sliceRow(aRow, aCol + 1));
    }

    public Double get(final int aRow, final int aCol) {
        return myUtility.get(aRow, aCol);
    }

    public int getColDim() {
        return myColDim;
    }

    public PhysicalStore.Factory<Double> getFactory() {
        return FACTORY;
    }

    public int getIndexOfLargestInColumn(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInColumn(aRow, aCol);
    }

    public int getIndexOfLargestInRow(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInRow(aRow, aCol);
    }

    public int getMinDim() {
        return Math.min(myRowDim, myColDim);
    }

    /**
     * @deprecated Use {@link #get(int,int)} instead
     */
    @Deprecated
    public Double getNumber(final int aRow, final int aCol) {
        return this.get(aRow, aCol);
    }

    public int getRowDim() {
        return myRowDim;
    }

    @Override
    public int hashCode() {
        return MatrixUtils.hashCode(this);
    }

    public boolean isAbsolute(final int aRow, final int aCol) {
        return myUtility.isAbsolute(aRow, aCol);
    }

    public boolean isLowerLeftShaded() {
        return false;
    }

    public boolean isReal(final int aRow, final int aCol) {
        return myUtility.isReal(aRow, aCol);
    }

    public boolean isShaded() {
        return false;
    }

    public boolean isUpperRightShaded() {
        return false;
    }

    public boolean isZero(final int aRow, final int aCol) {
        return this.isZero(aRow + aCol * myRowDim);
    }

    public void maxpy(final Double aSclrA, final MatrixStore<Double> aMtrxX) {
        PrimitiveDenseStore.maxpy(this.data(), myRowDim, 0, myColDim, aSclrA, aMtrxX, ProcessorCount.RUNTIME);
    }

    public void modifyAll(final UnaryFunction<Double> aFunc) {
        PrimitiveDenseStore.modifyAll(this, myRowDim, 0, myColDim, aFunc, ProcessorCount.RUNTIME);
    }

    public void modifyColumn(final int aRow, final int aCol, final UnaryFunction<Double> aFunc) {
        myUtility.modifyColumn(aRow, aCol, aFunc);
    }

    public void modifyDiagonal(final int aRow, final int aCol, final UnaryFunction<Double> aFunc) {
        myUtility.modifyDiagonal(aRow, aCol, aFunc);
    }

    public void modifyRow(final int aRow, final int aCol, final UnaryFunction<Double> aFunc) {
        myUtility.modifyRow(aRow, aCol, aFunc);
    }

    public MatrixStore<Double> multiplyLeft(final MatrixStore<Double> aStore) {

        final int tmpRowDim = aStore.getRowDim();
        final int tmpColDim = myColDim;

        final double[] retVal = new double[tmpRowDim * tmpColDim];

        PrimitiveDenseStore.multiply(retVal, 0, tmpRowDim, tmpColDim, this.cast(aStore).data(), this.data(), ProcessorCount.RUNTIME);

        return new PrimitiveDenseStore(tmpRowDim, tmpColDim, retVal);
    }

    public MatrixStore<Double> multiplyRight(final MatrixStore<Double> aStore) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = aStore.getColDim();

        final double[] retVal = new double[tmpRowDim * tmpColDim];

        PrimitiveDenseStore.multiply(retVal, 0, tmpRowDim, tmpColDim, this.data(), this.cast(aStore).data(), ProcessorCount.RUNTIME);

        return new PrimitiveDenseStore(tmpRowDim, tmpColDim, retVal);
    }

    public void raxpy(final Double aSclrA, final int aRowX, final int aRowY, final int aFirstCol) {

        final double tmpValA = aSclrA.doubleValue();
        final double[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        int tmpIndX = aRowX + aFirstCol * tmpRowDim;
        int tmpIndY = aRowY + aFirstCol * tmpRowDim;

        for (int j = aFirstCol; j < tmpColDim; j++) {
            tmpData[tmpIndY] += tmpValA * tmpData[tmpIndX];
            tmpIndX += tmpRowDim;
            tmpIndY += tmpRowDim;
        }
    }

    public void set(final int aRow, final int aCol, final double aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void set(final int aRow, final int aCol, final Double aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void shadeLowerLeft() {
        ;
    }

    public void shadeUpperRight() {
        ;
    }

    public void substituteBackwards(final Access2D<Double> aBody, final boolean assumeOne, final boolean transposed) {
        PrimitiveDenseStore.substituteBackwards(this.data(), myRowDim, 0, myColDim, aBody, assumeOne, transposed, ProcessorCount.RUNTIME);
    }

    public void substituteForwards(final Access2D<Double> aBody, final boolean assumeOne, final boolean transposed) {
        PrimitiveDenseStore.substituteForwards(this.data(), myRowDim, 0, myColDim, aBody, assumeOne, transposed, ProcessorCount.RUNTIME);
    }

    public double[][] toRawCopy() {
        return myUtility.toRawCopy();
    }

    public PrimitiveScalar toScalar(final int aRow, final int aCol) {
        return new PrimitiveScalar(this.doubleValue(aRow + aCol * myRowDim));
    }

    public void transformLeft(final Householder.Reference<Double> aTransf, final int aFirstCol) {
        PrimitiveDenseStore.doHouseholderLeft(this.data(), myRowDim, aFirstCol, myColDim, aTransf.getPrimitiveWorkCopy().copy(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformLeft(final Householder<Double> aTransf) {
        this.transformLeft(aTransf, 0);
    }

    public void transformLeft(final Householder<Double> aTransf, final int aFirstCol) {
        PrimitiveDenseStore.doHouseholderLeft(this.data(), myRowDim, aFirstCol, myColDim, new Householder.Primitive(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformLeft(final Rotation<Double> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {

            PrimitiveDenseStore.doRotateLeft(this.data(), myColDim, tmpLow, tmpHigh, aTransf.cos.doubleValue(), aTransf.sin.doubleValue());

        } else if ((aTransf.cos != null) && (aTransf.cos.compareTo(aTransf.sin) == 0)) {

            myUtility.modifyRow(tmpLow, 0, MULTIPLY, aTransf.cos);

        } else {

            myUtility.modifyRow(tmpLow, 0, NEGATE);
        }
    }

    public void transformRight(final Householder.Reference<Double> aTransf, final int aFirstRow) {
        PrimitiveDenseStore.doHouseholderRight(this.data(), aFirstRow, myRowDim, myColDim, aTransf.getPrimitiveWorkCopy().copy(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformRight(final Householder<Double> aTransf) {
        this.transformRight(aTransf, 0);
    }

    public void transformRight(final Householder<Double> aTransf, final int aFirstRow) {
        PrimitiveDenseStore.doHouseholderRight(this.data(), aFirstRow, myRowDim, myColDim, new Householder.Primitive(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformRight(final Rotation<Double> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {

            PrimitiveDenseStore.doRotateRight(this.data(), myRowDim, tmpLow, tmpHigh, aTransf.cos.doubleValue(), aTransf.sin.doubleValue());

        } else if ((aTransf.cos != null) && (aTransf.cos.compareTo(aTransf.sin) == 0)) {

            myUtility.modifyColumn(0, tmpHigh, MULTIPLY, aTransf.cos);

        } else {

            myUtility.modifyColumn(0, tmpHigh, NEGATE);
        }
    }

    public PrimitiveDenseStore transpose() {
        return (PrimitiveDenseStore) FACTORY.transpose(this);
    }

    public void unshade() {
        ;
    }

    public void visitAll(final AggregatorFunction<Double> aVisitor) {
        myUtility.visitAll(aVisitor);
    }

    public void visitColumn(final int aRow, final int aCol, final AggregatorFunction<Double> aVisitor) {
        myUtility.visitColumn(aRow, aCol, aVisitor);
    }

    public void visitDiagonal(final int aRow, final int aCol, final AggregatorFunction<Double> aVisitor) {
        myUtility.visitDiagonal(aRow, aCol, aVisitor);
    }

    public void visitRow(final int aRow, final int aCol, final AggregatorFunction<Double> aVisitor) {
        myUtility.visitRow(aRow, aCol, aVisitor);
    }

    private PrimitiveDenseStore cast(final MatrixStore<Double> aStore) {
        if (aStore instanceof PrimitiveDenseStore) {
            return (PrimitiveDenseStore) aStore;
        } else {
            return (PrimitiveDenseStore) FACTORY.copy(aStore);
        }
    }

    private boolean generateApplyAndCopyHouseholderColumn(final int aRow, final int aCol, final Householder.Primitive aDestination) {

        final double[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColBaseIndex = tmpRowDim * aCol;

        double tmpVal;
        double tmpVal2 = ZERO;
        for (int i = aRow; i < tmpRowDim; i++) {
            tmpVal = tmpData[i + tmpColBaseIndex];
            tmpVal2 += tmpVal * tmpVal;
        }
        tmpVal2 = Math.sqrt(tmpVal2);

        final boolean retVal = !TypeUtils.isZero(tmpVal2);

        if (retVal) {

            double tmpScale = tmpData[aRow + tmpColBaseIndex];

            if (tmpScale <= ZERO) {
                tmpScale -= tmpVal2;
                tmpData[aRow + tmpColBaseIndex] = tmpVal2;
            } else {
                tmpScale += tmpVal2;
                tmpData[aRow + tmpColBaseIndex] = -tmpVal2;
            }

            final double[] tmpVector = aDestination.vector;

            tmpVal2 = ONE;
            tmpVector[aRow] = ONE;
            for (int i = aRow + 1; i < tmpRowDim; i++) {
                tmpVal = tmpData[i + tmpColBaseIndex] /= tmpScale;
                tmpVal2 += tmpVal * tmpVal;
                tmpVector[i] = tmpVal;
            }

            aDestination.beta = TWO / tmpVal2;

            aDestination.first = aRow;
        }

        return retVal;
    }

}
