/*
 * Copyright © 2003 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.store;

import static org.ojalgo.constant.BigMath.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.array.ArrayUtils;
import org.ojalgo.array.BigArray;
import org.ojalgo.concurrent.ConcurrentExecutor;
import org.ojalgo.concurrent.ProcessorCount;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.AggregatorCollection;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.BigAggregator;
import org.ojalgo.function.aggregator.ChainableAggregator;
import org.ojalgo.function.aggregator.CollectableAggregator;
import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.function.implementation.FunctionSet;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.decomposition.DecompositionStore;
import org.ojalgo.matrix.decomposition.LUDecomposition.Pivot;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.scalar.BigScalar;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * A {@linkplain BigDecimal} implementation of {@linkplain PhysicalStore}.
 *
 * @author apete
 */
public final class BigDenseStore extends BigArray implements PhysicalStore<BigDecimal>, DecompositionStore<BigDecimal> {

    public static final PhysicalStore.Factory<BigDecimal> FACTORY = new PhysicalStore.Factory<BigDecimal>() {

        public BigDenseStore conjugate(final Access2D<? extends Number> aSource) {
            return this.transpose(aSource);
        }

        public BigDenseStore copy(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getRowDim();
            final int tmpColDim = aSource.getColDim();

            final BigDecimal[] retValData = new BigDecimal[tmpRowDim * tmpColDim];
            final BigDenseStore retVal = new BigDenseStore(tmpRowDim, tmpColDim, retValData);

            BigDenseStore.copy(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return retVal;
        }

        public BigDenseStore copy(final double[][] aSource) {

            final int tmpRowDim = aSource.length;
            final int tmpColDim = aSource[0].length;

            final BigDecimal[] retValData = new BigDecimal[tmpRowDim * tmpColDim];
            final BigDenseStore retVal = new BigDenseStore(tmpRowDim, tmpColDim, retValData);

            BigDenseStore.copy(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return retVal;
        }

        /**
         * @deprecated v29 Use {@link #copy(Access2D)} instead
         */
        @Deprecated
        public BigDenseStore copyArray(final Array2D<? extends Number> aSource) {
            return this.copy(aSource);
        }

        public BigDenseStore copyMatrix(final BasicMatrix aSource) {

            final int tmpRowDim = aSource.getRowDim();
            final int tmpColDim = aSource.getColDim();

            final BigDecimal[] retValData = new BigDecimal[tmpRowDim * tmpColDim];
            final BigDenseStore retVal = new BigDenseStore(tmpRowDim, tmpColDim, retValData);

            BigDenseStore.copy(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return retVal;
        }

        /**
         * @deprecated Use {@link #copy(double[][])} instead
         */
        @Deprecated
        public BigDenseStore copyRaw(final double[][] aSource) {
            return this.copy(aSource);
        }

        /**
         * @deprecated v29 Use {@link #copy(Access2D)} instead
         */
        @Deprecated
        public BigDenseStore copyStore(final MatrixStore<? extends Number> aSource) {
            return this.copy(aSource);
        }

        public AggregatorCollection<BigDecimal> getAggregatorCollection() {
            return BigAggregator.getCollection();
        }

        public FunctionSet<BigDecimal> getFunctionSet() {
            return BigFunction.getSet();
        }

        public BigDecimal getNumber(final double aNmbr) {
            return new BigDecimal(aNmbr);
        }

        public BigDecimal getNumber(final Number aNmbr) {
            return TypeUtils.toBigDecimal(aNmbr);
        }

        public BigScalar getStaticOne() {
            return BigScalar.ONE;
        }

        public BigScalar getStaticZero() {
            return BigScalar.ZERO;
        }

        public BigDenseStore makeColumn(final BigDecimal[] aColumn) {
            return new BigDenseStore(aColumn.length, 1, ArrayUtils.copyOf(aColumn));
        }

        public BigDenseStore makeColumn(final double[] aColumn) {

            final int tmpRowDim = aColumn.length;
            final BigDecimal[] retValData = new BigDecimal[tmpRowDim];

            for (int i = 0; i < tmpRowDim; i++) {
                retValData[i] = new BigDecimal(aColumn[i]);
            }

            return new BigDenseStore(tmpRowDim, 1, retValData);
        }

        public BigDenseStore makeColumn(final List<BigDecimal> aColumn) {

            final int tmpRowDim = aColumn.size();
            final BigDecimal[] retValData = new BigDecimal[tmpRowDim];

            for (int i = 0; i < tmpRowDim; i++) {
                retValData[i] = aColumn.get(i);
            }

            return new BigDenseStore(tmpRowDim, 1, retValData);
        }

        public BigDenseStore makeEmpty(final int aRowDim, final int aColDim) {
            return new BigDenseStore(aRowDim, aColDim, new BigDecimal[aRowDim * aColDim]);
        }

        public BigDenseStore makeEye(final int aRowDim, final int aColDim) {

            final BigDenseStore retVal = this.makeZero(aRowDim, aColDim);

            retVal.myUtility.fillDiagonal(0, 0, this.getStaticOne().getNumber());

            return retVal;
        }

        public BigDenseStore makeZero(final int aRowDim, final int aColDim) {
            return new BigDenseStore(aRowDim, aColDim);
        }

        public BigScalar toScalar(final double aNmbr) {
            return new BigScalar(aNmbr);
        }

        public BigScalar toScalar(final Number aNmbr) {
            return new BigScalar(TypeUtils.toBigDecimal(aNmbr));
        }

        public BigDenseStore transpose(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getColDim();
            final int tmpColDim = aSource.getRowDim();

            final BigDecimal[] retValData = new BigDecimal[tmpRowDim * tmpColDim];

            BigDenseStore.transpose(retValData, tmpRowDim, 0, tmpColDim, aSource, ProcessorCount.RUNTIME);

            return new BigDenseStore(tmpRowDim, tmpColDim, retValData);
        }
    };

    static BigDecimal aggregateAll(final BigArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final ChainableAggregator aVisitor, final int availableCPUs) {

        final AggregatorFunction<BigDecimal> tmpAggrFunc = aVisitor.getBigFunction();

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<BigDecimal> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Callable<BigDecimal>() {

                public BigDecimal call() throws Exception {
                    return BigDenseStore.aggregateAll(aData, aRowDim, aFirstCol, tmpSplit, aVisitor, tmpCPUs);
                }
            });

            final Future<BigDecimal> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Callable<BigDecimal>() {

                public BigDecimal call() throws Exception {
                    return BigDenseStore.aggregateAll(aData, aRowDim, tmpSplit, aColLimit, aVisitor, tmpCPUs);
                }
            });

            try {

                tmpAggrFunc.invoke(tmpFirstPart.get());
                tmpAggrFunc.invoke(tmpSecondPart.get());

            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.visit(aRowDim * aFirstCol, aRowDim * aColLimit, 1, tmpAggrFunc);
        }

        return tmpAggrFunc.getNumber();
    }

    static BigDecimal aggregateAll(final BigArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final CollectableAggregator aVisitor, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<BigDecimal> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Callable<BigDecimal>() {

                public BigDecimal call() throws Exception {
                    return BigDenseStore.aggregateAll(aData, aRowDim, aFirstCol, tmpSplit, aVisitor, tmpCPUs);
                }
            });

            final Future<BigDecimal> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Callable<BigDecimal>() {

                public BigDecimal call() throws Exception {
                    return BigDenseStore.aggregateAll(aData, aRowDim, tmpSplit, aColLimit, aVisitor, tmpCPUs);
                }
            });

            try {

                return tmpFirstPart.get().add(tmpSecondPart.get());

            } catch (final InterruptedException anException) {
                anException.printStackTrace();
                return null;
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
                return null;
            }

        } else {

            final AggregatorFunction<BigDecimal> tmpAggrFunc = aVisitor.getBigFunction();

            aData.visit(aRowDim * aFirstCol, aRowDim * aColLimit, 1, tmpAggrFunc);

            return tmpAggrFunc.getNumber();
        }
    }

    static void copy(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<? extends Number> aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.copy(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.copy(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = TypeUtils.toBigDecimal(aSource.get(i, j));
                }
            }
        }
    }

    static void copy(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final BasicMatrix aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.copy(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.copy(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aSource.toBigDecimal(i, j);
                }
            }
        }
    }

    static void copy(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final double[][] aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.copy(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.copy(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = new BigDecimal(aSource[i][j]);
                }
            }
        }
    }

    static void daxpyCholesky(final BigDecimal[] aData, final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColLimit, final BigDecimal[] aMultipliers, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.daxpyCholesky(aData, aPivotRow, aRowDim, aFirstCol, tmpSplit, aMultipliers, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.daxpyCholesky(aData, aPivotRow, aRowDim, tmpSplit, aColLimit, aMultipliers, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            BigDecimal tmpVal;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {

                tmpIndex = j + j * aRowDim;
                //tmpVal = aMultipliers[j].divide(aMultipliers[aPivotRow]);
                tmpVal = BigFunction.DIVIDE.invoke(aMultipliers[j], aMultipliers[aPivotRow]);

                // For each row below the diagonal
                for (int i = j; i < aRowDim; i++) {
                    aData[tmpIndex] = aData[tmpIndex].subtract(BigFunction.MULTIPLY.invoke(tmpVal, aMultipliers[i]));
                    tmpIndex++;
                }
            }
        }
    }

    static void daxpyLU(final BigDecimal[] aData, final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColLimit, final BigDecimal[] aMultipliers, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.daxpyLU(aData, aPivotRow, aRowDim, aFirstCol, tmpSplit, aMultipliers, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.daxpyLU(aData, aPivotRow, aRowDim, tmpSplit, aColLimit, aMultipliers, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            BigDecimal tmpVal;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {
                tmpIndex = aPivotRow + j * aRowDim;
                tmpVal = aData[tmpIndex];
                for (int i = aPivotRow + 1; i < aRowDim; i++) {
                    tmpIndex++;
                    aData[tmpIndex] = aData[tmpIndex].subtract(BigFunction.MULTIPLY.invoke(aMultipliers[i], tmpVal));
                }
            }
        }
    }

    static void doHouseholderLeft(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Householder.Big aHouseholder, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.doHouseholderLeft(aData, aRowDim, aFirstCol, tmpSplit, aHouseholder, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.doHouseholderLeft(aData, aRowDim, tmpSplit, aColLimit, aHouseholder, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final BigDecimal[] tmpHouseholderVector = aHouseholder.vector;
            final int tmpFirstNonZero = aHouseholder.first;
            final BigDecimal tmpBeta = aHouseholder.beta;

            BigDecimal tmpScale;
            int tmpIndex;
            for (int j = aFirstCol; j < aColLimit; j++) {
                tmpScale = ZERO;
                tmpIndex = tmpFirstNonZero + j * aRowDim;
                for (int i = tmpFirstNonZero; i < aRowDim; i++) {
                    tmpScale = BigFunction.ADD.invoke(tmpScale, BigFunction.MULTIPLY.invoke(tmpHouseholderVector[i], aData[tmpIndex++]));
                }
                tmpScale = BigFunction.MULTIPLY.invoke(tmpScale, tmpBeta);
                tmpIndex = tmpFirstNonZero + j * aRowDim;
                for (int i = tmpFirstNonZero; i < aRowDim; i++) {
                    aData[tmpIndex] = BigFunction.SUBTRACT.invoke(aData[tmpIndex], BigFunction.MULTIPLY.invoke(tmpScale, tmpHouseholderVector[i]));
                    tmpIndex++;
                }
            }
        }
    }

    static void doHouseholderRight(final BigDecimal[] aData, final int aFirstRow, final int aRowLimit, final int aColDim, final Householder.Big aHouseholder, final int availableCPUs) {

        final int tmpRowCount = aRowLimit - aFirstRow;

        if ((availableCPUs > 1) && (tmpRowCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstRow + tmpRowCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.doHouseholderRight(aData, aFirstRow, tmpSplit, aColDim, aHouseholder, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.doHouseholderRight(aData, tmpSplit, aRowLimit, aColDim, aHouseholder, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final BigDecimal[] tmpHouseholderVector = aHouseholder.vector;
            final int tmpFirstNonZero = aHouseholder.first;
            final BigDecimal tmpBeta = aHouseholder.beta;

            final int tmpRowDim = aData.length / aColDim;

            BigDecimal tmpScale;
            int tmpIndex;
            for (int i = aFirstRow; i < aRowLimit; i++) {
                tmpScale = ZERO;
                tmpIndex = i + tmpFirstNonZero * tmpRowDim;
                for (int j = tmpFirstNonZero; j < aColDim; j++) {
                    tmpScale = BigFunction.ADD.invoke(tmpScale, BigFunction.MULTIPLY.invoke(tmpHouseholderVector[j], aData[tmpIndex]));
                    tmpIndex += tmpRowDim;
                }
                tmpScale = BigFunction.MULTIPLY.invoke(tmpScale, tmpBeta);
                tmpIndex = i + tmpFirstNonZero * tmpRowDim;
                for (int j = tmpFirstNonZero; j < aColDim; j++) {
                    aData[tmpIndex] = BigFunction.SUBTRACT.invoke(aData[tmpIndex], BigFunction.MULTIPLY.invoke(tmpScale, tmpHouseholderVector[j]));
                    tmpIndex += tmpRowDim;
                }
            }
        }
    }

    static void doRotateLeft(final BigDecimal[] aData, final int aColDim, final int aRowA, final int aRowB, final BigDecimal aCos, final BigDecimal aSin) {

        BigDecimal tmpOldA;
        BigDecimal tmpOldB;

        int tmpIndexA = aRowA;
        int tmpIndexB = aRowB;
        final int tmpIndexStep = aData.length / aColDim;

        for (int j = 0; j < aColDim; j++) {

            tmpOldA = aData[tmpIndexA];
            tmpOldB = aData[tmpIndexB];

            aData[tmpIndexA] = BigFunction.ADD.invoke(BigFunction.MULTIPLY.invoke(aCos, tmpOldA), BigFunction.MULTIPLY.invoke(aSin, tmpOldB));
            aData[tmpIndexB] = BigFunction.SUBTRACT.invoke(BigFunction.MULTIPLY.invoke(aCos, tmpOldB), BigFunction.MULTIPLY.invoke(aSin, tmpOldA));

            tmpIndexA += tmpIndexStep;
            tmpIndexB += tmpIndexStep;
        }
    }

    static void doRotateRight(final BigDecimal[] aData, final int aRowDim, final int aColA, final int aColB, final BigDecimal aCos, final BigDecimal aSin) {

        BigDecimal tmpOldA;
        BigDecimal tmpOldB;

        int tmpIndexA = aColA * aRowDim;
        int tmpIndexB = aColB * aRowDim;

        for (int i = 0; i < aRowDim; i++) {

            tmpOldA = aData[tmpIndexA];
            tmpOldB = aData[tmpIndexB];

            aData[tmpIndexA] = BigFunction.SUBTRACT.invoke(BigFunction.MULTIPLY.invoke(aCos, tmpOldA), BigFunction.MULTIPLY.invoke(aSin, tmpOldB));
            aData[tmpIndexB] = BigFunction.ADD.invoke(BigFunction.MULTIPLY.invoke(aCos, tmpOldB), BigFunction.MULTIPLY.invoke(aSin, tmpOldA));

            tmpIndexA++;
            tmpIndexB++;
        }
    }

    static void fillMatching(final BigArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final BigArray aLeftArg, final BinaryFunction<BigDecimal> aFunc, final BigArray aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void fillMatching(final BigArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final BigArray aLeftArg, final BinaryFunction<BigDecimal> aFunc, final BigDecimal aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void fillMatching(final BigArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final BigDecimal aLeftArg, final BinaryFunction<BigDecimal> aFunc, final BigArray aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.fill(aRowDim * aFirstCol, aRowDim * aColLimit, aLeftArg, aFunc, aRightArg);
        }
    }

    static void fillMatching(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final BigDecimal aLeftArg, final BinaryFunction<BigDecimal> aFunc, final MatrixStore<BigDecimal> aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg, aRightArg.get(i, j));
                }
            }
        }
    }

    static void fillMatching(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final MatrixStore<BigDecimal> aLeftArg, final BinaryFunction<BigDecimal> aFunc, final BigDecimal aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg.get(i, j), aRightArg);
                }
            }
        }
    }

    static void fillMatching(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final MatrixStore<BigDecimal> aLeftArg, final BinaryFunction<BigDecimal> aFunc, final MatrixStore<BigDecimal> aRightArg, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, aFirstCol, tmpSplit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.fillMatching(aData, aRowDim, tmpSplit, aColLimit, aLeftArg, aFunc, aRightArg, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = aFunc.invoke(aLeftArg.get(i, j), aRightArg.get(i, j));
                }
            }
        }
    }

    static void maxpy(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final BigDecimal aScale, final MatrixStore<BigDecimal> aStore, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.maxpy(aData, aRowDim, aFirstCol, tmpSplit, aScale, aStore, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.maxpy(aData, aRowDim, tmpSplit, aColLimit, aScale, aStore, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex] = BigFunction.ADD.invoke(BigFunction.MULTIPLY.invoke(aScale, aStore.get(i, j)), aData[tmpIndex]);
                    tmpIndex++;
                }
            }
        }
    }

    static void modifyAll(final BigArray aData, final int aRowDim, final int aFirstCol, final int aColLimit, final UnaryFunction<BigDecimal> aFunc, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.modifyAll(aData, aRowDim, aFirstCol, tmpSplit, aFunc, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.modifyAll(aData, aRowDim, tmpSplit, aColLimit, aFunc, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            aData.modify(aRowDim * aFirstCol, aRowDim * aColLimit, 1, aFunc);
        }
    }

    static void multiply(final BigDecimal[] aProductArray, final int aFirstRow, final int aRowLimit, final int aColDim, final BigDecimal[] aLeftArray, final BigDecimal[] aRightArray, final int availableCPUs) {

        final int tmpRowCount = aRowLimit - aFirstRow;

        if ((availableCPUs > 1) && (tmpRowCount > BranchLimit.MULTIPLY)) {

            final int tmpSplit = aFirstRow + tmpRowCount / 2;
            final int tmpAvailableCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.multiply(aProductArray, aFirstRow, tmpSplit, aColDim, aLeftArray, aRightArray, tmpAvailableCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.multiply(aProductArray, tmpSplit, aRowLimit, aColDim, aLeftArray, aRightArray, tmpAvailableCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpCalcSize = aRightArray.length / aColDim;
            final int tmpRowDim = aLeftArray.length / tmpCalcSize;

            final BigDecimal[] tmpLeftRow = new BigDecimal[tmpCalcSize];
            int tmpIndex;
            BigDecimal tmpVal;

            for (int i = aFirstRow; i < aRowLimit; i++) {
                for (int c = 0; c < tmpCalcSize; c++) {
                    tmpLeftRow[c] = aLeftArray[i + c * tmpRowDim];
                }
                for (int j = 0; j < aColDim; j++) {
                    tmpIndex = j * tmpCalcSize;
                    tmpVal = ZERO;
                    for (int c = 0; c < tmpCalcSize; c++) {
                        tmpVal = BigFunction.ADD.invoke(tmpVal, BigFunction.MULTIPLY.invoke(tmpLeftRow[c], aRightArray[tmpIndex++]));
                    }
                    aProductArray[i + j * tmpRowDim] = tmpVal;
                }
            }
        }
    }

    static void multiply(final BigDecimal[] aProductArray, final MatrixStore<BigDecimal> aLeftStore, final MatrixStore<BigDecimal> aRightStore) {

        final int tmpRowDim = aLeftStore.getRowDim();
        final int tmpCalcSize = aRightStore.getRowDim();
        final int tmpColDim = aRightStore.getColDim();

        final boolean tmpLL = aLeftStore.isLowerLeftShaded();
        final boolean tmpLU = aLeftStore.isUpperRightShaded();
        final boolean tmpRL = aRightStore.isLowerLeftShaded();
        final boolean tmpRU = aRightStore.isUpperRightShaded();
        int tmpFirst;
        int tmpLimit;

        final BigDecimal[] tmpLeftRow = new BigDecimal[tmpCalcSize];
        BigDecimal tmpVal;

        for (int i = 0; i < tmpRowDim; i++) {
            for (int c = 0; c < tmpCalcSize; c++) {
                tmpLeftRow[c] = aLeftStore.get(i, c);
            }
            for (int j = 0; j < tmpColDim; j++) {
                tmpFirst = MatrixUtils.max(tmpLL ? i - 1 : 0, tmpRU ? j - 1 : 0, 0);
                tmpLimit = MatrixUtils.min(tmpLU ? i + 2 : tmpCalcSize, tmpRL ? j + 2 : tmpCalcSize, tmpCalcSize);
                tmpVal = ZERO;
                for (int c = tmpFirst; c < tmpLimit; c++) {
                    tmpVal = BigFunction.ADD.invoke(tmpVal, BigFunction.MULTIPLY.invoke(tmpLeftRow[c], aRightStore.get(c, j)));
                }
                aProductArray[i + j * tmpRowDim] = tmpVal;
            }
        }
    }

    static void substituteBackwards(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<BigDecimal> aBody, final boolean assumeOne, final boolean transposed, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.substituteBackwards(aData, aRowDim, aFirstCol, tmpSplit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.substituteBackwards(aData, aRowDim, tmpSplit, aColLimit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpDiagDim = aBody.getMinDim();

            final BigDecimal[] tmpRow = new BigDecimal[tmpDiagDim];
            BigDecimal tmpVal;
            int tmpColBaseIndex;

            for (int i = tmpDiagDim - 1; i >= 0; i--) {

                for (int j = i; j < tmpDiagDim; j++) {
                    tmpRow[j] = transposed ? aBody.get(j, i) : aBody.get(i, j);
                }

                for (int s = aFirstCol; s < aColLimit; s++) {

                    tmpColBaseIndex = s * aRowDim;

                    tmpVal = ZERO;
                    for (int j = i + 1; j < tmpDiagDim; j++) {
                        tmpVal = tmpVal.add(tmpRow[j].multiply(aData[j + tmpColBaseIndex]));
                    }
                    aData[i + tmpColBaseIndex] = aData[i + tmpColBaseIndex].subtract(tmpVal);

                    if (!assumeOne) {
                        aData[i + tmpColBaseIndex] = BigFunction.DIVIDE.invoke(aData[i + tmpColBaseIndex], tmpRow[i]);
                    }
                }
            }
        }
    }

    static void substituteForwards(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<BigDecimal> aBody, final boolean assumeOne, final boolean transposed, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.substituteForwards(aData, aRowDim, aFirstCol, tmpSplit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.substituteForwards(aData, aRowDim, tmpSplit, aColLimit, aBody, assumeOne, transposed, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            final int tmpDiagDim = aBody.getMinDim();

            final BigDecimal[] tmpRow = new BigDecimal[tmpDiagDim];
            BigDecimal tmpVal;
            int tmpColBaseIndex;

            for (int i = 0; i < tmpDiagDim; i++) {

                for (int j = 0; j <= i; j++) {
                    tmpRow[j] = transposed ? aBody.get(j, i) : aBody.get(i, j);
                }

                for (int s = aFirstCol; s < aColLimit; s++) {

                    tmpColBaseIndex = s * aRowDim;

                    tmpVal = ZERO;
                    for (int j = 0; j < i; j++) {
                        tmpVal = tmpVal.add(tmpRow[j].multiply(aData[j + tmpColBaseIndex]));
                    }
                    aData[i + tmpColBaseIndex] = aData[i + tmpColBaseIndex].subtract(tmpVal);

                    if (!assumeOne) {
                        aData[i + tmpColBaseIndex] = BigFunction.DIVIDE.invoke(aData[i + tmpColBaseIndex], tmpRow[i]);
                    }
                }
            }
        }
    }

    static void transpose(final BigDecimal[] aData, final int aRowDim, final int aFirstCol, final int aColLimit, final Access2D<? extends Number> aSource, final int availableCPUs) {

        final int tmpColCount = aColLimit - aFirstCol;

        if ((availableCPUs > 1) && (tmpColCount > BranchLimit.STANDARD)) {

            final int tmpSplit = aFirstCol + tmpColCount / 2;
            final int tmpCPUs = availableCPUs / 2;

            final Future<?> tmpFirstPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.transpose(aData, aRowDim, aFirstCol, tmpSplit, aSource, tmpCPUs);
                }
            });

            final Future<?> tmpSecondPart = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                public void run() {
                    BigDenseStore.transpose(aData, aRowDim, tmpSplit, aColLimit, aSource, tmpCPUs);
                }
            });

            try {
                tmpFirstPart.get();
                tmpSecondPart.get();
            } catch (final InterruptedException anException) {
                anException.printStackTrace();
            } catch (final ExecutionException anException) {
                anException.printStackTrace();
            }

        } else {

            int tmpIndex = aRowDim * aFirstCol;
            for (int j = aFirstCol; j < aColLimit; j++) {
                for (int i = 0; i < aRowDim; i++) {
                    aData[tmpIndex++] = TypeUtils.toBigDecimal(aSource.get(j, i));
                }
            }
        }
    }

    private final int myColDim;

    private final int myRowDim;

    private final Array2D<BigDecimal> myUtility;

    BigDenseStore(final BigDecimal[] anArray) {

        super(anArray);

        myRowDim = anArray.length;
        myColDim = 1;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    BigDenseStore(final int aLength) {

        super(aLength);

        myRowDim = aLength;
        myColDim = 1;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    BigDenseStore(final int aRowDim, final int aColDim) {

        super(aRowDim * aColDim);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    BigDenseStore(final int aRowDim, final int aColDim, final BigDecimal[] anArray) {

        super(anArray);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    public BigDecimal aggregateAll(final ChainableAggregator aVisitor) {
        return BigDenseStore.aggregateAll(this, myRowDim, 0, myColDim, aVisitor, ProcessorCount.RUNTIME);
    }

    public BigDecimal aggregateAll(final CollectableAggregator aVisitor) {
        return BigDenseStore.aggregateAll(this, myRowDim, 0, myColDim, aVisitor, ProcessorCount.RUNTIME);
    }

    public Array2D<BigDecimal> asArray2D() {
        return myUtility;
    }

    public Array1D<BigDecimal> asList() {
        return myUtility.asArray1D();
    }

    public final MatrixStore.Builder<BigDecimal> builder() {
        return new MatrixStore.Builder<BigDecimal>(this);
    }

    public void caxpy(final BigDecimal aSclrA, final int aColX, final int aColY, final int aFirstRow) {

        final BigDecimal[] tmpData = this.data();

        final int tmpRowDim = myRowDim;

        int tmpIndX = aFirstRow + aColX * tmpRowDim;
        int tmpIndY = aFirstRow + aColY * tmpRowDim;

        for (int i = aFirstRow; i < tmpRowDim; i++) {
            tmpData[tmpIndY] = BigFunction.ADD.invoke(BigFunction.MULTIPLY.invoke(aSclrA, tmpData[tmpIndX]), tmpData[tmpIndY]);
            tmpIndX++;
            tmpIndY++;
        }
    }

    public boolean computeInPlaceCholesky(final boolean checkForSPD) {

        // True if Positive Definite (does not check for symmetry)
        boolean tmpPD = myRowDim == myColDim;
        final int tmpDim = myRowDim;
        final BigDecimal[] tmpArray = this.data();

        int tmpIndex;
        final BigDecimal[] tmpLocal = new BigDecimal[tmpDim];
        BigDecimal tmpVal;

        // Along the main diagonal
        for (int ij = 0; tmpPD && (ij < tmpDim); ij++) {

            // Pivot element
            tmpIndex = ij + ij * tmpDim;
            tmpLocal[ij] = tmpArray[tmpIndex];

            if (tmpLocal[ij].signum() == 1) {

                // Current column below the diagonal
                tmpVal = BigFunction.SQRT.invoke(tmpLocal[ij]);
                tmpArray[tmpIndex] = tmpVal;
                for (int j = ij + 1; j < tmpLocal.length; j++) {
                    tmpIndex++;
                    tmpLocal[j] = tmpArray[tmpIndex];
                    tmpArray[tmpIndex] = BigFunction.DIVIDE.invoke(tmpArray[tmpIndex], tmpVal);
                }

                // For each of the remining columns
                BigDenseStore.daxpyCholesky(tmpArray, ij, tmpDim, ij + 1, tmpDim, tmpLocal, ProcessorCount.RUNTIME);

                //                for (int j = ij + 1; j < tmpDim; j++) {
                //
                //                    tmpIndex = j + j * tmpDim;
                //                    tmpVal = BigFunction.DIVIDE.invoke(tmpLocal[j], tmpLocal[ij]);
                //
                //                    // For each row below the diagonal
                //                    for (int i = j; i < tmpDim; i++) {
                //                        tmpArray[tmpIndex] = tmpArray[tmpIndex].subtract(tmpVal.multiply(tmpLocal[i]));
                //                        tmpIndex++;
                //                    }
                //                }
            } else {
                tmpPD = false;
            }
        }

        return tmpPD;
    }

    public Pivot computeInPlaceLU(final boolean assumeNoPivotingRequired) {

        final Pivot retVal = new Pivot(myRowDim);

        final BigDecimal[] tmpData = this.data();
        final BigDecimal[] tmpMultiplierColumn = new BigDecimal[myRowDim];

        final int tmpMinDim = Math.min(myRowDim, myColDim);

        int tmpPivotRowIndex, tmpDataIndex;
        BigDecimal tmpNmbr;

        // Main loop - along the diagonal
        for (int ij = 0; ij < tmpMinDim; ij++) {

            if (!assumeNoPivotingRequired) {
                // Find next pivot row, stop searching when something good enough is found
                tmpNmbr = tmpData[tmpDataIndex = ij + myRowDim * ij].abs();
                tmpPivotRowIndex = ij;
                for (int i = ij + 1; (i < myRowDim) && (tmpNmbr.compareTo(HALF) == -1); i++) {
                    if (tmpData[++tmpDataIndex].abs().compareTo(tmpNmbr) == 1) {
                        tmpNmbr = tmpData[tmpDataIndex].abs();
                        tmpPivotRowIndex = i;
                    }
                }
                // Pivot?
                if (tmpPivotRowIndex != ij) {
                    myUtility.exchangeRows(tmpPivotRowIndex, ij);
                    retVal.change(tmpPivotRowIndex, ij);
                }
            }

            // Do the calculations...
            tmpNmbr = tmpData[tmpDataIndex = ij + myRowDim * ij];
            if (tmpNmbr.signum() != 0) {

                // Calculate multipliers and copy to local column
                for (int i = ij + 1; i < myRowDim; i++) {
                    tmpDataIndex++;
                    tmpData[tmpDataIndex] = BigFunction.DIVIDE.invoke(tmpData[tmpDataIndex], tmpNmbr);
                    tmpMultiplierColumn[i] = tmpData[tmpDataIndex];
                }

                // Apply transformations to everything below and to the right of the pivot element
                BigDenseStore.daxpyLU(tmpData, ij, myRowDim, ij + 1, myColDim, tmpMultiplierColumn, ProcessorCount.RUNTIME);

            } else {

                tmpData[tmpDataIndex] = ZERO;
            }
        }

        return retVal;
    }

    public void computeInPlaceQR() {

        final BigDecimal[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        final Householder.Big tmpWorkCopy = new Householder.Big(tmpRowDim);

        for (int j = 0; j < tmpColDim; j++) {
            if (this.generateApplyAndCopyHouseholderColumn(j, j, tmpWorkCopy)) {
                BigDenseStore.doHouseholderLeft(tmpData, tmpRowDim, j + 1, tmpColDim, tmpWorkCopy, ProcessorCount.RUNTIME);
            }
        }
    }

    public void computeInPlaceTridiagonal() {

        final int tmpDim = myRowDim;
        final int tmpLim = tmpDim - 2;

        final BigDecimal[] tmpData = this.data();

        final Householder.Big tmpHousehoulder = new Householder.Big(tmpDim);

        int tmpNext;
        for (int ij = 0; ij < tmpLim; ij++) {

            tmpNext = ij + 1;

            if (this.generateApplyAndCopyHouseholderColumn(tmpNext, ij, tmpHousehoulder)) {
                BigDenseStore.doHouseholderLeft(tmpData, tmpDim, tmpNext, tmpDim, tmpHousehoulder, ProcessorCount.RUNTIME);
                BigDenseStore.doHouseholderRight(tmpData, tmpNext, tmpDim, tmpDim, tmpHousehoulder, ProcessorCount.RUNTIME);
            }
        }
    }

    public BigDenseStore conjugate() {
        return this.transpose();
    }

    public BigDenseStore copy() {
        return new BigDenseStore(myRowDim, myColDim, this.copyOfData());
    }

    public double doubleValue(final int aRow, final int aCol) {
        return myUtility.doubleValue(aRow, aCol);
    }

    public boolean equals(final MatrixStore<BigDecimal> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(this, aStore, aCntxt);
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(final Object anObj) {
        if (anObj instanceof MatrixStore) {
            return this.equals((MatrixStore<BigDecimal>) anObj, TypeUtils.EQUALS_NUMBER_CONTEXT);
        } else {
            return super.equals(anObj);
        }
    }

    public void exchangeColumns(final int aColA, final int aColB) {
        myUtility.exchangeColumns(aColA, aColB);
    }

    public void exchangeRows(final int aRowA, final int aRowB) {
        myUtility.exchangeRows(aRowA, aRowB);
    }

    public void fillAll(final BigDecimal aNmbr) {
        myUtility.fillAll(aNmbr);
    }

    public void fillByMultiplying(final MatrixStore<BigDecimal> aLeftArg, final MatrixStore<BigDecimal> aRightArg) {
        BigDenseStore.multiply(this.data(), 0, myRowDim, myColDim, this.cast(aLeftArg).data(), this.cast(aRightArg).data(), ProcessorCount.RUNTIME);
    }

    public void fillColumn(final int aRow, final int aCol, final BigDecimal aNmbr) {
        myUtility.fillColumn(aRow, aCol, aNmbr);
    }

    public void fillDiagonal(final int aRow, final int aCol, final BigDecimal aNmbr) {
        myUtility.fillDiagonal(aRow, aCol, aNmbr);
    }

    public void fillMatching(final Access2D<BigDecimal> aSource2D) {
        BigDenseStore.copy(this.data(), myRowDim, 0, myColDim, aSource2D, ProcessorCount.RUNTIME);
    }

    public void fillMatching(final BigDecimal aLeftArg, final BinaryFunction<BigDecimal> aFunc, final MatrixStore<BigDecimal> aRightArg) {
        if (aRightArg instanceof BigArray) {
            BigDenseStore.fillMatching(this, myRowDim, 0, myColDim, aLeftArg, aFunc, (BigArray) aRightArg, ProcessorCount.RUNTIME);
        } else {
            BigDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillMatching(final MatrixStore<BigDecimal> aLeftArg, final BinaryFunction<BigDecimal> aFunc, final BigDecimal aRightArg) {
        if (aLeftArg instanceof BigArray) {
            BigDenseStore.fillMatching(this, myRowDim, 0, myColDim, (BigArray) aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        } else {
            BigDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillMatching(final MatrixStore<BigDecimal> aLeftArg, final BinaryFunction<BigDecimal> aFunc, final MatrixStore<BigDecimal> aRightArg) {
        if ((aLeftArg instanceof BigArray) && (aRightArg instanceof BigArray)) {
            BigDenseStore.fillMatching(this, myRowDim, 0, myColDim, (BigArray) aLeftArg, aFunc, (BigArray) aRightArg, ProcessorCount.RUNTIME);
        } else {
            BigDenseStore.fillMatching(this.data(), myRowDim, 0, myColDim, aLeftArg, aFunc, aRightArg, ProcessorCount.RUNTIME);
        }
    }

    public void fillRow(final int aRow, final int aCol, final BigDecimal aNmbr) {
        myUtility.fillRow(aRow, aCol, aNmbr);
    }

    public Householder<BigDecimal> generateHouseholderColumn(final int newI, final int newIj) {
        // TODO Auto-generated method stub
        return null;
    }

    public Householder<BigDecimal> generateHouseholderRow(final int newIj, final int newI) {
        // TODO Auto-generated method stub
        return null;
    }

    public BigDecimal get(final int aRow, final int aCol) {
        return myUtility.get(aRow, aCol);
    }

    public int getColDim() {
        return myColDim;
    }

    public PhysicalStore.Factory<BigDecimal> getFactory() {
        return FACTORY;
    }

    public int getIndexOfLargestInColumn(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInColumn(aRow, aCol);
    }

    public int getIndexOfLargestInRow(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInRow(aRow, aCol);
    }

    public int getMinDim() {
        return Math.min(myRowDim, myColDim);
    }

    /**
     * @deprecated v29 Use {@link #get(int,int)} instead
     */
    @Deprecated
    public BigDecimal getNumber(final int aRow, final int aCol) {
        return this.get(aRow, aCol);
    }

    public int getRowDim() {
        return myRowDim;
    }

    @Override
    public int hashCode() {
        return MatrixUtils.hashCode(this);
    }

    public boolean isAbsolute(final int aRow, final int aCol) {
        return myUtility.isAbsolute(aRow, aCol);
    }

    public boolean isLowerLeftShaded() {
        return false;
    }

    public boolean isReal(final int aRow, final int aCol) {
        return myUtility.isReal(aRow, aCol);
    }

    public boolean isShaded() {
        return false;
    }

    public boolean isUpperRightShaded() {
        return false;
    }

    public boolean isZero(final int aRow, final int aCol) {
        return myUtility.isZero(aRow, aCol);
    }

    public void maxpy(final BigDecimal aSclrA, final MatrixStore<BigDecimal> aMtrxX) {
        BigDenseStore.maxpy(this.data(), myRowDim, 0, myColDim, aSclrA, aMtrxX, ProcessorCount.RUNTIME);
    }

    public void modifyAll(final UnaryFunction<BigDecimal> aFunc) {
        BigDenseStore.modifyAll(this, myRowDim, 0, myColDim, aFunc, ProcessorCount.RUNTIME);
    }

    public void modifyColumn(final int aRow, final int aCol, final UnaryFunction<BigDecimal> aFunc) {
        myUtility.modifyColumn(aRow, aCol, aFunc);
    }

    public void modifyDiagonal(final int aRow, final int aCol, final UnaryFunction<BigDecimal> aFunc) {
        myUtility.modifyDiagonal(aRow, aCol, aFunc);
    }

    public void modifyRow(final int aRow, final int aCol, final UnaryFunction<BigDecimal> aFunc) {
        myUtility.modifyRow(aRow, aCol, aFunc);
    }

    public MatrixStore<BigDecimal> multiplyLeft(final MatrixStore<BigDecimal> aStore) {

        final int tmpRowDim = aStore.getRowDim();
        final int tmpColDim = myColDim;

        final BigDecimal[] retVal = new BigDecimal[tmpRowDim * tmpColDim];

        BigDenseStore.multiply(retVal, 0, tmpRowDim, tmpColDim, this.cast(aStore).data(), this.data(), ProcessorCount.RUNTIME);

        return new BigDenseStore(tmpRowDim, tmpColDim, retVal);
    }

    public MatrixStore<BigDecimal> multiplyRight(final MatrixStore<BigDecimal> aStore) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = aStore.getColDim();

        final BigDecimal[] retVal = new BigDecimal[tmpRowDim * tmpColDim];

        BigDenseStore.multiply(retVal, 0, tmpRowDim, tmpColDim, this.data(), this.cast(aStore).data(), ProcessorCount.RUNTIME);

        return new BigDenseStore(tmpRowDim, tmpColDim, retVal);
    }

    public void raxpy(final BigDecimal aSclrA, final int aRowX, final int aRowY, final int aFirstCol) {

        final BigDecimal[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        int tmpIndX = aRowX + aFirstCol * tmpRowDim;
        int tmpIndY = aRowY + aFirstCol * tmpRowDim;

        for (int j = aFirstCol; j < tmpColDim; j++) {
            tmpData[tmpIndY] = BigFunction.ADD.invoke(BigFunction.MULTIPLY.invoke(aSclrA, tmpData[tmpIndX]), tmpData[tmpIndY]);
            tmpIndX += tmpRowDim;
            tmpIndY += tmpRowDim;
        }
    }

    public void set(final int aRow, final int aCol, final BigDecimal aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void set(final int aRow, final int aCol, final double aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void shadeLowerLeft() {
        ;
    }

    public void shadeUpperRight() {
        ;
    }

    public void substituteBackwards(final Access2D<BigDecimal> aBody, final boolean assumeOne, final boolean transposed) {
        BigDenseStore.substituteBackwards(this.data(), myRowDim, 0, myColDim, aBody, assumeOne, transposed, ProcessorCount.RUNTIME);
    }

    public void substituteForwards(final Access2D<BigDecimal> aBody, final boolean assumeOne, final boolean transposed) {
        BigDenseStore.substituteForwards(this.data(), myRowDim, 0, myColDim, aBody, assumeOne, transposed, ProcessorCount.RUNTIME);
    }

    public double[][] toRawCopy() {
        return myUtility.toRawCopy();
    }

    public Scalar<BigDecimal> toScalar(final int aRow, final int aCol) {
        return new BigScalar(this.get(aRow, aCol));
    }

    public void transformLeft(final Householder.Reference<BigDecimal> aTransf, final int aFirstCol) {
        BigDenseStore.doHouseholderLeft(this.data(), myRowDim, aFirstCol, myColDim, aTransf.getBigWorkCopy().copy(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformLeft(final Householder<BigDecimal> aTransf) {
        this.transformLeft(aTransf, 0);
    }

    public void transformLeft(final Householder<BigDecimal> aTransf, final int aFirstCol) {
        BigDenseStore.doHouseholderLeft(this.data(), myRowDim, aFirstCol, myColDim, new Householder.Big(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformLeft(final Rotation<BigDecimal> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {

            BigDenseStore.doRotateLeft(this.data(), myColDim, tmpLow, tmpHigh, aTransf.cos, aTransf.sin);

        } else if ((aTransf.cos != null) && (aTransf.cos.compareTo(aTransf.sin) == 0)) {

            myUtility.modifyRow(tmpLow, 0, BigFunction.MULTIPLY, aTransf.cos);

        } else {

            myUtility.modifyRow(tmpLow, 0, BigFunction.NEGATE);
        }
    }

    public void transformRight(final Householder.Reference<BigDecimal> aTransf, final int aFirstRow) {
        BigDenseStore.doHouseholderRight(this.data(), aFirstRow, myRowDim, myColDim, aTransf.getBigWorkCopy().copy(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformRight(final Householder<BigDecimal> aTransf) {
        this.transformRight(aTransf, 0);
    }

    public void transformRight(final Householder<BigDecimal> aTransf, final int aFirstRow) {
        BigDenseStore.doHouseholderRight(this.data(), aFirstRow, myRowDim, myColDim, new Householder.Big(aTransf), ProcessorCount.RUNTIME);
    }

    public void transformRight(final Rotation<BigDecimal> aTransf) {

        final int tmpLow = aTransf.low;
        final int tmpHigh = aTransf.high;

        if (tmpLow != tmpHigh) {

            BigDenseStore.doRotateRight(this.data(), myRowDim, tmpLow, tmpHigh, aTransf.cos, aTransf.sin);

        } else if ((aTransf.cos != null) && (aTransf.cos.compareTo(aTransf.sin) == 0)) {

            myUtility.modifyColumn(0, tmpHigh, BigFunction.MULTIPLY, aTransf.cos);

        } else {

            myUtility.modifyColumn(0, tmpHigh, BigFunction.NEGATE);
        }
    }

    public BigDenseStore transpose() {
        return (BigDenseStore) FACTORY.transpose(this);
    }

    public void unshade() {
        ;
    }

    public void visitAll(final AggregatorFunction<BigDecimal> aVisitor) {
        myUtility.visitAll(aVisitor);
    }

    public void visitColumn(final int aRow, final int aCol, final AggregatorFunction<BigDecimal> aVisitor) {
        myUtility.visitColumn(aRow, aCol, aVisitor);
    }

    public void visitDiagonal(final int aRow, final int aCol, final AggregatorFunction<BigDecimal> aVisitor) {
        myUtility.visitDiagonal(aRow, aCol, aVisitor);
    }

    public void visitRow(final int aRow, final int aCol, final AggregatorFunction<BigDecimal> aVisitor) {
        myUtility.visitRow(aRow, aCol, aVisitor);
    }

    private BigDenseStore cast(final MatrixStore<BigDecimal> aStore) {
        if (aStore instanceof BigDenseStore) {
            return (BigDenseStore) aStore;
        } else {
            return (BigDenseStore) FACTORY.copy(aStore);
        }
    }

    private boolean generateApplyAndCopyHouseholderColumn(final int aRow, final int aCol, final Householder.Big aDestination) {

        final BigDecimal[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColBaseIndex = tmpRowDim * aCol;

        BigDecimal tmpVal;
        BigDecimal tmpVal2 = ZERO;
        for (int i = aRow; i < tmpRowDim; i++) {
            tmpVal = tmpData[i + tmpColBaseIndex];
            tmpVal2 = BigFunction.ADD.invoke(tmpVal2, BigFunction.MULTIPLY.invoke(tmpVal, tmpVal));
        }
        tmpVal2 = BigFunction.SQRT.invoke(tmpVal2);

        final boolean retVal = !TypeUtils.isZero(tmpVal2.doubleValue());

        if (retVal) {

            BigDecimal tmpScale = tmpData[aRow + tmpColBaseIndex];

            if (tmpScale.signum() != 1) {
                tmpScale = BigFunction.SUBTRACT.invoke(tmpScale, tmpVal2);
                tmpData[aRow + tmpColBaseIndex] = tmpVal2;
            } else {
                tmpScale = BigFunction.ADD.invoke(tmpScale, tmpVal2);
                tmpData[aRow + tmpColBaseIndex] = tmpVal2.negate();
            }

            final BigDecimal[] tmpVector = aDestination.vector;

            tmpVal2 = ONE;
            tmpVector[aRow] = ONE;
            for (int i = aRow + 1; i < tmpRowDim; i++) {
                tmpVal = tmpData[i + tmpColBaseIndex] = BigFunction.DIVIDE.invoke(tmpData[i + tmpColBaseIndex], tmpScale);
                tmpVal2 = BigFunction.ADD.invoke(tmpVal2, BigFunction.MULTIPLY.invoke(tmpVal, tmpVal));
                tmpVector[i] = tmpVal;
            }

            aDestination.beta = BigFunction.DIVIDE.invoke(TWO, tmpVal2);

            aDestination.first = aRow;
        }

        return retVal;
    }

}
