/*
 * Copyright © 2006 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.function.implementation;

import static org.ojalgo.constant.BigMath.*;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.ParameterFunction;
import org.ojalgo.function.UnaryFunction;

public final class BigFunction extends FunctionSet<BigDecimal> {

    public static final UnaryFunction<BigDecimal> ABS = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return anArg.abs(CONTEXT);
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.ABS.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> ACOS = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.ACOS.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> ACOSH = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.ACOSH.invoke(anArg);
        }
    };

    public static final BinaryFunction<BigDecimal> ADD = new BinaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg1, final BigDecimal anArg2) {
            return anArg1.add(anArg2, CONTEXT);
        }

        public final double invoke(final double anArg1, final double anArg2) {
            return PrimitiveFunction.ADD.invoke(anArg1, anArg2);
        }
    };

    public static final UnaryFunction<BigDecimal> ASIN = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.ASIN.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> ASINH = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.ASINH.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> ATAN = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.ATAN.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> ATANH = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.ATANH.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> CARDINALITY = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return anArg.signum() == 0 ? ZERO : ONE;
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.CARDINALITY.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> CONJUGATE = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return anArg.plus(CONTEXT);
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.CONJUGATE.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> COS = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.COS.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> COSH = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.COSH.invoke(anArg);
        }
    };

    public static final BinaryFunction<BigDecimal> DIVIDE = new BinaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg1, final BigDecimal anArg2) {
            //return anArg1.divide(anArg2, CONTEXT); // Very slow!
            return anArg1.divide(anArg2, CONTEXT.getPrecision(), CONTEXT.getRoundingMode()); // Faster...
        }

        public final double invoke(final double anArg1, final double anArg2) {
            return PrimitiveFunction.DIVIDE.invoke(anArg1, anArg2);
        }
    };

    public static final UnaryFunction<BigDecimal> EXP = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.EXP.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> EXPM1 = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.EXPM1.invoke(anArg);
        }
    };

    public static final BinaryFunction<BigDecimal> HYPOT = new BinaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg1, final BigDecimal anArg2) {
            return SQRT.invoke(anArg1.multiply(anArg1).add(anArg2.multiply(anArg2)));
        }

        public final double invoke(final double anArg1, final double anArg2) {
            return PrimitiveFunction.HYPOT.invoke(anArg1, anArg2);
        }
    };

    public static final UnaryFunction<BigDecimal> INVERT = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return DIVIDE.invoke(ONE, anArg);
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.INVERT.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> SQRT1PX2 = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return SQRT.invoke(ONE.add(anArg.multiply(anArg)));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.SQRT1PX2.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> LOG = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.LOG.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> LOG10 = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.LOG10.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> LOG1P = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.LOG1P.invoke(anArg);
        }
    };

    public static final BinaryFunction<BigDecimal> MAX = new BinaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg1, final BigDecimal anArg2) {
            return anArg1.max(anArg2);
        }

        public final double invoke(final double anArg1, final double anArg2) {
            return PrimitiveFunction.MAX.invoke(anArg1, anArg2);
        }
    };

    public static final BinaryFunction<BigDecimal> MIN = new BinaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg1, final BigDecimal anArg2) {
            return anArg1.min(anArg2);
        }

        public final double invoke(final double anArg1, final double anArg2) {
            return PrimitiveFunction.MIN.invoke(anArg1, anArg2);
        }
    };

    public static final BinaryFunction<BigDecimal> MULTIPLY = new BinaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg1, final BigDecimal anArg2) {
            return anArg1.multiply(anArg2, CONTEXT);
        }

        public final double invoke(final double anArg1, final double anArg2) {
            return PrimitiveFunction.MULTIPLY.invoke(anArg1, anArg2);
        }
    };

    public static final UnaryFunction<BigDecimal> NEGATE = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return anArg.negate(CONTEXT);
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.NEGATE.invoke(anArg);
        }
    };

    public static final BinaryFunction<BigDecimal> POW = new BinaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg1, final BigDecimal anArg2) {
            return new BigDecimal(this.invoke(anArg1.doubleValue(), anArg2.doubleValue()));
        }

        public final double invoke(final double anArg1, final double anArg2) {
            return PrimitiveFunction.POW.invoke(anArg1, anArg2);
        }
    };

    public static final ParameterFunction<BigDecimal> POWER = new ParameterFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg, final int aParam) {
            return anArg.pow(aParam, CONTEXT);
        }

        public final double invoke(final double anArg, final int aParam) {
            return PrimitiveFunction.POWER.invoke(anArg, aParam);
        }
    };

    public static final ParameterFunction<BigDecimal> ROOT = new ParameterFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg, final int aParam) {
            if (aParam <= 0) {
                throw new IllegalArgumentException();
            } else if (aParam == 1) {
                return anArg.plus(CONTEXT);
            } else if (aParam == 2) {
                return SQRT.invoke(anArg);
            } else {
                return new BigDecimal(PrimitiveFunction.ROOT.invoke(anArg.doubleValue(), aParam));
            }
        }

        public final double invoke(final double anArg, final int aParam) {
            return PrimitiveFunction.ROOT.invoke(anArg, aParam);
        }
    };

    public static final ParameterFunction<BigDecimal> SCALE = new ParameterFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg, final int aParam) {
            return anArg.setScale(aParam, CONTEXT.getRoundingMode());
        }

        public final double invoke(final double anArg, final int aParam) {
            return PrimitiveFunction.SCALE.invoke(anArg, aParam);
        }
    };

    public static final UnaryFunction<BigDecimal> SIGNUM = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            switch (anArg.signum()) {
            case 1:
                return ONE;
            case -1:
                return ONE.negate();
            default:
                return ZERO;
            }
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.SIGNUM.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> SIN = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.SIN.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> SINH = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.SINH.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> SQRT = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {

            BigDecimal retVal = new BigDecimal(Math.sqrt(anArg.doubleValue()));

            BigDecimal tmpShouldBeZero;
            final int tmpScale = CONTEXT.getPrecision();
            final RoundingMode tmpRoundingMode = CONTEXT.getRoundingMode();
            while ((tmpShouldBeZero = retVal.multiply(retVal).subtract(anArg).setScale(tmpScale, tmpRoundingMode)).signum() != 0) {
                retVal = retVal.subtract(tmpShouldBeZero.divide(TWO.multiply(retVal), CONTEXT));
            }

            return retVal.plus(CONTEXT);
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.SQRT.invoke(anArg);
        }
    };

    public static final BinaryFunction<BigDecimal> SUBTRACT = new BinaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg1, final BigDecimal anArg2) {
            return anArg1.subtract(anArg2, CONTEXT);
        }

        public final double invoke(final double anArg1, final double anArg2) {
            return PrimitiveFunction.SUBTRACT.invoke(anArg1, anArg2);
        }
    };

    public static final UnaryFunction<BigDecimal> TAN = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.TAN.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> TANH = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return new BigDecimal(this.invoke(anArg.doubleValue()));
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.TANH.invoke(anArg);
        }
    };

    public static final UnaryFunction<BigDecimal> VALUE = new UnaryFunction<BigDecimal>() {

        public final BigDecimal invoke(final BigDecimal anArg) {
            return anArg.plus(CONTEXT);
        }

        public final double invoke(final double anArg) {
            return PrimitiveFunction.VALUE.invoke(anArg);
        }
    };

    private static final MathContext CONTEXT = MathContext.DECIMAL128;
    private static final BigFunction SET = new BigFunction();

    public static BigFunction getSet() {
        return SET;
    }

    private BigFunction() {
        super();
    }

    @Override
    public UnaryFunction<BigDecimal> abs() {
        return ABS;
    }

    @Override
    public UnaryFunction<BigDecimal> acos() {
        return ACOS;
    }

    @Override
    public UnaryFunction<BigDecimal> acosh() {
        return ACOSH;
    }

    @Override
    public BinaryFunction<BigDecimal> add() {
        return ADD;
    }

    @Override
    public UnaryFunction<BigDecimal> asin() {
        return ASIN;
    }

    @Override
    public UnaryFunction<BigDecimal> asinh() {
        return ASINH;
    }

    @Override
    public UnaryFunction<BigDecimal> atan() {
        return ATAN;
    }

    @Override
    public UnaryFunction<BigDecimal> atanh() {
        return ATANH;
    }

    @Override
    public UnaryFunction<BigDecimal> cardinality() {
        return CARDINALITY;
    }

    @Override
    public UnaryFunction<BigDecimal> conjugate() {
        return CONJUGATE;
    }

    @Override
    public UnaryFunction<BigDecimal> cos() {
        return COS;
    }

    @Override
    public UnaryFunction<BigDecimal> cosh() {
        return COSH;
    }

    @Override
    public BinaryFunction<BigDecimal> divide() {
        return DIVIDE;
    }

    @Override
    public UnaryFunction<BigDecimal> exp() {
        return EXP;
    }

    @Override
    public BinaryFunction<BigDecimal> hypot() {
        return HYPOT;
    }

    @Override
    public UnaryFunction<BigDecimal> invert() {
        return INVERT;
    }

    @Override
    public UnaryFunction<BigDecimal> log() {
        return LOG;
    }

    @Override
    public BinaryFunction<BigDecimal> max() {
        return MAX;
    }

    @Override
    public BinaryFunction<BigDecimal> min() {
        return MIN;
    }

    @Override
    public BinaryFunction<BigDecimal> multiply() {
        return MULTIPLY;
    }

    @Override
    public UnaryFunction<BigDecimal> negate() {
        return NEGATE;
    }

    @Override
    public BinaryFunction<BigDecimal> pow() {
        return POW;
    }

    @Override
    public ParameterFunction<BigDecimal> power() {
        return POWER;
    }

    @Override
    public ParameterFunction<BigDecimal> root() {
        return ROOT;
    }

    @Override
    public ParameterFunction<BigDecimal> scale() {
        return SCALE;
    }

    @Override
    public UnaryFunction<BigDecimal> signum() {
        return SIGNUM;
    }

    @Override
    public UnaryFunction<BigDecimal> sin() {
        return SIN;
    }

    @Override
    public UnaryFunction<BigDecimal> sinh() {
        return SINH;
    }

    @Override
    public UnaryFunction<BigDecimal> sqrt() {
        return SQRT;
    }

    @Override
    public UnaryFunction<BigDecimal> sqrt1px2() {
        return SQRT1PX2;
    }

    @Override
    public BinaryFunction<BigDecimal> subtract() {
        return SUBTRACT;
    }

    @Override
    public UnaryFunction<BigDecimal> tan() {
        return TAN;
    }

    @Override
    public UnaryFunction<BigDecimal> tanh() {
        return TANH;
    }

    @Override
    public UnaryFunction<BigDecimal> value() {
        return VALUE;
    }

}
