/*
 * Copyright © 2006 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation;

import java.math.RoundingMode;

import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.PrimitiveMatrix;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.type.CalendarDateUnit;
import org.ojalgo.type.context.NumberContext;

/**
 * <p>
 * An {@linkplain OptimisationSolver} implementation implements a specific
 * optimisation algorithm. Typically each algorithm solves problems of
 * (at least) one problem category. {@linkplain OptimisationModel} represents
 * a problem category.
 * </p><p>
 * A solver internally works with primitive double.
 * </p>
 * 
 * @author apete
 */
public interface OptimisationSolver extends Optimisation {

    public static abstract interface Builder<S extends OptimisationSolver> {

        S build();

    }

    public static final class Options {

        public static final int DEFAULT_ITERATIONS_LIMIT = Integer.MAX_VALUE;
        public static final NumberContext DEFAULT_PRINT_CONTEXT = NumberContext.getGeneral(6, 10);
        public static final NumberContext DEFAULT_PROBLEM_CONTEXT = NumberContext.getGeneral(10, RoundingMode.HALF_EVEN);
        public static final NumberContext DEFAULT_SOLUTION_CONTEXT = NumberContext.getGeneral(6, RoundingMode.DOWN);
        public static final long DEFAULT_TIME_LIMIT = CalendarDateUnit.MILLENIUM.size();

        /**
         * The maximmum number of iterations allowed for the solve() command.
         */
        public int iterationsLimit = DEFAULT_ITERATIONS_LIMIT;
        /**
         * For display only!
         */
        public NumberContext printContext = DEFAULT_PRINT_CONTEXT;
        /**
         * Problem parameters; constraints and objective function
         */
        public NumberContext problemContext = DEFAULT_PROBLEM_CONTEXT;
        /**
         * Solution variables; primary and dual (langrange multipliers)
         */
        public NumberContext solutionContext = DEFAULT_SOLUTION_CONTEXT;
        /**
         * The maximmum number of millis allowed for the solve() command.
         */
        public long timeLimit = DEFAULT_TIME_LIMIT;

        Options() {
            super();
        }

    }

    public static class Result {

        private final int myIterationsCount;
        private final MatrixStore<Double> mySolution;
        private final State myState;

        public Result(final Result aResult, final State aDifferentState) {

            super();

            myState = aDifferentState;
            final BasicMatrix tmpSolution = aResult.getSolution();
            if (tmpSolution != null) {
                mySolution = tmpSolution.toPrimitiveStore();
            } else {
                mySolution = null;
            }

            myIterationsCount = aResult.getIterationsCount();
        }

        public Result(final State aState, final MatrixStore<Double> aSolution, final int anIterationCount) {

            super();

            myState = aState;
            mySolution = aSolution;
            myIterationsCount = anIterationCount;
        }

        public final int getIterationsCount() {
            return myIterationsCount;
        }

        public final BasicMatrix getSolution() {
            if (mySolution != null) {
                return new PrimitiveMatrix(mySolution);
            } else {
                return null;
            }
        }

        public final State getState() {
            return myState;
        }

        @Override
        public String toString() {
            return myState + " (" + myIterationsCount + ") " + ((mySolution != null) ? PrimitiveDenseStore.FACTORY.copy(mySolution) : "?");
        }

    }

    Result solve();

    Result solve(OptimisationModel aValidationModel);
}
