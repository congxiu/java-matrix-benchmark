/*
 * Copyright © 2009 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation.linear;

import static org.ojalgo.constant.PrimitiveMath.*;

import java.util.Arrays;

import org.ojalgo.ProgrammingError;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.optimisation.Expression;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.optimisation.GenericSolver;
import org.ojalgo.optimisation.OptimisationSolver;
import org.ojalgo.optimisation.Variable;
import org.ojalgo.optimisation.quadratic.QuadraticExpressionsModel;
import org.ojalgo.type.IndexSelector;

/**
 * LinearSolver solves optimisation problems of the (LP standard) form:
 * <p>
 * min [C]<sup>T</sup>[X]<br>
 * when [AE][X] == [BE]<br>
 *  and 0 <= [X]
 * </p>
 * A Linear Program is in Standard Form if:
 * <ul>
 * <li>All constraints are equality constraints.</li>
 * <li>All variables have a nonnegativity sign restriction.</li>
 * </ul>
 * Further it is required here that the constraint right hand sides are
 * nonnegative (nonnegative elements in [BE]).
 * 
 * @author apete
 */
public abstract class LinearSolver extends GenericSolver {

    public static final class Builder extends GenericSolver.Matrices<Builder> implements OptimisationSolver.Builder<LinearSolver> {

        private final int[] myPivots;

        public Builder() {

            super();

            myPivots = null;
        }

        public Builder(final LinearExpressionsModel aModel) {

            super();

            myPivots = LinearSolver.copy(aModel, this);
        }

        public Builder(final Matrices<?> aMatrices) {

            super(aMatrices);

            myPivots = null;
        }

        public Builder(final MatrixStore<Double> C) {

            super();

            this.objective(C);

            myPivots = null;
        }

        public Builder(final MatrixStore<Double>[] aMtrxArr) {

            super(aMtrxArr);

            myPivots = null;
        }

        public Builder(final QuadraticExpressionsModel aModel) {

            super();

            myPivots = LinearSolver.copy(aModel, this);
        }

        public LinearSolver build() {

            final int tmpCountEqualityConstraints = this.countEqualityConstraints();

            final int[] tmpPivots = myPivots != null ? myPivots : LinearSolver.makePivots(tmpCountEqualityConstraints);

            return new SimplexTableauSolver(this, tmpPivots);
        }
    }

    static int[] copy(final ExpressionsBasedModel<?> aSourceModel, final LinearSolver.Builder aDestinationBuilder) {

        final boolean tmpMaximisation = aSourceModel.isMaximisation();

        final Variable[] tmpVariables = aSourceModel.getVariables();

        final Expression tmpObjFunc = aSourceModel.getObjectiveExpression();

        final Expression[] tmpNegEqExprs = aSourceModel.selectNegativeEqualityConstraintExpressions();
        final Expression[] tmpPosEqExprs = aSourceModel.selectPositiveEqualityConstraintExpressions();
        final Expression[] tmpNegLoExprs = aSourceModel.selectNegativeLowerConstraintExpressions();
        final Expression[] tmpPosLoExprs = aSourceModel.selectPositiveLowerConstraintExpressions();
        final Expression[] tmpNegUpExprs = aSourceModel.selectNegativeUpperConstraintExpressions();
        final Expression[] tmpPosUpExprs = aSourceModel.selectPositiveUpperConstraintExpressions();

        final Variable[] tmpNonLoVars = aSourceModel.selectNonZeroLowerConstraintVariables();
        final Variable[] tmpAllUpVars = aSourceModel.selectUpperConstraintVariables();
        final Variable[] tmpAllEqVars = aSourceModel.selectEqualityConstraintVariables();

        final int tmpConstraiCount = tmpNegEqExprs.length + tmpPosEqExprs.length + tmpNegLoExprs.length + tmpPosLoExprs.length + tmpNegUpExprs.length + tmpPosUpExprs.length + tmpNonLoVars.length + tmpAllUpVars.length + tmpAllEqVars.length;
        final int tmpProblVarCount = tmpVariables.length;
        final int tmpSlackVarCount = tmpNegLoExprs.length + tmpPosLoExprs.length + tmpNegUpExprs.length + tmpPosUpExprs.length + tmpNonLoVars.length + tmpAllUpVars.length;
        final int tmpTotalVarCount = tmpProblVarCount + tmpSlackVarCount;

        final int[] retValPivots = LinearSolver.makePivots(tmpConstraiCount);

        final PhysicalStore<Double> tmpC = PrimitiveDenseStore.FACTORY.makeZero(tmpTotalVarCount, 1);
        final PhysicalStore<Double> tmpAE = PrimitiveDenseStore.FACTORY.makeZero(tmpConstraiCount, tmpTotalVarCount);
        final PhysicalStore<Double> tmpBE = PrimitiveDenseStore.FACTORY.makeZero(tmpConstraiCount, 1);

        aDestinationBuilder.objective(tmpC);
        aDestinationBuilder.equalities(tmpAE, tmpBE);

        int tmpSlackColIndex = tmpProblVarCount;
        for (int j = 0; j < tmpProblVarCount; j++) {

            // C

            if (tmpMaximisation) {
                tmpC.set(j, 0, tmpObjFunc.getAdjustedLinearFactor(j).negate().doubleValue());
            } else {
                tmpC.set(j, 0, tmpObjFunc.getAdjustedLinearFactor(j).doubleValue());
            }

            // AE & BE

            int tmpRowBaseIndex = 0;

            // NON BASIC

            // Negative Equality Expressions
            for (int i = 0; i < tmpNegEqExprs.length; i++) {
                tmpAE.set(tmpRowBaseIndex + i, j, tmpNegEqExprs[i].getAdjustedLinearFactor(j).negate().doubleValue());
                if (j == 0) {
                    tmpBE.set(tmpRowBaseIndex + i, j, tmpNegEqExprs[i].getAdjustedUpperLimit().negate().doubleValue());
                }
            }
            tmpRowBaseIndex += tmpNegEqExprs.length;

            // Positive Equality Expressions
            for (int i = 0; i < tmpPosEqExprs.length; i++) {
                tmpAE.set(tmpRowBaseIndex + i, j, tmpPosEqExprs[i].getAdjustedLinearFactor(j).doubleValue());
                if (j == 0) {
                    tmpBE.set(tmpRowBaseIndex + i, j, tmpPosEqExprs[i].getAdjustedUpperLimit().doubleValue());
                }
            }
            tmpRowBaseIndex += tmpPosEqExprs.length;

            // Positive Lower Limit Expressions
            for (int i = 0; i < tmpPosLoExprs.length; i++) {
                tmpAE.set(tmpRowBaseIndex + i, j, tmpPosLoExprs[i].getAdjustedLinearFactor(j).doubleValue());
                if (j == 0) {
                    tmpAE.set(tmpRowBaseIndex + i, tmpSlackColIndex++, NEG);
                    tmpBE.set(tmpRowBaseIndex + i, j, tmpPosLoExprs[i].getAdjustedLowerLimit().doubleValue());
                }
            }
            tmpRowBaseIndex += tmpPosLoExprs.length;

            // Negative Upper Limit Expressions
            for (int i = 0; i < tmpNegUpExprs.length; i++) {
                tmpAE.set(tmpRowBaseIndex + i, j, tmpNegUpExprs[i].getAdjustedLinearFactor(j).doubleValue());
                if (j == 0) {
                    tmpAE.set(tmpRowBaseIndex + i, tmpSlackColIndex++, ONE);
                    tmpBE.set(tmpRowBaseIndex + i, j, tmpNegUpExprs[i].getAdjustedUpperLimit().doubleValue());
                }
            }
            tmpRowBaseIndex += tmpNegUpExprs.length;

            // Lower Limit Variables
            for (int i = 0; i < tmpNonLoVars.length; i++) {
                if (tmpNonLoVars[i].equals(tmpVariables[j])) {
                    tmpAE.set(tmpRowBaseIndex + i, j, ONE);
                    tmpAE.set(tmpRowBaseIndex + i, tmpSlackColIndex++, NEG);
                    tmpBE.set(tmpRowBaseIndex + i, 0, tmpNonLoVars[i].getLowerLimit().doubleValue());
                }
            }
            tmpRowBaseIndex += tmpNonLoVars.length;

            // BASIC

            // Negative Lower Limit Expressions
            for (int i = 0; i < tmpNegLoExprs.length; i++) {
                tmpAE.set(tmpRowBaseIndex + i, j, tmpNegLoExprs[i].getAdjustedLinearFactor(j).negate().doubleValue());
                if (j == 0) {
                    retValPivots[tmpRowBaseIndex + i] = tmpSlackColIndex;
                    tmpAE.set(tmpRowBaseIndex + i, tmpSlackColIndex++, ONE);
                    tmpBE.set(tmpRowBaseIndex + i, j, tmpNegLoExprs[i].getAdjustedLowerLimit().negate().doubleValue());
                }
            }
            tmpRowBaseIndex += tmpNegLoExprs.length;

            // Positive Upper Limit Expressions
            for (int i = 0; i < tmpPosUpExprs.length; i++) {
                tmpAE.set(tmpRowBaseIndex + i, j, tmpPosUpExprs[i].getAdjustedLinearFactor(j).doubleValue());
                if (j == 0) {
                    retValPivots[tmpRowBaseIndex + i] = tmpSlackColIndex;
                    tmpAE.set(tmpRowBaseIndex + i, tmpSlackColIndex++, ONE);
                    tmpBE.set(tmpRowBaseIndex + i, j, tmpPosUpExprs[i].getAdjustedUpperLimit().doubleValue());
                }
            }
            tmpRowBaseIndex += tmpPosUpExprs.length;

            // Upper Limit Variables
            for (int i = 0; i < tmpAllUpVars.length; i++) {
                if (tmpAllUpVars[i].equals(tmpVariables[j])) {
                    tmpAE.set(tmpRowBaseIndex + i, j, ONE);
                    retValPivots[tmpRowBaseIndex + i] = tmpSlackColIndex;
                    tmpAE.set(tmpRowBaseIndex + i, tmpSlackColIndex++, ONE);
                    tmpBE.set(tmpRowBaseIndex + i, 0, tmpAllUpVars[i].getUpperLimit().doubleValue());
                }
            }
            tmpRowBaseIndex += tmpAllUpVars.length;

            // Equality Variables
            for (int i = 0; i < tmpAllEqVars.length; i++) {
                if (tmpAllEqVars[i].equals(tmpVariables[j])) {
                    retValPivots[tmpRowBaseIndex + i] = j;
                    tmpAE.set(tmpRowBaseIndex + i, j, ONE);
                    tmpBE.set(tmpRowBaseIndex + i, 0, tmpAllEqVars[i].getUpperLimit().doubleValue());

                }
            }
            tmpRowBaseIndex += tmpAllEqVars.length;

        }

        if (DEBUG) {
            BasicLogger.logDebug("C");
            MatrixUtils.printToStream(BasicLogger.DEBUG, tmpC, Options.DEFAULT_PRINT_CONTEXT);
            BasicLogger.logDebug("AE");
            MatrixUtils.printToStream(BasicLogger.DEBUG, tmpAE, Options.DEFAULT_PRINT_CONTEXT);
            BasicLogger.logDebug("BE");
            MatrixUtils.printToStream(BasicLogger.DEBUG, tmpBE, Options.DEFAULT_PRINT_CONTEXT);
            BasicLogger.logDebug("Basis: {}", Arrays.toString(retValPivots));
        }

        return retValPivots;
    }

    static int[] makePivots(final int aNumberOfConstraints) {
        final int[] retVal = new int[aNumberOfConstraints];
        Arrays.fill(retVal, -1);
        return retVal;
    }

    private final Matrices<?> myMatrices;
    private final IndexSelector mySelector;

    @SuppressWarnings("unused")
    private LinearSolver() {

        this(null, new int[] {});

        ProgrammingError.throwForIllegalInvocation();
    }

    protected LinearSolver(final LinearSolver.Builder aBuilder, final int[] aPivots) {

        super();

        if (aBuilder.countEqualityConstraints() != aPivots.length) {
            throw new IllegalStateException("There must be exactly one pivot for each constraint!");
        }

        myMatrices = aBuilder;
        mySelector = new IndexSelector(aBuilder.countVariables(), aPivots);
    }

    LinearSolver(final LinearSolver.Builder aBuilder, final IndexSelector aSelector) {

        super();

        if (!((aBuilder.countVariables() == aSelector.size()) && (aBuilder.countEqualityConstraints() == aSelector.countIncluded()))) {
            throw new IllegalStateException("Basis not complete!");
        }

        myMatrices = aBuilder;
        mySelector = aSelector;
    }

    protected final int countBasisDeficit() {
        return myMatrices.countEqualityConstraints() - mySelector.countIncluded();
    }

    protected final int countConstraints() {
        return myMatrices.countEqualityConstraints();
    }

    protected final int countVariables() {
        return myMatrices.countVariables();
    }

    protected final void exclude(final int anIndexToExclude) {
        mySelector.exclude(anIndexToExclude);
    }

    protected final void excludeAll() {
        mySelector.excludeAll();
    }

    protected final MatrixStore<Double> getAE() {
        return myMatrices.getAE();
    }

    protected final MatrixStore<Double> getAE(final int[] aColSelector) {
        return myMatrices.getAE(aColSelector);
    }

    protected final MatrixStore<Double> getBE() {
        return myMatrices.getBE();
    }

    protected final MatrixStore<Double> getC() {
        return myMatrices.getC();
    }

    protected final MatrixStore<Double> getC(final int[] aRowSelector) {
        return myMatrices.getC(aRowSelector);
    }

    protected final int[] getExcluded() {
        return mySelector.getExcluded();
    }

    protected final int[] getIncluded() {
        return mySelector.getIncluded();
    }

    protected final MatrixStore<Double> getX() {
        return myMatrices.getX();
    }

    protected final boolean hasConstraints() {
        return myMatrices.hasEqualityConstraints();
    }

    protected final void include(final int anIndexToInclude) {
        mySelector.include(anIndexToInclude);
    }

    protected final void include(final int[] someIndecesToInclude) {
        mySelector.include(someIndecesToInclude);
    }

    protected final void setX(final MatrixStore<Double> aMtrx) {
        myMatrices.setX(aMtrx);
    }
}
