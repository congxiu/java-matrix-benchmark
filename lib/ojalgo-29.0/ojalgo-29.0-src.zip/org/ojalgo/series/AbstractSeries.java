/*
 * Copyright © 2008 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.series;

import java.awt.Color;
import java.util.Comparator;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.ParameterFunction;
import org.ojalgo.function.UnaryFunction;

abstract class AbstractSeries<K extends Comparable<K>, V extends Number> extends TreeMap<K, V> implements BasicSeries<K, V> {

    private Color myColour = null;
    private String myName = null;

    protected AbstractSeries() {
        super();
    }

    protected AbstractSeries(final Comparator<? super K> someC) {
        super(someC);
    }

    protected AbstractSeries(final Map<? extends K, ? extends V> someM) {
        super(someM);
    }

    protected AbstractSeries(final SortedMap<K, ? extends V> someM) {
        super(someM);
    }

    public BasicSeries<K, V> colour(final Color aPaint) {
        this.setColour(aPaint);
        return this;
    }

    public V firstValue() {
        return this.get(this.firstKey());
    }

    public Color getColour() {
        return myColour;
    }

    public String getName() {
        return myName;
    }

    public double[] getPrimitiveValues() {

        final double[] retVal = new double[this.size()];

        int i = 0;
        for (final V tmpValue : this.values()) {
            retVal[i] = tmpValue.doubleValue();
            i++;
        }

        return retVal;
    }

    public V lastValue() {
        return this.get(this.lastKey());
    }

    public void modify(final BinaryFunction<V> aFunc, final V anArg) {
        for (final Map.Entry<K, V> tmpEntry : this.entrySet()) {
            this.put(tmpEntry.getKey(), aFunc.invoke(tmpEntry.getValue(), anArg));
        }
    }

    public void modify(final ParameterFunction<V> aFunc, final int aParam) {
        for (final Map.Entry<K, V> tmpEntry : this.entrySet()) {
            this.put(tmpEntry.getKey(), aFunc.invoke(tmpEntry.getValue(), aParam));
        }
    }

    public void modify(final UnaryFunction<V> aFunc) {
        for (final Map.Entry<K, V> tmpEntry : this.entrySet()) {
            this.put(tmpEntry.getKey(), aFunc.invoke(tmpEntry.getValue()));
        }
    }

    public BasicSeries<K, V> name(final String aName) {
        this.setName(aName);
        return this;
    }

    public void setColour(final Color aPaint) {
        myColour = aPaint;
    }

    public void setName(final String aName) {
        myName = aName;
    }

}
