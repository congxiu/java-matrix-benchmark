/*
 * Copyright © 2006 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.series;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.ParameterFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.type.CalendarDateUnit;

public class CoordinationSet<K extends Comparable<K>, V extends Number> extends HashMap<String, BasicTimeSeries<K, V>> {

    private CalendarDateUnit myResolution = null;

    public CoordinationSet() {
        super();
    }

    public CoordinationSet(final CalendarDateUnit aResolution) {

        super();

        myResolution = aResolution;
    }

    public CoordinationSet(final Collection<BasicTimeSeries<K, V>> aTimeSeriesCollection) {

        super(aTimeSeriesCollection.size());

        for (final BasicTimeSeries<K, V> tmpBasicTimeSeries : aTimeSeriesCollection) {
            this.put(tmpBasicTimeSeries);
        }
    }

    public CoordinationSet(final Collection<BasicTimeSeries<K, V>> aTimeSeriesCollection, final CalendarDateUnit aResolution) {

        super(aTimeSeriesCollection.size());

        myResolution = aResolution;

        for (final BasicTimeSeries<K, V> tmpBasicTimeSeries : aTimeSeriesCollection) {
            this.put(tmpBasicTimeSeries);
        }
    }

    public CoordinationSet(final int someInitialCapacity) {
        super(someInitialCapacity);
    }

    public CoordinationSet(final int someInitialCapacity, final float someLoadFactor) {
        super(someInitialCapacity, someLoadFactor);
    }

    public CoordinationSet(final Map<? extends String, ? extends BasicTimeSeries<K, V>> someM) {
        super(someM);
    }

    public CoordinationSet<K, V> coordinate(final K aFirstKey, final K aLastKey) {

        final CoordinationSet<K, V> retVal = new CoordinationSet<K, V>();

        for (final BasicTimeSeries<K, V> tmpSeries : this.values()) {
            retVal.put(tmpSeries.reconstruct(aFirstKey, aLastKey, this.getResolution()));
        }

        return retVal;
    }

    /**
     * Most likely you'll want to use {@linkplain #prune()} instead. 
     */
    public CoordinationSet<K, V> expand() {
        return this.coordinate(this.getEarliestFirstKey(), this.getLatestLastKey());
    }

    public BasicTimeSeries<K, V> get(final BasicTimeSeries<K, V> aSeries) {
        return super.get(aSeries.getName());
    }

    public SortedSet<K> getAllContainedKeys() {

        final TreeSet<K> retVal = new TreeSet<K>();

        for (final BasicTimeSeries<K, V> tmpSeries : this.values()) {
            retVal.addAll(tmpSeries.keySet());
        }

        return retVal;
    }

    public K getEarliestFirstKey() {

        K retVal = null, tmpVal = null;

        for (final BasicTimeSeries<K, V> tmpSeries : this.values()) {

            tmpVal = tmpSeries.firstKey();

            if ((retVal == null) || (tmpVal.compareTo(retVal) < 0)) {
                retVal = tmpVal;
            }
        }

        return retVal;
    }

    public K getEarliestLastKey() {

        K retVal = null, tmpVal = null;

        for (final BasicTimeSeries<K, V> tmpSeries : this.values()) {

            tmpVal = tmpSeries.lastKey();

            if ((retVal == null) || (tmpVal.compareTo(retVal) < 0)) {
                retVal = tmpVal;
            }
        }

        return retVal;
    }

    public K getLatestFirstKey() {

        K retVal = null, tmpVal = null;

        for (final BasicTimeSeries<K, V> tmpSeries : this.values()) {

            tmpVal = tmpSeries.firstKey();

            if ((retVal == null) || (tmpVal.compareTo(retVal) > 0)) {
                retVal = tmpVal;
            }
        }

        return retVal;
    }

    public K getLatestLastKey() {

        K retVal = null, tmpVal = null;

        for (final BasicTimeSeries<K, V> tmpSeries : this.values()) {

            tmpVal = tmpSeries.lastKey();

            if ((retVal == null) || (tmpVal.compareTo(retVal) > 0)) {
                retVal = tmpVal;
            }
        }

        return retVal;
    }

    public CalendarDateUnit getResolution() {

        if (myResolution != null) {

            return myResolution;

        } else {

            CalendarDateUnit retVal = null, tmpVal = null;

            for (final BasicTimeSeries<K, V> tmpSeries : this.values()) {

                tmpVal = tmpSeries.getResolution();

                if ((retVal == null) || (tmpVal.compareTo(retVal) > 0)) {
                    retVal = tmpVal;
                }
            }

            return retVal;
        }
    }

    public void modify(final BinaryFunction<V> aFunc, final V anArg) {
        for (final BasicTimeSeries<K, V> tmpSeries : this.values()) {
            tmpSeries.modify(aFunc, anArg);
        }
    };

    public void modify(final ParameterFunction<V> aFunc, final int aParam) {
        for (final BasicTimeSeries<K, V> tmpSeries : this.values()) {
            tmpSeries.modify(aFunc, aParam);
        }
    };

    public void modify(final UnaryFunction<V> aFunc) {
        for (final BasicTimeSeries<K, V> tmpSeries : this.values()) {
            tmpSeries.modify(aFunc);
        }
    }

    public CoordinationSet<K, V> prune() {
        return this.coordinate(this.getLatestFirstKey(), this.getEarliestLastKey());
    }

    public BasicTimeSeries<K, V> put(final BasicTimeSeries<K, V> aSeries) {
        return super.put(aSeries.getName(), aSeries);
    }

}
