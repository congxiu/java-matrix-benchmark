/*
 * Copyright © 2004 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.array;

import static org.ojalgo.constant.PrimitiveMath.*;

import java.util.Arrays;

import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.ParameterFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.TypeUtils;

/**
 * A one- and/or arbitrary-dimensional array of {@linkplain org.ojalgo.scalar.ComplexNumber}.
 * 
 * @see PrimitiveArray
 * @author apete
 */
public class ComplexArray extends BasicArray<ComplexNumber> {

    protected static void exchange(final ComplexNumber[] aData, final int aFirstA, final int aFirstB, final int aStep, final int aCount) {

        int tmpIndexA = aFirstA;
        int tmpIndexB = aFirstB;

        ComplexNumber tmpVal;

        for (int i = 0; i < aCount; i++) {

            tmpVal = aData[tmpIndexA];
            aData[tmpIndexA] = aData[tmpIndexB];
            aData[tmpIndexB] = tmpVal;

            tmpIndexA += aStep;
            tmpIndexB += aStep;
        }
    }

    protected static void fill(final ComplexNumber[] aData, final int aFirst, final int aLimit, final int aStep, final ComplexNumber aNmbr) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aNmbr;
        }
    }

    protected static void invoke(final ComplexNumber[] aData, final int aFirst, final int aLimit, final int aStep, final AggregatorFunction<ComplexNumber> aVisitor) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aVisitor.invoke(aData[i]);
        }
    }

    protected static void invoke(final ComplexNumber[] aData, final int aFirst, final int aLimit, final int aStep, final ComplexNumber aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexNumber[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aFunc.invoke(aLeftArg, aRightArg[i]);
        }
    }

    protected static void invoke(final ComplexNumber[] aData, final int aFirst, final int aLimit, final int aStep, final ComplexNumber[] aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexNumber aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aFunc.invoke(aLeftArg[i], aRightArg);
        }
    }

    protected static void invoke(final ComplexNumber[] aData, final int aFirst, final int aLimit, final int aStep, final ComplexNumber[] aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexNumber[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aFunc.invoke(aLeftArg[i], aRightArg[i]);
        }
    }

    protected static void invoke(final ComplexNumber[] aData, final int aFirst, final int aLimit, final int aStep, final ComplexNumber[] anArg, final ParameterFunction<ComplexNumber> aFunc, final int aParam) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aFunc.invoke(anArg[i], aParam);
        }
    }

    protected static void invoke(final ComplexNumber[] aData, final int aFirst, final int aLimit, final int aStep, final ComplexNumber[] anArg, final UnaryFunction<ComplexNumber> aFunc) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aFunc.invoke(anArg[i]);
        }
    }

    private final ComplexNumber[] myData;

    protected ComplexArray(final ComplexNumber[] anArray) {

        super(anArray.length);

        myData = anArray;
    }

    protected ComplexArray(final int aLength) {

        super(aLength);

        myData = new ComplexNumber[aLength];

        this.fill(0, aLength, 1, ComplexNumber.ZERO);
    }

    public final double doubleValue(final int anInd) {
        return myData[anInd].doubleValue();
    }

    @Override
    public boolean equals(final Object anObj) {
        if (anObj instanceof ComplexArray) {
            return Arrays.equals(myData, ((ComplexArray) anObj).data());
        } else {
            return super.equals(anObj);
        }
    }

    @Override
    public final void exchange(final int aFirstA, final int aFirstB, final int aStep, final int aCount) {
        ComplexArray.exchange(myData, aFirstA, aFirstB, aStep, aCount);
    }

    public final void fill(final int aFirst, final int aLimit, final ComplexArray aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexArray aRightArg) {
        ComplexArray.invoke(myData, aFirst, aLimit, 1, aLeftArg.data(), aFunc, aRightArg.data());
    }

    public final void fill(final int aFirst, final int aLimit, final ComplexArray aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexNumber aRightArg) {
        ComplexArray.invoke(myData, aFirst, aLimit, 1, aLeftArg.data(), aFunc, aRightArg);
    }

    public final void fill(final int aFirst, final int aLimit, final ComplexNumber aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexArray aRightArg) {
        ComplexArray.invoke(myData, aFirst, aLimit, 1, aLeftArg, aFunc, aRightArg.data());
    }

    @Override
    public final void fill(final int aFirst, final int aLimit, final int aStep, final ComplexNumber aNmbr) {
        ComplexArray.fill(myData, aFirst, aLimit, aStep, aNmbr);
    }

    public final ComplexNumber get(final int anInd) {
        return myData[anInd];
    }

    @Override
    public int getIndexOfLargest(final int aFirst, final int aLimit, final int aStep) {

        int retVal = aFirst;
        double tmpLargest = ZERO;
        double tmpValue;

        for (int i = aFirst; i < aLimit; i += aStep) {
            tmpValue = myData[i].getModulus();
            if (tmpValue > tmpLargest) {
                tmpLargest = tmpValue;
                retVal = i;
            }
        }

        return retVal;
    }

    /**
     * @deprecated v29 Use {@link #get(int)} instead
     */
    @Deprecated
    public final ComplexNumber getNumber(final int anInd) {
        return this.get(anInd);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(myData);
    }

    @Override
    public final boolean isAbsolute(final int anInd) {
        return myData[anInd].isAbsolute();
    }

    @Override
    public final boolean isReal(final int anInd) {
        return TypeUtils.isZero(this.get(anInd).getImaginary());
    }

    @Override
    public final boolean isZero(final int anInd) {
        return TypeUtils.isZero(this.get(anInd).getModulus());
    }

    public final void modify(final int aFirst, final int aLimit, final int aStep, final BinaryFunction<ComplexNumber> aFunc, final ComplexArray aRightArg) {
        ComplexArray.invoke(myData, aFirst, aLimit, aStep, myData, aFunc, aRightArg.data());
    }

    @Override
    public final void modify(final int aFirst, final int aLimit, final int aStep, final BinaryFunction<ComplexNumber> aFunc, final ComplexNumber aRightArg) {
        ComplexArray.invoke(myData, aFirst, aLimit, aStep, myData, aFunc, aRightArg);
    }

    public final void modify(final int aFirst, final int aLimit, final int aStep, final ComplexArray aLeftArg, final BinaryFunction<ComplexNumber> aFunc) {
        ComplexArray.invoke(myData, aFirst, aLimit, aStep, aLeftArg.data(), aFunc, myData);
    }

    @Override
    public final void modify(final int aFirst, final int aLimit, final int aStep, final ComplexNumber aLeftArg, final BinaryFunction<ComplexNumber> aFunc) {
        ComplexArray.invoke(myData, aFirst, aLimit, aStep, aLeftArg, aFunc, myData);
    }

    @Override
    public final void modify(final int aFirst, final int aLimit, final int aStep, final ParameterFunction<ComplexNumber> aFunc, final int aParam) {
        ComplexArray.invoke(myData, aFirst, aLimit, aStep, myData, aFunc, aParam);
    }

    @Override
    public final void modify(final int aFirst, final int aLimit, final int aStep, final UnaryFunction<ComplexNumber> aFunc) {
        ComplexArray.invoke(myData, aFirst, aLimit, aStep, myData, aFunc);
    }

    /**
     * @see org.ojalgo.array.BasicArray#searchAscending(java.lang.Number)
     */
    @Override
    public final int searchAscending(final ComplexNumber aNmbr) {
        return Arrays.binarySearch(myData, aNmbr);
    }

    @Override
    public final void set(final int anInd, final ComplexNumber aNmbr) {
        myData[anInd] = aNmbr;
    }

    @Override
    public final void set(final int anInd, final double aNmbr) {
        myData[anInd] = new ComplexNumber(aNmbr);
    }

    @Override
    public final void sortAscending() {
        Arrays.sort(myData);
    }

    public final ComplexNumber toScalar(final int anInd) {
        return myData[anInd];
    }

    @Override
    public final void visit(final int aFirst, final int aLimit, final int aStep, final AggregatorFunction<ComplexNumber> aVisitor) {
        ComplexArray.invoke(myData, aFirst, aLimit, aStep, aVisitor);
    }

    protected final ComplexNumber[] copyOfData() {
        return ArrayUtils.copyOf(myData);
    }

    protected final ComplexNumber[] data() {
        return myData;
    }

}
