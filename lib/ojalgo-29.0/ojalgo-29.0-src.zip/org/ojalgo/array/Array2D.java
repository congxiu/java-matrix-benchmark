/*
 * Copyright © 2006 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.array;

import java.io.Serializable;
import java.math.BigDecimal;

import org.ojalgo.access.Access2D;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.ParameterFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;

/**
 * Array2D
 *
 * @author apete
 */
public final class Array2D<N extends Number> implements Access2D<N>, Serializable {

    public static Array2D<BigDecimal> makeBig(final BigDecimal[][] aRaw) {

        final int tmpRowDim = aRaw.length;
        final int tmpColDim = aRaw[0].length;

        final BigDecimal[] tmpArray = new BigDecimal[tmpRowDim * tmpColDim];

        for (int i = 0; i < tmpRowDim; i++) {
            for (int j = 0; j < tmpColDim; j++) {
                tmpArray[i + tmpRowDim * j] = aRaw[i][j];
            }
        }

        return new BigArray(tmpArray).asArray2D(tmpRowDim, tmpColDim);
    }

    public static Array2D<BigDecimal> makeBig(final int aRowDim, final int aColDim) {
        return new BigArray(aRowDim * aColDim).asArray2D(aRowDim, aColDim);
    }

    public static Array2D<ComplexNumber> makeComplex(final ComplexNumber[][] aRaw) {

        final int tmpRowDim = aRaw.length;
        final int tmpColDim = aRaw[0].length;

        final ComplexNumber[] tmpArray = new ComplexNumber[tmpRowDim * tmpColDim];

        for (int i = 0; i < tmpRowDim; i++) {
            for (int j = 0; j < tmpColDim; j++) {
                tmpArray[i + tmpRowDim * j] = aRaw[i][j];
            }
        }

        return new ComplexArray(tmpArray).asArray2D(tmpRowDim, tmpColDim);
    }

    public static Array2D<ComplexNumber> makeComplex(final int aRowDim, final int aColDim) {
        return new ComplexArray(aRowDim * aColDim).asArray2D(aRowDim, aColDim);
    }

    public static Array2D<Double> makePrimitive(final double[][] aRaw) {

        final int tmpRowDim = aRaw.length;
        final int tmpColDim = aRaw[0].length;

        final double[] tmpArray = new double[tmpRowDim * tmpColDim];

        for (int i = 0; i < tmpRowDim; i++) {
            for (int j = 0; j < tmpColDim; j++) {
                tmpArray[i + tmpRowDim * j] = aRaw[i][j];
            }
        }

        return new PrimitiveArray(tmpArray).asArray2D(tmpRowDim, tmpColDim);
    }

    public static Array2D<Double> makePrimitive(final int aRowDim, final int aColDim) {
        return new PrimitiveArray(aRowDim * aColDim).asArray2D(aRowDim, aColDim);
    }

    private final BasicArray<N> myDelegate;

    private final int myRowDim;
    private final int myColDim;

    @SuppressWarnings("unused")
    private Array2D() {
        this(null, 0, 0);
    }

    Array2D(final BasicArray<N> aDelegate, final int aRowDim, final int aColDim) {

        super();

        myDelegate = aDelegate;

        myRowDim = aRowDim;
        myColDim = aColDim;
    }

    /**
     * Flattens this two dimensional array to a one dimensional array.
     * The (internal/actual) array is not copied, it is just accessed through
     * a different adaptor.
     */
    public Array1D<N> asArray1D() {
        return myDelegate.asArray1D();
    }

    public double doubleValue(final int aRow, final int aCol) {
        return myDelegate.doubleValue(aRow + aCol * myRowDim);
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof Array2D) {
            final Array2D<N> tmpObj = (Array2D<N>) obj;
            return (myRowDim == tmpObj.getRowDim()) && (myColDim == tmpObj.getColDim()) && myDelegate.equals(tmpObj.getDelegate());
        } else {
            return super.equals(obj);
        }
    }

    public void exchangeColumns(final int aColA, final int aColB) {
        myDelegate.exchange(aColA * myRowDim, aColB * myRowDim, 1, myRowDim);
    }

    public void exchangeRows(final int aRowA, final int aRowB) {
        myDelegate.exchange(aRowA, aRowB, myRowDim, myColDim);
    }

    public void fillAll(final N aNmbr) {
        myDelegate.fill(0, myDelegate.length, 1, aNmbr);
    }

    public void fillColumn(final int aRow, final int aCol, final N aNmbr) {
        myDelegate.fill(aRow + aCol * myRowDim, myRowDim + aCol * myRowDim, 1, aNmbr);
    }

    public void fillDiagonal(final int aRow, final int aCol, final N aNmbr) {

        final int tmpCount = Math.min(myRowDim - aRow, myColDim - aCol);

        myDelegate.fill(aRow + aCol * myRowDim, aRow + tmpCount + (aCol + tmpCount) * myRowDim, 1 + myRowDim, aNmbr);
    }

    @SuppressWarnings("unchecked")
    public void fillMatching(final Array2D<N> aLeftArg, final BinaryFunction<N> aFunc, final Array2D<N> aRightArg) {
        final BasicArray<N> tmpLeftDelegate = aLeftArg.getDelegate();
        final BasicArray<N> tmpRightDelegate = aRightArg.getDelegate();
        if ((myDelegate instanceof PrimitiveArray) && (tmpLeftDelegate instanceof PrimitiveArray) && (tmpRightDelegate instanceof PrimitiveArray)) {
            ((PrimitiveArray) myDelegate).fill(0, myDelegate.length, (PrimitiveArray) tmpLeftDelegate, (BinaryFunction<Double>) aFunc, (PrimitiveArray) tmpRightDelegate);
        } else if ((myDelegate instanceof ComplexArray) && (tmpLeftDelegate instanceof ComplexArray) && (tmpRightDelegate instanceof ComplexArray)) {
            ((ComplexArray) myDelegate).fill(0, myDelegate.length, (ComplexArray) tmpLeftDelegate, (BinaryFunction<ComplexNumber>) aFunc, (ComplexArray) tmpRightDelegate);
        } else if ((myDelegate instanceof BigArray) && (tmpLeftDelegate instanceof BigArray) && (tmpRightDelegate instanceof BigArray)) {
            ((BigArray) myDelegate).fill(0, myDelegate.length, (BigArray) tmpLeftDelegate, (BinaryFunction<BigDecimal>) aFunc, (BigArray) tmpRightDelegate);
        }
    }

    public void fillRow(final int aRow, final int aCol, final N aNmbr) {
        myDelegate.fill(aRow + aCol * myRowDim, aRow + myColDim * myRowDim, myRowDim, aNmbr);
    }

    public N get(final int aRow, final int aCol) {
        return myDelegate.get(aRow + aCol * myRowDim);
    }

    public int getColDim() {
        return myColDim;
    }

    public int getIndexOfLargestInColumn(final int aRow, final int aCol) {
        return myDelegate.getIndexOfLargest(aRow + aCol * myRowDim, myRowDim + aCol * myRowDim, 1) % myRowDim;
    }

    public int getIndexOfLargestInRow(final int aRow, final int aCol) {
        return myDelegate.getIndexOfLargest(aRow + aCol * myRowDim, aRow + myColDim * myRowDim, myRowDim) / myRowDim;
    }

    public int getMaxDim() {
        return Math.max(myRowDim, myColDim);
    }

    public int getMinDim() {
        return Math.min(myRowDim, myColDim);
    }

    /**
     * @deprecated v29 Use {@link #get(int,int)} instead
     */
    @Deprecated
    public N getNumber(final int aRow, final int aCol) {
        return this.get(aRow, aCol);
    }

    public int getRowDim() {
        return myRowDim;
    }

    @Override
    public int hashCode() {
        return myRowDim * myColDim * myDelegate.hashCode();
    }

    /**
     * @see Scalar#isAbsolute()
     */
    public boolean isAbsolute(final int aRow, final int aCol) {
        return myDelegate.isAbsolute(aRow + aCol * myRowDim);
    }

    /**
     * @see Scalar#isReal()
     */
    public boolean isReal(final int aRow, final int aCol) {
        return myDelegate.isReal(aRow + aCol * myRowDim);
    }

    /**
     * @see Scalar#isZero()
     */
    public boolean isZero(final int aRow, final int aCol) {
        return myDelegate.isZero(aRow + aCol * myRowDim);
    }

    public void modifyAll(final BinaryFunction<N> aFunc, final N aNmbr) {
        myDelegate.modify(0, myDelegate.length, 1, aFunc, aNmbr);
    }

    public void modifyAll(final N aNmbr, final BinaryFunction<N> aFunc) {
        myDelegate.modify(0, myDelegate.length, 1, aNmbr, aFunc);
    }

    public void modifyAll(final ParameterFunction<N> aFunc, final int aParam) {
        myDelegate.modify(0, myDelegate.length, 1, aFunc, aParam);
    }

    public void modifyAll(final UnaryFunction<N> aFunc) {
        myDelegate.modify(0, myDelegate.length, 1, aFunc);
    }

    public void modifyColumn(final int aRow, final int aCol, final BinaryFunction<N> aFunc, final N aNmbr) {
        myDelegate.modify(aRow + aCol * myRowDim, myRowDim + aCol * myRowDim, 1, aFunc, aNmbr);
    }

    public void modifyColumn(final int aRow, final int aCol, final N aNmbr, final BinaryFunction<N> aFunc) {
        myDelegate.modify(aRow + aCol * myRowDim, myRowDim + aCol * myRowDim, 1, aNmbr, aFunc);
    }

    public void modifyColumn(final int aRow, final int aCol, final ParameterFunction<N> aFunc, final int aParam) {
        myDelegate.modify(aRow + aCol * myRowDim, myRowDim + aCol * myRowDim, 1, aFunc, aParam);
    }

    public void modifyColumn(final int aRow, final int aCol, final UnaryFunction<N> aFunc) {
        myDelegate.modify(aRow + aCol * myRowDim, myRowDim + aCol * myRowDim, 1, aFunc);
    }

    public void modifyDiagonal(final int aRow, final int aCol, final BinaryFunction<N> aFunc, final N aNmbr) {

        final int tmpCount = Math.min(myRowDim - aRow, myColDim - aCol);

        myDelegate.modify(aRow + aCol * myRowDim, aRow + tmpCount + (aCol + tmpCount) * myRowDim, 1 + myRowDim, aFunc, aNmbr);
    }

    public void modifyDiagonal(final int aRow, final int aCol, final N aNmbr, final BinaryFunction<N> aFunc) {

        final int tmpCount = Math.min(myRowDim - aRow, myColDim - aCol);

        myDelegate.modify(aRow + aCol * myRowDim, aRow + tmpCount + (aCol + tmpCount) * myRowDim, 1 + myRowDim, aNmbr, aFunc);
    }

    public void modifyDiagonal(final int aRow, final int aCol, final ParameterFunction<N> aFunc, final int aParam) {

        final int tmpCount = Math.min(myRowDim - aRow, myColDim - aCol);

        myDelegate.modify(aRow + aCol * myRowDim, aRow + tmpCount + (aCol + tmpCount) * myRowDim, 1 + myRowDim, aFunc, aParam);
    }

    public void modifyDiagonal(final int aRow, final int aCol, final UnaryFunction<N> aFunc) {

        final int tmpCount = Math.min(myRowDim - aRow, myColDim - aCol);

        myDelegate.modify(aRow + aCol * myRowDim, aRow + tmpCount + (aCol + tmpCount) * myRowDim, 1 + myRowDim, aFunc);
    }

    @SuppressWarnings("unchecked")
    public void modifyMatching(final Array2D<N> anArray, final BinaryFunction<N> aFunc) {
        if (myDelegate instanceof PrimitiveArray) {
            PrimitiveArray.invoke(((PrimitiveArray) myDelegate).data(), 0, myDelegate.length, 1, (((PrimitiveArray) anArray.getDelegate())).data(), ((BinaryFunction<Double>) aFunc), ((PrimitiveArray) myDelegate).data());
        } else if (myDelegate instanceof ComplexArray) {
            ComplexArray.invoke(((ComplexArray) myDelegate).data(), 0, myDelegate.length, 1, (((ComplexArray) anArray.getDelegate())).data(), ((BinaryFunction<ComplexNumber>) aFunc), ((ComplexArray) myDelegate).data());
        } else if (myDelegate instanceof BigArray) {
            BigArray.invoke(((BigArray) myDelegate).data(), 0, myDelegate.length, 1, (((BigArray) anArray.getDelegate())).data(), ((BinaryFunction<BigDecimal>) aFunc), ((BigArray) myDelegate).data());
        }
    }

    @SuppressWarnings("unchecked")
    public void modifyMatching(final BinaryFunction<N> aFunc, final Array2D<N> anArray) {
        if (myDelegate instanceof PrimitiveArray) {
            PrimitiveArray.invoke(((PrimitiveArray) myDelegate).data(), 0, myDelegate.length, 1, ((PrimitiveArray) myDelegate).data(), ((BinaryFunction<Double>) aFunc), (((PrimitiveArray) anArray.getDelegate())).data());
        } else if (myDelegate instanceof ComplexArray) {
            ComplexArray.invoke(((ComplexArray) myDelegate).data(), 0, myDelegate.length, 1, ((ComplexArray) myDelegate).data(), ((BinaryFunction<ComplexNumber>) aFunc), (((ComplexArray) anArray.getDelegate())).data());
        } else if (myDelegate instanceof BigArray) {
            BigArray.invoke(((BigArray) myDelegate).data(), 0, myDelegate.length, 1, ((BigArray) myDelegate).data(), ((BinaryFunction<BigDecimal>) aFunc), (((BigArray) anArray.getDelegate())).data());
        }
    }

    public void modifyRow(final int aRow, final int aCol, final BinaryFunction<N> aFunc, final N aNmbr) {
        myDelegate.modify(aRow + aCol * myRowDim, aRow + myColDim * myRowDim, myRowDim, aFunc, aNmbr);
    }

    public void modifyRow(final int aRow, final int aCol, final N aNmbr, final BinaryFunction<N> aFunc) {
        myDelegate.modify(aRow + aCol * myRowDim, aRow + myColDim * myRowDim, myRowDim, aNmbr, aFunc);
    }

    public void modifyRow(final int aRow, final int aCol, final ParameterFunction<N> aFunc, final int aParam) {
        myDelegate.modify(aRow + aCol * myRowDim, aRow + myColDim * myRowDim, myRowDim, aFunc, aParam);
    }

    public void modifyRow(final int aRow, final int aCol, final UnaryFunction<N> aFunc) {
        myDelegate.modify(aRow + aCol * myRowDim, aRow + myColDim * myRowDim, myRowDim, aFunc);
    }

    public void set(final int aRow, final int aCol, final double aNmbr) {
        myDelegate.set(aRow + aCol * myRowDim, aNmbr);
    }

    public void set(final int aRow, final int aCol, final N aNmbr) {
        myDelegate.set(aRow + aCol * myRowDim, aNmbr);
    }

    public int size() {
        return myDelegate.length;
    }

    public Array1D<N> sliceColumn(final int aRow, final int aCol) {
        return new Array1D<N>(myDelegate, aRow + aCol * myRowDim, myRowDim + aCol * myRowDim, 1);
    }

    public Array1D<N> sliceDiagonal(final int aRow, final int aCol) {

        final int tmpCount = Math.min(myRowDim - aRow, myColDim - aCol);

        return new Array1D<N>(myDelegate, aRow + aCol * myRowDim, aRow + tmpCount + (aCol + tmpCount) * myRowDim, 1 + myRowDim);
    }

    public Array1D<N> sliceRow(final int aRow, final int aCol) {
        return new Array1D<N>(myDelegate, aRow + aCol * myRowDim, aRow + myColDim * myRowDim, myRowDim);
    }

    /**
     * @return An array of arrays of doubles
     */
    public double[][] toRawCopy() {
        return ArrayUtils.toRawCopyOf(this);
    }

    public Scalar<N> toScalar(final int aRow, final int aCol) {
        return myDelegate.toScalar(aRow + aCol * myRowDim);
    }

    @Override
    public String toString() {
        return myDelegate.toString();
    }

    public void visitAll(final AggregatorFunction<N> aVisitor) {
        myDelegate.visit(0, myDelegate.length, 1, aVisitor);
    }

    public void visitColumn(final int aRow, final int aCol, final AggregatorFunction<N> aVisitor) {
        myDelegate.visit(aRow + aCol * myRowDim, myRowDim + aCol * myRowDim, 1, aVisitor);
    }

    public void visitDiagonal(final int aRow, final int aCol, final AggregatorFunction<N> aVisitor) {

        final int tmpCount = Math.min(myRowDim - aRow, myColDim - aCol);

        myDelegate.visit(aRow + aCol * myRowDim, aRow + tmpCount + (aCol + tmpCount) * myRowDim, 1 + myRowDim, aVisitor);
    }

    public void visitRow(final int aRow, final int aCol, final AggregatorFunction<N> aVisitor) {
        myDelegate.visit(aRow + aCol * myRowDim, aRow + myColDim * myRowDim, myRowDim, aVisitor);
    }

    BasicArray<N> getDelegate() {
        return myDelegate;
    }

}
