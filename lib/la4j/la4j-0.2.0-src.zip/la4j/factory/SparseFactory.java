/*
 * Copyright 2011, Vladimir Kostyukov
 * 
 * This file is part of la4j project (http://la4j.googlecode.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 *      
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package la4j.factory;

import java.util.Random;

import la4j.matrix.Matrix;
import la4j.matrix.sparse.SparseMatrix;
import la4j.vector.Vector;
import la4j.vector.sparse.SparseVector;

public class SparseFactory implements Factory {

	@Override
	public Matrix createMatrix() {
		return new SparseMatrix();
	}

	@Override
	public Matrix createMatrix(int rows, int columns) {
		return new SparseMatrix(rows, columns);
	}

	@Override
	public Matrix createMatrix(double[][] array) {
		return new SparseMatrix(array);
	}

	@Override
	public Matrix createMatrixWithCopy(double[][] array) {
		return new SparseMatrix(array);
	}

	@Override
	public Matrix createRandomMatrix(int rows, int columns) {
		
		int nonzero = (rows * columns) / 4; // 25%
		SparseMatrix result = new SparseMatrix(rows, columns, nonzero);

		Random rnd = new Random();
		for (int i = 0; i < nonzero; i++) {
			result.set(rnd.nextInt(rows), rnd.nextInt(columns), rnd.nextDouble());
		}
		
		return result;
	}

	@Override
	public Matrix createRandomSymmetricMatrix(int rows, int columns) {

		int nonzero = (rows * columns) / 8; // 12,5%
		
		SparseMatrix result = new SparseMatrix(rows, columns, nonzero);

		Random rnd = new Random();
		for (int i = 0; i < nonzero; i++) {

			int row = rnd.nextInt(rows);
			int column = rnd.nextInt(columns);
			double value = rnd.nextDouble();
			
			result.set(row, column, value);
			result.set(column, rows, value);
		}
		
		return result;
	}

	@Override
	public Matrix createSquareMatrix(int size) {
		return createMatrix(size, size);
	}

	@Override
	public Matrix createIdentityMatrix(int size) {

		SparseMatrix result = new SparseMatrix(size, size, size);
		
		for (int i = 0; i < size; i++) {
			result.set(i, i, 1.0);
		}
		
		return result;
	}

	@Override
	public Vector createVector() {
		return new SparseVector();
	}

	@Override
	public Vector createVector(int length) {
		return new SparseVector(length);
	}

	@Override
	public Vector createVector(double[] array) {
		return new SparseVector(array);
	}

	@Override
	public Vector createVectorWithCopy(double[] array) {
		return new SparseVector(array);
	}

	@Override
	public Vector createRandomVector(int length) {
		
		int nonzero = length / 4; // 25%
		SparseVector result = new SparseVector(length, nonzero);

		Random rnd = new Random();
		for (int i = 0; i < nonzero; i++) {
			result.set(rnd.nextInt(length), rnd.nextDouble());
		}
		
		return result;		
	}
}
