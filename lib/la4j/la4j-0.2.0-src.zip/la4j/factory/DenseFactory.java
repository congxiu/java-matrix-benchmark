/*
 * Copyright 2011, Vladimir Kostyukov
 * 
 * This file is part of la4j project (http://la4j.googlecode.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 *      
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package la4j.factory;

import java.util.Random;

import la4j.matrix.Matrix;
import la4j.matrix.dense.DenseMatrix;
import la4j.vector.Vector;
import la4j.vector.dense.DenseVector;

public class DenseFactory implements Factory {

	@Override
	public Matrix createMatrix() {
		return new DenseMatrix();
	}
	
	@Override
	public Matrix createMatrix(int rows, int columns) {
		return new DenseMatrix(rows, columns);
	}
	
	@Override
	public Matrix createMatrix(double array[][]) {
		return new DenseMatrix(array);
	}

	@Override
	public Matrix createMatrixWithCopy(double array[][]) {
		
		int rows = array.length;
		int columns = array[0].length;

		double result[][] = new double[rows][columns];

		for (int i = 0; i < rows; i++) {
			System.arraycopy(array[i], 0, result[i], 0, columns);
		}

		return new DenseMatrix(result);
	}

	@Override
	public Matrix createRandomMatrix(int rows, int columns) {
		
		double result[][] = new double[rows][columns];
		
		Random gen = new Random();

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				result[i][j] = gen.nextDouble();  
			}
		}

		return new DenseMatrix(result);
	}
	
	@Override
	public Matrix createRandomSymmetricMatrix(int rows, int columns) {
		
		double result[][] = new double[rows][columns];
		
		Random gen = new Random();
		
		for (int i = 0; i < rows; i++) {
			for (int j = i; j < columns; j++) {
				double value = gen.nextDouble(); 
				result[i][j] = value;
				result[j][i] = value;
			}		
		}
		
		return new DenseMatrix(result);
	}

	@Override
	public Matrix createSquareMatrix(int size) {
		return new DenseMatrix(size, size);
	}

	@Override
	public Matrix createIdentityMatrix(int size) {
		
		double result[][] = new double[size][size];
		
		for (int i = 0; i < size; i++) {
			result[i][i] = (double) 1.0;
		}

		return new DenseMatrix(result);
	}

	@Override
	public Vector createVector() {
		return new DenseVector();
	}

	@Override
	public Vector createVector(int length) {
		return new DenseVector(length);
	}

	@Override
	public Vector createVector(double array[]) {
		return new DenseVector(array);
	}

	@Override
	public Vector createVectorWithCopy(double array[]) {
		double arraycopy[] = new double[array.length];
		System.arraycopy(array, 0, arraycopy, 0, array.length);
		return new DenseVector(arraycopy);
	}

	@Override
	public Vector createRandomVector(int length) {

		double result[] = new double[length];
		
		Random gen = new Random();
		for (int i = 0; i < length; i++) {
			result[i] = gen.nextDouble();
		}

		return new DenseVector(result);
	}
}
