/*
 * Copyright 2011, Vladimir Kostyukov
 * 
 * This file is part of la4j project (http://la4j.googlecode.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 *      
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package la4j.linear;

import la4j.err.LinearSystemException;
import la4j.factory.Factory;
import la4j.matrix.Matrix;
import la4j.vector.Vector;

public class ZeidelSolver implements LinearSystemSolver {

	private final static int MAX_ITERATIONS = 100000;

	@Override
	public Vector solve(LinearSystem linearSystem, Factory factory) throws LinearSystemException {

		Matrix a = linearSystem.coefficientsMatrix().clone();
		Vector b = linearSystem.rightHandVector();
		
		if (!isMethodCanBeUsed(a)) throw new LinearSystemException("Zeidel method can not be used");
		
		for (int i = 0; i < a.rows(); i++) {
			for (int j = 0; j < a.columns(); j++) {
				if (i != j) a.set(i, j, a.get(i, j) / a.get(i, i));
			}
		}
		
		Vector current = factory.createVector(linearSystem.variables());
		
		int iteration = 0;
		while (iteration < MAX_ITERATIONS && !linearSystem.isSolution(current)) {

			for (int i = 0; i < a.rows(); i++) {
				
				double summand = b.get(i) / a.get(i, i);
				for (int j = 0; j < a.columns(); j++) {
					if (i != j) summand -= a.get(i, j) * current.get(j);
				}
				
				current.set(i, summand);
			}
			
			iteration++;
		}

		if (iteration == MAX_ITERATIONS) throw new LinearSystemException("method Zeidel can not be used");

		return current;
	}
	
	private boolean isMethodCanBeUsed(Matrix matrix) {
		
		for (int i = 0; i < matrix.rows(); i++) {
			
			double sum = 0;
			for (int j = 0; j < matrix.columns(); j++) {
				if (i != j) sum += Math.abs(matrix.get(i, j));
			}

			if (sum > Math.abs(matrix.get(i, i)) - EPS) return false;
		}

		return true;
	}
}
