/*
 * Copyright 2011, Vladimir Kostyukov
 * 
 * This file is part of la4j project (http://la4j.googlecode.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 *      
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package la4j.linear;

import la4j.err.LinearSystemException;
import la4j.factory.Factory;
import la4j.vector.Vector;

/**
 * Linear System Solver interface;
 * 
 * This class implements Strategy design pattern;
 * 
 */
public interface LinearSystemSolver {
	
	public static final double EPS = 10e-7;
	
	/**
	 * Solve the linear system with factory;
	 * 
	 * @param linearSystem
	 * @return
	 * @throws LinearSystemException
	 */
	public Vector solve(LinearSystem linearSystem, Factory factory) throws LinearSystemException;
}
