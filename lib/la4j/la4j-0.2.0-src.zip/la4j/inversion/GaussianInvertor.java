/*
 * Copyright 2011, Vladimir Kostyukov
 * 
 * This file is part of la4j project (http://la4j.googlecode.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 *      
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package la4j.inversion;

import la4j.err.LinearSystemException;
import la4j.err.MatrixInversionException;
import la4j.factory.Factory;
import la4j.linear.GaussianSolver;
import la4j.linear.LinearSystem;
import la4j.linear.LinearSystemSolver;
import la4j.matrix.Matrix;
import la4j.vector.Vector;

public class GaussianInvertor implements MatrixInvertor {

	@Override
	public Matrix inverse(Matrix matrix, Factory factory) throws MatrixInversionException {

		if (matrix.rows() != matrix.columns()) throw new MatrixInversionException();
		
		Matrix result = factory.createMatrix(matrix.rows(), matrix.columns());
		LinearSystemSolver solver = new GaussianSolver();
		
		try {
		
			for (int i = 0; i < matrix.rows(); i++) {
				
				Vector b = factory.createVector(matrix.rows());
				b.set(i, 1.0);
				
				LinearSystem system = new LinearSystem(matrix, b);
				Vector x = system.solve(solver, factory);
				
				result.setColumn(i, x);
			}
		
		} catch (LinearSystemException ex) {
			throw new MatrixInversionException(ex.getMessage());
		}
		
		return result;
	}
}
