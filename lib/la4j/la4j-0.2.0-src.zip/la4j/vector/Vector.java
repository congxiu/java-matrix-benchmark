/*
 * Copyright 2011, Vladimir Kostyukov
 * 
 * This file is part of la4j project (http://la4j.googlecode.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 *      
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package la4j.vector;

import java.io.Externalizable;

import la4j.err.VectorException;
import la4j.factory.Factory;
import la4j.io.IOConstants;

public interface Vector extends Externalizable, Cloneable, IOConstants {
	
	public static final double EPS = 10e-7;

	/**
	 * Get i-th element of vector;
	 * 
	 * @param i element number
	 * @return the i-th element
	 */
	public double get(int i);

	/**
	 * 
	 * @param i
	 * @param value
	 */
	public void set(int i, double value);

	/**
	 * 
	 * @return
	 */
	public int length();
	
	/**
	 * 
	 * @return
	 */
	public int nonzero();

	/**
	 * 
	 * @return
	 */
	public double[] toArray();

	/**
	 * 
	 * @return
	 */
	public double[] toArrayCopy();

	/**
	 * 
	 * @param length
	 */
	public void resize(int length);

	/**
	 * 
	 * @param d
	 * @return
	 */
	public Vector add(double value);
	
	/**
	 * 
	 * @param value
	 * @param factory
	 * @return
	 */
	public Vector add(double value, Factory factory);

	/**
	 * 
	 * @param v
	 * @return
	 * @throws VectorException
	 */
	public Vector add(Vector vector) throws VectorException;
	
	/**
	 * 
	 * @param vector
	 * @param factory
	 * @return
	 * @throws VectorException
	 */
	public Vector add(Vector vector, Factory factory) throws VectorException;

	/**
	 * 
	 * @param d
	 * @return
	 */
	public Vector multiply(double value);
	
	/**
	 * 
	 * @param value
	 * @param factory
	 * @return
	 */
	public Vector multiply(double value, Factory factory);
	
	/**
	 * 
	 * @param v
	 * @return
	 * @throws VectorException
	 */
	public Vector multiply(Vector vector) throws VectorException;
	
	/**
	 * 
	 * @param vector
	 * @param factory
	 * @return
	 * @throws VectorException
	 */
	public Vector multiply(Vector vector, Factory factory) throws VectorException;

	/**
	 * 
	 * @param d
	 * @return
	 */
	public Vector subtract(double value);
	
	/**
	 * 
	 * @param value
	 * @param factory
	 * @return
	 */
	public Vector subtract(double value, Factory factory);

	/**
	 * 
	 * @param v
	 * @return
	 * @throws VectorException
	 */
	public Vector subtract(Vector vector) throws VectorException;
	
	/**
	 * 
	 * @param vector
	 * @param factory
	 * @return
	 * @throws VectorException
	 */
	public Vector subtract(Vector vector, Factory factory) throws VectorException;

	/**
	 * 
	 * @param d
	 * @return
	 */
	public Vector div(double value);
	
	/**
	 * 
	 * @param value
	 * @param factory
	 * @return
	 */
	public Vector div(double value, Factory factory);

	/**
	 * 
	 * @param v
	 * @return
	 * @throws VectorException
	 */
	public double scalarProduct(Vector vector) throws VectorException;

	/**
	 * 
	 * @return
	 */
	public double norm();
	
	/**
	 * 
	 * @return
	 */
	public Vector asNormalized();
	
	/**
	 * 
	 * @param factory
	 * @return
	 */
	public Vector asNormailzed(Factory factory);

	/**
	 * 
	 * @param i
	 * @param j
	 */
	public void swap(int i, int j);

	/**
	 * 
	 * @return
	 */
	public Vector blank();
	
	/**
	 * 
	 * @param factory
	 * @return
	 */
	public Vector blank(Factory factory);
	
	/**
	 * 
	 * @return
	 */
	public Vector copy();
	
	/**
	 * 
	 * @param factory
	 * @return
	 */
	public Vector copy(Factory factory);
	
	/**
	 * 
	 * @return
	 */
	public String toString();

	/**
	 * 
	 * @return
	 */
	public Vector clone();
}	

