/*
 * Copyright 2011, Vladimir Kostyukov
 * 
 * This file is part of la4j project (http://la4j.googlecode.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 *      
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package la4j.vector;

import la4j.err.VectorException;
import la4j.factory.Factory;

public abstract class AbstractVector implements Vector {
	
	protected int length;

	protected Factory factory;
	
	public AbstractVector(Factory factory) {
		this.factory = factory;
	}
	
	@Override
	public int length() {
		return length;
	}

	@Override
	public Vector add(double value) {
		return add(value, factory);
	}
	
	@Override
	public Vector add(double value, Factory factory) {
		
		if (factory == null) throw new NullPointerException();
		
		Vector result = factory.createVector(length);
		
		for (int i = 0; i < length; i++) {
			result.set(i, get(i) + value);
		}

		return result;
	}

	@Override
	public Vector add(Vector vector) throws VectorException {
		return add(vector, factory);
	}
	
	@Override
	public Vector add(Vector vector, Factory factory) throws VectorException  {
		
		if (vector == null || factory == null) throw new NullPointerException();

		if (length != vector.length()) {
			throw new VectorException("can't sum this vectors: wrong dimmentions");
		}
		
		Vector result = factory.createVector(length);
		
		for (int i = 0; i < length; i++) {
			result.set(i, get(i) + vector.get(i));
		}

		return result;
	}

	@Override
	public Vector multiply(double value) {
		return multiply(value, factory);
	}
	
	@Override
	public Vector multiply(double value, Factory factory) {
		
		if (factory == null) throw new NullPointerException();
		
		Vector result = factory.createVector(length);
		
		for (int i = 0; i < length; i++) {
			result.set(i, get(i) * value);
		}

		return result;		
	}

	@Override
	public Vector multiply(Vector vector) throws VectorException {
		return multiply(vector, factory);
	}
	
	@Override
	public Vector multiply(Vector vector, Factory factory) throws VectorException {
		
		if (vector == null | factory == null) throw new NullPointerException();
		
		if (length != vector.length()) {
			throw new VectorException("can't sum this vectors: wrong dimmentions");
		}
		
		Vector result = factory.createVector(length);
		
		for (int i = 0; i < length; i++) {
			result.set(i, get(i) * vector.get(i));
		}

		return result;
	}

	@Override
	public Vector subtract(double value) {
		return subtract(value, factory);
	}
	
	@Override
	public Vector subtract(double value, Factory factory) {
		return add(-value, factory);
	}

	@Override
	public Vector subtract(Vector vector) throws VectorException {
		return subtract(vector, factory);
	}
	
	@Override
	public Vector subtract(Vector vector, Factory factory) throws VectorException {
		return add(vector.multiply(-1.0), factory);
	}

	@Override
	public Vector div(double value) {
		return div(value, factory);
	}
	
	@Override
	public Vector div(double value, Factory factory) {
		return multiply(1.0 / value, factory);
	}
	
	@Override
	public double scalarProduct(Vector vector) throws VectorException {
		
		if (vector == null) throw new NullPointerException();
		
		if (length != vector.length()) {
			throw new VectorException("can not calc scalar product of this vectors: wrong dimmentions");
		}
		
		double result = 0.0;
		for (int i = 0; i < length; i++) {
			result += get(i) * vector.get(i);
		}

		return result;
	}
	
	@Override
	public double norm() {
		try {
			return Math.sqrt(scalarProduct(this));
		} catch (VectorException ex) {
			return 0.0;
		}
	}

	@Override
	public Vector asNormalized() {
		return asNormailzed(factory);
	}
	
	@Override
	public Vector asNormailzed(Factory factory) {
		return div(norm(), factory);
	}
	
	@Override
	public Vector blank() {
		return blank(factory);
	}
	
	@Override
	public Vector blank(Factory factory) {
		return factory.createVector(length);
	}
	
	@Override
	public Vector copy() {
		return copy(factory);
	}
	
	@Override
	public Vector copy(Factory factory) {
		
		if (factory == null) throw new NullPointerException();
		
		Vector result = factory.createVector(length);
		for (int i = 0; i < length; i++) {
			result.set(i, get(i));
		}
		
		return result;
	}

	@Override
	public int hashCode() {

		int result = 17;
		
		for (int i = 0; i < length; i++) {
			long value = (long) get(i);
			result = 37 * result + (int) (value ^ (value >>> 32));
		}
		
		return result;
	}

	@Override
	public boolean equals(Object object) {
		
		if (this == object) return true;
		if (object == null) return false;
		if (!(object instanceof Vector)) return false;
		
		Vector vector = (Vector) object;
		
		if (length != vector.length()) return false;
		
		boolean result = true;
		for (int i = 0; result && i < length; i++) {
			result = result & (Math.abs(get(i) - vector.get(i)) < EPS);
		}

		return result;
	}

	@Override
	public String toString() {
		
		StringBuilder sb = new StringBuilder();

		sb.append("[");
		for (int i = 0; i < length; i++) {
			sb.append(String.format("%6.3f", get(i)));
			sb.append((i < length - 1 ? ", " : ""));
		}
		sb.append("]");

		return sb.toString();
	}

	@Override
	public Vector clone() {
		try {
			return (Vector) super.clone();
		} catch (CloneNotSupportedException ex) {
			throw new InternalError();
		}
	}
	
}
