/*
 * Copyright 2011, Vladimir Kostyukov
 * 
 * This file is part of la4j project (http://la4j.googlecode.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 *      
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package la4j.io;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Locale;

import la4j.matrix.Matrix;
import la4j.matrix.dense.DenseMatrix;
import la4j.matrix.sparse.SparseMatrix;
import la4j.vector.Vector;
import la4j.vector.dense.DenseVector;
import la4j.vector.sparse.SparseVector;

public class MMOutputStream extends OutputStream implements ObjectOutput, IOConstants {

	private static final int MINIMIN_SIZE = 32;
	
	private String buffer[];
	private int length;
	
	private BufferedWriter out;
	
	public MMOutputStream(OutputStream out) {
		this.buffer = new String[MINIMIN_SIZE];
		this.length = 0;
		this.out = new BufferedWriter(new OutputStreamWriter(out));
	}
	
	@Override
	public void writeByte(int v) throws IOException {
		
		switch (v) {
		case HEADER_MARKER:
			writeHeader();
			break;

		case META_MARKER:
			writeMeta();
			break;
			
		case ELEMENT_MARKER:
			writeElement();
			break;
		}
	}
	
	@Override
	public void writeInt(int v) throws IOException {
		put(String.valueOf(v));		
	}

	@Override
	public void writeLong(long v) throws IOException {
		put(String.valueOf(v));
	}

	@Override
	public void writeFloat(float v) throws IOException {
		put(String.format(Locale.US, "%.6f", v));
	}

	@Override
	public void writeDouble(double v) throws IOException {
		put(String.format(Locale.US, "%.12f", v));
	}

	@Override
	public void writeObject(Object obj) throws IOException {

		length = 0;
		
		if (obj instanceof Vector) {
			writeVector((Vector) obj);
		} else if (obj instanceof Matrix) {
			writeMatrix((Matrix) obj);
		} else {
			throw new RuntimeException();
		}
	}

	@Override
	public void write(int b) throws IOException {
		out.write(b);
	}
	
	@Override
	public void flush() throws IOException {
		out.flush();
	}

	@Override
	public void close() throws IOException {
		out.close();
	}

	public void writeVector(Vector vector) throws IOException {
		
		put(VECTOR_ID);
		
		if (vector instanceof SparseVector) {
			put(SPARSE_HEADER);
		} else if (vector instanceof DenseVector) {
			put(DENSE_HEADER);
		} else {
			throw new RuntimeException();
		}
		
		writeHeader();
		vector.writeExternal(this);
		flush();
	}
	
	public void writeMatrix(Matrix matrix) throws IOException {
		
		put(MATRIX_ID);
		
		if (matrix instanceof SparseMatrix) {
			put(SPARSE_HEADER);
		} else if (matrix instanceof DenseMatrix) {
			put(DENSE_HEADER);
		} else {
			throw new RuntimeException();
		}
		
		writeHeader();
		matrix.writeExternal(this);
		flush();
	}
	
	private void writeHeader() throws IOException {
		
		out.write("%%MatrixMarket ");
		out.write(buffer[0] + " ");
		out.write(buffer[1] + " ");
		out.write("real general");
		out.newLine();
		
		length = 0;

	}
	
	private void writeMeta() throws IOException {
		
		dumpBuffer();
		out.newLine();

	}
	
	private void writeElement() throws IOException {

		dumpBuffer();
		out.newLine();
		
	}
	
	private void put(String value) {
		if (buffer.length <= length + 1) {
			growup();
		}
		
		buffer[length++] = value;
	}
	
	private void dumpBuffer() throws IOException {
		
		for (int i = 0; i < length; i++) {
			out.write(buffer[i] + " ");
		}
		
		length = 0;
	}

	private void growup() {
		
		int newLength =  (length * 3) / 2 + 1;
		
		String newBuffer[] = new String[newLength];
		System.arraycopy(buffer, 0, newBuffer, 0, length);

		this.buffer = newBuffer;
	}
	
	@Override public void writeBoolean(boolean v) throws IOException { throw new UnsupportedOperationException(); }
	@Override public void writeShort(int v) throws IOException { throw new UnsupportedOperationException(); }
	@Override public void writeChar(int v) throws IOException { throw new UnsupportedOperationException(); }
	@Override public void writeBytes(String s) throws IOException { throw new UnsupportedOperationException(); }
	@Override public void writeChars(String s) throws IOException { throw new UnsupportedOperationException(); }
	@Override public void writeUTF(String s) throws IOException { throw new UnsupportedOperationException(); }
}
