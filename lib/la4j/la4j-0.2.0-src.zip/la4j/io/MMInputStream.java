/*
 * Copyright 2011, Vladimir Kostyukov
 * 
 * This file is part of la4j project (http://la4j.googlecode.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 *      
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package la4j.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInput;
import java.util.StringTokenizer;

import la4j.factory.DenseFactory;
import la4j.factory.Factory;
import la4j.factory.SparseFactory;
import la4j.matrix.Matrix;
import la4j.vector.Vector;

public class MMInputStream extends InputStream implements ObjectInput, IOConstants {

	private BufferedReader in;
	private StringTokenizer tokenizer;
	
	public MMInputStream(InputStream in) {
		this.in = new BufferedReader(new InputStreamReader(in));
	}

	@Override
	public int skipBytes(int n) throws IOException {
		return (int) in.skip(n);
	}
	
	@Override
	public int readInt() throws IOException {
		return Integer.valueOf(nextToken());
	}

	@Override
	public long readLong() throws IOException {
		return Long.valueOf(nextToken());
	}

	@Override
	public float readFloat() throws IOException {
		return Float.valueOf(nextToken());
	}

	@Override
	public double readDouble() throws IOException {
		return Double.valueOf(nextToken());
	}

	@Override
	public Object readObject() throws ClassNotFoundException, IOException {

		StringTokenizer localTokenizer = new StringTokenizer(in.readLine());
		
		if (!localTokenizer.nextToken().equals("%%MatrixMarket")) {
			throw new IOException();
		}
		
		String id = localTokenizer.nextToken();
		
		if (id.equals(VECTOR_ID)) {
			return readVector(localTokenizer.nextToken());
		} else if (id.equals(MATRIX_ID)) {
			return readMatrix(localTokenizer.nextToken());
		} else {
			throw new IOException();
		}
	}

	@Override
	public int read() throws IOException {
		return in.read();
	}
	
	private Vector readVector(String header) throws IOException, ClassNotFoundException {
		
		// TODO: DRY broken
		
		Factory factory = null;
		
		if (header.equals(DENSE_HEADER)) {
			factory = new DenseFactory();
		} else if (header.equals(SPARSE_HEADER)) {
			factory = new SparseFactory();
		} else {
			throw new ClassNotFoundException(header);
		}
		
		Vector result = factory.createVector();
		result.readExternal(this);
		return result; 
	}
	
	private Matrix readMatrix(String header) throws IOException, ClassNotFoundException {

		// TODO: DRY broken
		
		Factory factory = null;
		
		if (header.equals(DENSE_HEADER)) {
			factory = new DenseFactory();
		} else if (header.equals(SPARSE_HEADER)) {
			factory = new SparseFactory();
		} else {
			throw new ClassNotFoundException(header);
		}
		
		Matrix result = factory.createMatrix();
		result.readExternal(this);
		return result;
	}
	
	private String nextToken() throws IOException {

		while(tokenizer == null || !tokenizer.hasMoreTokens()) {
		
			String line = in.readLine();
			if (line.charAt(0) != '#') {
				tokenizer = new StringTokenizer(line);
			}
			
		}
		
		return tokenizer.nextToken();
	}
	
	@Override public void readFully(byte[] b) throws IOException { throw new  UnsupportedOperationException(); }
	@Override public void readFully(byte[] b, int off, int len) throws IOException { throw new  UnsupportedOperationException(); }
	@Override public boolean readBoolean() throws IOException { throw new  UnsupportedOperationException(); }
	@Override public byte readByte() throws IOException { return 0x0; }
	@Override public int readUnsignedByte() throws IOException { 	throw new  UnsupportedOperationException(); }
	@Override public short readShort() throws IOException { throw new UnsupportedOperationException(); }
	@Override public int readUnsignedShort() throws IOException { throw new  UnsupportedOperationException(); }
	@Override public char readChar() throws IOException { throw new  UnsupportedOperationException(); }
	@Override public String readLine() throws IOException { throw new UnsupportedOperationException(); }
	@Override public String readUTF() throws IOException { throw new UnsupportedOperationException(); }
}
