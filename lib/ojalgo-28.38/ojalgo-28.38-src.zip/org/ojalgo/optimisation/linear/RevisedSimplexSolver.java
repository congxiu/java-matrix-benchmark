/*
 * Copyright © 2009 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation.linear;

import static org.ojalgo.constant.PrimitiveMath.*;
import static org.ojalgo.function.implementation.PrimitiveFunction.*;

import org.ojalgo.matrix.decomposition.MatrixDecomposition;
import org.ojalgo.matrix.decomposition.QRDecomposition;
import org.ojalgo.matrix.store.IdentityStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.MergedColumnsStore;
import org.ojalgo.matrix.store.MergedRowsStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.SelectedColumnsStore;
import org.ojalgo.matrix.store.ZeroStore;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.optimisation.OptimisationModel;
import org.ojalgo.optimisation.OptimisationSolver;
import org.ojalgo.optimisation.State;
import org.ojalgo.type.IndexSelector;
import org.ojalgo.type.context.NumberContext;

/**
 * RevisedSimplexSolver
 * 
 * http://www.cise.ufl.edu/~davis/Morgan/chapter2.htm
 *
 * @author apete
 */
class RevisedSimplexSolver extends LinearSolver {

    private final MatrixDecomposition<Double> myBasis = QRDecomposition.makePrimitive();

    private RevisedSimplexSolver(final LinearSolver.Builder aBuilder, final IndexSelector aBasisSelector) {
        super(aBuilder, aBasisSelector);
    }

    RevisedSimplexSolver(final LinearSolver.Builder aBuilder, final int[] aPivots) {
        super(aBuilder, aPivots);
    }

    public Result solve() {

        final int myNumberOfVariables = this.countVariables();
        final int myNumberOfArtificials = this.countBasisDeficit();
        final int myNumberOfConstraints = this.countConstraints();

        if (myNumberOfArtificials > 0) {

            final LinearSolver.Builder tmpMatrices = new LinearSolver.Builder();
            final int tmpMinDim = StrictMath.min(myNumberOfConstraints, myNumberOfArtificials);

            MatrixStore<Double> retVal = new IdentityStore<Double>(PrimitiveDenseStore.FACTORY, tmpMinDim);

            if (myNumberOfConstraints > tmpMinDim) {
                retVal = new MergedColumnsStore<Double>(retVal, new ZeroStore<Double>(PrimitiveDenseStore.FACTORY, myNumberOfConstraints - tmpMinDim, myNumberOfArtificials));
            } else if (myNumberOfArtificials > tmpMinDim) {
                retVal = new MergedRowsStore<Double>(retVal, new ZeroStore<Double>(PrimitiveDenseStore.FACTORY, myNumberOfConstraints, myNumberOfArtificials - tmpMinDim));
            }

            final MatrixStore<Double> tmpMakeEye = retVal;
            final MatrixStore<Double> tmpPhase1AE = new MergedRowsStore<Double>(this.getAE(), tmpMakeEye);
            final MatrixStore<Double> tmpPhase1BE = this.getBE();

            tmpMatrices.equalities(tmpPhase1AE, tmpPhase1BE);

            final PhysicalStore<Double> tmpPhase1C = PrimitiveDenseStore.FACTORY.makeZero(myNumberOfVariables + myNumberOfArtificials, 1);
            for (int i = myNumberOfVariables; i < myNumberOfVariables + myNumberOfArtificials; i++) {
                tmpPhase1C.set(i, 0, ONE);
            }
            tmpMatrices.objective(tmpPhase1C);

            final IndexSelector tmpPhase1Selector = new IndexSelector(myNumberOfVariables + myNumberOfArtificials);
            tmpPhase1Selector.include(this.getIncluded());
            for (int i = 0; i < myNumberOfArtificials; i++) {
                tmpPhase1Selector.include(myNumberOfVariables + i);
            }

            final RevisedSimplexSolver tmpPase1Solver = new RevisedSimplexSolver(tmpMatrices, tmpPhase1Selector);
            final OptimisationSolver.Result tmpResult = tmpPase1Solver.solve();

            //            this.excludeAll();
            //            this.include(tmpPhase1Selector.getIncluded());

            this.excludeAll();
            this.include(tmpPhase1Selector.getIncluded());
        }

        int[] tmpIncl = null, tmpExcl = null;

        int tmpEnter = -1;
        int tmpLeave = -1;

        if (this.hasConstraints()) {

            do {

                tmpIncl = this.getIncluded();
                tmpExcl = this.getExcluded();

                if (DEBUG) {
                    //                    BasicLogger.logDebug("AE");
                    //                    MatrixUtils.print(myMatrices.getAE());
                    //                    BasicLogger.logDebug("incl: {}.", Arrays.toString(tmpIncl));
                    //                    BasicLogger.logDebug("inclAE");
                    //                    MatrixUtils.print(myMatrices.getAE(tmpIncl));
                }

                myBasis.compute(this.getAE(tmpIncl));

                this.setX(myBasis.solve(this.getBE()));

                final MatrixStore<Double> tmpInvAEE = myBasis.solve(this.getAE(tmpExcl));

                final PhysicalStore<Double> tmpReduced = this.getC(tmpExcl).transpose();
                tmpReduced.fillMatching(tmpReduced, SUBTRACT, tmpInvAEE.multiplyLeft(this.getC(tmpIncl).transpose()));

                tmpEnter = this.findNextPivotColumn(tmpReduced);

                if (tmpEnter != -1) {

                    //final MatrixStore<Double> tmpW = myBasis.solve(myMatrices.getAE(tmpEnter));
                    final MatrixStore<Double> tmpW = new SelectedColumnsStore<Double>(tmpInvAEE, new int[] { tmpEnter });

                    tmpLeave = this.findPivotRow(this.getX(), tmpW);

                    if (tmpLeave != -1) {

                        if (DEBUG) {
                            BasicLogger.logDebug("Enter: {},\tLeave: {}.", tmpExcl[tmpEnter], tmpIncl[tmpLeave]);
                        }

                        //                        this.exclude(tmpIncl[tmpLeave]);
                        //                        this.include(tmpExcl[tmpEnter]);

                        this.exclude(tmpIncl[tmpLeave]);
                        this.include(tmpExcl[tmpEnter]);

                        this.setState(State.FEASIBLE);

                    } else {
                        this.setState(State.UNBOUNDED);
                    }
                } else {

                    this.setState(State.OPTIMAL);
                }

            } while ((tmpEnter != -1) && (tmpLeave != -1));

        } else {
            this.setX(null);
            this.setState(State.UNBOUNDED);
        }

        final PhysicalStore<Double> tmpSolution = PrimitiveDenseStore.FACTORY.makeZero(myNumberOfVariables, 1);
        if (this.getState().isNotLessThan(State.FEASIBLE)) {
            for (int i = 0; i < tmpIncl.length; i++) {
                tmpSolution.set(tmpIncl[i], 0, this.getX().doubleValue(i, 0));
            }
        }

        return new Result(this.getState(), tmpSolution, this.getIterationsCount());
    }

    public Result solve(final OptimisationModel aValidationModel) {
        return this.solve();
    }

    private int findNextPivotColumn(final MatrixStore<Double> aC) {

        int retVal = -1;
        double tmpMinVal = -options.problemContext.getError();
        double tmpVal;

        for (int i = 0; i < aC.getColDim(); i++) {
            tmpVal = aC.doubleValue(i, 0);
            if (tmpVal < tmpMinVal) {
                retVal = i;
                tmpMinVal = tmpVal;
                if (DEBUG) {
                    BasicLogger.logDebug("Reduced Contribution Weight: {}.", tmpVal);
                }
            }
        }

        return retVal;
    }

    private int findPivotRow(final MatrixStore<Double> aD, final MatrixStore<Double> aW) {

        int retVal = -1;
        double tmpNumer, tmpDenom, tmpRatio;
        double tmpMinRatio = MAX_VALUE;

        final NumberContext tmpProblemContext = options.problemContext;

        for (int i = 0; i < aD.getRowDim(); i++) {

            //            tmpNumer = aD.doubleValue(i, 0);
            //            tmpDenom = aW.doubleValue(i, 0);
            //            tmpRatio = tmpNumer / tmpDenom;
            //
            //            if (!TypeUtils.isZero(options.solutionContext.round(tmpDenom)) && (tmpRatio >= ZERO) && (tmpRatio < tmpMinRatio) && !((tmpRatio == ZERO) && (tmpDenom < ZERO))) {
            //                retVal = i;
            //                tmpMinRatio = tmpRatio;
            //                if (DEBUG) {
            //                    BasicLogger.logDebug("Ratio: {},\tNumerator/RHS: {}, \tDenominator/Pivot: {}.", tmpRatio, tmpNumer, tmpDenom);
            //                }
            //            }

            tmpDenom = aW.doubleValue(i, 0);

            if (!tmpProblemContext.isZero(tmpDenom)) {

                tmpNumer = aD.doubleValue(i, 0);
                tmpRatio = tmpNumer / tmpDenom;

                if ((tmpRatio >= ZERO) && (tmpRatio < tmpMinRatio) && !(tmpProblemContext.isZero(tmpRatio) && (tmpDenom < ZERO))) {
                    retVal = i;
                    tmpMinRatio = tmpRatio;
                    if (DEBUG) {
                        BasicLogger.logDebug("Ratio: {},\tNumerator/RHS: {}, \tDenominator/Pivot: {}.", tmpRatio, tmpNumer, tmpDenom);
                    }
                }
            }

        }

        return retVal;
    }

    @Override
    protected boolean needsAnotherIteration() {
        // TODO Auto-generated method stub
        return false;
    }

}
