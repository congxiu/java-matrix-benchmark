/*
 * Copyright © 2004 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation;

import static org.ojalgo.constant.BigMath.*;
import static org.ojalgo.function.implementation.BigFunction.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.ojalgo.ProgrammingError;
import org.ojalgo.array.Array1D;
import org.ojalgo.function.multiary.LinearFunction;
import org.ojalgo.function.multiary.QuadraticFunction;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.optimisation.OptimisationSolver.Result;
import org.ojalgo.optimisation.linear.LinearExpressionsModel;
import org.ojalgo.type.context.NumberContext;

/**
 * <p>
 * Lets you construct optimisation problems by collecting mathematical
 * expressions (in terms of the variables). Each expression can be a
 * constraint and/or contribute to the objective function.
 * </p>
 * Basic instructions:
 * <ol>
 * <li>Define (create) a set of variables. Each variable may have a lower
 * as well as an upper limit and a cost associated with it.</li>
 * <li>Create a model using that set of variables.</li>
 * <li>Add expressions to the model. The model is the expression
 * factory/builder. Each expression can act as both a constraint and as
 * a part of the objective.</li>
 * <li>Instanciate a solver using the model.</li>
 * <li>Solve!</li>
 * </ol>
 * 
 * @author apete
 */
public abstract class ExpressionsBasedModel<M extends ExpressionsBasedModel<M>> extends AbstractModel {

    private static final String NEW_LINE = "\n";
    private static final String OBJECTIVE = "Objective";
    private static final String START_END = "############################################\n";

    private final HashMap<String, Expression> myExpressions = new HashMap<String, Expression>();

    private final Variable[] myVariables;

    @SuppressWarnings("unused")
    private ExpressionsBasedModel() {

        super();

        myVariables = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    protected ExpressionsBasedModel(final ExpressionsBasedModel<?> aModel) {

        super();

        myVariables = aModel.getVariables();
        for (int i = 0; i < myVariables.length; i++) {
            myVariables[i] = myVariables[i].copy();
        }

        for (final Expression tmpExpression : aModel.getExpressions()) {
            myExpressions.put(tmpExpression.getName(), tmpExpression);
        }
    }

    protected ExpressionsBasedModel(final Set<? extends Variable> someVariables) {
        this(someVariables.toArray(new Variable[someVariables.size()]));
    }

    protected ExpressionsBasedModel(final Variable[] someVariables) {

        super();

        myVariables = someVariables.clone();
    }

    public Expression addConstraint(final String aName, final BigDecimal aLowerLimit, final Array1D<BigDecimal> somefactors, final BigDecimal anUpperLimit) {

        final Expression retVal = this.addQuadLin(aName, null, ZERO);

        retVal.setLowerLimit(aLowerLimit);
        retVal.setUpperLimit(anUpperLimit);

        for (int i = 0; i < somefactors.size(); i++) {
            retVal.setLinearFactor(i, somefactors.get(i));
        }

        return retVal;
    }

    public Expression addConstraint(final String aName, final BigDecimal aLowerLimit, final BigDecimal anUpperLimit) {

        final Expression retVal = this.addQuadLin(aName, null, ONE);

        retVal.setLowerLimit(aLowerLimit);
        retVal.setUpperLimit(anUpperLimit);

        return retVal;
    }

    public Expression addCorrelationExpression(final String aName, final BasicMatrix aCorrelationsMatrix) {

        final Expression retVal = this.addEmptyQuadraticExpression(aName);

        for (int i = 0; i < aCorrelationsMatrix.getRowDim(); i++) {
            for (int j = 0; j < aCorrelationsMatrix.getColDim(); j++) {
                retVal.setQuadraticFactor(i, j, aCorrelationsMatrix.toBigDecimal(i, j));
            }
        }

        return retVal;
    }

    public Expression addEmptyLinearExpression(final String aName) {
        return this.addQuadLin(aName, null, ZERO);
    }

    public Expression addEmptyQuadraticExpression(final String aName) {
        return this.addQuadLin(aName, ZERO, null);
    }

    public Expression addGeneralExpression(final String aName) {
        return this.addQuadLin(aName, ZERO, ZERO);
    }

    /**
     * Generates a constraint that measures the distance from a specified
     * point. Actually, the expression measures the square of the distance...
     * 
     * @param aName An expression name
     * @param aPoint The "specified point"
     * @return Expression of the square of the distance from the origin
     */
    public Expression addOffsetExpression(final String aName, final List<BigDecimal> aPoint) {

        final Expression retVal = this.addQuadLin(aName, ONE, ZERO);

        final BigDecimal tmpLinearWeight = TWO.negate();
        BigDecimal tmpConstant = ZERO;

        BigDecimal tmpVal;
        for (int i = 0; i < aPoint.size(); i++) {

            tmpVal = aPoint.get(i);

            retVal.setLinearFactor(i, tmpVal.multiply(tmpLinearWeight));

            tmpConstant = tmpConstant.add(tmpVal.multiply(tmpVal));
        }

        retVal.setConstant(tmpConstant);

        return retVal;
    }

    public Expression addOffsetExpressionWithException(final String aName, final List<BigDecimal> aPoint, final int anExceptionIndex) {

        final Expression retVal = this.addQuadLin(aName, ONE, ZERO);

        final BigDecimal tmpLinearWeight = TWO.negate();
        BigDecimal tmpConstant = ZERO;

        BigDecimal tmpVal;
        for (int i = 0; i < aPoint.size(); i++) {
            if (i != anExceptionIndex) {

                tmpVal = aPoint.get(i);

                retVal.setLinearFactor(i, tmpVal.multiply(tmpLinearWeight));

                tmpConstant = tmpConstant.add(tmpVal.multiply(tmpVal));
            }
        }
        retVal.setConstant(tmpConstant);

        retVal.setQuadraticFactor(anExceptionIndex, anExceptionIndex, ZERO);

        return retVal;
    }

    public Expression addSimpleWeightExpression(final String aName) {
        return this.addQuadLin(aName, null, ONE);
    }

    public Expression addWeightExpression(final String aName, final BigDecimal[] someLinearWeights) {

        final Expression retVal = this.addQuadLin(aName, null, ZERO);

        for (int i = 0; i < someLinearWeights.length; i++) {
            retVal.setLinearFactor(i, someLinearWeights[i]);
        }

        return retVal;
    }

    public Expression addWeightExpression(final String aName, final List<BigDecimal> someLinearWeights) {

        final Expression retVal = this.addQuadLin(aName, null, ZERO);

        for (int i = 0; i < someLinearWeights.size(); i++) {
            retVal.setLinearFactor(i, someLinearWeights.get(i));
        }

        return retVal;
    }

    public abstract M copy();

    public int countExpressions() {
        return myExpressions.size();
    }

    public int countVariables() {
        return myVariables.length;
    }

    abstract public OptimisationSolver getDefaultSolver();

    public Expression getExpression(final String aName) {
        return myExpressions.get(aName);
    }

    public Expression[] getExpressions() {
        return myExpressions.values().toArray(new Expression[myExpressions.size()]);
    }

    public boolean[] getIntegers() {

        final int tmpLength = myVariables.length;

        final boolean[] retVal = new boolean[tmpLength];

        for (int i = 0; i < tmpLength; i++) {
            retVal[i] = myVariables[i].isInteger();
        }

        return retVal;
    }

    public final Expression getObjectiveExpression() {

        Expression retVal = myExpressions.get(OBJECTIVE);

        if (retVal == null) {

            if (this.isAnyExpressionQuadratic()) {
                retVal = Expression.makeZeroZero(OBJECTIVE, myVariables);
            } else {
                retVal = Expression.makeNullZero(OBJECTIVE, myVariables);
            }

            final LinearFunction<BigDecimal> tmpLinear = retVal.getLinear();
            final QuadraticFunction<BigDecimal> tmpQuadratic = retVal.getQuadratic();

            Variable tmpVariable;
            for (int i = 0; i < myVariables.length; i++) {
                tmpVariable = myVariables[i];

                if (tmpVariable.isObjective()) {
                    tmpLinear.setFactor(i, tmpVariable.getContributionWeight());
                }
            }

            for (final Expression tmpExpression : myExpressions.values()) {

                if (tmpExpression.isObjective()) {

                    final BigDecimal tmpContributionWeight = tmpExpression.getContributionWeight();
                    final boolean tmpNotOne = tmpContributionWeight.compareTo(ONE) != 0; // To avoid multiplication by 1.0

                    if (tmpExpression.hasLinear()) {
                        if (tmpNotOne) {
                            tmpLinear.getFactors().maxpy(tmpContributionWeight, tmpExpression.getLinear().getFactors());
                        } else {
                            tmpLinear.getFactors().fillMatching(tmpLinear.getFactors(), ADD, tmpExpression.getLinear().getFactors());
                        }
                    }

                    if (tmpExpression.hasQuadratic()) {

                        if (tmpNotOne) {
                            tmpQuadratic.getFactors().maxpy(tmpContributionWeight, tmpExpression.getQuadratic().getFactors());
                        } else {
                            tmpQuadratic.getFactors().fillMatching(tmpQuadratic.getFactors(), ADD, tmpExpression.getQuadratic().getFactors());
                        }
                    }
                }
            }

            myExpressions.put(OBJECTIVE, retVal);
        }

        return retVal;
    }

    public final BigDecimal getValue() {
        return this.getObjectiveExpression().invoke(this.getCurrent());
    }

    public Variable getVariable(final int anIndex) {
        return myVariables[anIndex];
    }

    public Variable[] getVariables() {
        return myVariables.clone();
    }

    public final BigDecimal[] getVariableValues() {

        final BigDecimal[] retVal = new BigDecimal[myVariables.length];

        for (int i = 0; i < myVariables.length; i++) {
            retVal[i] = myVariables[i].getValue();
        }

        return retVal;
    }

    public int indexOfVariable(final String aName) {
        int retVal = -1;
        for (int i = 0; (retVal < 0) && (i < myVariables.length); i++) {
            if (aName.equals(myVariables[i].getName())) {
                retVal = i;
            }
        }
        return retVal;
    }

    public final boolean isAnyExpressionQuadratic() {

        boolean retVal = false;

        // final int tmpLength = myExpressions.size();

        //        for (int i = 0; !retVal && (i < tmpLength); i++) {
        //            retVal |= myExpressions.get(i).hasQuadratic();
        //        }

        String tmpType;
        for (final Iterator<String> tmpIterator = myExpressions.keySet().iterator(); !retVal && tmpIterator.hasNext();) {
            tmpType = tmpIterator.next();
            retVal |= myExpressions.get(tmpType).hasQuadratic();
        }

        return retVal;
    }

    public final boolean isAnyVariableInteger() {

        boolean retVal = false;

        final int tmpLength = myVariables.length;

        for (int i = 0; !retVal && (i < tmpLength); i++) {
            retVal |= myVariables[i].isInteger();
        }

        return retVal;
    }

    public final BigDecimal maximise() {

        this.setMaximisation(true);

        return this.solve();
    }

    public final BigDecimal minimise() {

        this.setMinimisation(true);

        return this.solve();
    }

    @SuppressWarnings("unchecked")
    public final M relax() {

        final int tmpLength = myVariables.length;
        for (int i = 0; i < tmpLength; i++) {
            myVariables[i].integer(false);
        }

        return (M) this;
    }

    public final void resetObjectiveExpression() {
        myExpressions.remove(OBJECTIVE);
    }

    public final Expression[] selectEqualityConstraintExpressions() {

        final List<Expression> tmpList = new ArrayList<Expression>();

        for (final Expression tmpExpression : myExpressions.values()) {
            if (tmpExpression.isEqualityConstraint()) {
                tmpList.add(tmpExpression);
            }
        }

        return tmpList.toArray(new Expression[tmpList.size()]);
    }

    public final Variable[] selectEqualityConstraintVariables() {

        final List<Variable> tmpList = new ArrayList<Variable>();

        for (final Variable tmpVariable : myVariables) {
            if (tmpVariable.isEqualityConstraint()) {
                tmpList.add(tmpVariable);
            }
        }

        return tmpList.toArray(new Variable[tmpList.size()]);
    }

    public final Expression[] selectLowerConstraintExpressions() {

        final List<Expression> tmpList = new ArrayList<Expression>();

        for (final Expression tmpExpression : myExpressions.values()) {
            if (tmpExpression.isLowerConstraint()) {
                tmpList.add(tmpExpression);
            }
        }

        return tmpList.toArray(new Expression[tmpList.size()]);
    }

    public final Variable[] selectLowerConstraintVariables() {

        final List<Variable> tmpList = new ArrayList<Variable>();

        for (final Variable tmpVariable : myVariables) {
            if (tmpVariable.isLowerConstraint()) {
                tmpList.add(tmpVariable);
            }
        }

        return tmpList.toArray(new Variable[tmpList.size()]);
    }

    public final Expression[] selectNegativeEqualityConstraintExpressions() {

        final List<Expression> tmpList = new ArrayList<Expression>();

        for (final Expression tmpExpression : myExpressions.values()) {
            if (tmpExpression.isEqualityConstraint() && (tmpExpression.getUpperLimit().signum() == -1)) {
                tmpList.add(tmpExpression);
            }
        }

        return tmpList.toArray(new Expression[tmpList.size()]);
    }

    public final Expression[] selectNegativeLowerConstraintExpressions() {

        final List<Expression> tmpList = new ArrayList<Expression>();

        for (final Expression tmpExpression : myExpressions.values()) {
            if (tmpExpression.isLowerConstraint() && (tmpExpression.getLowerLimit().signum() != 1)) {
                tmpList.add(tmpExpression);
            }
        }

        return tmpList.toArray(new Expression[tmpList.size()]);
    }

    public final Expression[] selectNegativeUpperConstraintExpressions() {

        final List<Expression> tmpList = new ArrayList<Expression>();

        for (final Expression tmpExpression : myExpressions.values()) {
            if (tmpExpression.isUpperConstraint() && (tmpExpression.getUpperLimit().signum() == -1)) {
                tmpList.add(tmpExpression);
            }
        }

        return tmpList.toArray(new Expression[tmpList.size()]);
    }

    public final Variable[] selectNonZeroLowerConstraintVariables() {

        final List<Variable> tmpList = new ArrayList<Variable>();

        for (final Variable tmpVariable : myVariables) {
            if (tmpVariable.isLowerConstraint() && (tmpVariable.getLowerLimit().signum() != 0)) {
                tmpList.add(tmpVariable);
            }
        }

        return tmpList.toArray(new Variable[tmpList.size()]);
    }

    public final Expression[] selectPositiveEqualityConstraintExpressions() {

        final List<Expression> tmpList = new ArrayList<Expression>();

        for (final Expression tmpExpression : myExpressions.values()) {
            if (tmpExpression.isEqualityConstraint() && (tmpExpression.getUpperLimit().signum() != -1)) {
                tmpList.add(tmpExpression);
            }
        }

        return tmpList.toArray(new Expression[tmpList.size()]);
    }

    public final Expression[] selectPositiveLowerConstraintExpressions() {

        final List<Expression> tmpList = new ArrayList<Expression>();

        for (final Expression tmpExpression : myExpressions.values()) {
            if (tmpExpression.isLowerConstraint() && (tmpExpression.getLowerLimit().signum() == 1)) {
                tmpList.add(tmpExpression);
            }
        }

        return tmpList.toArray(new Expression[tmpList.size()]);
    }

    public final Expression[] selectPositiveUpperConstraintExpressions() {

        final List<Expression> tmpList = new ArrayList<Expression>();

        for (final Expression tmpExpression : myExpressions.values()) {
            if (tmpExpression.isUpperConstraint() && (tmpExpression.getUpperLimit().signum() != -1)) {
                tmpList.add(tmpExpression);
            }
        }

        return tmpList.toArray(new Expression[tmpList.size()]);
    }

    public final Expression[] selectUpperConstraintExpressions() {

        final List<Expression> tmpList = new ArrayList<Expression>();

        for (final Expression tmpExpression : myExpressions.values()) {
            if (tmpExpression.isUpperConstraint()) {
                tmpList.add(tmpExpression);
            }
        }

        return tmpList.toArray(new Expression[tmpList.size()]);
    }

    public final Variable[] selectUpperConstraintVariables() {

        final List<Variable> tmpList = new ArrayList<Variable>();

        for (final Variable tmpVariable : myVariables) {
            if (tmpVariable.isUpperConstraint()) {
                tmpList.add(tmpVariable);
            }
        }

        return tmpList.toArray(new Variable[tmpList.size()]);
    }

    public void setLowerLimitOnVariable(final int aVariableIndex, final BigDecimal aLimit) {
        myVariables[aVariableIndex].setLowerLimit(aLimit);
    }

    public void setUpperLimitOnVariable(final int aVariableIndex, final BigDecimal aLimit) {
        myVariables[aVariableIndex].setUpperLimit(aLimit);
    }

    @Override
    public final String toString() {

        final StringBuilder retVal = new StringBuilder(START_END);

        for (final Variable tmpVariable : myVariables) {
            tmpVariable.appendToString(retVal);
            retVal.append(NEW_LINE);
        }

        for (final Expression tmpExpression : myExpressions.values()) {
            tmpExpression.appendToString(retVal, this.getCurrent());
            retVal.append(NEW_LINE);
        }

        return retVal.append(START_END).toString();
    }

    public boolean validateComposition() throws ModelValidationException {

        boolean retVal = true;

        final int tmpCountVariables = this.countVariables();

        for (final Variable tmpVariable : myVariables) {
            retVal &= tmpVariable.validateConfiguration();
        }

        for (final Expression tmpExpression : myExpressions.values()) {
            if (tmpExpression.dim() != tmpCountVariables) {
                return false;
            }
            retVal &= tmpExpression.validateConfiguration();
        }

        return retVal;
    }

    public boolean validateSolution(final BasicMatrix aSolution, final NumberContext aContext) {

        final MatrixStore<BigDecimal> tmpSolution = aSolution.getRows(MatrixUtils.makeIncreasingRange(0, myVariables.length)).toBigStore();

        try {
            for (int i = 0; i < myVariables.length; i++) {
                myVariables[i].validate(tmpSolution.get(i, 0), aContext);
            }
        } catch (final ModelValidationException anException) {
            BasicLogger.logError(anException.toString());
            return false;
        }

        for (final Expression tmpExpression : myExpressions.values()) {
            if (!tmpExpression.validateSolution(tmpSolution, aContext)) {
                return false;
            }
        }

        return true;
    }

    public boolean validateSolution(final NumberContext aContext) {

        final MatrixStore<BigDecimal> tmpSolution = BigDenseStore.FACTORY.makeColumn(this.getVariableValues());

        try {
            for (int i = 0; i < myVariables.length; i++) {
                myVariables[i].validate(tmpSolution.get(i, 0), aContext);
            }
        } catch (final ModelValidationException anException) {
            BasicLogger.logError(anException.toString());
            return false;
        }

        for (final Expression tmpExpression : myExpressions.values()) {
            if (!tmpExpression.validateSolution(tmpSolution, aContext)) {
                return false;
            }
        }

        return true;
    }

    private Expression setLinear(final Expression anExpression, final BigDecimal aValue) {

        for (int i = 0; i < myVariables.length; i++) {
            anExpression.setLinearFactor(i, aValue);
        }

        return anExpression;
    }

    private Expression setQuadraticDiagonal(final Expression anExpression, final BigDecimal aValue) {

        for (int ij = 0; ij < myVariables.length; ij++) {
            anExpression.setQuadraticFactor(ij, ij, aValue);
        }

        return anExpression;
    }

    private BigDecimal solve() {

        List<BigDecimal> tmpSolution = null;

        final OptimisationSolver tmpSolver = this.getDefaultSolver();

        Result tmpResult;
        if (DEBUG && (this instanceof LinearExpressionsModel)) {
            tmpResult = tmpSolver.solve(this);
        } else {
            tmpResult = tmpSolver.solve();

        }
        final BasicMatrix tmpSolution2 = tmpResult.getSolution();
        tmpSolution = tmpSolution2.toBigStore().asList();

        for (int i = 0; i < myVariables.length; i++) {
            myVariables[i].setValue(tmpSolution.get(i));
        }

        return this.getObjectiveExpression().invoke(this.getVariableValues());
    }

    protected void assertLowerVariableLimits() {
        for (final Variable tmpVariable : myVariables) {
            if (tmpVariable.getLowerLimit() == null) {
                tmpVariable.setLowerLimit(ZERO);
            } else if (tmpVariable.getLowerLimit().signum() == -1) {
                throw new IllegalArgumentException("Cannot have a lower limit less than zero: " + tmpVariable.toString());
            }
        }
    }

    protected List<BigDecimal> getCurrent() {

        final List<BigDecimal> retVal = new ArrayList<BigDecimal>();

        BigDecimal tmpVal;
        for (int i = 0; i < myVariables.length; i++) {

            tmpVal = myVariables[i].getValue();
            if (tmpVal != null) {
                retVal.add(i, tmpVal);
            } else {
                retVal.add(i, ZERO);
            }
        }

        return retVal;
    }

    Expression addQuadLin(final String aName, final BigDecimal aQuadVal, final BigDecimal aLinVal) {

        Expression retVal = null;

        if (aQuadVal != null) {

            if (aLinVal != null) {

                retVal = Expression.makeZeroZero(aName, myVariables);

            } else {

                retVal = Expression.makeZeroNull(aName, myVariables);
            }

        } else {

            if (aLinVal != null) {

                retVal = Expression.makeNullZero(aName, myVariables);

            } else {

                throw new ProgrammingError("Not a function!");
            }
        }

        if ((aQuadVal != null) && (aQuadVal.signum() != 0)) {
            this.setQuadraticDiagonal(retVal, aQuadVal);
        }

        if ((aLinVal != null) && (aLinVal.signum() != 0)) {
            this.setLinear(retVal, aLinVal);
        }

        myExpressions.put(aName, retVal);

        return retVal;
    }

}
