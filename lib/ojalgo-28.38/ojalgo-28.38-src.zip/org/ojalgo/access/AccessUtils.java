/*
 * Copyright © 2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.access;

public abstract class AccessUtils {

    /**
     * @param aStructure An access structure
     * @param aReference An access element reference
     * @return The index of that element
     */
    public static int index(final int[] aStructure, final int[] aReference) {
        int retVal = aReference[0];
        int tmpFactor = aStructure[0];
        final int tmpLength = aReference.length;
        for (int i = 1; i < tmpLength; i++) {
            retVal += tmpFactor * aReference[i];
            tmpFactor *= aStructure[i];
        }
        return retVal;
    }

    /**
     * @param aStructure An access structure
     * @return The size of an access with that structure
     */
    public static int size(final int[] aStructure) {
        int retVal = 1;
        final int tmpLength = aStructure.length;
        for (int i = 0; i < tmpLength; i++) {
            retVal *= aStructure[i];
        }
        return retVal;
    }

    /**
     * @param aStructure An access structure
     * @param aDimension A dimension index
     * @return The size of that dimension
     */
    public static int size(final int[] aStructure, final int aDimension) {
        return aStructure.length > aDimension ? aStructure[aDimension] : 1;
    }

    /**
     * @param aStructure An access structure
     * @param aDimension A dimension index indication a direction
     * @return The step size (index change) in that direction
     */
    public static int step(final int[] aStructure, final int aDimension) {
        int retVal = 1;
        for (int i = 0; i < aDimension; i++) {
            retVal *= AccessUtils.size(aStructure, i);
        }
        return retVal;
    }

    /**
     * A more complex/general version of {@linkplain #step(int[], int)}.
     * 
     * @param aStructure An access structure
     * @param aReferenceIncrement A vector indication a direction (and size)
     * @return The step size (index change)
     */
    public static int step(final int[] aStructure, final int[] aReferenceIncrement) {
        int retVal = 0;
        int tmpFactor = 1;
        final int tmpLimit = aReferenceIncrement.length;
        for (int i = 1; i < tmpLimit; i++) {
            retVal += tmpFactor * aReferenceIncrement[i];
            tmpFactor *= aStructure[i];
        }
        return retVal;
    }

    private AccessUtils() {
        super();
    }

}
