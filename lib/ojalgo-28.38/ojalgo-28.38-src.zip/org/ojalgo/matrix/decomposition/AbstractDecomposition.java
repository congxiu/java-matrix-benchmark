/*
 * Copyright © 2005 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.util.concurrent.Future;

import org.ojalgo.concurrent.ConcurrentExecutor;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * AbstractDecomposition
 *
 * @author apete
 */
abstract class AbstractDecomposition<N extends Number> implements MatrixDecomposition<N> {

    public static boolean DEBUG = false;

    private final PhysicalStore.Factory<N> myFactory;

    private boolean myComputed = false;

    @SuppressWarnings("unused")
    private AbstractDecomposition() {
        this(null);
    }

    protected AbstractDecomposition(final PhysicalStore.Factory<N> aFactory) {

        super();

        myFactory = aFactory;
    }

    public boolean equals(final MatrixDecomposition<N> aDecomp, final NumberContext aCntxt) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean equals(final Object someObj) {
        if (someObj instanceof MatrixStore) {
            return this.equals((MatrixStore<N>) someObj, TypeUtils.EQUALS_NUMBER_CONTEXT);
        } else {
            return super.equals(someObj);
        }
    }

    public final MatrixStore<N> invert(final MatrixStore<N> aStore) {

        this.compute(aStore);

        return this.getInverse();
    }

    public boolean isComputed() {
        return myComputed;
    }

    public void reset() {
        myComputed = false;
    }

    public Future<DecomposeAndSolve<N>> solve(final MatrixStore<N> aBody, final MatrixStore<N> aRHS) {
        return ConcurrentExecutor.INSTANCE.submit(new DecomposeAndSolve<N>(this, aBody, aRHS));
    }

    protected boolean computed(final boolean aState) {
        return (myComputed = aState);
    }

    protected final PhysicalStore.Factory<N> getFactory() {
        return myFactory;
    }

}
