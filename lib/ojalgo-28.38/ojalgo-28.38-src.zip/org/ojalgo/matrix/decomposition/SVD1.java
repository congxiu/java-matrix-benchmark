/*
 * Copyright © 2009 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * New implementation that delegates to Eigenvalue.
 *
 * @author apete
 */
abstract class SVD1<N extends Number & Comparable<N>> extends SingularValueDecomposition<N> {

    static final class Primitive extends SVD1<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY, (EigenvalueDecomposition<Double>) EigenvalueDecomposition.makePrimitive());
        }

        @Override
        protected DiagonalAccess<Double> extractSimilar(final PhysicalStore<Double> aStore, final boolean aNormalAspectRatio) {

            final Array2D<Double> tmpArray2D = ((PrimitiveDenseStore) aStore).asArray2D();

            final Array1D<Double> tmpMain = tmpArray2D.sliceDiagonal(0, 0);

            if (aNormalAspectRatio) {

                final Array1D<Double> tmpSuper = tmpArray2D.sliceDiagonal(0, 1);

                return DiagonalAccess.makePrimitive(tmpMain, tmpSuper, null);

            } else {

                final Array1D<Double> tmpSub = tmpArray2D.sliceDiagonal(1, 0);

                return DiagonalAccess.makePrimitive(tmpMain, null, tmpSub);
            }
        }

        @Override
        protected DiagonalAccess<Double> makeTridiagonal(final DiagonalAccess<Double> aBidiagonal, final boolean aNormalAspectRatio) {

            final int tmpMinDim = aBidiagonal.getMinDim();

            final Array1D<Double> tmpMain = Array1D.makePrimitive(tmpMinDim);
            final Array1D<Double> tmpOff = Array1D.makePrimitive(tmpMinDim - 1);

            final Array1D<Double> tmpPrim = aBidiagonal.mainDiagonal;
            final Array1D<Double> tmpSeco = aNormalAspectRatio ? aBidiagonal.superdiagonal : aBidiagonal.subdiagonal;

            double tmpThisPrim, tmpLastPrim, tmpLastSeco;

            tmpThisPrim = tmpPrim.doubleValue(0);
            tmpMain.set(0, tmpThisPrim * tmpThisPrim);

            for (int ij = 1; ij < tmpMinDim; ij++) {

                tmpLastPrim = tmpThisPrim;
                tmpThisPrim = tmpPrim.doubleValue(ij);

                tmpLastSeco = tmpSeco.doubleValue(ij - 1);

                tmpMain.set(ij, (tmpThisPrim * tmpThisPrim) + (tmpLastSeco * tmpLastSeco));
                tmpOff.set(ij - 1, tmpLastPrim * tmpLastSeco);
            }

            return DiagonalAccess.makePrimitive(tmpMain, tmpOff, tmpOff);
        }

        protected Array1D<Double> makeWarkCopyArray(final int aDim) {
            return Array1D.makePrimitive(aDim);
        }
    }

    private transient PhysicalStore<N> myD;
    private final EigenvalueDecomposition<N> myDelegateEigenvalue;
    private boolean myNormalAspectRatio = true;
    private transient PhysicalStore<N> myQ1;
    private Householder<N>[] myQ1Householders;
    private transient PhysicalStore<N> myQ2;
    private Householder<N>[] myQ2Householders;
    private DiagonalAccess<N> mySimilar;
    private transient Array1D<Double> mySingularValues;
    private final N myZero;

    private SVD1(final PhysicalStore.Factory<N> aFactory) {
        this(aFactory, null);
    }

    protected SVD1(final PhysicalStore.Factory<N> aFactory, final EigenvalueDecomposition<N> aDelegate) {

        super(aFactory);

        myDelegateEigenvalue = aDelegate;

        myZero = aFactory.getStaticZero().getNumber();
    }

    @SuppressWarnings("unchecked")
    public final boolean compute(final MatrixStore<N> aStore) {

        this.reset();

        final int tmpRowDim = aStore.getRowDim();
        final int tmpMinDim = aStore.getMinDim();
        final int tmpColDim = aStore.getColDim();

        final boolean tmpNormalAspectRatio = myNormalAspectRatio = tmpRowDim >= tmpColDim;

        final PhysicalStore<N> tmpD = this.getFactory().copy(aStore);

        Householder<N> tmpHouseholder;
        final Householder[] tmpQ1Householders = myQ1Householders = new Householder[tmpMinDim];
        final Householder[] tmpQ2Householders = myQ2Householders = new Householder[tmpMinDim];

        for (int ij = 0; ij < tmpMinDim; ij++) {

            if (tmpNormalAspectRatio) {

                tmpHouseholder = tmpD.generateHouseholderColumn(ij, ij);
                tmpD.transformLeft(tmpHouseholder, ij + 1);
                tmpQ1Householders[ij] = tmpHouseholder;

                tmpHouseholder = tmpD.generateHouseholderRow(ij, ij + 1);
                tmpD.transformRight(tmpHouseholder, ij + 1);
                tmpQ2Householders[ij] = tmpHouseholder;

            } else {

                tmpHouseholder = tmpD.generateHouseholderRow(ij, ij);
                tmpD.transformRight(tmpHouseholder, ij + 1);
                tmpQ2Householders[ij] = tmpHouseholder;

                tmpHouseholder = tmpD.generateHouseholderColumn(ij + 1, ij);
                tmpD.transformLeft(tmpHouseholder, ij + 1);
                tmpQ1Householders[ij] = tmpHouseholder;
            }
        }

        mySimilar = this.extractSimilar(tmpD, tmpNormalAspectRatio);

        myDelegateEigenvalue.computeTridiagonal(this.makeTridiagonal(mySimilar, tmpNormalAspectRatio));

        return this.computed(true);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public final MatrixStore<N> getD() {

        if (myD == null) {

            final Array1D<ComplexNumber> tmpEigenvalues = myDelegateEigenvalue.getEigenvalues();

            final int tmpDim = tmpEigenvalues.length;

            myD = this.getFactory().makeZero(tmpDim, tmpDim);

            double tmpVal;
            for (int ij = 0; ij < tmpDim; ij++) {
                tmpVal = tmpEigenvalues.get(ij).getReal();
                if (tmpVal > PrimitiveMath.ZERO) {
                    myD.set(ij, ij, StrictMath.sqrt(tmpVal));
                }
            }
        }

        return myD;
    }

    public final MatrixStore<N> getQ1() {

        if (myQ1 == null) {

            final PhysicalStore<N> tmpV = myDelegateEigenvalue.getV().copy();

            if (myNormalAspectRatio) {
                this.solve(tmpV, this.getD(), mySimilar);
            }

            myQ1 = this.transform(tmpV, myQ1Householders);
        }

        return myQ1;
    }

    public final MatrixStore<N> getQ2() {

        if (myQ2 == null) {

            final PhysicalStore<N> tmpV = myDelegateEigenvalue.getV().copy();

            if (!myNormalAspectRatio) {
                this.solve(tmpV, this.getD(), mySimilar.transpose());
            }

            myQ2 = this.transform(tmpV, myQ2Householders);
        }

        return myQ2;
    }

    public final Array1D<Double> getSingularValues() {

        if (mySingularValues == null) {

            final Array1D<ComplexNumber> tmpEigenvalues = myDelegateEigenvalue.getEigenvalues();

            final int tmpDim = tmpEigenvalues.length;

            mySingularValues = Array1D.makePrimitive(tmpDim);
            double tmpVal;
            for (int ij = 0; ij < tmpDim; ij++) {
                tmpVal = tmpEigenvalues.get(ij).getReal();
                if (tmpVal > PrimitiveMath.ZERO) {
                    mySingularValues.set(ij, StrictMath.sqrt(tmpVal));
                }
            }
            mySingularValues.sortDescending();
        }

        return mySingularValues;
    }

    public final boolean isFullSize() {
        return false;
    }

    public final boolean isOrdered() {
        return true;
    }

    public final boolean isSolvable() {
        return this.isComputed();
    }

    /**
     * @deprecated Use {@link #isOrdered()} instead
     */
    @Deprecated
    public final boolean isSorted() {
        return this.isOrdered();
    }

    @Override
    public final void reset() {

        super.reset();

        myDelegateEigenvalue.reset();

        myQ1Householders = null;
        myQ2Householders = null;
        mySimilar = null;

        myQ1 = null;
        myD = null;
        myQ2 = null;

        mySingularValues = null;
    }

    public final MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        return this.getInverse().multiplyRight(aRHS);
    }

    /**
     * Will solve the equation system [aV][aD][X]=[aSimilar]<sup>T</sup> and overwrite the solution [X] to [aV].
     */
    private void solve(final PhysicalStore<N> aV, final MatrixStore<N> aD, final DiagonalAccess<N> aSimilar) {

        final int tmpDim = aV.getRowDim();
        final int tmpLim = tmpDim - 1;

        double tmpSingular;
        for (int j = 0; j < tmpDim; j++) {
            tmpSingular = aD.doubleValue(j, j);
            if (TypeUtils.isZero(tmpSingular)) {
                for (int i = 0; i < tmpDim; i++) {
                    aV.set(i, j, myZero.doubleValue());
                }
            } else {
                for (int i = 0; i < tmpLim; i++) {
                    aV.set(i, j, (aSimilar.doubleValue(i, i) * aV.doubleValue(i, j) + aSimilar.doubleValue(i, i + 1) * aV.doubleValue(i + 1, j)) / tmpSingular);
                }
                aV.set(tmpLim, j, (aSimilar.doubleValue(tmpLim, tmpLim) * aV.doubleValue(tmpLim, j)) / tmpSingular);
            }
        }
    }

    private PhysicalStore<N> transform(final PhysicalStore<N> aV, final Householder<N>[] someTransformations) {

        final int tmpRowDim = someTransformations[0].size();
        final int tmpColDim = aV.getRowDim();

        if (tmpRowDim != tmpColDim) {

            final PhysicalStore<N> tmpI = this.getFactory().makeEye(tmpRowDim, tmpColDim);
            for (int j = tmpColDim - 1; j >= 0; j--) {
                tmpI.transformLeft(someTransformations[j], j);
            }
            return (PhysicalStore<N>) tmpI.multiplyRight(aV);

        } else {

            for (int j = tmpColDim - 1; j >= 0; j--) {
                aV.transformLeft(someTransformations[j], 0);
            }
            return aV;
        }
    }

    protected abstract DiagonalAccess<N> extractSimilar(PhysicalStore<N> aStore, boolean aNormalAspectRatio);

    protected abstract DiagonalAccess<N> makeTridiagonal(DiagonalAccess<N> aBidiagonal, boolean aNormalAspectRatio);

}
