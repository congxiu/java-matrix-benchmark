/*
 * Copyright © 2003 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.LowerTriangularStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.context.NumberContext;

public abstract class Chol0<N extends Number> extends CholeskyDecomposition<N> {

    static final class Big extends Chol0<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

    }

    static final class Complex extends Chol0<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

    }

    static final class Primitive extends Chol0<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

    }

    private boolean mySPD = false;
    private CholeskyDecomposition.Store<N> myStore;

    protected Chol0(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public boolean compute(final MatrixStore<N> aStore) {
        return this.compute(aStore, false);
    }

    public boolean computeWithCheck(final MatrixStore<N> aStore) {
        return this.compute(aStore, true);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public N getDeterminant() {

        Scalar<N> retVal = this.getFactory().getStaticOne();

        final int tmpDim = myStore.getMinDim();
        for (int ij = 0; ij < tmpDim; ij++) {
            retVal = retVal.multiply(myStore.toScalar(ij, ij).power(2).getNumber());
        }

        return retVal.getNumber();
    }

    public MatrixStore<N> getInverse() {
        return this.solve(this.getFactory().makeEye(myStore.getRowDim(), myStore.getColDim()));
    }

    public MatrixStore<N> getL() {
        return new LowerTriangularStore<N>(myStore, false);
    }

    public final boolean isFullSize() {
        return true;
    }

    public boolean isSolvable() {
        return this.isComputed() && mySPD;
    }

    public boolean isSPD() {
        return mySPD;
    }

    @Override
    public void reset() {

        super.reset();

        mySPD = false;
    }

    /**
     * Solves [this][X] = [aRHS] by first solving
     * <pre>[L][Y] = [aRHS]</pre>
     * and then
     * <pre>[U][X] = [Y]</pre>.
     * 
     * @param aRHS The right hand side
     * @return [X]
     */
    public MatrixStore<N> solve(final MatrixStore<N> aRHS) {

        final CholeskyDecomposition.Store<N> retVal = this.copy(aRHS);

        retVal.substituteForwards(myStore, false, false);

        retVal.substituteBackwards(myStore, false, true);

        return retVal;
    }

    private final boolean compute(final MatrixStore<N> aStore, final boolean checkForSPD) {

        this.reset();

        if ((myStore != null) && (myStore.getRowDim() == aStore.getRowDim()) && (myStore.getColDim() == aStore.getColDim())) {
            myStore.fillMatching(aStore);
        } else {
            myStore = this.copy(aStore);
        }

        mySPD = myStore.computeInPlaceCholesky(checkForSPD);

        return this.computed(true);
    }

    private final CholeskyDecomposition.Store<N> copy(final MatrixStore<N> aStore) {
        return (CholeskyDecomposition.Store<N>) this.getFactory().copy(aStore);
    }

}
