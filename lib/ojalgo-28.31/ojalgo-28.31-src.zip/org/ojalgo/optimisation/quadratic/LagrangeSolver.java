/* 
 * Copyright © 2003 Optimatika (www.optimatika.se)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
package org.ojalgo.optimisation.quadratic;

import org.ojalgo.RecoverableCondition;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.MergedColumnsStore;
import org.ojalgo.matrix.store.MergedRowsStore;
import org.ojalgo.matrix.store.SelectedRowsStore;
import org.ojalgo.matrix.store.TransposedStore;
import org.ojalgo.matrix.store.ZeroStore;
import org.ojalgo.optimisation.State;

/**
 * @author apete
 */
class LagrangeSolver extends QuadraticSolver {

    LagrangeSolver(final QuadraticSolver.Builder aBuilder) {
        super(aBuilder);
    }

    private QuadraticSolver buildIterationSolver() {

        final Matrices<?> tmpMatrices = this.getMatrices();

        if (tmpMatrices.hasEqualityConstraints()) {

            final int tmpZeroSize = tmpMatrices.getAE().getRowDim();

            final MatrixStore<Double> tmpUpperLeftAE = tmpMatrices.getQ();
            final MatrixStore<Double> tmpUpperRightAE = new TransposedStore<Double>(tmpMatrices.getAE());
            final MatrixStore<Double> tmpLowerLefAE = tmpMatrices.getAE();
            final MatrixStore<Double> tmpLowerRightAE = ZeroStore.makePrimitive(tmpZeroSize, tmpZeroSize);

            final MatrixStore<Double> tmpSubAE = new MergedColumnsStore<Double>(new MergedRowsStore<Double>(tmpUpperLeftAE, tmpUpperRightAE), new MergedRowsStore<Double>(tmpLowerLefAE, tmpLowerRightAE));

            final MatrixStore<Double> tmpUpperBE = tmpMatrices.getC();
            final MatrixStore<Double> tmpLowerBE = tmpMatrices.getBE();

            final MatrixStore<Double> tmpSubBE = new MergedColumnsStore<Double>(tmpUpperBE, tmpLowerBE);

            return new Builder().equalities(tmpSubAE, tmpSubBE).build();

        } else {

            return new Builder().equalities(tmpMatrices.getQ(), tmpMatrices.getC()).build();
        }
    }

    @Override
    protected void initialise() {
        ;
    }

    @Override
    protected boolean needsAnotherIteration() {
        return false;
    }

    @Override
    protected void performIteration() throws RecoverableCondition {

        final QuadraticSolver tmpSolver = this.buildIterationSolver();
        final Result tmpResult = tmpSolver.solve();

        final Matrices<?> tmpMatrices = this.getMatrices();
        if (tmpResult.getState().isNotLessThan(State.FEASIBLE)) {

            final int[] tmpSelectorX = MatrixUtils.makeIncreasingRange(0, tmpMatrices.countVariables());
            tmpMatrices.setX(new SelectedRowsStore<Double>(tmpSolver.getMatrices().getX(), tmpSelectorX));

            final int[] tmpSelectorLE = MatrixUtils.makeIncreasingRange(tmpSelectorX.length, tmpMatrices.countEqualityConstraints());
            tmpMatrices.setLE(new SelectedRowsStore<Double>(tmpSolver.getMatrices().getX(), tmpSelectorLE));

            this.setState(State.OPTIMAL);

        } else {

            tmpMatrices.setX(null);
            tmpMatrices.setLE(null);
            this.setState(State.INFEASIBLE);
        }

    }

}
