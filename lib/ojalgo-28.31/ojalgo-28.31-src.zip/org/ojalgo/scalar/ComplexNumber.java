/*
 * Copyright © 2003 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.scalar;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.MathContext;

import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.implementation.ComplexFunction;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * ComplexNumber is an immutable complex number class. It only
 * implements the most basic complex number operations.
 * {@linkplain org.ojalgo.function.implementation.ComplexFunction}
 * implements some of the more complicated ones.
 * 
 * @author apete
 * @see org.ojalgo.function.implementation.ComplexFunction
 */
public final class ComplexNumber extends AbstractScalar<ComplexNumber> {

    static final class Polar implements Representation {

        private final double myArg;
        private transient double myIm = PrimitiveMath.NaN;
        private final double myMod;
        private transient double myRe = PrimitiveMath.NaN;

        public Polar() {
            this(PrimitiveMath.ZERO, PrimitiveMath.ZERO);
        }

        public Polar(final double aMod, final double anArg) {

            super();

            myMod = aMod;
            myArg = anArg;
        }

        public double getArgument() {
            return myArg;
        }

        public double getImaginary() {

            if (Double.isNaN(myIm)) {

                myIm = PrimitiveMath.ZERO;

                if (myMod != PrimitiveMath.ZERO) {

                    final double tmpSin = StrictMath.sin(myArg);

                    if (tmpSin != PrimitiveMath.ZERO) {
                        myIm = myMod * tmpSin;
                    }
                }
            }

            return myIm;
        }

        public double getModulus() {
            return myMod;
        }

        public double getReal() {

            if (Double.isNaN(myRe)) {

                myRe = PrimitiveMath.ZERO;

                if (myMod != PrimitiveMath.ZERO) {

                    final double tmpCos = StrictMath.cos(myArg);

                    if (tmpCos != PrimitiveMath.ZERO) {
                        myRe = myMod * tmpCos;
                    }
                }
            }

            return myRe;
        }

        public boolean isInfinite() {
            return Double.isInfinite(myMod);
        }

        public boolean isNaN() {
            return Double.isNaN(myMod) || Double.isNaN(myArg);
        }

    }

    static final class Rectangular implements Representation {

        private transient double myArg = PrimitiveMath.NaN;
        private final double myIm;
        private transient double myMod = PrimitiveMath.NaN;
        private final double myRe;

        public Rectangular() {
            this(PrimitiveMath.ZERO, PrimitiveMath.ZERO);
        }

        public Rectangular(final double aRe, final double anIm) {

            super();

            myRe = aRe;
            myIm = anIm;
        }

        public double getArgument() {

            if (Double.isNaN(myArg)) {
                myArg = StrictMath.atan2(myIm, myRe);
            }

            return myArg;
        }

        public double getImaginary() {
            return myIm;
        }

        public double getModulus() {

            if (Double.isNaN(myMod)) {
                myMod = StrictMath.hypot(myRe, myIm);
            }

            return myMod;
        }

        public double getReal() {
            return myRe;
        }

        public boolean isInfinite() {
            return Double.isInfinite(myRe) || Double.isInfinite(myIm);
        }

        public boolean isNaN() {
            return Double.isNaN(myRe) || Double.isNaN(myIm);
        }

    }

    static interface Representation extends Serializable {

        double getArgument();

        double getImaginary();

        double getModulus();

        double getReal();

        boolean isInfinite();

        boolean isNaN();

    }

    public static final ComplexNumber I = ComplexNumber.fromRectangularCoordinates(PrimitiveMath.ZERO, PrimitiveMath.ONE);
    public static final ComplexNumber INFINITY = ComplexNumber.fromPolarCoordinates(Double.POSITIVE_INFINITY, PrimitiveMath.ZERO);
    public static final ComplexNumber ONE = ComplexNumber.fromRectangularCoordinates(PrimitiveMath.ONE, PrimitiveMath.ZERO);
    public static final ComplexNumber ZERO = ComplexNumber.fromRectangularCoordinates(PrimitiveMath.ZERO, PrimitiveMath.ZERO);

    private static final String LEFT = "(";
    private static final String MINUS = " - ";
    private static final String PLUS = " + ";
    private static final String RIGHT = "i)";

    public static ComplexNumber fromPolarCoordinates(final double aMod, final double anArg) {
        return new ComplexNumber(new Polar(aMod, anArg));
    }

    public static ComplexNumber fromRectangularCoordinates(final double aRe, final double anIm) {
        return new ComplexNumber(new Rectangular(aRe, anIm));
    }

    private final Representation myRep;

    public ComplexNumber(final double aRealValue) {

        super();

        myRep = new Rectangular(aRealValue, PrimitiveMath.ZERO);
    }

    @SuppressWarnings("unused")
    private ComplexNumber() {

        super();

        myRep = new Polar(PrimitiveMath.ZERO, PrimitiveMath.ZERO);
    }

    private ComplexNumber(final Representation aRep) {

        super();

        myRep = aRep;
    }

    public ComplexNumber add(final ComplexNumber aNumber) {

        final double retRe = myRep.getReal() + aNumber.getReal();
        final double retIm = myRep.getImaginary() + aNumber.getImaginary();

        return ComplexNumber.fromRectangularCoordinates(retRe, retIm);
    }

    public ComplexNumber add(final double aValue) {

        final double retRe = myRep.getReal() + aValue;
        final double retIm = myRep.getImaginary();

        return ComplexNumber.fromRectangularCoordinates(retRe, retIm);
    }

    public int compareTo(final ComplexNumber aNmbr) {
        return Double.compare(this.getModulus(), aNmbr.getModulus());
    }

    public ComplexNumber conjugate() {

        final double retRe = myRep.getReal();
        final double retIm = -myRep.getImaginary();

        return ComplexNumber.fromRectangularCoordinates(retRe, retIm);
    }

    public ComplexNumber divide(final ComplexNumber aNumber) {

        double retMod = PrimitiveMath.ZERO;

        final double tmpModThis = this.getModulus();
        final double tmpModNmbr = aNumber.getModulus();

        if (tmpModThis == tmpModNmbr) {
            retMod = PrimitiveMath.ONE;
        } else {
            retMod = tmpModThis / tmpModNmbr;
        }

        final double retArg = this.getArgument() - aNumber.getArgument();

        return ComplexNumber.fromPolarCoordinates(retMod, retArg);
    }

    public ComplexNumber divide(final double aValue) {

        final double retRe = myRep.getReal() / aValue;
        final double retIm = myRep.getImaginary() / aValue;

        return ComplexNumber.fromRectangularCoordinates(retRe, retIm);
    }

    /**
     * @see java.lang.Number#doubleValue()
     */
    @Override
    public double doubleValue() {
        return myRep.getReal();
    }

    /**
     * Will call {@linkplain NumberContext#enforce(double)} on the real
     * and imaginary parts separately.
     * 
     * @see org.ojalgo.scalar.Scalar#enforce(org.ojalgo.type.context.NumberContext)
     */
    public ComplexNumber enforce(final NumberContext aCntxt) {

        final double tmpRe = aCntxt.enforce(myRep.getReal());
        final double tmpIm = aCntxt.enforce(myRep.getImaginary());

        return ComplexNumber.fromRectangularCoordinates(tmpRe, tmpIm);
    }

    public boolean equals(final Scalar<?> aSclr) {
        return TypeUtils.isZero(myRep.getReal() - aSclr.getReal()) && TypeUtils.isZero(myRep.getImaginary() - aSclr.getImaginary());
    }

    /**
     * @see java.lang.Number#floatValue()
     */
    @Override
    public float floatValue() {
        return (float) myRep.getReal();
    }

    public double getArgument() {
        return myRep.getArgument();
    }

    public double getImaginary() {
        return myRep.getImaginary();
    }

    public double getModulus() {
        return myRep.getModulus();
    }

    public ComplexNumber getNumber() {
        return this;
    }

    public double getReal() {
        return myRep.getReal();
    }

    /**
     * @see java.lang.Number#intValue()
     */
    @Override
    public int intValue() {
        return (int) myRep.getReal();
    }

    public ComplexNumber invert() {
        return ComplexNumber.ONE.divide(this);
    }

    public boolean isInfinite() {
        return myRep.isInfinite();
    }

    public boolean isNaN() {
        return myRep.isNaN();
    }

    public boolean isReal() {
        return TypeUtils.isZero(myRep.getImaginary());
    }

    /**
     * @see java.lang.Number#longValue()
     */
    @Override
    public long longValue() {
        return (long) myRep.getReal();
    }

    public ComplexNumber multiply(final ComplexNumber aNumber) {

        ComplexNumber retVal = null;

        if (myRep.getImaginary() == PrimitiveMath.ZERO) {

            retVal = aNumber.multiply(this.getReal());

        } else if (aNumber.getImaginary() == PrimitiveMath.ZERO) {

            retVal = this.multiply(aNumber.getReal());

        } else {

            final double retMod = this.getModulus() * aNumber.getModulus();
            final double retArg = this.getArgument() + aNumber.getArgument();

            retVal = ComplexNumber.fromPolarCoordinates(retMod, retArg);
        }

        return retVal;
    }

    public ComplexNumber multiply(final double aValue) {

        final double retRe = myRep.getReal() * aValue;
        final double retIm = myRep.getImaginary() * aValue;

        return ComplexNumber.fromRectangularCoordinates(retRe, retIm);
    }

    public ComplexNumber negate() {

        final double retRe = -myRep.getReal();
        final double retIm = -myRep.getImaginary();

        return ComplexNumber.fromRectangularCoordinates(retRe, retIm);
    }

    public Scalar<ComplexNumber> power(final int anExp) {
        return ComplexFunction.POWER.invoke(this, anExp);
    }

    public ComplexNumber root(final int anExp) {
        return ComplexFunction.ROOT.invoke(this, anExp);
    }

    /**
     * Will call {@linkplain NumberContext#round(double)} on the real
     * and imaginary parts separately.
     * 
     * @see org.ojalgo.scalar.Scalar#enforce(org.ojalgo.type.context.NumberContext)
     */
    public ComplexNumber round(final NumberContext aCntxt) {

        final double tmpRe = aCntxt.round(myRep.getReal());
        final double tmpIm = aCntxt.round(myRep.getImaginary());

        return ComplexNumber.fromRectangularCoordinates(tmpRe, tmpIm);
    }

    public ComplexNumber signum() {
        if (this.isZero()) {
            return ComplexNumber.ZERO;
        } else {
            return ComplexNumber.fromPolarCoordinates(PrimitiveMath.ONE, myRep.getArgument());
        }
    }

    public ComplexNumber subtract(final ComplexNumber aNumber) {

        final double retRe = myRep.getReal() - aNumber.getReal();
        final double retIm = myRep.getImaginary() - aNumber.getImaginary();

        return ComplexNumber.fromRectangularCoordinates(retRe, retIm);
    }

    public ComplexNumber subtract(final double aValue) {

        final double retRe = myRep.getReal() - aValue;
        final double retIm = myRep.getImaginary();

        return ComplexNumber.fromRectangularCoordinates(retRe, retIm);
    }

    public BigDecimal toBigDecimal() {
        return new BigDecimal(myRep.getReal(), MathContext.DECIMAL64);
    }

    public ComplexNumber toComplexNumber() {
        return this;
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {

        final StringBuilder retVal = new StringBuilder(LEFT);

        final double tmpIm = myRep.getImaginary();

        retVal.append(myRep.getReal());

        if (tmpIm < PrimitiveMath.ZERO) {
            retVal.append(MINUS).append(-tmpIm);
        } else {
            retVal.append(PLUS).append(tmpIm);
        }

        return retVal.append(RIGHT).toString();
    }

}
