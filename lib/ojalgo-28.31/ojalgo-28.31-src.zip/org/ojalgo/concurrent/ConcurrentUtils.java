/*
 * Copyright © 2009 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.concurrent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;

public abstract class ConcurrentUtils implements ExecutorService {

    /**
     * An {@linkplain ExecutorService} to be used when forking algorithms.
     * It has the following properties:
     * <ul>
     * <li>
     * The number of simultaneous jobs is not limitied. Which means there
     * is no problem to submit nested jobs (jobs that themselves submit
     * jobs). It is, however, strongly recommended to somehow
     * control/limit the number of submitted jobs.
     * </li><li>
     * New threads are created as needed. Jobs are never waiting in a 
     * queue.
     * </li><li>
     * There are no guarantees regarding in which order jobs are started
     * or end.
     * </li><li>
     * A minimum of 1 thread is always kept alive idle even if there are no jobs.
     * </li>
     * </ul>
     * <p>
     * This {@linkplain ExecutorService} is used all the time by ojAlgo,
     * for all sorts of things, and you're welocome to use it for other things.
     * </p><p>
     * Since this is a {@linkplain ThreadPoolExecutor} instance with a
     * non-zero core pool size your program has to be terminated actively
     * -
     * you have to "quit" your program.
     * </p>
     */
    public static final ThreadPoolExecutor EXECUTOR = new DaemonPoolExecutor();

    /**
     * @see Runtime#availableProcessors()
     */
    public static final int AVAILABLE_PROCESSORS = ConcurrentUtils.getAvailableProcessors();

    public static int getCorePoolSize() {
        return (int) StrictMath.sqrt(Runtime.getRuntime().availableProcessors());
    }

    public static boolean isProcessorAvailable() {
        return (EXECUTOR.getPoolSize() < (2 * AVAILABLE_PROCESSORS)) && (EXECUTOR.getActiveCount() < AVAILABLE_PROCESSORS);
    }

    private static int getAvailableProcessors() {
        return Runtime.getRuntime().availableProcessors();
    }

    private ConcurrentUtils() {
        super();
    }

}
