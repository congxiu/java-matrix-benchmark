/*
 * Copyright © 2007 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import static org.ojalgo.constant.PrimitiveMath.*;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.concurrent.Future;

import org.ojalgo.ProgrammingError;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.PreconfiguredSecond;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.ComplexAggregator;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.jama.JamaEigenvalue;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

public abstract class EigenvalueDecomposition<N extends Number> extends AbstractDecomposition<N> implements Eigenvalue<N> {

    static final class Big extends EigenvalueDecomposition<BigDecimal> {

        private static final PhysicalStore.Factory<BigDecimal> BIG = BigDenseStore.FACTORY;
        private static final PhysicalStore.Factory<Double> PRIMITIVE = PrimitiveDenseStore.FACTORY;

        private final Eigenvalue<Double> myDelegate = new Primitive();

        Big() {
            super(BigDenseStore.FACTORY);
        }

        public boolean computeNonsymmetric(final MatrixStore<BigDecimal> aNonsymmetricStore) {

            final boolean retVal = myDelegate.computeNonsymmetric(PRIMITIVE.copy(aNonsymmetricStore));

            this.setEigenvalues(myDelegate.getEigenvalues());
            this.setD(BIG.copy(myDelegate.getD()));
            this.setV(BIG.copy(myDelegate.getV()));

            return retVal;
        }

        public boolean computeSymmetric(final MatrixStore<BigDecimal> aSymmetricStore) {

            final boolean retVal = myDelegate.computeSymmetric(PRIMITIVE.copy(aSymmetricStore));

            this.setEigenvalues(myDelegate.getEigenvalues());
            this.setD(BIG.copy(myDelegate.getD()));
            this.setV(BIG.copy(myDelegate.getV()));

            return retVal;
        }

        @Override
        public boolean equals(final MatrixDecomposition<BigDecimal> aDecomp, final NumberContext aCntxt) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public boolean isComputed() {
            return myDelegate.isComputed();
        }

        @Override
        public void reset() {
            myDelegate.reset();
        }

        public MatrixStore<BigDecimal> solve(final MatrixStore<BigDecimal> aRHS) {
            return BIG.copy(myDelegate.solve(PRIMITIVE.copy(aRHS)));
        }

        /**
         * @see org.ojalgo.matrix.decomposition.MatrixDecomposition#solve(org.ojalgo.matrix.store.MatrixStore, org.ojalgo.matrix.store.MatrixStore)
         * @deprecated Can't use this method!
         */
        @Override
        @Deprecated
        public Future<DecomposeAndSolve<BigDecimal>> solve(final MatrixStore<BigDecimal> aBody, final MatrixStore<BigDecimal> aRHS) {
            ProgrammingError.throwForIllegalInvocation();
            return null;
        }

        @Override
        boolean compute(final DiagonalAccess<BigDecimal> aTridiagonalSymmetricStore) {
            return myDelegate.computeSymmetric(PRIMITIVE.copy(aTridiagonalSymmetricStore));
        }

    }

    static final class Complex extends EigenvalueDecomposition<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

        public boolean computeNonsymmetric(final MatrixStore<ComplexNumber> aNonsymmetricStore) {
            // TODO Auto-generated method stub
            return false;
        }

        public boolean computeSymmetric(final MatrixStore<ComplexNumber> aSymmetricStore) {
            // TODO Auto-generated method stub
            return false;
        }

        public MatrixStore<ComplexNumber> solve(final MatrixStore<ComplexNumber> aRHS) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        boolean compute(final DiagonalAccess<ComplexNumber> aTridiagonalSymmetricStore) {
            // TODO Auto-generated method stub
            return false;
        }

    }

    /** Eigenvalues and eigenvectors of a real matrix. 
     <P>
     If A is symmetric, then A = V*D*V' where the eigenvalue matrix D is
     diagonal and the eigenvector matrix V is orthogonal.
     I.e. A = V.times(D.times(V.transpose())) and 
     V.times(V.transpose()) equals the identity matrix.
     <P>
     If A is not symmetric, then the eigenvalue matrix D is block diagonal
     with the real eigenvalues in 1-by-1 blocks and any complex eigenvalues,
     lambda + i*mu, in 2-by-2 blocks, [lambda, mu; -mu, lambda].  The
     columns of V represent the eigenvectors in the sense that A*V = V*D,
     i.e. A.times(V) equals V.times(D).  The matrix V may be badly
     conditioned, or even singular, so the validity of the equation
     A = V*D*inverse(V) depends upon V.cond().
     **/
    static final class Primitive extends EigenvalueDecomposition<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

        public boolean computeNonsymmetric(final MatrixStore<Double> aNonsymmetricStore) {

            this.setSymmetric(false);

            final int tmpDim = aNonsymmetricStore.getMinDim();

            final double[] tmpMainDiagonal = new double[tmpDim];
            final double[] tmpOffDiagonal = new double[tmpDim];
            final double[][] tmpV = new double[tmpDim][tmpDim];
            final double[][] tmpH = aNonsymmetricStore.toRawCopy();

            EigenvalueDecomposition.reduceToHessenbergForm(tmpMainDiagonal, tmpOffDiagonal, tmpV, tmpH);

            EigenvalueDecomposition.reduceHessenbergToRealSchurForm(tmpMainDiagonal, tmpOffDiagonal, tmpV, tmpH);

            this.setEigenvaluesAndD(tmpMainDiagonal, tmpOffDiagonal);
            this.setV(this.getFactory().copy(tmpV));

            return this.computed(true);
        }

        public boolean computeSymmetric(final MatrixStore<Double> aSymmetricStore) {

            this.setSymmetric(true);

            if (DEBUG) {
                MatrixUtils.printToStream(BasicLogger.DEBUG, aSymmetricStore, TypeUtils.EQUALS_NUMBER_CONTEXT);
            }

            final int tmpDim = aSymmetricStore.getMinDim();

            final double[] tmpMainDiagonal = new double[tmpDim];
            final double[] tmpOffDiagonal = new double[tmpDim];
            final double[][] tmpRawV = aSymmetricStore.toRawCopy();

            EigenvalueDecomposition.tridiagonalize(tmpMainDiagonal, tmpOffDiagonal, tmpRawV);

            EigenvalueDecomposition.packSecondaryDiagonal(tmpOffDiagonal);

            final PhysicalStore<Double> tmpV = this.getFactory().copy(tmpRawV);

            EigenvalueDecomposition.diagonalize(tmpMainDiagonal, tmpOffDiagonal, tmpV);

            EigenvalueDecomposition.sortEigenvaluesAndVectors(tmpMainDiagonal, tmpV);

            this.setEigenvaluesAndD(tmpMainDiagonal, tmpOffDiagonal);
            this.setV(tmpV);

            return this.computed(true);
        }

        public MatrixStore<Double> solve(final MatrixStore<Double> aRHS) {
            return this.getInverse().multiplyRight(aRHS);
        }

        private void setEigenvaluesAndD(final double[] aMainDiagonal, final double[] anOffDiagonal) {

            final int tmpDim = aMainDiagonal.length;

            final Array1D<ComplexNumber> tmpEigenvalues = Array1D.makeComplex(tmpDim);
            final PhysicalStore<Double> tmpD = PrimitiveDenseStore.FACTORY.makeZero(tmpDim, tmpDim);

            double tmpMainDiag;
            double tmpOffDiag;
            for (int ij = 0; ij < tmpDim; ij++) {

                tmpMainDiag = aMainDiagonal[ij];
                tmpOffDiag = anOffDiagonal[ij];

                tmpEigenvalues.set(ij, ComplexNumber.fromRectangularCoordinates(tmpMainDiag, tmpOffDiag));

                tmpD.set(ij, ij, tmpMainDiag);
                if (tmpOffDiag > ZERO) {
                    tmpD.set(ij, ij + 1, tmpOffDiag);
                } else if (tmpOffDiag < ZERO) {
                    tmpD.set(ij, ij - 1, tmpOffDiag);
                }
            }

            tmpEigenvalues.sortDescending();

            this.setEigenvalues(tmpEigenvalues);
            this.setD(tmpD);
        }

        @Override
        boolean compute(final DiagonalAccess<Double> aTridiagonalSymmetricStore) {

            this.setSymmetric(true);

            final int tmpDim = aTridiagonalSymmetricStore.getMinDim();

            final double[] tmpMainDiagonal = aTridiagonalSymmetricStore.mainDiagonal.toRawCopy();

            // Fungerar inte eftersom diagonalize kräver att myOffDiagonal är lika lång som myMainDiagonal
            //myOffDiagonal = aTridiagonalSymmetricStore.superdiagonal.toRawCopy();
            // Måste göra så här istället
            final double[] tmpOffDiagonal = new double[tmpDim];
            for (int i = 0; i < tmpDim - 1; i++) {
                tmpOffDiagonal[i] = aTridiagonalSymmetricStore.superdiagonal.doubleValue(i);
            }

            final PhysicalStore<Double> tmpV = PrimitiveDenseStore.FACTORY.makeEye(tmpDim, tmpDim);

            EigenvalueDecomposition.diagonalize(tmpMainDiagonal, tmpOffDiagonal, tmpV);

            EigenvalueDecomposition.sortEigenvaluesAndVectors(tmpMainDiagonal, tmpV);

            this.setEigenvaluesAndD(tmpMainDiagonal, tmpOffDiagonal);
            this.setV(tmpV);

            return this.computed(true);
        }

    }

    static final double EPSILON = Math.pow(2.0, -52.0);

    /**
     * @return A BigDecimal adapter to PrimitiveEigenvalue.
     */
    public static final Eigenvalue<BigDecimal> makeBig() {
        return new Big();
    }

    public static final Eigenvalue<Double> makeJama() {
        return new JamaEigenvalue();
    }

    public static final Eigenvalue<Double> makePrimitive() {
        return new Primitive();
    }

    static void diagonalize(final double[] aMainDiagonal, final double[] aSecondaryDiagonal, final PhysicalStore<Double> aMtrxV) {

        if (DEBUG) {
            BasicLogger.logDebug("BEGIN diagonalize");
            BasicLogger.logDebug("Main D: {}", Arrays.toString(aMainDiagonal));
            BasicLogger.logDebug("Seco D: {}", Arrays.toString(aSecondaryDiagonal));
            BasicLogger.logDebug("V", aMtrxV);
            BasicLogger.logDebug();
        }

        final int tmpDim = aMainDiagonal.length;

        double tmpShift = ZERO;
        double tmpShiftIncr;

        double tmpTestVal = ZERO;
        int m;

        // Main loop
        for (int l = 0; l < tmpDim; l++) {

            // Find small subdiagonal element
            tmpTestVal = Math.max(tmpTestVal, Math.abs(aMainDiagonal[l]) + Math.abs(aSecondaryDiagonal[l]));
            m = l;
            while (m < tmpDim) {
                if (Math.abs(aSecondaryDiagonal[m]) <= EigenvalueDecomposition.EPSILON * tmpTestVal) {
                    break;
                }
                m++;
            }

            // If m == l, aMainDiagonal[l] is an eigenvalue, otherwise, iterate.
            if (m > l) {

                do {

                    final double tmp1Ml0 = aMainDiagonal[l];
                    final double tmp1Ml1 = aMainDiagonal[l + 1];
                    final double tmp1Sl0 = aSecondaryDiagonal[l];

                    // Compute implicit shift

                    double p = (tmp1Ml1 - tmp1Ml0) / (TWO * tmp1Sl0);
                    double r = Math.hypot(p, ONE);
                    if (p < 0) {
                        r = -r;
                    }

                    final double tmp2Ml0 = aMainDiagonal[l] = tmp1Sl0 / (p + r);
                    final double tmp2Ml1 = aMainDiagonal[l + 1] = tmp1Sl0 * (p + r);
                    final double tmp2Sl1 = aSecondaryDiagonal[l + 1];

                    tmpShiftIncr = tmp1Ml0 - tmp2Ml0;
                    for (int i = l + 2; i < tmpDim; i++) {
                        aMainDiagonal[i] -= tmpShiftIncr;
                    }
                    tmpShift += tmpShiftIncr;

                    // Implicit QL transformation

                    double tmpRotCos = ONE;
                    double tmpRotSin = ZERO;

                    double tmpRotCos2 = tmpRotCos;
                    double tmpRotSin2 = ZERO;

                    double tmpRotCos3 = tmpRotCos;

                    p = aMainDiagonal[m]; // Initiate p
                    for (int i = m - 1; i >= l; i--) {

                        final double tmp1Mi0 = aMainDiagonal[i];
                        final double tmp1Si0 = aSecondaryDiagonal[i];

                        r = Math.hypot(p, tmp1Si0);

                        tmpRotCos3 = tmpRotCos2;

                        tmpRotCos2 = tmpRotCos;
                        tmpRotSin2 = tmpRotSin;

                        tmpRotCos = p / r;
                        tmpRotSin = tmp1Si0 / r;

                        aMainDiagonal[i + 1] = tmpRotCos2 * p + tmpRotSin * (tmpRotCos * tmpRotCos2 * tmp1Si0 + tmpRotSin * tmp1Mi0);
                        aSecondaryDiagonal[i + 1] = tmpRotSin2 * r;

                        p = tmpRotCos * tmp1Mi0 - tmpRotSin * tmpRotCos2 * tmp1Si0; // Next p

                        // Accumulate transformation - rotate the eigenvector matrix
                        aMtrxV.transformRight(new Rotation<Double>(i, i + 1, tmpRotCos, tmpRotSin));
                    }

                    p = -tmpRotSin * tmpRotSin2 * tmpRotCos3 * tmp2Sl1 * aSecondaryDiagonal[l] / tmp2Ml1; // Final p

                    aMainDiagonal[l] = tmpRotCos * p;
                    aSecondaryDiagonal[l] = tmpRotSin * p;

                } while (Math.abs(aSecondaryDiagonal[l]) > EigenvalueDecomposition.EPSILON * tmpTestVal); // Check for convergence
            } // End if (m > l)

            final double tmpEigenvalue = aMainDiagonal[l] + tmpShift;
            if (TypeUtils.isZero(tmpEigenvalue)) {
                aMainDiagonal[l] = ZERO;
            } else {
                aMainDiagonal[l] = tmpEigenvalue;
            }
            aSecondaryDiagonal[l] = ZERO;
        } // End main loop - l

        if (DEBUG) {
            BasicLogger.logDebug("END diagonalize");
            BasicLogger.logDebug("Main D: {}", Arrays.toString(aMainDiagonal));
            BasicLogger.logDebug("Seco D: {}", Arrays.toString(aSecondaryDiagonal));
            BasicLogger.logDebug("V", aMtrxV);
            BasicLogger.logDebug();
        }
    }

    static void packSecondaryDiagonal(final double[] aSecondaryDiagonal) {

        final int tmpDim = aSecondaryDiagonal.length;

        for (int i = 1; i < tmpDim; i++) {
            aSecondaryDiagonal[i - 1] = aSecondaryDiagonal[i];
        }
        aSecondaryDiagonal[tmpDim - 1] = ZERO;
    }

    static void reduceHessenbergToRealSchurForm(final double[] aMainDiagonal, final double[] aSecondaryDiagonal, final double[][] V, final double[][] H) {

        //  This is derived from the Algol procedure hqr2,
        //  by Martin and Wilkinson, Handbook for Auto. Comp.,
        //  Vol.ii-Linear Algebra, and the corresponding
        //  Fortran subroutine in EISPACK.

        // Initialize

        final int nn = aMainDiagonal.length;
        int n = nn - 1;
        final int low = 0;
        final int high = nn - 1;
        double exshift = ZERO;
        double p = 0, q = 0, r = 0, s = 0, z = 0, t, w, x, y;

        // Store roots isolated by balanc and compute matrix norm

        double norm = ZERO;
        for (int i = 0; i < nn; i++) {
            if ((i < low) | (i > high)) {
                aMainDiagonal[i] = H[i][i];
                aSecondaryDiagonal[i] = ZERO;
            }
            for (int j = Math.max(i - 1, 0); j < nn; j++) {
                norm = norm + Math.abs(H[i][j]);
            }
        }

        // Outer loop over eigenvalue index

        int iter = 0;
        while (n >= low) {

            // Look for single small sub-diagonal element

            int l = n;
            while (l > low) {
                s = Math.abs(H[l - 1][l - 1]) + Math.abs(H[l][l]);
                if (s == ZERO) {
                    s = norm;
                }
                if (Math.abs(H[l][l - 1]) < EigenvalueDecomposition.EPSILON * s) {
                    break;
                }
                l--;
            }

            // Check for convergence
            // One root found

            if (l == n) {
                H[n][n] = H[n][n] + exshift;
                aMainDiagonal[n] = H[n][n];
                aSecondaryDiagonal[n] = ZERO;
                n--;
                iter = 0;

                // Two roots found

            } else if (l == n - 1) {
                w = H[n][n - 1] * H[n - 1][n];
                p = (H[n - 1][n - 1] - H[n][n]) / 2.0;
                q = p * p + w;
                z = Math.sqrt(Math.abs(q));
                H[n][n] = H[n][n] + exshift;
                H[n - 1][n - 1] = H[n - 1][n - 1] + exshift;
                x = H[n][n];

                // Real pair

                if (q >= 0) {
                    if (p >= 0) {
                        z = p + z;
                    } else {
                        z = p - z;
                    }
                    aMainDiagonal[n - 1] = x + z;
                    aMainDiagonal[n] = aMainDiagonal[n - 1];
                    if (z != ZERO) {
                        aMainDiagonal[n] = x - w / z;
                    }
                    aSecondaryDiagonal[n - 1] = ZERO;
                    aSecondaryDiagonal[n] = ZERO;
                    x = H[n][n - 1];
                    s = Math.abs(x) + Math.abs(z);
                    p = x / s;
                    q = z / s;
                    r = Math.sqrt(p * p + q * q);
                    p = p / r;
                    q = q / r;

                    // Row modification

                    for (int j = n - 1; j < nn; j++) {
                        z = H[n - 1][j];
                        H[n - 1][j] = q * z + p * H[n][j];
                        H[n][j] = q * H[n][j] - p * z;
                    }

                    // Column modification

                    for (int i = 0; i <= n; i++) {
                        z = H[i][n - 1];
                        H[i][n - 1] = q * z + p * H[i][n];
                        H[i][n] = q * H[i][n] - p * z;
                    }

                    // Accumulate transformations

                    for (int i = low; i <= high; i++) {
                        z = V[i][n - 1];
                        V[i][n - 1] = q * z + p * V[i][n];
                        V[i][n] = q * V[i][n] - p * z;
                    }

                    // Complex pair

                } else {
                    aMainDiagonal[n - 1] = x + p;
                    aMainDiagonal[n] = x + p;
                    aSecondaryDiagonal[n - 1] = z;
                    aSecondaryDiagonal[n] = -z;
                }
                n = n - 2;
                iter = 0;

                // No convergence yet

            } else {

                // Form shift

                x = H[n][n];
                y = ZERO;
                w = ZERO;
                if (l < n) {
                    y = H[n - 1][n - 1];
                    w = H[n][n - 1] * H[n - 1][n];
                }

                // Wilkinson's original ad hoc shift

                if (iter == 10) {
                    exshift += x;
                    for (int i = low; i <= n; i++) {
                        H[i][i] -= x;
                    }
                    s = Math.abs(H[n][n - 1]) + Math.abs(H[n - 1][n - 2]);
                    x = y = 0.75 * s;
                    w = -0.4375 * s * s;
                }

                // MATLAB's new ad hoc shift

                if (iter == 30) {
                    s = (y - x) / 2.0;
                    s = s * s + w;
                    if (s > 0) {
                        s = Math.sqrt(s);
                        if (y < x) {
                            s = -s;
                        }
                        s = x - w / ((y - x) / 2.0 + s);
                        for (int i = low; i <= n; i++) {
                            H[i][i] -= s;
                        }
                        exshift += s;
                        x = y = w = 0.964;
                    }
                }

                iter = iter + 1; // (Could check iteration count here.)

                // Look for two consecutive small sub-diagonal elements

                int m = n - 2;
                while (m >= l) {
                    z = H[m][m];
                    r = x - z;
                    s = y - z;
                    p = (r * s - w) / H[m + 1][m] + H[m][m + 1];
                    q = H[m + 1][m + 1] - z - r - s;
                    r = H[m + 2][m + 1];
                    s = Math.abs(p) + Math.abs(q) + Math.abs(r);
                    p = p / s;
                    q = q / s;
                    r = r / s;
                    if (m == l) {
                        break;
                    }
                    if (Math.abs(H[m][m - 1]) * (Math.abs(q) + Math.abs(r)) < EigenvalueDecomposition.EPSILON * (Math.abs(p) * (Math.abs(H[m - 1][m - 1]) + Math.abs(z) + Math.abs(H[m + 1][m + 1])))) {
                        break;
                    }
                    m--;
                }

                for (int i = m + 2; i <= n; i++) {
                    H[i][i - 2] = ZERO;
                    if (i > m + 2) {
                        H[i][i - 3] = ZERO;
                    }
                }

                // Double QR step involving rows l:n and columns m:n

                for (int k = m; k <= n - 1; k++) {
                    final boolean notlast = (k != n - 1);
                    if (k != m) {
                        p = H[k][k - 1];
                        q = H[k + 1][k - 1];
                        r = (notlast ? H[k + 2][k - 1] : ZERO);
                        x = Math.abs(p) + Math.abs(q) + Math.abs(r);
                        if (x != ZERO) {
                            p = p / x;
                            q = q / x;
                            r = r / x;
                        }
                    }
                    if (x == ZERO) {
                        break;
                    }
                    s = Math.sqrt(p * p + q * q + r * r);
                    if (p < 0) {
                        s = -s;
                    }
                    if (s != 0) {
                        if (k != m) {
                            H[k][k - 1] = -s * x;
                        } else if (l != m) {
                            H[k][k - 1] = -H[k][k - 1];
                        }
                        p = p + s;
                        x = p / s;
                        y = q / s;
                        z = r / s;
                        q = q / p;
                        r = r / p;

                        // Row modification

                        for (int j = k; j < nn; j++) {
                            p = H[k][j] + q * H[k + 1][j];
                            if (notlast) {
                                p = p + r * H[k + 2][j];
                                H[k + 2][j] = H[k + 2][j] - p * z;
                            }
                            H[k][j] = H[k][j] - p * x;
                            H[k + 1][j] = H[k + 1][j] - p * y;
                        }

                        // Column modification

                        for (int i = 0; i <= Math.min(n, k + 3); i++) {
                            p = x * H[i][k] + y * H[i][k + 1];
                            if (notlast) {
                                p = p + z * H[i][k + 2];
                                H[i][k + 2] = H[i][k + 2] - p * r;
                            }
                            H[i][k] = H[i][k] - p;
                            H[i][k + 1] = H[i][k + 1] - p * q;
                        }

                        // Accumulate transformations

                        for (int i = low; i <= high; i++) {
                            p = x * V[i][k] + y * V[i][k + 1];
                            if (notlast) {
                                p = p + z * V[i][k + 2];
                                V[i][k + 2] = V[i][k + 2] - p * r;
                            }
                            V[i][k] = V[i][k] - p;
                            V[i][k + 1] = V[i][k + 1] - p * q;
                        }
                    } // (s != 0)
                } // k loop
            } // check convergence
        } // while (n >= low)

        // Backsubstitute to find vectors of upper triangular form

        if (norm == ZERO) {
            return;
        }

        for (n = nn - 1; n >= 0; n--) {
            p = aMainDiagonal[n];
            q = aSecondaryDiagonal[n];

            // Real vector

            if (q == 0) {
                int l = n;
                H[n][n] = 1.0;
                for (int i = n - 1; i >= 0; i--) {
                    w = H[i][i] - p;
                    r = ZERO;
                    for (int j = l; j <= n; j++) {
                        r = r + H[i][j] * H[j][n];
                    }
                    if (aSecondaryDiagonal[i] < ZERO) {
                        z = w;
                        s = r;
                    } else {
                        l = i;
                        if (aSecondaryDiagonal[i] == ZERO) {
                            if (w != ZERO) {
                                H[i][n] = -r / w;
                            } else {
                                H[i][n] = -r / (EigenvalueDecomposition.EPSILON * norm);
                            }

                            // Solve real equations

                        } else {
                            x = H[i][i + 1];
                            y = H[i + 1][i];
                            q = (aMainDiagonal[i] - p) * (aMainDiagonal[i] - p) + aSecondaryDiagonal[i] * aSecondaryDiagonal[i];
                            t = (x * s - z * r) / q;
                            H[i][n] = t;
                            if (Math.abs(x) > Math.abs(z)) {
                                H[i + 1][n] = (-r - w * t) / x;
                            } else {
                                H[i + 1][n] = (-s - y * t) / z;
                            }
                        }

                        // Overflow control

                        t = Math.abs(H[i][n]);
                        if ((EigenvalueDecomposition.EPSILON * t) * t > 1) {
                            for (int j = i; j <= n; j++) {
                                H[j][n] = H[j][n] / t;
                            }
                        }
                    }
                }

                // Complex vector

            } else if (q < 0) {
                int l = n - 1;

                // Last vector component imaginary so matrix is triangular

                if (Math.abs(H[n][n - 1]) > Math.abs(H[n - 1][n])) {
                    H[n - 1][n - 1] = q / H[n][n - 1];
                    H[n - 1][n] = -(H[n][n] - p) / H[n][n - 1];
                } else {

                    final ComplexNumber tmpX = ComplexNumber.fromRectangularCoordinates(ZERO, (-H[n - 1][n]));
                    final ComplexNumber tmpY = ComplexNumber.fromRectangularCoordinates((H[n - 1][n - 1] - p), q);

                    final ComplexNumber tmpZ = tmpX.divide(tmpY);

                    H[n - 1][n - 1] = tmpZ.getReal();
                    H[n - 1][n] = tmpZ.getImaginary();
                }
                H[n][n - 1] = ZERO;
                H[n][n] = 1.0;
                for (int i = n - 2; i >= 0; i--) {
                    double ra, sa, vr, vi;
                    ra = ZERO;
                    sa = ZERO;
                    for (int j = l; j <= n; j++) {
                        ra = ra + H[i][j] * H[j][n - 1];
                        sa = sa + H[i][j] * H[j][n];
                    }
                    w = H[i][i] - p;

                    if (aSecondaryDiagonal[i] < ZERO) {
                        z = w;
                        r = ra;
                        s = sa;
                    } else {
                        l = i;
                        if (aSecondaryDiagonal[i] == 0) {
                            final ComplexNumber tmpX = ComplexNumber.fromRectangularCoordinates((-ra), (-sa));
                            final ComplexNumber tmpY = ComplexNumber.fromRectangularCoordinates(w, q);

                            final ComplexNumber tmpZ = tmpX.divide(tmpY);

                            H[i][n - 1] = tmpZ.getReal();
                            H[i][n] = tmpZ.getImaginary();
                        } else {

                            // Solve complex equations

                            x = H[i][i + 1];
                            y = H[i + 1][i];
                            vr = (aMainDiagonal[i] - p) * (aMainDiagonal[i] - p) + aSecondaryDiagonal[i] * aSecondaryDiagonal[i] - q * q;
                            vi = (aMainDiagonal[i] - p) * 2.0 * q;
                            if ((vr == ZERO) & (vi == ZERO)) {
                                vr = EigenvalueDecomposition.EPSILON * norm * (Math.abs(w) + Math.abs(q) + Math.abs(x) + Math.abs(y) + Math.abs(z));
                            }

                            final ComplexNumber tmpX = ComplexNumber.fromRectangularCoordinates((x * r - z * ra + q * sa), (x * s - z * sa - q * ra));
                            final ComplexNumber tmpY = ComplexNumber.fromRectangularCoordinates(vr, vi);

                            final ComplexNumber tmpZ = tmpX.divide(tmpY);

                            H[i][n - 1] = tmpZ.getReal();
                            H[i][n] = tmpZ.getImaginary();

                            if (Math.abs(x) > (Math.abs(z) + Math.abs(q))) {
                                H[i + 1][n - 1] = (-ra - w * H[i][n - 1] + q * H[i][n]) / x;
                                H[i + 1][n] = (-sa - w * H[i][n] - q * H[i][n - 1]) / x;
                            } else {
                                final ComplexNumber tmpX1 = ComplexNumber.fromRectangularCoordinates((-r - y * H[i][n - 1]), (-s - y * H[i][n]));
                                final ComplexNumber tmpY1 = ComplexNumber.fromRectangularCoordinates(z, q);

                                final ComplexNumber tmpZ1 = tmpX1.divide(tmpY1);

                                H[i + 1][n - 1] = tmpZ1.getReal();
                                H[i + 1][n] = tmpZ1.getImaginary();
                            }
                        }

                        // Overflow control

                        t = Math.max(Math.abs(H[i][n - 1]), Math.abs(H[i][n]));
                        if ((EigenvalueDecomposition.EPSILON * t) * t > 1) {
                            for (int j = i; j <= n; j++) {
                                H[j][n - 1] = H[j][n - 1] / t;
                                H[j][n] = H[j][n] / t;
                            }
                        }
                    }
                }
            }
        }

        // Vectors of isolated roots

        for (int i = 0; i < nn; i++) {
            if ((i < low) | (i > high)) {
                for (int j = i; j < nn; j++) {
                    V[i][j] = H[i][j];
                }
            }
        }

        // Back transformation to get eigenvectors of original matrix

        for (int j = nn - 1; j >= low; j--) {
            for (int i = low; i <= high; i++) {
                z = ZERO;
                for (int k = low; k <= Math.min(j, high); k++) {
                    z = z + V[i][k] * H[k][j];
                }
                V[i][j] = z;
            }
        }
    }

    static void reduceToHessenbergForm(final double[] myEigenvaluesRealPart, final double[] myEigenvaluesImaginaryPart, final double[][] V, final double[][] H) {

        //        BasicLogger.logDebug("v.re: {}", myEigenvaluesRealPart);
        //        BasicLogger.logDebug("v.im: {}", myEigenvaluesImaginaryPart);

        final int n = myEigenvaluesRealPart.length;

        final double[] ort = new double[n];
        //  This is derived from the Algol procedures orthes and ortran,
        //  by Martin and Wilkinson, Handbook for Auto. Comp.,
        //  Vol.ii-Linear Algebra, and the corresponding
        //  Fortran subroutines in EISPACK.

        final int low = 0;
        final int high = n - 1;

        for (int m = low + 1; m <= high - 1; m++) {

            // Scale column.

            double scale = ZERO;
            for (int i = m; i <= high; i++) {
                scale = scale + Math.abs(H[i][m - 1]);
            }
            if (scale != ZERO) {

                // Compute Householder transformation.

                double h = ZERO;
                for (int i = high; i >= m; i--) {
                    ort[i] = H[i][m - 1] / scale;
                    h += ort[i] * ort[i];
                }
                double g = Math.sqrt(h);
                if (ort[m] > 0) {
                    g = -g;
                }
                h = h - ort[m] * g;
                ort[m] = ort[m] - g;

                // Apply Householder similarity transformation
                // H = (I-u*u'/h)*H*(I-u*u')/h)

                for (int j = m; j < n; j++) {
                    double f = ZERO;
                    for (int i = high; i >= m; i--) {
                        f += ort[i] * H[i][j];
                    }
                    f = f / h;
                    for (int i = m; i <= high; i++) {
                        H[i][j] -= f * ort[i];
                    }
                }

                for (int i = 0; i <= high; i++) {
                    double f = ZERO;
                    for (int j = high; j >= m; j--) {
                        f += ort[j] * H[i][j];
                    }
                    f = f / h;
                    for (int j = m; j <= high; j++) {
                        H[i][j] -= f * ort[j];
                    }
                }
                ort[m] = scale * ort[m];
                H[m][m - 1] = scale * g;
            }
        }

        // Accumulate transformations (Algol's ortran).

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                V[i][j] = (i == j ? 1.0 : ZERO);
            }
        }

        for (int m = high - 1; m >= low + 1; m--) {
            if (H[m][m - 1] != ZERO) {
                for (int i = m + 1; i <= high; i++) {
                    ort[i] = H[i][m - 1];
                }
                for (int j = m; j <= high; j++) {
                    double g = ZERO;
                    for (int i = m; i <= high; i++) {
                        g += ort[i] * V[i][j];
                    }
                    // Double division avoids possible underflow
                    g = (g / ort[m]) / H[m][m - 1];
                    for (int i = m; i <= high; i++) {
                        V[i][j] += g * ort[i];
                    }
                }
            }
        }

        if (DEBUG) {
            MatrixUtils.printToStream(BasicLogger.DEBUG, PrimitiveDenseStore.FACTORY.copy(V), TypeUtils.EQUALS_NUMBER_CONTEXT);
            MatrixUtils.printToStream(BasicLogger.DEBUG, PrimitiveDenseStore.FACTORY.copy(H), TypeUtils.EQUALS_NUMBER_CONTEXT);
        }
    }

    static void sortEigenvaluesAndVectors(final double[] eigenvalues, final PhysicalStore<Double> eigenvectors) {

        final int tmpDim = eigenvalues.length;
        final int tmpLim = tmpDim - 1;

        for (int j1 = 0; j1 < tmpLim; j1++) {

            double tmpValue = eigenvalues[j1];
            int j2 = j1;

            for (int ij = j1 + 1; ij < tmpDim; ij++) {

                if (Math.abs(eigenvalues[ij]) > Math.abs(tmpValue)) {

                    tmpValue = eigenvalues[ij];
                    j2 = ij;
                }
            }

            if (j2 != j1) {
                eigenvalues[j2] = eigenvalues[j1];
                eigenvalues[j1] = tmpValue;
                eigenvectors.exchangeColumns(j1, j2);
            }
        }
    }

    /**
     * Symmetric Householder reduction to tridiagonal form.
     * 
     * @param aMainDiagonal
     * @param aSecondaryDiagonal
     * @param aMtrxV
     */
    static void tridiagonalize(final double[] aMainDiagonal, final double[] aSecondaryDiagonal, final double[][] aMtrxV) {

        //        BasicLogger.logDebug("tridiagonalize");
        //        BasicLogger.logDebug("v.re: {}", Arrays.toString(myEigenvaluesRealPart));
        //        BasicLogger.logDebug("v.im: {}", Arrays.toString(myEigenvaluesImaginaryPart));
        //        MatrixUtils.printToStream(BasicLogger.DEBUG, PrimitiveDenseStore.FACTORY.copyRaw(V), TypeUtils.EQUALS_NUMBER_CONTEXT);
        //        BasicLogger.logDebug();

        final int tmpDim = aMainDiagonal.length;

        //  This is derived from the Algol procedures tred2 by
        //  Bowdler, Martin, Reinsch, and Wilkinson, Handbook for
        //  Auto. Comp., Vol.ii-Linear Algebra, and the corresponding
        //  Fortran subroutine in EISPACK.

        for (int j = 0; j < tmpDim; j++) {
            aMainDiagonal[j] = aMtrxV[tmpDim - 1][j];
        }

        // Householder reduction to tridiagonal form.

        for (int i = tmpDim - 1; i > 0; i--) {

            // Scale to avoid under/overflow.

            double scale = ZERO;
            double h = ZERO;
            for (int k = 0; k < i; k++) {
                scale = scale + Math.abs(aMainDiagonal[k]);
            }
            if (scale == ZERO) {
                aSecondaryDiagonal[i] = aMainDiagonal[i - 1];
                for (int j = 0; j < i; j++) {
                    aMainDiagonal[j] = aMtrxV[i - 1][j];
                    aMtrxV[i][j] = ZERO;
                    aMtrxV[j][i] = ZERO;
                }
            } else {

                // Generate Householder vector.

                for (int k = 0; k < i; k++) {
                    aMainDiagonal[k] /= scale;
                    h += aMainDiagonal[k] * aMainDiagonal[k];
                }
                double f = aMainDiagonal[i - 1];
                double g = Math.sqrt(h);
                if (f > 0) {
                    g = -g;
                }
                aSecondaryDiagonal[i] = scale * g;
                h = h - f * g;
                aMainDiagonal[i - 1] = f - g;
                for (int j = 0; j < i; j++) {
                    aSecondaryDiagonal[j] = ZERO;
                }

                // Apply similarity transformation to remaining columns.

                for (int j = 0; j < i; j++) {
                    f = aMainDiagonal[j];
                    aMtrxV[j][i] = f;
                    g = aSecondaryDiagonal[j] + aMtrxV[j][j] * f;
                    for (int k = j + 1; k <= i - 1; k++) {
                        g += aMtrxV[k][j] * aMainDiagonal[k];
                        aSecondaryDiagonal[k] += aMtrxV[k][j] * f;
                    }
                    aSecondaryDiagonal[j] = g;
                }
                f = ZERO;
                for (int j = 0; j < i; j++) {
                    aSecondaryDiagonal[j] /= h;
                    f += aSecondaryDiagonal[j] * aMainDiagonal[j];
                }
                final double hh = f / (h + h);
                for (int j = 0; j < i; j++) {
                    aSecondaryDiagonal[j] -= hh * aMainDiagonal[j];
                }
                for (int j = 0; j < i; j++) {
                    f = aMainDiagonal[j];
                    g = aSecondaryDiagonal[j];
                    for (int k = j; k <= i - 1; k++) {
                        aMtrxV[k][j] -= (f * aSecondaryDiagonal[k] + g * aMainDiagonal[k]);
                    }
                    aMainDiagonal[j] = aMtrxV[i - 1][j];
                    aMtrxV[i][j] = ZERO;
                }
            }
            aMainDiagonal[i] = h;
        }

        // Accumulate transformations.

        for (int i = 0; i < tmpDim - 1; i++) {
            aMtrxV[tmpDim - 1][i] = aMtrxV[i][i];
            aMtrxV[i][i] = 1.0;
            final double h = aMainDiagonal[i + 1];
            if (h != ZERO) {
                for (int k = 0; k <= i; k++) {
                    aMainDiagonal[k] = aMtrxV[k][i + 1] / h;
                }
                for (int j = 0; j <= i; j++) {
                    double g = ZERO;
                    for (int k = 0; k <= i; k++) {
                        g += aMtrxV[k][i + 1] * aMtrxV[k][j];
                    }
                    for (int k = 0; k <= i; k++) {
                        aMtrxV[k][j] -= g * aMainDiagonal[k];
                    }
                }
            }
            for (int k = 0; k <= i; k++) {
                aMtrxV[k][i + 1] = ZERO;
            }
        }
        for (int j = 0; j < tmpDim; j++) {
            aMainDiagonal[j] = aMtrxV[tmpDim - 1][j];
            aMtrxV[tmpDim - 1][j] = ZERO;
        }
        aMtrxV[tmpDim - 1][tmpDim - 1] = 1.0;
        aSecondaryDiagonal[0] = ZERO;

        //        BasicLogger.logDebug();
        //        BasicLogger.logDebug("v.re: {}", Arrays.toString(myEigenvaluesRealPart));
        //        BasicLogger.logDebug("v.im: {}", Arrays.toString(myEigenvaluesImaginaryPart));
        //        MatrixUtils.printToStream(BasicLogger.DEBUG, PrimitiveDenseStore.FACTORY.copyRaw(V), TypeUtils.EQUALS_NUMBER_CONTEXT);
        //        BasicLogger.logDebug("tridiagonalize");
    }

    static <N extends Number> DiagonalAccess<Double> tridiagonalize(final PhysicalStore<N> aStore) {

        final int tmpMinDim = aStore.getMinDim();

        final Householder[] tmpQ1Householders = new Householder[tmpMinDim];
        final Householder[] tmpQ2Householders = new Householder[tmpMinDim];

        Householder<N> tmpHouseholder;
        for (int ij = 0; ij < tmpMinDim; ij++) {

            tmpHouseholder = aStore.generateHouseholderColumn(ij + 1, ij);
            aStore.transformLeft(tmpHouseholder, ij + 1);
            tmpQ1Householders[ij] = tmpHouseholder;

            tmpHouseholder = aStore.generateHouseholderRow(ij, ij + 1);
            aStore.transformRight(tmpHouseholder, ij + 1);
            tmpQ2Householders[ij] = tmpHouseholder;
        }

        final Array2D<Double> tmpArray2D = ((PrimitiveDenseStore) aStore).asArray2D();

        final Array1D<Double> tmpMain = tmpArray2D.sliceDiagonal(0, 0);
        final Array1D<Double> tmpSuper = tmpArray2D.sliceDiagonal(0, 1);
        final Array1D<Double> tmpSub = tmpArray2D.sliceDiagonal(1, 0);

        return DiagonalAccess.makePrimitive(tmpMain, tmpSuper, tmpSub);
    }

    private MatrixStore<N> myD;
    private Array1D<ComplexNumber> myEigenvalues;
    private transient MatrixStore<N> myInverse;
    private boolean mySymmetric;
    private MatrixStore<N> myV;

    protected EigenvalueDecomposition(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    /**
     * Will check for symmetry and then call either
     * {@link #computeSymmetric(MatrixStore)}
     * or
     * {@link #computeNonsymmetric(MatrixStore)}.
     * 
     * @see org.ojalgo.matrix.decomposition.MatrixDecomposition#compute(org.ojalgo.matrix.store.MatrixStore)
     */
    public final boolean compute(final MatrixStore<N> aStore) {

        final int tmpDim = aStore.getMinDim();

        boolean tmpSymmetric = true;

        for (int j = 0; tmpSymmetric && (j < tmpDim); j++) {
            for (int i = j + 1; tmpSymmetric && (i < tmpDim); i++) {
                tmpSymmetric &= aStore.toScalar(i, j).subtract(aStore.get(j, i)).isZero();
            }
        }

        if (tmpSymmetric) {
            return this.computeSymmetric(aStore);
        } else {
            return this.computeNonsymmetric(aStore);
        }
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public final MatrixStore<N> getD() {
        return myD;
    }

    public final ComplexNumber getDeterminant() {

        final AggregatorFunction<ComplexNumber> tmpVisitor = ComplexAggregator.getCollection().product();

        this.getEigenvalues().visitAll(tmpVisitor);

        return tmpVisitor.getNumber();
    }

    public final Array1D<ComplexNumber> getEigenvalues() {
        return myEigenvalues;
    }

    public final MatrixStore<N> getInverse() {

        if (myInverse == null) {

            final MatrixStore<N> tmpV = this.getV();
            final MatrixStore<N> tmpD = this.getD();

            final int tmpDim = tmpD.getMinDim();

            final PhysicalStore<N> tmpMtrx = tmpV.transpose();

            final N tmpZero = this.getFactory().getStaticZero().getNumber();
            final BinaryFunction<N> tmpDivide = this.getFactory().getFunctionSet().divide();

            for (int i = 0; i < tmpDim; i++) {
                if (tmpD.isZero(i, i)) {
                    tmpMtrx.fillRow(i, 0, tmpZero);
                } else {
                    tmpMtrx.modifyRow(i, 0, new PreconfiguredSecond<N>(tmpDivide, tmpD.get(i, i)));
                }
            }

            myInverse = tmpMtrx.multiplyLeft(tmpV);
        }

        return myInverse;
    }

    public final ComplexNumber getTrace() {

        final AggregatorFunction<ComplexNumber> tmpVisitor = ComplexAggregator.getCollection().sum();

        this.getEigenvalues().visitAll(tmpVisitor);

        return tmpVisitor.getNumber();
    }

    public final MatrixStore<N> getV() {
        return myV;
    }

    public final boolean isFullSize() {
        return true;
    }

    public final boolean isSolvable() {
        return this.isComputed() && this.isSymmetric();
    }

    public final boolean isSymmetric() {
        return mySymmetric;
    }

    protected final void setSymmetric(final boolean newSymmetric) {
        mySymmetric = newSymmetric;
    }

    abstract boolean compute(final DiagonalAccess<N> aTridiagonalSymmetricStore);

    final void setD(final MatrixStore<N> newD) {
        myD = newD;
    }

    final void setEigenvalues(final Array1D<ComplexNumber> newEigenvalues) {
        myEigenvalues = newEigenvalues;
    }

    final void setV(final MatrixStore<N> newV) {
        myV = newV;
    }

}
