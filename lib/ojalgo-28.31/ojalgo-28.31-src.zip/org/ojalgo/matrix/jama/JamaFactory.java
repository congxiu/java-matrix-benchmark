/*
 * Copyright © 2008 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.jama;

import java.util.List;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array2D;
import org.ojalgo.function.aggregator.AggregatorCollection;
import org.ojalgo.function.aggregator.PrimitiveAggregator;
import org.ojalgo.function.implementation.FunctionSet;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.random.RandomNumber;
import org.ojalgo.scalar.PrimitiveScalar;

/**
 * Implements both {@linkplain BasicMatrix.Factory} and
 * {@linkplain PhysicalStore.Factory}, and creates
 * {@linkplain JamaMatrix} instances.
 *
 * @author apete
 */
public final class JamaFactory extends Object implements BasicMatrix.Factory, PhysicalStore.Factory<Double> {

    JamaFactory() {
        super();
    }

    public JamaMatrix copy(final Access2D<? extends Number> aSource) {

        final int tmpRowDim = aSource.getRowDim();
        final int tmpColDim = aSource.getColDim();

        final double[][] retVal = new double[tmpRowDim][tmpColDim];

        for (int i = 0; i < tmpRowDim; i++) {
            for (int j = 0; j < tmpColDim; j++) {
                retVal[i][j] = aSource.doubleValue(i, j);
            }
        }

        return new JamaMatrix(retVal);
    }

    /**
     * @deprecated v29 Use {@link #copy(Access2D)} instead
     */
    @Deprecated
    public JamaMatrix copyArray(final Array2D<? extends Number> aSource) {
        return this.copy(aSource);
    }

    public JamaMatrix conjugate(final Access2D<? extends Number> aSource) {
        return this.transpose(aSource);
    }

    public JamaMatrix copyMatrix(final BasicMatrix aSource) {

        final int tmpRowDim = aSource.getRowDim();
        final int tmpColDim = aSource.getColDim();

        final double[][] retVal = new double[tmpRowDim][tmpColDim];

        for (int i = 0; i < tmpRowDim; i++) {
            for (int j = 0; j < tmpColDim; j++) {
                retVal[i][j] = aSource.doubleValue(i, j);
            }
        }

        return new JamaMatrix(retVal);
    }

    /**
     * @deprecated Use {@link #copy(double[][])} instead
     */
    public JamaMatrix copyRaw(final double[][] aSource) {
        return copy(aSource);
    }

    public JamaMatrix copy(final double[][] aSource) {

        final int tmpRowDim = aSource.length;
        final int tmpColDim = aSource[0].length;

        final double[][] retVal = new double[tmpRowDim][tmpColDim];

        for (int i = 0; i < tmpRowDim; i++) {
            for (int j = 0; j < tmpColDim; j++) {
                retVal[i][j] = aSource[i][j];
            }
        }

        return new JamaMatrix(retVal);
    }

    /**
     * @deprecated v29 Use {@link #copy(Access2D)} instead
     */
    @Deprecated
    public JamaMatrix copyStore(final MatrixStore<? extends Number> aSource) {
        return this.copy(aSource);
    }

    public JamaMatrix transpose(final Access2D<? extends Number> aSource) {

        final int tmpRowDim = aSource.getColDim();
        final int tmpColDim = aSource.getRowDim();

        final double[][] retVal = new double[tmpRowDim][tmpColDim];

        for (int i = 0; i < tmpRowDim; i++) {
            for (int j = 0; j < tmpColDim; j++) {
                retVal[i][j] = aSource.doubleValue(j, i);
            }
        }

        return new JamaMatrix(retVal);
    }

    public AggregatorCollection<Double> getAggregatorCollection() {
        return PrimitiveAggregator.getCollection();
    }

    public FunctionSet<Double> getFunctionSet() {
        return PrimitiveFunction.getSet();
    }

    public Double getNumber(final double aNmbr) {
        return aNmbr;
    }

    public Double getNumber(final Number aNmbr) {
        return aNmbr.doubleValue();
    }

    public PrimitiveScalar getStaticOne() {
        return PrimitiveScalar.ONE;
    }

    public PrimitiveScalar getStaticZero() {
        return PrimitiveScalar.ZERO;
    }

    public JamaMatrix makeColumn(final double[] aColumn) {

        final double[][] retVal = new double[aColumn.length][1];

        for (int i = 0; i < retVal.length; i++) {
            retVal[i][0] = aColumn[i];
        }

        return new JamaMatrix(retVal);
    }

    public JamaMatrix makeColumn(final Double[] aColumn) {

        final double[][] retVal = new double[aColumn.length][1];

        for (int i = 0; i < retVal.length; i++) {
            retVal[i][0] = aColumn[i];
        }

        return new JamaMatrix(retVal);
    }

    public JamaMatrix makeColumn(final List<Double> aColumn) {

        final double[][] retVal = new double[aColumn.size()][1];

        for (int i = 0; i < retVal.length; i++) {
            retVal[i][0] = aColumn.get(i);
        }

        return new JamaMatrix(retVal);
    }

    public JamaMatrix makeColumnVector(final List<? extends Number> aColumn) {

        final double[] tmpColumn = new double[aColumn.size()];

        for (int i = 0; i < tmpColumn.length; i++) {
            tmpColumn[i] = aColumn.get(i).doubleValue();
        }

        return this.makeColumn(tmpColumn);
    }

    public JamaMatrix makeEmpty(final int aRowDim, final int aColDim) {
        return new JamaMatrix(new double[aRowDim][aColDim]);
    }

    public JamaMatrix makeEye(final int aRowDim, final int aColDim) {

        final JamaMatrix retVal = this.makeZero(aRowDim, aColDim);

        retVal.fillDiagonal(0, 0, this.getStaticOne().getNumber());

        return retVal;
    }

    public JamaMatrix makeRandom(final int aRowDim, final int aColDim, final RandomNumber aRndm) {

        final double[][] retVal = new double[aRowDim][aColDim];

        for (int i = 0; i < aRowDim; i++) {
            for (int j = 0; j < aColDim; j++) {
                retVal[i][j] = aRndm.doubleValue();
            }
        }

        return new JamaMatrix(retVal);
    }

    public JamaMatrix makeRowVector(final List<? extends Number> aRow) {

        final double[][] tmpRow = new double[1][aRow.size()];

        for (int j = 0; j < tmpRow.length; j++) {
            tmpRow[0][j] = aRow.get(j).doubleValue();
        }

        return new JamaMatrix(tmpRow);
    }

    public JamaMatrix makeZero(final int aRowDim, final int aColDim) {
        return new JamaMatrix(new double[aRowDim][aColDim]);
    }

    public PrimitiveScalar toScalar(final double aNmbr) {
        return new PrimitiveScalar(aNmbr);
    }

    public PrimitiveScalar toScalar(final Number aNmbr) {
        return new PrimitiveScalar(aNmbr);
    }

}
