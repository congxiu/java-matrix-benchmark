/*
 * Copyright © 2006 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.function.implementation;

import static org.ojalgo.constant.PrimitiveMath.*;

import org.ojalgo.ProgrammingError;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.ParameterFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.type.TypeUtils;

public final class PrimitiveFunction extends FunctionSet<Double> {

    public static final UnaryFunction<Double> ABS = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.abs(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> ACOS = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.acos(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> ACOSH = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.log(anArg + StrictMath.sqrt((anArg * anArg) - PrimitiveMath.ONE));
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final BinaryFunction<Double> ADD = new BinaryFunction<Double>() {

        public final double invoke(final double anArg1, final double anArg2) {
            return anArg1 + anArg2;
        }

        public final Double invoke(final Double anArg1, final Double anArg2) {
            return this.invoke(anArg1.doubleValue(), anArg2.doubleValue());
        }
    };

    public static final UnaryFunction<Double> ASIN = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.asin(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> ASINH = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.log(anArg + StrictMath.sqrt((anArg * anArg) + PrimitiveMath.ONE));
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> ATAN = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.atan(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> ATANH = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.log((PrimitiveMath.ONE + anArg) / (PrimitiveMath.ONE - anArg)) / PrimitiveMath.TWO;
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> CARDINALITY = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return TypeUtils.isZero(anArg) ? PrimitiveMath.ZERO : PrimitiveMath.ONE;
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> CONJUGATE = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return anArg;
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> SQRT1PX2 = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.sqrt(ONE + anArg * anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> COS = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.cos(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> COSH = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.cosh(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final BinaryFunction<Double> DIVIDE = new BinaryFunction<Double>() {

        public final double invoke(final double anArg1, final double anArg2) {
            return anArg1 / anArg2;
        }

        public final Double invoke(final Double anArg1, final Double anArg2) {
            return this.invoke(anArg1.doubleValue(), anArg2.doubleValue());
        }
    };

    public static final UnaryFunction<Double> EXP = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.exp(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> EXPM1 = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.expm1(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final BinaryFunction<Double> HYPOT = new BinaryFunction<Double>() {

        public final double invoke(final double anArg1, final double anArg2) {
            return StrictMath.hypot(anArg1, anArg2);
        }

        public final Double invoke(final Double anArg1, final Double anArg2) {
            return this.invoke(anArg1.doubleValue(), anArg2.doubleValue());
        }
    };

    public static final UnaryFunction<Double> INVERT = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return PrimitiveMath.ONE / anArg;
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> LOG = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.log(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> LOG10 = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.log10(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> LOG1P = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.log1p(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final BinaryFunction<Double> MAX = new BinaryFunction<Double>() {

        public final double invoke(final double anArg1, final double anArg2) {
            return StrictMath.max(anArg1, anArg2);
        }

        public final Double invoke(final Double anArg1, final Double anArg2) {
            return this.invoke(anArg1.doubleValue(), anArg2.doubleValue());
        }
    };

    public static final BinaryFunction<Double> MIN = new BinaryFunction<Double>() {

        public final double invoke(final double anArg1, final double anArg2) {
            return StrictMath.min(anArg1, anArg2);
        }

        public final Double invoke(final Double anArg1, final Double anArg2) {
            return this.invoke(anArg1.doubleValue(), anArg2.doubleValue());
        }
    };

    public static final BinaryFunction<Double> MULTIPLY = new BinaryFunction<Double>() {

        public final double invoke(final double anArg1, final double anArg2) {
            return anArg1 * anArg2;
        }

        public final Double invoke(final Double anArg1, final Double anArg2) {
            return this.invoke(anArg1.doubleValue(), anArg2.doubleValue());
        }
    };

    public static final UnaryFunction<Double> NEGATE = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return -anArg;
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final BinaryFunction<Double> POW = new BinaryFunction<Double>() {

        public final double invoke(final double anArg1, final double anArg2) {
            return StrictMath.pow(anArg1, anArg2);
        }

        public final Double invoke(final Double anArg1, final Double anArg2) {
            return this.invoke(anArg1.doubleValue(), anArg2.doubleValue());
        }
    };

    public static final ParameterFunction<Double> POWER = new ParameterFunction<Double>() {

        public final double invoke(final double anArg, int aParam) {

            double retVal = PrimitiveMath.ONE;

            if (aParam < 0) {

                retVal = INVERT.invoke(POWER.invoke(anArg, -aParam));

            } else {

                while (aParam > 0) {

                    retVal = retVal * anArg;

                    aParam--;
                }
            }

            return retVal;
        }

        public final Double invoke(final Double anArg, final int aParam) {
            return this.invoke(anArg.doubleValue(), aParam);
        }
    };

    public static final ParameterFunction<Double> ROOT = new ParameterFunction<Double>() {

        public final double invoke(final double anArg, final int aParam) {

            if (aParam != 0) {
                return StrictMath.pow(anArg, PrimitiveMath.ONE / aParam);
            } else {
                throw new IllegalArgumentException();
            }
        }

        public final Double invoke(final Double anArg, final int aParam) {
            return this.invoke(anArg.doubleValue(), aParam);
        }
    };

    public static final ParameterFunction<Double> SCALE = new ParameterFunction<Double>() {

        public final double invoke(final double anArg, int aParam) {

            if (aParam < 0) {
                throw new ProgrammingError("Cannot have exponents smaller than zero.");
            }

            long tmpFactor = 1l;
            final long tmp10 = (long) PrimitiveMath.TEN;

            while (aParam > 0) {
                tmpFactor *= tmp10;
                aParam--;
            }

            return StrictMath.rint(tmpFactor * anArg) / tmpFactor;
        }

        public final Double invoke(final Double anArg, final int aParam) {
            return this.invoke(anArg.doubleValue(), aParam);
        }
    };

    public static final UnaryFunction<Double> SIGNUM = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.signum(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> SIN = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.sin(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> SINH = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.sinh(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> SQRT = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.sqrt(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final BinaryFunction<Double> SUBTRACT = new BinaryFunction<Double>() {

        public final double invoke(final double anArg1, final double anArg2) {
            return anArg1 - anArg2;
        }

        public final Double invoke(final Double anArg1, final Double anArg2) {
            return this.invoke(anArg1.doubleValue(), anArg2.doubleValue());
        }
    };

    public static final UnaryFunction<Double> TAN = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.tan(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> TANH = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return StrictMath.tanh(anArg);
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    public static final UnaryFunction<Double> VALUE = new UnaryFunction<Double>() {

        public final double invoke(final double anArg) {
            return anArg;
        }

        public final Double invoke(final Double anArg) {
            return this.invoke(anArg.doubleValue());
        }
    };

    private static final PrimitiveFunction SET = new PrimitiveFunction();

    public static PrimitiveFunction getSet() {
        return SET;
    }

    private PrimitiveFunction() {
        super();
    }

    @Override
    public UnaryFunction<Double> abs() {
        return ABS;
    }

    @Override
    public UnaryFunction<Double> acos() {
        return ACOS;
    }

    @Override
    public UnaryFunction<Double> acosh() {
        return ACOSH;
    }

    @Override
    public BinaryFunction<Double> add() {
        return ADD;
    }

    @Override
    public UnaryFunction<Double> asin() {
        return ASIN;
    }

    @Override
    public UnaryFunction<Double> asinh() {
        return ASINH;
    }

    @Override
    public UnaryFunction<Double> atan() {
        return ATAN;
    }

    @Override
    public UnaryFunction<Double> atanh() {
        return ATANH;
    }

    @Override
    public UnaryFunction<Double> cardinality() {
        return CARDINALITY;
    }

    @Override
    public UnaryFunction<Double> conjugate() {
        return CONJUGATE;
    }

    @Override
    public UnaryFunction<Double> cos() {
        return COS;
    }

    @Override
    public UnaryFunction<Double> cosh() {
        return COSH;
    }

    @Override
    public BinaryFunction<Double> divide() {
        return DIVIDE;
    }

    @Override
    public UnaryFunction<Double> exp() {
        return EXP;
    }

    @Override
    public BinaryFunction<Double> hypot() {
        return HYPOT;
    }

    @Override
    public UnaryFunction<Double> invert() {
        return INVERT;
    }

    @Override
    public UnaryFunction<Double> log() {
        return LOG;
    }

    @Override
    public BinaryFunction<Double> max() {
        return MAX;
    }

    @Override
    public BinaryFunction<Double> min() {
        return MIN;
    }

    @Override
    public BinaryFunction<Double> multiply() {
        return MULTIPLY;
    }

    @Override
    public UnaryFunction<Double> negate() {
        return NEGATE;
    }

    @Override
    public BinaryFunction<Double> pow() {
        return POW;
    }

    @Override
    public ParameterFunction<Double> power() {
        return POWER;
    }

    @Override
    public ParameterFunction<Double> root() {
        return ROOT;
    }

    @Override
    public ParameterFunction<Double> scale() {
        return SCALE;
    }

    @Override
    public UnaryFunction<Double> signum() {
        return SIGNUM;
    }

    @Override
    public UnaryFunction<Double> sin() {
        return SIN;
    }

    @Override
    public UnaryFunction<Double> sinh() {
        return SINH;
    }

    @Override
    public UnaryFunction<Double> sqrt() {
        return SQRT;
    }

    @Override
    public UnaryFunction<Double> sqrt1px2() {
        return SQRT1PX2;
    }

    @Override
    public BinaryFunction<Double> subtract() {
        return SUBTRACT;
    }

    @Override
    public UnaryFunction<Double> tan() {
        return TAN;
    }

    @Override
    public UnaryFunction<Double> tanh() {
        return TANH;
    }

    @Override
    public UnaryFunction<Double> value() {
        return VALUE;
    }

}
