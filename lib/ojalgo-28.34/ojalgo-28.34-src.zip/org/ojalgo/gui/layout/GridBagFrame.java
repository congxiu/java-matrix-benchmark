/*
 * Copyright © 2008 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.gui.layout;

import java.awt.Component;
import java.awt.GraphicsConfiguration;
import java.awt.GridBagLayout;
import java.awt.HeadlessException;
import java.awt.Insets;

import javax.swing.JFrame;

public abstract class GridBagFrame extends JFrame implements GridBagComponent {

    private final ConstraintsBuilder myConstraintsFactory = new ConstraintsBuilder();;

    @SuppressWarnings("unused")
    private GridBagFrame() throws HeadlessException {
        super();
    }

    @SuppressWarnings("unused")
    private GridBagFrame(GraphicsConfiguration someGc) {
        super(someGc);
    }

    @SuppressWarnings("unused")
    private GridBagFrame(String someTitle) throws HeadlessException {
        super(someTitle);
    }

    @SuppressWarnings("unused")
    private GridBagFrame(String someTitle, GraphicsConfiguration someGc) {
        super(someTitle, someGc);
    }

    protected GridBagFrame(int aRowDim, int aColDim) {

        super();

        this.setLayout(new GridBagLayout());

        GridBagComponent.ConstraintsBuilder.initialiseLayout(this, aRowDim, aColDim, true);
    }

    protected GridBagFrame(int[] someRowHeights, int[] someColWidths) {

        super();

        this.setLayout(new GridBagLayout());

        GridBagComponent.ConstraintsBuilder.initialiseLayout(this, someRowHeights, someColWidths, true);
    }

    /**
     * @see org.ojalgo.gui.layout.GridBagComponent#add(java.awt.Component, int, int)
     */
    public void add(Component aComponent, int gridx, int gridy) {
        this.add(aComponent, myConstraintsFactory.build(gridx, gridy));
    }

    /**
     * @see org.ojalgo.gui.layout.GridBagComponent#add(java.awt.Component, int, int, int, int)
     */
    public void add(Component aComponent, int gridx, int gridy, int gridwidth, int gridheight) {
        this.add(aComponent, myConstraintsFactory.build(gridx, gridy, gridwidth, gridheight));
    }

    public GridBagFrame anchor(int anchor) {
        myConstraintsFactory.anchor(anchor);
        return this;
    }

    public GridBagFrame fill(int fill) {
        myConstraintsFactory.fill(fill);
        return this;
    }

    public GridBagFrame insets(Insets insets) {
        myConstraintsFactory.insets(insets);
        return this;
    }

    public void makeColumnHeavyweight(int aCol) {
        GridBagComponent.ConstraintsBuilder.makeColumnHeavyweight(this, aCol);
    }

    public void makeRowHeavyweight(int aRow) {
        GridBagComponent.ConstraintsBuilder.makeRowHeavyweight(this, aRow);
    }

}
