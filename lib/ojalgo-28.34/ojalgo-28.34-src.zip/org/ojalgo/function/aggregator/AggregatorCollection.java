/*
 * Copyright © 2009 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.function.aggregator;

/**
 * Do not cache instances of this class! The methods {@linkplain BigAggregator#getCollection()},
 * {@linkplain ComplexAggregator#getCollection()} and {@linkplain PrimitiveAggregator#getCollection()}
 * return threadlocal instances, and when you access the individual
 * aggregators they are {@linkplain AggregatorFunction#reset()} for you.
 *
 * @author apete
 */
public final class AggregatorCollection<N extends Number> {

    private AggregatorFunction<N> myCardinality;
    private AggregatorFunction<N> myLargest;
    private AggregatorFunction<N> myNorm1;
    private AggregatorFunction<N> myNorm2;
    private AggregatorFunction<N> myProduct;
    private AggregatorFunction<N> mySmallest;
    private AggregatorFunction<N> mySum;

    AggregatorCollection() {
        super();
    }

    /**
     * Count of non-zero elements
     */
    public AggregatorFunction<N> cardinality() {
        return myCardinality.reset();
    }

    /**
     * Largest absolute value
     */
    public AggregatorFunction<N> largest() {
        return myLargest.reset();
    }

    /**
     * Equivalent to, but probably faster than, norm(1);
     */
    public AggregatorFunction<N> norm1() {
        return myNorm1.reset();
    }

    /**
     * Equivalent to, but probably faster than, norm(2);
     */
    public AggregatorFunction<N> norm2() {
        return myNorm2.reset();
    }

    /**
     * Running product
     */
    public AggregatorFunction<N> product() {
        return myProduct.reset();
    }

    /**
     * Smallest non-zero absolute value
     */
    public AggregatorFunction<N> smallest() {
        return mySmallest.reset();
    }

    /**
     * Running sum
     */
    public AggregatorFunction<N> sum() {
        return mySum.reset();
    }

    AggregatorCollection<N> cardinality(final AggregatorFunction<N> someCardinality) {
        myCardinality = someCardinality;
        return this;
    }

    AggregatorCollection<N> largest(final AggregatorFunction<N> someLargest) {
        myLargest = someLargest;
        return this;
    }

    AggregatorCollection<N> norm1(final AggregatorFunction<N> someNorm1) {
        myNorm1 = someNorm1;
        return this;
    }

    AggregatorCollection<N> norm2(final AggregatorFunction<N> someNorm2) {
        myNorm2 = someNorm2;
        return this;
    }

    AggregatorCollection<N> product(final AggregatorFunction<N> someProduct) {
        myProduct = someProduct;
        return this;
    }

    AggregatorCollection<N> smallest(final AggregatorFunction<N> someSmallest) {
        mySmallest = someSmallest;
        return this;
    }

    AggregatorCollection<N> sum(final AggregatorFunction<N> someSum) {
        mySum = someSum;
        return this;
    }

}
