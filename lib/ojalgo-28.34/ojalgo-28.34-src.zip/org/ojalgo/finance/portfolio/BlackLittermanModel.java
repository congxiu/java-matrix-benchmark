/*
 * Copyright © 2005 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.ojalgo.ProgrammingError;
import org.ojalgo.array.Array2D;
import org.ojalgo.constant.BigMath;
import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.matrix.BasicMatrix;

public final class BlackLittermanModel extends CovarianceBasedModel {

    /**
     * View/Opinion.
     * 
     * You may want to create your own subclass...
     *
     * @author apete
     */
    private static final class View extends MeanVarianceAsset {

        private BigDecimal myMeanReturn = BigMath.ZERO;
        private final BlackLittermanModel myModel;
        private BigDecimal myReturnVariance = null;
        private BigDecimal myScale = null;
        private final List<BigDecimal> myWeights;

        public View(BlackLittermanModel aModel, List<BigDecimal> someWeights) {

            super();

            myModel = aModel;
            myWeights = someWeights;
        }

        @SuppressWarnings("unused")
        private View() {

            super();

            myModel = null;
            myWeights = null;

            ProgrammingError.throwForIllegalInvocation();
        }

        @Override
        public BigDecimal getMeanReturn() {
            if (myMeanReturn != null) {
                return myMeanReturn;
            } else {
                return BigMath.ZERO;
            }
        }

        @Override
        public BigDecimal getReturnVariance() {

            if (myReturnVariance != null) {

                return myReturnVariance;

            } else {

                BasicMatrix tmpWeights = myModel.buildColumnVector(myWeights);

                BigDecimal retVal = myModel.calculateVariance(tmpWeights);

                if (myScale != null) {

                    retVal = retVal.multiply(myScale);

                } else {

                    retVal = retVal.multiply(myModel.getConfidence());
                }

                return retVal;
            }
        }

        @Override
        public List<BigDecimal> getWeights() {
            return myWeights;
        }

        protected final void setMeanReturn(BigDecimal aMeanReturn) {
            myMeanReturn = aMeanReturn;
        }

        protected final void setReturnVariance(BigDecimal aReturnVariance) {
            myReturnVariance = aReturnVariance;
        }

        protected final void setScale(BigDecimal aScale) {
            myScale = aScale;
        }

    }

    private BigDecimal myConfidence = BigMath.ONE;
    private final BasicMatrix myOriginalWeights;
    private final List<MeanVarianceAsset> myViews;

    public BlackLittermanModel(CovarianceBasedModel aCovarianceBasedModel, BasicMatrix someOriginalWeights) {
        this(aCovarianceBasedModel.getMarketEquilibrium());
    }

    public BlackLittermanModel(MarketEquilibrium aMarketEquilibrium, BasicMatrix someOriginalWeights) {

        super(aMarketEquilibrium);

        int tmpSize = someOriginalWeights.getRowDim();

        myOriginalWeights = someOriginalWeights;
        myViews = new ArrayList<MeanVarianceAsset>(tmpSize);
    }

    @SuppressWarnings("unused")
    private BlackLittermanModel(CovarianceBasedModel aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myOriginalWeights = null;
        myViews = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    private BlackLittermanModel(MarketEquilibrium aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myOriginalWeights = null;
        myViews = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    public final void addView(MeanVarianceAsset aView) {
        myViews.add(aView);
    }

    public final void addViewWithBalancedConfidence(List<BigDecimal> someWeights, BigDecimal aReturn) {

        View tmpView = new View(this, someWeights);

        tmpView.setMeanReturn(aReturn);
        tmpView.setReturnVariance(null);
        tmpView.setScale(null);

        myViews.add(tmpView);
    }

    public final void addViewWithScaledConfidence(List<BigDecimal> someWeights, BigDecimal aReturn, BigDecimal aScale) {

        View tmpView = new View(this, someWeights);

        tmpView.setMeanReturn(aReturn);
        tmpView.setReturnVariance(null);
        tmpView.setScale(aScale);

        myViews.add(tmpView);
    }

    public final void addViewWithStandardDeviation(List<BigDecimal> someWeights, BigDecimal aReturn, BigDecimal aStdDev) {

        View tmpView = new View(this, someWeights);

        tmpView.setMeanReturn(aReturn);
        tmpView.setReturnVariance(aStdDev.multiply(aStdDev));
        tmpView.setScale(null);

        myViews.add(tmpView);
    }

    public final void addViewWithVariance(List<BigDecimal> someWeights, BigDecimal aReturn, BigDecimal aVariance) {

        View tmpView = new View(this, someWeights);

        tmpView.setMeanReturn(aReturn);
        tmpView.setReturnVariance(aVariance);
        tmpView.setScale(null);

        myViews.add(tmpView);
    }

    /**
     * "weight on views" or "tau"
     */
    public final BigDecimal getConfidence() {
        return myConfidence;
    }

    public final void setConfidence(BigDecimal aWeight) {
        myConfidence = aWeight;
    }

    private BigDecimal calculateVariance(BasicMatrix aWeightsMtrx) {

        BasicMatrix tmpVal = this.getCovariances();

        tmpVal = tmpVal.multiplyRight(aWeightsMtrx);

        return tmpVal.multiplyLeft(aWeightsMtrx.transpose()).toBigDecimal(0, 0);
    }

    @Override
    protected BasicMatrix calculateInstrumentReturns() {
        return this.calculateEquilibriumReturns(this.calculateInstrumentWeights());
    }

    @Override
    protected BasicMatrix calculateInstrumentWeights() {

        BasicMatrix tmpViewPortfolios = this.getViewPortfolios();
        BasicMatrix tmpViewReturns = this.getViewReturns();
        BasicMatrix tmpViewVariances = this.getViewVariances();

        BasicMatrix tmpCovariances = this.getCovariances();

        BasicMatrix tmpRightParenthesis = tmpViewReturns.subtract(tmpViewPortfolios.multiplyRight(tmpCovariances).multiplyRight(myOriginalWeights));

        BasicMatrix tmpViewsTransposed = tmpViewPortfolios.transpose();

        BasicMatrix tmpLeftParenthesis = tmpViewVariances.add(tmpViewPortfolios.multiplyRight(tmpCovariances).multiplyRight(tmpViewsTransposed));

        return myOriginalWeights.add(tmpViewsTransposed.multiplyRight(tmpLeftParenthesis.solve(tmpRightParenthesis)));
    }

    protected final BasicMatrix getOriginalReturns() {
        return this.calculateEquilibriumReturns(myOriginalWeights);
    }

    /**
     * @see org.ojalgo.finance.portfolio.BlackLittermanModel#getOriginalWeights()
     * @see org.ojalgo.finance.portfolio.BlackLittermanModel#getInstrumentWeights()
     */
    protected final BasicMatrix getOriginalWeights() {
        return myOriginalWeights;
    }

    protected final BasicMatrix getViewPortfolios() {

        int tmpRowDim = myViews.size();
        int tmpColDim = myOriginalWeights.size();

        Array2D<BigDecimal> retVal = Array2D.makeBig(tmpRowDim, tmpColDim);

        FinancePortfolio tmpView;
        List<BigDecimal> tmpWeights;

        for (int i = 0; i < tmpRowDim; i++) {

            tmpView = myViews.get(i);
            tmpWeights = tmpView.getWeights();

            for (int j = 0; j < tmpColDim; j++) {
                retVal.set(i, j, tmpWeights.get(j));
            }
        }

        return CovarianceBasedModel.FACTORY.copyArray(retVal);
    }

    protected final BasicMatrix getViewReturns() {

        int tmpRowDim = myViews.size();
        int tmpColDim = 1;

        Array2D<BigDecimal> retVal = Array2D.makeBig(tmpRowDim, tmpColDim);

        BigDecimal tmpRet = null;
        BigDecimal tmpRAF = this.getRiskAversion();

        for (int i = 0; i < tmpRowDim; i++) {

            tmpRet = myViews.get(i).getMeanReturn();

            retVal.set(i, 0, BigFunction.DIVIDE.invoke(tmpRet, tmpRAF));
        }

        return CovarianceBasedModel.FACTORY.copyArray(retVal);
    }

    protected final List<MeanVarianceAsset> getViews() {
        return myViews;
    }

    protected final BasicMatrix getViewVariances() {

        int tmpDim = myViews.size();

        Array2D<BigDecimal> retVal = Array2D.makeBig(tmpDim, tmpDim);

        BigDecimal tmpVar = null;
        BigDecimal tmpWOV = this.getConfidence();

        for (int ij = 0; ij < tmpDim; ij++) {

            tmpVar = myViews.get(ij).getReturnVariance();

            retVal.set(ij, ij, BigFunction.DIVIDE.invoke(tmpVar, tmpWOV));
        }

        return CovarianceBasedModel.FACTORY.copyArray(retVal);
    }
}
