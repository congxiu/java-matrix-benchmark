/*
 * Copyright © 2004 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.array;

import static org.ojalgo.constant.PrimitiveMath.*;

import java.util.Arrays;

import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.ParameterFunction;
import org.ojalgo.function.PreconfiguredFirst;
import org.ojalgo.function.PreconfiguredParameter;
import org.ojalgo.function.PreconfiguredSecond;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.scalar.PrimitiveScalar;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.TypeUtils;

/**
 * <p>
 * A one- and/or arbitrary-dimensional array of double.
 * </p><p>
 * You cannot instantiate a PrimitiveArray directly. You have to either
 * subclass it and implement instantiation code in that subclass, or use
 * one of the static factory methods in {@linkplain Array1D}, {@linkplain Array2D}
 * or {@linkplain ArrayAnyD}.
 * </p>
 * 
 * @author apete
 */
public class PrimitiveArray extends BasicArray<Double> {

    protected static void add(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double aLeftArg, final double[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg + aRightArg[i];
        }
    }

    protected static void add(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] aLeftArg, final double aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg[i] + aRightArg;
        }
    }

    protected static void add(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] aLeftArg, final double[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg[i] + aRightArg[i];
        }
    }

    protected static void divide(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double aLeftArg, final double[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg / aRightArg[i];
        }
    }

    protected static void divide(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] aLeftArg, final double aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg[i] / aRightArg;
        }
    }

    protected static void divide(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] aLeftArg, final double[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg[i] / aRightArg[i];
        }
    }

    protected static void exchange(final double[] aData, final int aFirstA, final int aFirstB, final int aStep, final int aCount) {

        int tmpIndexA = aFirstA;
        int tmpIndexB = aFirstB;

        double tmpVal;

        for (int i = 0; i < aCount; i++) {

            tmpVal = aData[tmpIndexA];
            aData[tmpIndexA] = aData[tmpIndexB];
            aData[tmpIndexB] = tmpVal;

            tmpIndexA += aStep;
            tmpIndexB += aStep;
        }
    }

    protected static void fill(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double aVal) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aVal;
        }
    }

    protected static void invoke(final double[] aData, final int aFirst, final int aLimit, final int aStep, final AggregatorFunction<Double> aVisitor) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aVisitor.invoke(aData[i]);
        }
    }

    protected static void invoke(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double aLeftArg, final BinaryFunction<Double> aFunc, final double[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aFunc.invoke(aLeftArg, aRightArg[i]);
        }
    }

    protected static void invoke(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] aLeftArg, final BinaryFunction<Double> aFunc, final double aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aFunc.invoke(aLeftArg[i], aRightArg);
        }
    }

    protected static void invoke(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] aLeftArg, final BinaryFunction<Double> aFunc, final double[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aFunc.invoke(aLeftArg[i], aRightArg[i]);
        }
    }

    protected static void invoke(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] anArg, final ParameterFunction<Double> aFunc, final int aParam) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aFunc.invoke(anArg[i], aParam);
        }
    }

    protected static void invoke(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] anArg, final UnaryFunction<Double> aFunc) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aFunc.invoke(anArg[i]);
        }
    }

    protected static void multiply(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double aLeftArg, final double[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg * aRightArg[i];
        }
    }

    protected static void multiply(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] aLeftArg, final double aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg[i] * aRightArg;
        }
    }

    protected static void multiply(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] aLeftArg, final double[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg[i] * aRightArg[i];
        }
    }

    protected static void negate(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] anArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = -anArg[i];
        }
    }

    protected static void subtract(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double aLeftArg, final double[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg - aRightArg[i];
        }
    }

    protected static void subtract(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] aLeftArg, final double aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg[i] - aRightArg;
        }
    }

    protected static void subtract(final double[] aData, final int aFirst, final int aLimit, final int aStep, final double[] aLeftArg, final double[] aRightArg) {
        for (int i = aFirst; i < aLimit; i += aStep) {
            aData[i] = aLeftArg[i] - aRightArg[i];
        }
    }

    private final double[] myData;

    /**
     * Array not copied! No checking!
     */
    protected PrimitiveArray(final double[] anArray) {

        super(anArray.length);

        myData = anArray;
    }

    protected PrimitiveArray(final int aLength) {

        super(aLength);

        myData = new double[aLength];
    }

    public final double doubleValue(final int anInd) {
        return myData[anInd];
    }

    @Override
    public boolean equals(final Object anObj) {
        if (anObj instanceof PrimitiveArray) {
            return Arrays.equals(myData, ((PrimitiveArray) anObj).data());
        } else {
            return super.equals(anObj);
        }
    }

    @Override
    public final void exchange(final int aFirstA, final int aFirstB, final int aStep, final int aCount) {
        PrimitiveArray.exchange(myData, aFirstA, aFirstB, aStep, aCount);
    }

    public final void fill(final int aFirst, final int aLimit, final double aLeftArg, final BinaryFunction<Double> aFunc, final PrimitiveArray aRightArg) {
        if (aFunc == PrimitiveFunction.ADD) {
            PrimitiveArray.add(myData, aFirst, aLimit, 1, aLeftArg, aRightArg.data());
        } else if (aFunc == PrimitiveFunction.DIVIDE) {
            PrimitiveArray.divide(myData, aFirst, aLimit, 1, aLeftArg, aRightArg.data());
        } else if (aFunc == PrimitiveFunction.MULTIPLY) {
            PrimitiveArray.multiply(myData, aFirst, aLimit, 1, aLeftArg, aRightArg.data());
        } else if (aFunc == PrimitiveFunction.SUBTRACT) {
            PrimitiveArray.subtract(myData, aFirst, aLimit, 1, aLeftArg, aRightArg.data());
        } else {
            PrimitiveArray.invoke(myData, aFirst, aLimit, 1, aLeftArg, aFunc, aRightArg.data());
        }
    }

    @Override
    public final void fill(final int aFirst, final int aLimit, final int aStep, final Double aNmbr) {
        PrimitiveArray.fill(myData, aFirst, aLimit, aStep, aNmbr);
    }

    public final void fill(final int aFirst, final int aLimit, final PrimitiveArray aLeftArg, final BinaryFunction<Double> aFunc, final double aRightArg) {
        if (aFunc == PrimitiveFunction.ADD) {
            PrimitiveArray.add(myData, aFirst, aLimit, 1, aLeftArg.data(), aRightArg);
        } else if (aFunc == PrimitiveFunction.DIVIDE) {
            PrimitiveArray.divide(myData, aFirst, aLimit, 1, aLeftArg.data(), aRightArg);
        } else if (aFunc == PrimitiveFunction.MULTIPLY) {
            PrimitiveArray.multiply(myData, aFirst, aLimit, 1, aLeftArg.data(), aRightArg);
        } else if (aFunc == PrimitiveFunction.SUBTRACT) {
            PrimitiveArray.subtract(myData, aFirst, aLimit, 1, aLeftArg.data(), aRightArg);
        } else {
            PrimitiveArray.invoke(myData, aFirst, aLimit, 1, aLeftArg.data(), aFunc, aRightArg);
        }
    }

    public final void fill(final int aFirst, final int aLimit, final PrimitiveArray aLeftArg, final BinaryFunction<Double> aFunc, final PrimitiveArray aRightArg) {
        if (aFunc == PrimitiveFunction.ADD) {
            PrimitiveArray.add(myData, aFirst, aLimit, 1, aLeftArg.data(), aRightArg.data());
        } else if (aFunc == PrimitiveFunction.DIVIDE) {
            PrimitiveArray.divide(myData, aFirst, aLimit, 1, aLeftArg.data(), aRightArg.data());
        } else if (aFunc == PrimitiveFunction.MULTIPLY) {
            PrimitiveArray.multiply(myData, aFirst, aLimit, 1, aLeftArg.data(), aRightArg.data());
        } else if (aFunc == PrimitiveFunction.SUBTRACT) {
            PrimitiveArray.subtract(myData, aFirst, aLimit, 1, aLeftArg.data(), aRightArg.data());
        } else {
            PrimitiveArray.invoke(myData, aFirst, aLimit, 1, aLeftArg.data(), aFunc, aRightArg.data());
        }
    }

    public final Double get(final int anInd) {
        return myData[anInd];
    }

    @Override
    public int getIndexOfLargest(final int aFirst, final int aLimit, final int aStep) {

        int retVal = aFirst;
        double tmpLargest = ZERO;
        double tmpValue;

        for (int i = aFirst; i < aLimit; i += aStep) {
            tmpValue = StrictMath.abs(myData[i]);
            if (tmpValue > tmpLargest) {
                tmpLargest = tmpValue;
                retVal = i;
            }
        }

        return retVal;
    }

    /**
     * @deprecated v29 Use {@link #get(int)} instead
     */
    @Deprecated
    public final Double getNumber(final int anInd) {
        return this.get(anInd);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(myData);
    }

    @Override
    public final boolean isAbsolute(final int anInd) {
        return this.doubleValue(anInd) >= ZERO;
    }

    @Override
    public final boolean isReal(final int anInd) {
        return true;
    }

    @Override
    public final boolean isZero(final int anInd) {
        return TypeUtils.isZero(myData[anInd]);
    }

    @Override
    public final void modify(final int aFirst, final int aLimit, final int aStep, final BinaryFunction<Double> aFunc, final Double aRightArg) {
        if (aFunc == PrimitiveFunction.ADD) {
            PrimitiveArray.add(myData, aFirst, aLimit, aStep, myData, aRightArg);
        } else if (aFunc == PrimitiveFunction.DIVIDE) {
            PrimitiveArray.divide(myData, aFirst, aLimit, aStep, myData, aRightArg);
        } else if (aFunc == PrimitiveFunction.MULTIPLY) {
            PrimitiveArray.multiply(myData, aFirst, aLimit, aStep, myData, aRightArg);
        } else if (aFunc == PrimitiveFunction.SUBTRACT) {
            PrimitiveArray.subtract(myData, aFirst, aLimit, aStep, myData, aRightArg);
        } else {
            PrimitiveArray.invoke(myData, aFirst, aLimit, aStep, myData, aFunc, aRightArg);
        }
    }

    public final void modify(final int aFirst, final int aLimit, final int aStep, final BinaryFunction<Double> aFunc, final PrimitiveArray aRightArg) {
        if (aFunc == PrimitiveFunction.ADD) {
            PrimitiveArray.add(myData, aFirst, aLimit, aStep, myData, aRightArg.data());
        } else if (aFunc == PrimitiveFunction.DIVIDE) {
            PrimitiveArray.divide(myData, aFirst, aLimit, aStep, myData, aRightArg.data());
        } else if (aFunc == PrimitiveFunction.MULTIPLY) {
            PrimitiveArray.multiply(myData, aFirst, aLimit, aStep, myData, aRightArg.data());
        } else if (aFunc == PrimitiveFunction.SUBTRACT) {
            PrimitiveArray.subtract(myData, aFirst, aLimit, aStep, myData, aRightArg.data());
        } else {
            PrimitiveArray.invoke(myData, aFirst, aLimit, aStep, myData, aFunc, aRightArg.data());
        }
    }

    @Override
    public final void modify(final int aFirst, final int aLimit, final int aStep, final Double aLeftArg, final BinaryFunction<Double> aFunc) {
        if (aFunc == PrimitiveFunction.ADD) {
            PrimitiveArray.add(myData, aFirst, aLimit, aStep, aLeftArg, myData);
        } else if (aFunc == PrimitiveFunction.DIVIDE) {
            PrimitiveArray.divide(myData, aFirst, aLimit, aStep, aLeftArg, myData);
        } else if (aFunc == PrimitiveFunction.MULTIPLY) {
            PrimitiveArray.multiply(myData, aFirst, aLimit, aStep, aLeftArg, myData);
        } else if (aFunc == PrimitiveFunction.SUBTRACT) {
            PrimitiveArray.subtract(myData, aFirst, aLimit, aStep, aLeftArg, myData);
        } else {
            PrimitiveArray.invoke(myData, aFirst, aLimit, aStep, aLeftArg, aFunc, myData);
        }
    }

    @Override
    public final void modify(final int aFirst, final int aLimit, final int aStep, final ParameterFunction<Double> aFunc, final int aParam) {
        PrimitiveArray.invoke(myData, aFirst, aLimit, aStep, myData, aFunc, aParam);
    }

    public final void modify(final int aFirst, final int aLimit, final int aStep, final PrimitiveArray aLeftArg, final BinaryFunction<Double> aFunc) {
        if (aFunc == PrimitiveFunction.ADD) {
            PrimitiveArray.add(myData, aFirst, aLimit, aStep, aLeftArg.data(), myData);
        } else if (aFunc == PrimitiveFunction.DIVIDE) {
            PrimitiveArray.divide(myData, aFirst, aLimit, aStep, aLeftArg.data(), myData);
        } else if (aFunc == PrimitiveFunction.MULTIPLY) {
            PrimitiveArray.multiply(myData, aFirst, aLimit, aStep, aLeftArg.data(), myData);
        } else if (aFunc == PrimitiveFunction.SUBTRACT) {
            PrimitiveArray.subtract(myData, aFirst, aLimit, aStep, aLeftArg.data(), myData);
        } else {
            PrimitiveArray.invoke(myData, aFirst, aLimit, aStep, aLeftArg.data(), aFunc, myData);
        }
    }

    @Override
    public final void modify(final int aFirst, final int aLimit, final int aStep, final UnaryFunction<Double> aFunc) {
        if (aFunc == PrimitiveFunction.NEGATE) {
            PrimitiveArray.negate(myData, aFirst, aLimit, aStep, myData);
        } else if (aFunc instanceof PreconfiguredFirst<?>) {
            this.modify(aFirst, aLimit, aStep, ((PreconfiguredFirst<Double>) aFunc).getNumber(), ((PreconfiguredFirst<Double>) aFunc).getFunction());
        } else if (aFunc instanceof PreconfiguredSecond<?>) {
            this.modify(aFirst, aLimit, aStep, ((PreconfiguredSecond<Double>) aFunc).getFunction(), ((PreconfiguredSecond<Double>) aFunc).getNumber());
        } else if (aFunc instanceof PreconfiguredParameter<?>) {
            this.modify(aFirst, aLimit, aStep, ((PreconfiguredParameter<Double>) aFunc).getFunction(), ((PreconfiguredParameter<Double>) aFunc).getParameter());
        } else {
            PrimitiveArray.invoke(myData, aFirst, aLimit, aStep, myData, aFunc);
        }
    }

    @Override
    public final int searchAscending(final Double aNmbr) {
        return Arrays.binarySearch(myData, aNmbr.doubleValue());
    }

    @Override
    public final void set(final int anInd, final double aNmbr) {
        myData[anInd] = aNmbr;
    }

    @Override
    public final void set(final int anInd, final Double aNmbr) {
        myData[anInd] = aNmbr;
    }

    @Override
    public final void sortAscending() {
        Arrays.sort(myData);
    }

    public final Scalar<Double> toScalar(final int anInd) {
        return new PrimitiveScalar(myData[anInd]);
    }

    @Override
    public final void visit(final int aFirst, final int aLimit, final int aStep, final AggregatorFunction<Double> aVisitor) {
        PrimitiveArray.invoke(myData, aFirst, aLimit, aStep, aVisitor);
    }

    protected final double[] copyOfData() {
        return ArrayUtils.copyOf(myData);
    }

    protected final double[] data() {
        return myData;
    }
}
