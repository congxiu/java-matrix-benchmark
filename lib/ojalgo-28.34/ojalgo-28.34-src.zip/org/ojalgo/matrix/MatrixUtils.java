/*
 * Copyright © 2006 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix;

import java.io.PrintStream;
import java.math.BigDecimal;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.constant.BigMath;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.matrix.decomposition.Cholesky;
import org.ojalgo.matrix.decomposition.Eigenvalue;
import org.ojalgo.matrix.decomposition.LU;
import org.ojalgo.matrix.decomposition.QR;
import org.ojalgo.matrix.decomposition.SingularValue;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.ConjugatedStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.netio.ASCII;
import org.ojalgo.random.Uniform;
import org.ojalgo.scalar.BigScalar;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.PrimitiveScalar;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

public abstract class MatrixUtils {

    public static boolean equals(final BasicMatrix aMtrx1, final BasicMatrix aMtrx2, final NumberContext aCntxt) {
        return (aMtrx1.getRowDim() == aMtrx2.getRowDim()) && (aMtrx1.getColDim() == aMtrx2.getColDim()) && (aMtrx1.subtract(aMtrx2).getFrobeniusNorm().getReal() <= aCntxt.getError());
    }

    public static <N extends Number> boolean equals(final MatrixStore<N> aStore, final Cholesky<N> aDecomp, final NumberContext aCntxt) {

        boolean retVal = false;

        if (MatrixUtils.equals(aStore, (LU<N>) aDecomp, aCntxt)) {

            MatrixStore<N> tmpStore1 = aDecomp.getL();
            MatrixStore<N> tmpStore2 = new ConjugatedStore<N>(aDecomp.getU());

            if (MatrixUtils.equals(tmpStore1, tmpStore2, aCntxt)) {

                tmpStore1 = aDecomp.getR();

                tmpStore2 = tmpStore1.multiplyLeft(new ConjugatedStore<N>(tmpStore1));

                retVal = MatrixUtils.equals(tmpStore2, aStore, aCntxt);
            }
        }

        return retVal;
    }

    public static <N extends Number> boolean equals(final MatrixStore<N> aStore, final Eigenvalue<N> aDecomp, final NumberContext aCntxt) {

        final MatrixStore<N> tmpD = aDecomp.getD();
        final MatrixStore<N> tmpV = aDecomp.getV();

        // Check that [A][V] == [V][D] ([A] == [V][D][V]<sup>T</sup> is not always true)
        final MatrixStore<N> tmpStore1 = aStore.multiplyRight(tmpV);
        final MatrixStore<N> tmpStore2 = tmpD.multiplyLeft(tmpV);

        return MatrixUtils.equals(tmpStore1, tmpStore2, aCntxt);
    }

    public static <N extends Number> boolean equals(final MatrixStore<N> aStore, final LU<N> aDecomp, final NumberContext aCntxt) {

        final MatrixStore<N> tmpP = aDecomp.getP();
        final MatrixStore<N> tmpL = aDecomp.getL();
        final MatrixStore<N> tmpD = aDecomp.getD();
        final MatrixStore<N> tmpU = aDecomp.getU();

        final MatrixStore<N> tmpStore = tmpP.multiplyRight(tmpL.multiplyRight(tmpD.multiplyRight(tmpU)));

        return MatrixUtils.equals(tmpStore, aStore, aCntxt);
    }

    public static <N extends Number> boolean equals(final MatrixStore<N> aStore1, final MatrixStore<N> aStore2, final NumberContext aCntxt) {

        boolean retVal = (aStore1.getRowDim() == aStore2.getRowDim()) && (aStore1.getColDim() == aStore2.getColDim());

        final double tmpError = aCntxt.getError();

        for (int i = 0; retVal && (i < aStore1.getRowDim()); i++) {
            for (int j = 0; retVal && (j < aStore1.getColDim()); j++) {
                retVal &= aStore1.toScalar(i, j).subtract(aStore2.get(i, j)).getModulus() <= tmpError;
            }
        }

        return retVal;
    }

    public static <N extends Number> boolean equals(final MatrixStore<N> aStore, final QR<N> aDecomp, final NumberContext aCntxt) {

        final MatrixStore<N> tmpQ = aDecomp.getQ();
        final MatrixStore<N> tmpR = aDecomp.getR();

        final MatrixStore<N> tmpStore = tmpQ.multiplyRight(tmpR);

        return MatrixUtils.equals(tmpStore, aStore, aCntxt);
    }

    public static <N extends Number> boolean equals(final MatrixStore<N> aStore, final SingularValue<N> aDecomp, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, aDecomp, aCntxt, false);
    }

    public static <N extends Number> boolean equals(final MatrixStore<N> aStore, final SingularValue<N> aDecomp, final NumberContext aCntxt, final boolean fullRecreation) {

        final int tmpRowDim = aStore.getRowDim();
        final int tmpColDim = aStore.getColDim();

        final MatrixStore<N> tmpQ1 = aDecomp.getQ1();
        final MatrixStore<N> tmpD = aDecomp.getD();
        final MatrixStore<N> tmpQ2 = aDecomp.getQ2();

        MatrixStore<N> tmpThis;
        MatrixStore<N> tmpThat;

        boolean retVal = (tmpRowDim == tmpQ1.getRowDim()) && (tmpQ2.getRowDim() == tmpColDim);

        // Check that it's possible to reconstruct the original matrix.
        if (retVal) {

            tmpThis = aStore.multiplyRight(tmpQ2);
            tmpThat = tmpD.multiplyLeft(tmpQ1);

            retVal &= tmpThis.equals(tmpThat, aCntxt);

            if (fullRecreation) {

                tmpThis = aStore;
                tmpThat = tmpD.multiplyLeft(tmpQ1).multiplyRight(new ConjugatedStore<N>(tmpQ2));

                retVal &= tmpThis.equals(tmpThat, aCntxt);
            }
        }

        // Check that the singular values are sorted in descending order
        if (retVal) {
            final Array1D<Double> tmpSV = aDecomp.getSingularValues();
            for (int i = 1; retVal && (i < tmpSV.size()); i++) {
                retVal &= tmpSV.doubleValue(i - 1) >= tmpSV.doubleValue(i);
            }
            if (aDecomp.isOrdered()) {
                for (int ij = 1; retVal && (ij < tmpD.getMinDim()); ij++) {
                    retVal &= tmpD.doubleValue(ij - 1, ij - 1) >= tmpD.doubleValue(ij, ij);
                }
            }
        }

        // If Q1 is square, then check if it is orthogonal/unitary.
        if (fullRecreation && retVal && (tmpQ1.getRowDim() == tmpQ1.getColDim())) {

            final int aDim = tmpQ1.getMinDim();
            tmpThis = tmpQ1.getFactory().makeEye(aDim, aDim);
            tmpThat = new ConjugatedStore<N>(tmpQ1).multiplyLeft(tmpQ1);

            retVal &= tmpThis.equals(tmpThat, aCntxt);
        }

        // If Q2 is square, then check if it is orthogonal/unitary.
        if (fullRecreation && retVal && (tmpQ2.getRowDim() == tmpQ2.getColDim())) {

            final int aDim = tmpQ2.getMinDim();
            tmpThis = tmpQ2.getFactory().makeEye(aDim, aDim);
            tmpThat = new ConjugatedStore<N>(tmpQ2).multiplyLeft(tmpQ2);

            retVal &= tmpThis.equals(tmpThat, aCntxt);
        }

        // Check the pseudoinverse.
        if (fullRecreation && retVal) {
            retVal &= aStore.equals(aDecomp.getInverse().multiplyRight(aStore).multiplyLeft(aStore), aCntxt);
        }

        return retVal;
    }

    public static int hashCode(final BasicMatrix aMtrx) {
        int retVal = aMtrx.size() * PrimitiveMath.getPrimeNumber(30);
        final int tmpLimit = StrictMath.min(aMtrx.getRowDim(), aMtrx.getColDim());
        for (int ij = 0; ij < tmpLimit; ij++) {
            retVal *= TypeUtils.EQUALS_NUMBER_CONTEXT.round(aMtrx.toScalar(ij, ij).getModulus());
        }
        return retVal;
    }

    public static <N extends Number> int hashCode(final MatrixStore<N> aStore) {
        int retVal = aStore.size() * PrimitiveMath.getPrimeNumber(40);
        final int tmpLimit = StrictMath.min(aStore.getRowDim(), aStore.getColDim());
        for (int ij = 0; ij < tmpLimit; ij++) {
            retVal *= TypeUtils.EQUALS_NUMBER_CONTEXT.round(aStore.toScalar(ij, ij).getModulus());
        }
        return retVal;
    }

    public static int[] makeDecreasingRange(final int aFirst, final int aCount) {
        final int[] retVal = new int[aCount];
        for (int i = 0; i < retVal.length; i++) {
            retVal[i] = aFirst - i;
        }
        return retVal;
    }

    public static int[] makeIncreasingRange(final int aFirst, final int aCount) {
        final int[] retVal = new int[aCount];
        for (int i = 0; i < retVal.length; i++) {
            retVal[i] = aFirst + i;
        }
        return retVal;
    }

    public static PhysicalStore<ComplexNumber> makeRandomComplexStore(final int aRowDim, final int aColDim) {

        final PhysicalStore<ComplexNumber> retVal = ComplexDenseStore.FACTORY.makeEmpty(aRowDim, aColDim);

        final Uniform tmpArgGen = new Uniform(PrimitiveMath.ZERO, PrimitiveMath.TWO_PI);

        for (int j = 0; j < aColDim; j++) {
            for (int i = 0; i < aRowDim; i++) {
                retVal.set(i, j, ComplexNumber.fromPolarCoordinates(PrimitiveMath.E, tmpArgGen.doubleValue()).add(PrimitiveMath.PI));
            }
        }

        return retVal;
    }

    public static int[] makeRange(final int anInd) {
        return new int[] { anInd };
    }

    public static int max(final int... values) {
        int retVal = Integer.MIN_VALUE;
        for (int i = values.length; i-- != 0;) {
            retVal = values[i] > retVal ? values[i] : retVal;
        }
        return retVal;
    }

    public static int min(final int... values) {
        int retVal = Integer.MAX_VALUE;
        for (int i = values.length; i-- != 0;) {
            retVal = values[i] < retVal ? values[i] : retVal;
        }
        return retVal;
    }

    public static void printToStream(final PrintStream aPrintStream, final BasicMatrix aMtrx, final NumberContext aCntxt) {

        final int tmpRowDim = aMtrx.getRowDim();
        final int tmpColDim = aMtrx.getColDim();

        final String[][] tmpElements = new String[tmpRowDim][tmpColDim];

        int tmpWidth = 0;
        BigDecimal tmpElementNumber;
        String tmpElementString;
        for (int j = 0; j < tmpColDim; j++) {
            for (int i = 0; i < tmpRowDim; i++) {
                tmpElementNumber = aCntxt.enforce(aMtrx.toBigDecimal(i, j)).stripTrailingZeros();
                if (tmpElementNumber.signum() == 0) {
                    tmpElementNumber = BigMath.ZERO;
                }
                tmpElementString = tmpElementNumber.toPlainString();
                tmpWidth = StrictMath.max(tmpWidth, tmpElementString.length());
                tmpElements[i][j] = tmpElementString;
            }
        }
        tmpWidth++;

        int tmpPadding;
        aPrintStream.println();
        for (int i = 0; i < tmpRowDim; i++) {
            for (int j = 0; j < tmpColDim; j++) {
                tmpElementString = tmpElements[i][j];
                tmpPadding = tmpWidth - tmpElementString.length();
                for (int p = 0; p < tmpPadding; p++) {
                    aPrintStream.print(ASCII.SP);
                }
                aPrintStream.print(tmpElementString);
            }
            aPrintStream.println();
        }
    }

    public static void printToStream(final PrintStream aPrintStream, final MatrixStore<?> aStore, final NumberContext aCntxt) {
        MatrixUtils.printToStream(aPrintStream, BigMatrix.FACTORY.copyStore(aStore), aCntxt);
    }

    public static String toString(final BasicMatrix aMtrx) {

        final StringBuilder retVal = new StringBuilder(aMtrx.getClass().toString());

        if (aMtrx.isEmpty()) {

            retVal.append(" is empty!");

        } else {

            // First element
            retVal.append("\n{{" + aMtrx.toString(0, 0));

            // Rest of the first row
            for (int j = 1; j < aMtrx.getColDim(); j++) {
                retVal.append(",\t" + aMtrx.toString(0, j));
            }

            // For each of the remaining rows
            for (int i = 1; i < aMtrx.getRowDim(); i++) {

                // First column
                retVal.append("},\n{" + aMtrx.toString(i, 0));

                // Remaining coulmns
                for (int j = 1; j < aMtrx.getColDim(); j++) {
                    retVal.append(",\t" + aMtrx.toString(i, j));
                }
            }

            // Finish
            retVal.append("}}\n");
        }

        return retVal.toString();
    }

    public static Access2D<BigDecimal> wrapBigAccess2D(final BasicMatrix aMtrx) {
        return new Access2D<BigDecimal>() {

            public double doubleValue(final int aRow, final int aCol) {
                return aMtrx.doubleValue(aRow, aCol);
            }

            public BigDecimal get(final int aRow, final int aCol) {
                return aMtrx.toBigDecimal(aRow, aCol);
            }

            public int getColDim() {
                return aMtrx.getColDim();
            }

            public int getMinDim() {
                return StrictMath.min(aMtrx.getRowDim(), aMtrx.getColDim());
            }

            public int getRowDim() {
                return aMtrx.getRowDim();
            }

            public int size() {
                return aMtrx.size();
            }

            public BigScalar toScalar(final int aRow, final int aCol) {
                return new BigScalar(aMtrx.toBigDecimal(aRow, aCol));
            }
        };
    }

    public static Access2D<ComplexNumber> wrapComplexAccess2D(final BasicMatrix aMtrx) {
        return new Access2D<ComplexNumber>() {

            public double doubleValue(final int aRow, final int aCol) {
                return aMtrx.doubleValue(aRow, aCol);
            }

            public ComplexNumber get(final int aRow, final int aCol) {
                return aMtrx.toComplexNumber(aRow, aCol);
            }

            public int getColDim() {
                return aMtrx.getColDim();
            }

            public int getMinDim() {
                return StrictMath.min(aMtrx.getRowDim(), aMtrx.getColDim());
            }

            public int getRowDim() {
                return aMtrx.getRowDim();
            }

            public int size() {
                return aMtrx.size();
            }

            public ComplexNumber toScalar(final int aRow, final int aCol) {
                return aMtrx.toComplexNumber(aRow, aCol);
            }
        };
    }

    public static Access2D<Double> wrapPrimitiveAccess2D(final BasicMatrix aMtrx) {
        return new Access2D<Double>() {

            public double doubleValue(final int aRow, final int aCol) {
                return aMtrx.doubleValue(aRow, aCol);
            }

            public Double get(final int aRow, final int aCol) {
                return aMtrx.doubleValue(aRow, aCol);
            }

            public int getColDim() {
                return aMtrx.getColDim();
            }

            public int getMinDim() {
                return StrictMath.min(aMtrx.getRowDim(), aMtrx.getColDim());
            }

            public int getRowDim() {
                return aMtrx.getRowDim();
            }

            public int size() {
                return aMtrx.size();
            }

            public PrimitiveScalar toScalar(final int aRow, final int aCol) {
                return new PrimitiveScalar(aMtrx.doubleValue(aRow, aCol));
            }
        };
    }

    private MatrixUtils() {
        super();
    }
}
