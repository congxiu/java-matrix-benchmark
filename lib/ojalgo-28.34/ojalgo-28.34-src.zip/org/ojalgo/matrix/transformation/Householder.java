/*
 * Copyright © 2009 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.transformation;

import java.math.BigDecimal;

import org.ojalgo.array.Array1D;
import org.ojalgo.constant.BigMath;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.function.implementation.ComplexFunction;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;

public final class Householder<N extends Number> extends Object {

    public static BigDecimal copyToBig(final Householder<BigDecimal> aSource, final BigDecimal[] aDestination) {
        BigDecimal tmpVal, retVal = BigMath.ZERO;
        final int tmpSize = aSource.size();
        for (int i = aSource.first(); i < tmpSize; i++) {
            tmpVal = aSource.getNumber(BigDenseStore.FACTORY, i);
            retVal = BigFunction.ADD.invoke(retVal, BigFunction.MULTIPLY.invoke(tmpVal, tmpVal));
            aDestination[i] = tmpVal;
        }
        retVal = BigFunction.DIVIDE.invoke(BigMath.TWO, retVal);
        return retVal; //beta
    }

    public static ComplexNumber copyToComplex(final Householder<ComplexNumber> aSource, final ComplexNumber[] aDestination) {
        ComplexNumber tmpVal, retVal = ComplexNumber.ZERO;
        final int tmpSize = aSource.size();
        for (int i = aSource.first(); i < tmpSize; i++) {
            tmpVal = aSource.getNumber(ComplexDenseStore.FACTORY, i);
            retVal = ComplexFunction.ADD.invoke(retVal, ComplexFunction.MULTIPLY.invoke(tmpVal, tmpVal));
            aDestination[i] = tmpVal;
        }
        retVal = ComplexFunction.DIVIDE.invoke(ComplexNumber.ONE.add(ComplexNumber.ONE), retVal);
        return retVal; //beta
    }

    public static double copyToPrimitive(final Householder<Double> aSource, final double[] aDestination) {
        double tmpVal, retVal = PrimitiveMath.ZERO;
        final int tmpSize = aSource.size();
        for (int i = aSource.first(); i < tmpSize; i++) {
            tmpVal = aSource.doubleValue(i);
            retVal += tmpVal * tmpVal;
            aDestination[i] = tmpVal;
        }
        retVal = PrimitiveMath.TWO / retVal;
        return retVal; //beta
    }

    public static Householder<BigDecimal> makeBig(final BigDecimal[] allVectorElements) {
        return new Householder<BigDecimal>(0, false, Array1D.makeBig(allVectorElements));
    }

    public static Householder<BigDecimal> makeBig(final int aNumberOfLeadingZeros, final boolean aLeadingOneOrNot, final BigDecimal[] theRemainingVectorElements) {
        return new Householder<BigDecimal>(aNumberOfLeadingZeros, aLeadingOneOrNot, Array1D.makeBig(theRemainingVectorElements));
    }

    public static Householder<ComplexNumber> makeComplex(final ComplexNumber[] allVectorElements) {
        return new Householder<ComplexNumber>(0, false, Array1D.makeComplex(allVectorElements));
    }

    public static Householder<ComplexNumber> makeComplex(final int aNumberOfLeadingZeros, final boolean aLeadingOneOrNot, final ComplexNumber[] theRemainingVectorElements) {
        return new Householder<ComplexNumber>(aNumberOfLeadingZeros, aLeadingOneOrNot, Array1D.makeComplex(theRemainingVectorElements));
    }

    public static Householder<Double> makePrimitive(final double[] allVectorElements) {
        return new Householder<Double>(0, false, Array1D.makePrimitive(allVectorElements));
    }

    public static Householder<Double> makePrimitive(final int aNumberOfLeadingZeros, final boolean aLeadingOneOrNot, final double[] theRemainingVectorElements) {
        return new Householder<Double>(aNumberOfLeadingZeros, aLeadingOneOrNot, Array1D.makePrimitive(theRemainingVectorElements));
    }

    private final int myZeros;
    private final boolean myOne;
    private final Array1D<N> myRemaining;

    public Householder(final int aNumberOfLeadingZeros, final boolean aLeadingOneOrNot, final Array1D<N> theRemainingVectorElements) {

        super();

        myZeros = aNumberOfLeadingZeros;
        myOne = aLeadingOneOrNot;
        myRemaining = theRemainingVectorElements;
    }

    public double doubleValue(final int anIndex) {
        if (anIndex < myZeros) {
            return PrimitiveMath.ZERO;
        } else if (myOne && (anIndex == myZeros)) {
            return PrimitiveMath.ONE;
        } else {
            return myRemaining.doubleValue(myOne ? anIndex - 1 - myZeros : anIndex - myZeros);
        }
    }

    /**
     * @return The index of the first non-zero Householder vector element.
     */
    public int first() {
        return myZeros;
    }

    public N getNumber(final PhysicalStore.Factory<N> aFactory, final int anIndex) {
        if (anIndex < myZeros) {
            return aFactory.getStaticZero().getNumber();
        } else if (myOne && (anIndex == myZeros)) {
            return aFactory.getStaticOne().getNumber();
        } else {
            return myRemaining.get(myOne ? anIndex - 1 - myZeros : anIndex - myZeros);
        }
    }

    /**
    * @return The size/length of the Householder vector.
    */
    public int size() {
        return myOne ? myZeros + 1 + myRemaining.length : myZeros + myRemaining.length;
    }

    public Scalar<N> toScalar(final PhysicalStore.Factory<N> aFactory, final int anIndex) {
        if (anIndex < myZeros) {
            return aFactory.getStaticZero();
        } else if (myOne && (anIndex == myZeros)) {
            return aFactory.getStaticOne();
        } else {
            return myRemaining.toScalar(myOne ? anIndex - 1 - myZeros : anIndex - myZeros);
        }
    }

}
