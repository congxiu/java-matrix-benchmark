/*
 * Copyright © 2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.util.Arrays;

import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.TypeUtils;

abstract class EvD1<N extends Number> extends EigenvalueDecomposition<N> {

    /** Eigenvalues and eigenvectors of a real matrix. 
     <P>
     If A is symmetric, then A = V*D*V' where the eigenvalue matrix D is
     diagonal and the eigenvector matrix V is orthogonal.
     I.e. A = V.times(D.times(V.transpose())) and 
     V.times(V.transpose()) equals the identity matrix.
     <P>
     If A is not symmetric, then the eigenvalue matrix D is block diagonal
     with the real eigenvalues in 1-by-1 blocks and any complex eigenvalues,
     lambda + i*mu, in 2-by-2 blocks, [lambda, mu; -mu, lambda].  The
     columns of V represent the eigenvectors in the sense that A*V = V*D,
     i.e. A.times(V) equals V.times(D).  The matrix V may be badly
     conditioned, or even singular, so the validity of the equation
     A = V*D*inverse(V) depends upon V.cond().
     **/
    static final class Primitive extends EvD1<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

        public boolean computeNonsymmetric(final MatrixStore<Double> aNonsymmetricStore) {

            this.setSymmetric(false);

            final int tmpDim = aNonsymmetricStore.getRowDim();

            final double[] tmpMainDiagonal = new double[tmpDim];
            final double[] tmpOffDiagonal = new double[tmpDim];

            final double[][] tmpV = new double[tmpDim][tmpDim];
            for (int ij = 0; ij < tmpDim; ij++) {
                tmpV[ij][ij] = PrimitiveMath.ONE;
            }

            final double[] tmpH = new double[tmpDim * tmpDim];
            int tmpIndex = 0;
            for (int j = 0; j < tmpDim; j++) {
                for (int i = 0; i < tmpDim; i++) {
                    tmpH[tmpIndex] = aNonsymmetricStore.doubleValue(i, j);
                    tmpIndex++;
                }
            }

            EvD1.doCalculation(tmpMainDiagonal, tmpOffDiagonal, tmpV, tmpH);

            final int tmpDim1 = tmpMainDiagonal.length;

            final Array1D<ComplexNumber> tmpEigenvalues = Array1D.makeComplex(tmpDim1);
            final PhysicalStore<Double> tmpD = PrimitiveDenseStore.FACTORY.makeZero(tmpDim1, tmpDim1);

            double tmpMainDiag;
            double tmpOffDiag;
            for (int ij = 0; ij < tmpDim1; ij++) {

                tmpMainDiag = tmpMainDiagonal[ij];
                tmpOffDiag = tmpOffDiagonal[ij];

                tmpEigenvalues.set(ij, ComplexNumber.fromRectangularCoordinates(tmpMainDiag, tmpOffDiag));

                tmpD.set(ij, ij, tmpMainDiag);
                if (tmpOffDiag > PrimitiveMath.ZERO) {
                    tmpD.set(ij, ij + 1, tmpOffDiag);
                } else if (tmpOffDiag < PrimitiveMath.ZERO) {
                    tmpD.set(ij, ij - 1, tmpOffDiag);
                }
            }

            tmpEigenvalues.sortDescending();

            this.setEigenvalues(tmpEigenvalues);
            this.setD(tmpD);
            this.setV(this.getFactory().copy(tmpV));

            return this.computed(true);
        }

        @Override
        protected DiagonalAccess<Double> extractTridiagonal(final PhysicalStore<Double> aMtrxD) {

            final Array2D<Double> tmpArray2D = ((PrimitiveDenseStore) aMtrxD).asArray2D();

            final Array1D<Double> tmpMain = tmpArray2D.sliceDiagonal(0, 0);
            //final Array1D<Double> tmpSuper = tmpArray2D.sliceDiagonal(0, 1); All elements un super has not been correctly calculated, but sub and super shouldbe the same.
            final Array1D<Double> tmpSub = tmpArray2D.sliceDiagonal(1, 0);

            return DiagonalAccess.makePrimitive(tmpMain, tmpSub, tmpSub);
        }

        @Override
        protected DiagonalAccess<Double> toDiagonal(final DiagonalAccess<Double> aTridiagonal, final PhysicalStore<Double> aV) {

            final double[] tmpMainDiagonal = aTridiagonal.mainDiagonal.toRawCopy();

            final int tmpDim = tmpMainDiagonal.length;
            final int tmpLim = tmpDim - 1;

            final double[] tmpOffDiagonal = new double[tmpDim];
            final Array1D<Double> tmpSuperdiagonal = aTridiagonal.superdiagonal;
            for (int i = 0; i < tmpLim; i++) {
                tmpOffDiagonal[i] = tmpSuperdiagonal.doubleValue(i);
            }

            if (AbstractDecomposition.DEBUG) {
                BasicLogger.logDebug("BEGIN diagonalize");
                BasicLogger.logDebug("Main D: {}", Arrays.toString(tmpMainDiagonal));
                BasicLogger.logDebug("Seco D: {}", Arrays.toString(tmpOffDiagonal));
                BasicLogger.logDebug("V", aV);
                BasicLogger.logDebug();
            }

            double tmpShift = PrimitiveMath.ZERO;
            double tmpShiftIncr;

            double tmpMagnitude = PrimitiveMath.ZERO;
            double tmpLocalEpsilon;

            int m;
            // Main loop
            for (int l = 0; l < tmpDim; l++) {

                if (AbstractDecomposition.DEBUG) {
                    EvD1.log("Loop l=" + l, tmpMainDiagonal, tmpOffDiagonal);
                }

                // Find small subdiagonal element
                tmpMagnitude = StrictMath.max(tmpMagnitude, StrictMath.abs(tmpMainDiagonal[l]) + StrictMath.abs(tmpOffDiagonal[l]));
                tmpLocalEpsilon = PrimitiveMath.MACHINE_DOUBLE_ERROR * tmpMagnitude;

                m = l;
                while (m < tmpDim) {
                    if (Math.abs(tmpOffDiagonal[m]) <= tmpLocalEpsilon) {
                        break;
                    }
                    m++;
                }

                // If m == l, aMainDiagonal[l] is an eigenvalue, otherwise, iterate.
                if (m > l) {

                    do {

                        final double tmp1Ml0 = tmpMainDiagonal[l];
                        final double tmp1Ml1 = tmpMainDiagonal[l + 1];
                        final double tmp1Sl0 = tmpOffDiagonal[l];

                        // Compute implicit shift

                        double p = (tmp1Ml1 - tmp1Ml0) / (tmp1Sl0 + tmp1Sl0);
                        double r = Math.hypot(p, PrimitiveMath.ONE);
                        if (p < 0) {
                            r = -r;
                        }

                        final double tmp2Ml0 = tmpMainDiagonal[l] = tmp1Sl0 / (p + r);
                        final double tmp2Ml1 = tmpMainDiagonal[l + 1] = tmp1Sl0 * (p + r);
                        final double tmp2Sl1 = tmpOffDiagonal[l + 1];

                        tmpShiftIncr = tmp1Ml0 - tmp2Ml0;
                        for (int i = l + 2; i < tmpDim; i++) {
                            tmpMainDiagonal[i] -= tmpShiftIncr;
                        }
                        tmpShift += tmpShiftIncr;

                        if (AbstractDecomposition.DEBUG) {
                            EvD1.log("New shift =" + tmpShift, tmpMainDiagonal, tmpOffDiagonal);
                        }

                        // Implicit QL transformation

                        double tmpRotCos = PrimitiveMath.ONE;
                        double tmpRotSin = PrimitiveMath.ZERO;

                        double tmpRotCos2 = tmpRotCos;
                        double tmpRotSin2 = PrimitiveMath.ZERO;

                        double tmpRotCos3 = tmpRotCos;

                        p = tmpMainDiagonal[m]; // Initiate p
                        for (int i = m - 1; i >= l; i--) {

                            final double tmp1Mi0 = tmpMainDiagonal[i];
                            final double tmp1Si0 = tmpOffDiagonal[i];

                            r = Math.hypot(p, tmp1Si0);

                            tmpRotCos3 = tmpRotCos2;

                            tmpRotCos2 = tmpRotCos;
                            tmpRotSin2 = tmpRotSin;

                            tmpRotCos = p / r;
                            tmpRotSin = tmp1Si0 / r;

                            tmpMainDiagonal[i + 1] = tmpRotCos2 * p + tmpRotSin * (tmpRotCos * tmpRotCos2 * tmp1Si0 + tmpRotSin * tmp1Mi0);
                            tmpOffDiagonal[i + 1] = tmpRotSin2 * r;

                            p = tmpRotCos * tmp1Mi0 - tmpRotSin * tmpRotCos2 * tmp1Si0; // Next p

                            // Accumulate transformation - rotate the eigenvector matrix
                            aV.transformRight(new Rotation<Double>(i, i + 1, tmpRotCos, tmpRotSin));

                            if (AbstractDecomposition.DEBUG) {
                                EvD1.log("QL step done i=" + i, tmpMainDiagonal, tmpOffDiagonal);
                            }

                        }

                        p = -tmpRotSin * tmpRotSin2 * tmpRotCos3 * tmp2Sl1 * tmpOffDiagonal[l] / tmp2Ml1; // Final p

                        tmpMainDiagonal[l] = tmpRotCos * p;
                        tmpOffDiagonal[l] = tmpRotSin * p;

                    } while (Math.abs(tmpOffDiagonal[l]) > tmpLocalEpsilon); // Check for convergence
                } // End if (m > l)

                final double tmpEigenvalue = tmpMainDiagonal[l] + tmpShift;
                if (TypeUtils.isZero(tmpEigenvalue)) {
                    tmpMainDiagonal[l] = PrimitiveMath.ZERO;
                } else {
                    tmpMainDiagonal[l] = tmpEigenvalue;
                }
                tmpOffDiagonal[l] = PrimitiveMath.ZERO;
            } // End main loop - l

            if (AbstractDecomposition.DEBUG) {
                BasicLogger.logDebug("END diagonalize");
                BasicLogger.logDebug("Main D: {}", Arrays.toString(tmpMainDiagonal));
                BasicLogger.logDebug("Seco D: {}", Arrays.toString(tmpOffDiagonal));
                BasicLogger.logDebug("V", aV);
                BasicLogger.logDebug();
            }

            return DiagonalAccess.makePrimitive(Array1D.wrapPrimitive(tmpMainDiagonal), null, null);
        }

        @Override
        protected DiagonalAccess<Double> toSchur(final PhysicalStore<Double> aHessenberg, final PhysicalStore<Double> aMtrxV) {
            // TODO Auto-generated method stub
            return null;
        }

    }

    private static void log(final String aString, final double[] aMainDiagonal, final double[] anOffDiagonal) {

        final Array1D<Double> tmpMain = Array1D.wrapPrimitive(aMainDiagonal);
        final Array1D<Double> tmpOff = Array1D.wrapPrimitive(anOffDiagonal);

        final DiagonalAccess<Double> tmpDiag = DiagonalAccess.makePrimitive(tmpMain, tmpOff, tmpOff);

        BasicLogger.logDebug(aString, PrimitiveDenseStore.FACTORY.copy(tmpDiag));
    }

    static void doCalculation(final double[] tmpMainDiagonal, final double[] tmpOffDiagonal, final double[][] tmpV, final double[] aMtrxH) {

        final int tmpDim = tmpMainDiagonal.length;

        final double[] tmpOrt = new double[tmpDim];

        //  This is derived from the Algol procedures orthes and ortran,
        //  by Martin and Wilkinson, Handbook for Auto. Comp.,
        //  Vol.ii-Linear Algebra, and the corresponding
        //  Fortran subroutines in EISPACK.

        final int tmpDimMinusOne = tmpDim - 1;

        for (int m = 1; m < tmpDimMinusOne; m++) {

            // Scale column.

            double tmpScale = PrimitiveMath.ZERO;
            for (int i = m; i <= tmpDimMinusOne; i++) {
                tmpScale += Math.abs(aMtrxH[i + tmpDim * (m - 1)]);
            }
            if (tmpScale != PrimitiveMath.ZERO) {

                // Compute Householder transformation.

                double h = PrimitiveMath.ZERO;
                for (int i = tmpDimMinusOne; i >= m; i--) {
                    tmpOrt[i] = aMtrxH[i + tmpDim * (m - 1)] / tmpScale;
                    h += tmpOrt[i] * tmpOrt[i];
                }
                double g = Math.sqrt(h);
                if (tmpOrt[m] > 0) {
                    g = -g;
                }
                h = h - tmpOrt[m] * g;
                tmpOrt[m] = tmpOrt[m] - g;

                // Apply Householder similarity transformation
                // H = (I-u*u'/h)*H*(I-u*u')/h)

                for (int j = m; j < tmpDim; j++) {
                    double f = PrimitiveMath.ZERO;
                    for (int i = tmpDimMinusOne; i >= m; i--) {
                        f += tmpOrt[i] * aMtrxH[i + tmpDim * j];
                    }
                    f = f / h;
                    for (int i = m; i <= tmpDimMinusOne; i++) {
                        aMtrxH[i + tmpDim * j] -= f * tmpOrt[i];
                    }
                }

                for (int i = 0; i <= tmpDimMinusOne; i++) {
                    double f = PrimitiveMath.ZERO;
                    for (int j = tmpDimMinusOne; j >= m; j--) {
                        f += tmpOrt[j] * aMtrxH[i + tmpDim * j];
                    }
                    f = f / h;
                    for (int j = m; j <= tmpDimMinusOne; j++) {
                        aMtrxH[i + tmpDim * j] -= f * tmpOrt[j];
                    }
                }
                tmpOrt[m] = tmpScale * tmpOrt[m];
                aMtrxH[m + tmpDim * (m - 1)] = tmpScale * g;
            }
        }

        // Accumulate transformations (Algol's ortran).

        for (int m = tmpDimMinusOne - 1; m >= 1; m--) {
            if (aMtrxH[m + tmpDim * (m - 1)] != PrimitiveMath.ZERO) {
                for (int i = m + 1; i <= tmpDimMinusOne; i++) {
                    tmpOrt[i] = aMtrxH[i + tmpDim * (m - 1)];
                }
                for (int j = m; j <= tmpDimMinusOne; j++) {
                    double g = PrimitiveMath.ZERO;
                    for (int i = m; i <= tmpDimMinusOne; i++) {
                        g += tmpOrt[i] * tmpV[i][j];
                    }
                    // Double division avoids possible underflow
                    g = (g / tmpOrt[m]) / aMtrxH[m + tmpDim * (m - 1)];
                    for (int i = m; i <= tmpDimMinusOne; i++) {
                        tmpV[i][j] += g * tmpOrt[i];
                    }
                }
            }
        }

        int n = tmpDimMinusOne;
        double exshift = PrimitiveMath.ZERO;
        double p = 0, q = 0, r = 0, s = 0, z = 0, t, w, x, y;

        // Store roots isolated by balanc and compute matrix norm

        double tmpNorm = PrimitiveMath.ZERO;
        for (int i = 0; i < tmpDim; i++) {
            if ((i < 0) | (i > tmpDimMinusOne)) {
                tmpMainDiagonal[i] = aMtrxH[i + tmpDim * i];
                tmpOffDiagonal[i] = PrimitiveMath.ZERO;
            }
            for (int j = Math.max(i - 1, 0); j < tmpDim; j++) {
                tmpNorm = tmpNorm + Math.abs(aMtrxH[i + tmpDim * j]);
            }
        }

        // Outer loop over eigenvalue index

        int iter = 0;
        while (n >= 0) {

            // Look for single small sub-diagonal element

            int l = n;
            while (l > 0) {
                s = Math.abs(aMtrxH[(l - 1) + tmpDim * (l - 1)]) + Math.abs(aMtrxH[l + tmpDim * l]);
                if (s == PrimitiveMath.ZERO) {
                    s = tmpNorm;
                }
                if (Math.abs(aMtrxH[l + tmpDim * (l - 1)]) < PrimitiveMath.MACHINE_DOUBLE_ERROR * s) {
                    break;
                }
                l--;
            }

            // Check for convergence
            // One root found

            if (l == n) {
                aMtrxH[n + tmpDim * n] = aMtrxH[n + tmpDim * n] + exshift;
                tmpMainDiagonal[n] = aMtrxH[n + tmpDim * n];
                tmpOffDiagonal[n] = PrimitiveMath.ZERO;
                n--;
                iter = 0;

                // Two roots found

            } else if (l == n - 1) {
                w = aMtrxH[n + tmpDim * (n - 1)] * aMtrxH[(n - 1) + tmpDim * n];
                p = (aMtrxH[(n - 1) + tmpDim * (n - 1)] - aMtrxH[n + tmpDim * n]) / 2.0;
                q = p * p + w;
                z = Math.sqrt(Math.abs(q));
                aMtrxH[n + tmpDim * n] = aMtrxH[n + tmpDim * n] + exshift;
                aMtrxH[(n - 1) + tmpDim * (n - 1)] = aMtrxH[(n - 1) + tmpDim * (n - 1)] + exshift;
                x = aMtrxH[n + tmpDim * n];

                // Real pair

                if (q >= 0) {
                    if (p >= 0) {
                        z = p + z;
                    } else {
                        z = p - z;
                    }
                    tmpMainDiagonal[n - 1] = x + z;
                    tmpMainDiagonal[n] = tmpMainDiagonal[n - 1];
                    if (z != PrimitiveMath.ZERO) {
                        tmpMainDiagonal[n] = x - w / z;
                    }
                    tmpOffDiagonal[n - 1] = PrimitiveMath.ZERO;
                    tmpOffDiagonal[n] = PrimitiveMath.ZERO;
                    x = aMtrxH[n + tmpDim * (n - 1)];
                    s = Math.abs(x) + Math.abs(z);
                    p = x / s;
                    q = z / s;
                    r = Math.sqrt(p * p + q * q);
                    p = p / r;
                    q = q / r;

                    // Row modification

                    for (int j = n - 1; j < tmpDim; j++) {
                        z = aMtrxH[(n - 1) + tmpDim * j];
                        aMtrxH[(n - 1) + tmpDim * j] = q * z + p * aMtrxH[n + tmpDim * j];
                        aMtrxH[n + tmpDim * j] = q * aMtrxH[n + tmpDim * j] - p * z;
                    }

                    // Column modification

                    for (int i = 0; i <= n; i++) {
                        z = aMtrxH[i + tmpDim * (n - 1)];
                        aMtrxH[i + tmpDim * (n - 1)] = q * z + p * aMtrxH[i + tmpDim * n];
                        aMtrxH[i + tmpDim * n] = q * aMtrxH[i + tmpDim * n] - p * z;
                    }

                    // Accumulate transformations

                    for (int i = 0; i <= tmpDimMinusOne; i++) {
                        z = tmpV[i][n - 1];
                        tmpV[i][n - 1] = q * z + p * tmpV[i][n];
                        tmpV[i][n] = q * tmpV[i][n] - p * z;
                    }

                    // Complex pair

                } else {
                    tmpMainDiagonal[n - 1] = x + p;
                    tmpMainDiagonal[n] = x + p;
                    tmpOffDiagonal[n - 1] = z;
                    tmpOffDiagonal[n] = -z;
                }
                n = n - 2;
                iter = 0;

                // No convergence yet

            } else {

                // Form shift

                x = aMtrxH[n + tmpDim * n];
                y = PrimitiveMath.ZERO;
                w = PrimitiveMath.ZERO;
                if (l < n) {
                    y = aMtrxH[(n - 1) + tmpDim * (n - 1)];
                    w = aMtrxH[n + tmpDim * (n - 1)] * aMtrxH[(n - 1) + tmpDim * n];
                }

                // Wilkinson's original ad hoc shift

                if (iter == 10) {
                    exshift += x;
                    for (int i = 0; i <= n; i++) {
                        aMtrxH[i + tmpDim * i] -= x;
                    }
                    s = Math.abs(aMtrxH[n + tmpDim * (n - 1)]) + Math.abs(aMtrxH[(n - 1) + tmpDim * (n - 2)]);
                    x = y = 0.75 * s;
                    w = -0.4375 * s * s;
                }

                // MATLAB's new ad hoc shift

                if (iter == 30) {
                    s = (y - x) / 2.0;
                    s = s * s + w;
                    if (s > 0) {
                        s = Math.sqrt(s);
                        if (y < x) {
                            s = -s;
                        }
                        s = x - w / ((y - x) / 2.0 + s);
                        for (int i = 0; i <= n; i++) {
                            aMtrxH[i + tmpDim * i] -= s;
                        }
                        exshift += s;
                        x = y = w = 0.964;
                    }
                }

                iter = iter + 1; // (Could check iteration count here.)

                // Look for two consecutive small sub-diagonal elements

                int m = n - 2;
                while (m >= l) {
                    z = aMtrxH[m + tmpDim * m];
                    r = x - z;
                    s = y - z;
                    p = (r * s - w) / aMtrxH[(m + 1) + tmpDim * m] + aMtrxH[m + tmpDim * (m + 1)];
                    q = aMtrxH[(m + 1) + tmpDim * (m + 1)] - z - r - s;
                    r = aMtrxH[(m + 2) + tmpDim * (m + 1)];
                    s = Math.abs(p) + Math.abs(q) + Math.abs(r);
                    p = p / s;
                    q = q / s;
                    r = r / s;
                    if (m == l) {
                        break;
                    }
                    if (Math.abs(aMtrxH[m + tmpDim * (m - 1)]) * (Math.abs(q) + Math.abs(r)) < PrimitiveMath.MACHINE_DOUBLE_ERROR * (Math.abs(p) * (Math.abs(aMtrxH[(m - 1) + tmpDim * (m - 1)]) + Math.abs(z) + Math.abs(aMtrxH[(m + 1) + tmpDim * (m + 1)])))) {
                        break;
                    }
                    m--;
                }

                for (int i = m + 2; i <= n; i++) {
                    aMtrxH[i + tmpDim * (i - 2)] = PrimitiveMath.ZERO;
                    if (i > m + 2) {
                        aMtrxH[i + tmpDim * (i - 3)] = PrimitiveMath.ZERO;
                    }
                }

                // Double QR step involving rows l:n and columns m:n

                for (int k = m; k <= n - 1; k++) {
                    final boolean notlast = (k != n - 1);
                    if (k != m) {
                        p = aMtrxH[k + tmpDim * (k - 1)];
                        q = aMtrxH[(k + 1) + tmpDim * (k - 1)];
                        r = (notlast ? aMtrxH[(k + 2) + tmpDim * (k - 1)] : PrimitiveMath.ZERO);
                        x = Math.abs(p) + Math.abs(q) + Math.abs(r);
                        if (x != PrimitiveMath.ZERO) {
                            p = p / x;
                            q = q / x;
                            r = r / x;
                        }
                    }
                    if (x == PrimitiveMath.ZERO) {
                        break;
                    }
                    s = Math.sqrt(p * p + q * q + r * r);
                    if (p < 0) {
                        s = -s;
                    }
                    if (s != 0) {
                        if (k != m) {
                            aMtrxH[k + tmpDim * (k - 1)] = -s * x;
                        } else if (l != m) {
                            aMtrxH[k + tmpDim * (k - 1)] = -aMtrxH[k + tmpDim * (k - 1)];
                        }
                        p = p + s;
                        x = p / s;
                        y = q / s;
                        z = r / s;
                        q = q / p;
                        r = r / p;

                        // Row modification

                        for (int j = k; j < tmpDim; j++) {
                            p = aMtrxH[k + tmpDim * j] + q * aMtrxH[(k + 1) + tmpDim * j];
                            if (notlast) {
                                p = p + r * aMtrxH[(k + 2) + tmpDim * j];
                                aMtrxH[(k + 2) + tmpDim * j] = aMtrxH[(k + 2) + tmpDim * j] - p * z;
                            }
                            aMtrxH[k + tmpDim * j] = aMtrxH[k + tmpDim * j] - p * x;
                            aMtrxH[(k + 1) + tmpDim * j] = aMtrxH[(k + 1) + tmpDim * j] - p * y;
                        }

                        // Column modification

                        for (int i = 0; i <= Math.min(n, k + 3); i++) {
                            p = x * aMtrxH[i + tmpDim * k] + y * aMtrxH[i + tmpDim * (k + 1)];
                            if (notlast) {
                                p = p + z * aMtrxH[i + tmpDim * (k + 2)];
                                aMtrxH[i + tmpDim * (k + 2)] = aMtrxH[i + tmpDim * (k + 2)] - p * r;
                            }
                            aMtrxH[i + tmpDim * k] = aMtrxH[i + tmpDim * k] - p;
                            aMtrxH[i + tmpDim * (k + 1)] = aMtrxH[i + tmpDim * (k + 1)] - p * q;
                        }

                        // Accumulate transformations

                        for (int i = 0; i <= tmpDimMinusOne; i++) {
                            p = x * tmpV[i][k] + y * tmpV[i][k + 1];
                            if (notlast) {
                                p = p + z * tmpV[i][k + 2];
                                tmpV[i][k + 2] = tmpV[i][k + 2] - p * r;
                            }
                            tmpV[i][k] = tmpV[i][k] - p;
                            tmpV[i][k + 1] = tmpV[i][k + 1] - p * q;
                        }
                    } // (s != 0)
                } // k loop
            } // check convergence
        } // while (n >= low)

        // Backsubstitute to find vectors of upper triangular form

        if (tmpNorm != PrimitiveMath.ZERO) {

            for (n = tmpDim - 1; n >= 0; n--) {
                p = tmpMainDiagonal[n];
                q = tmpOffDiagonal[n];

                // Real vector

                if (q == 0) {
                    int l = n;
                    aMtrxH[n + tmpDim * n] = 1.0;
                    for (int i = n - 1; i >= 0; i--) {
                        w = aMtrxH[i + tmpDim * i] - p;
                        r = PrimitiveMath.ZERO;
                        for (int j = l; j <= n; j++) {
                            r = r + aMtrxH[i + tmpDim * j] * aMtrxH[j + tmpDim * n];
                        }
                        if (tmpOffDiagonal[i] < PrimitiveMath.ZERO) {
                            z = w;
                            s = r;
                        } else {
                            l = i;
                            if (tmpOffDiagonal[i] == PrimitiveMath.ZERO) {
                                if (w != PrimitiveMath.ZERO) {
                                    aMtrxH[i + tmpDim * n] = -r / w;
                                } else {
                                    aMtrxH[i + tmpDim * n] = -r / (PrimitiveMath.MACHINE_DOUBLE_ERROR * tmpNorm);
                                }

                                // Solve real equations

                            } else {
                                x = aMtrxH[i + tmpDim * (i + 1)];
                                y = aMtrxH[(i + 1) + tmpDim * i];
                                q = (tmpMainDiagonal[i] - p) * (tmpMainDiagonal[i] - p) + tmpOffDiagonal[i] * tmpOffDiagonal[i];
                                t = (x * s - z * r) / q;
                                aMtrxH[i + tmpDim * n] = t;
                                if (Math.abs(x) > Math.abs(z)) {
                                    aMtrxH[(i + 1) + tmpDim * n] = (-r - w * t) / x;
                                } else {
                                    aMtrxH[(i + 1) + tmpDim * n] = (-s - y * t) / z;
                                }
                            }

                            // Overflow control

                            t = Math.abs(aMtrxH[i + tmpDim * n]);
                            if ((PrimitiveMath.MACHINE_DOUBLE_ERROR * t) * t > 1) {
                                for (int j = i; j <= n; j++) {
                                    aMtrxH[j + tmpDim * n] = aMtrxH[j + tmpDim * n] / t;
                                }
                            }
                        }
                    }

                    // Complex vector

                } else if (q < 0) {
                    int l = n - 1;

                    // Last vector component imaginary so matrix is triangular

                    if (Math.abs(aMtrxH[n + tmpDim * (n - 1)]) > Math.abs(aMtrxH[(n - 1) + tmpDim * n])) {
                        aMtrxH[(n - 1) + tmpDim * (n - 1)] = q / aMtrxH[n + tmpDim * (n - 1)];
                        aMtrxH[(n - 1) + tmpDim * n] = -(aMtrxH[n + tmpDim * n] - p) / aMtrxH[n + tmpDim * (n - 1)];
                    } else {

                        final ComplexNumber tmpX = ComplexNumber.fromRectangularCoordinates(PrimitiveMath.ZERO, (-aMtrxH[(n - 1) + tmpDim * n]));
                        final ComplexNumber tmpY = ComplexNumber.fromRectangularCoordinates((aMtrxH[(n - 1) + tmpDim * (n - 1)] - p), q);

                        final ComplexNumber tmpZ = tmpX.divide(tmpY);

                        aMtrxH[(n - 1) + tmpDim * (n - 1)] = tmpZ.getReal();
                        aMtrxH[(n - 1) + tmpDim * n] = tmpZ.getImaginary();
                    }
                    aMtrxH[n + tmpDim * (n - 1)] = PrimitiveMath.ZERO;
                    aMtrxH[n + tmpDim * n] = 1.0;
                    for (int i = n - 2; i >= 0; i--) {
                        double ra, sa, vr, vi;
                        ra = PrimitiveMath.ZERO;
                        sa = PrimitiveMath.ZERO;
                        for (int j = l; j <= n; j++) {
                            ra = ra + aMtrxH[i + tmpDim * j] * aMtrxH[j + tmpDim * (n - 1)];
                            sa = sa + aMtrxH[i + tmpDim * j] * aMtrxH[j + tmpDim * n];
                        }
                        w = aMtrxH[i + tmpDim * i] - p;

                        if (tmpOffDiagonal[i] < PrimitiveMath.ZERO) {
                            z = w;
                            r = ra;
                            s = sa;
                        } else {
                            l = i;
                            if (tmpOffDiagonal[i] == 0) {
                                final ComplexNumber tmpX = ComplexNumber.fromRectangularCoordinates((-ra), (-sa));
                                final ComplexNumber tmpY = ComplexNumber.fromRectangularCoordinates(w, q);

                                final ComplexNumber tmpZ = tmpX.divide(tmpY);

                                aMtrxH[i + tmpDim * (n - 1)] = tmpZ.getReal();
                                aMtrxH[i + tmpDim * n] = tmpZ.getImaginary();
                            } else {

                                // Solve complex equations

                                x = aMtrxH[i + tmpDim * (i + 1)];
                                y = aMtrxH[(i + 1) + tmpDim * i];
                                vr = (tmpMainDiagonal[i] - p) * (tmpMainDiagonal[i] - p) + tmpOffDiagonal[i] * tmpOffDiagonal[i] - q * q;
                                vi = (tmpMainDiagonal[i] - p) * 2.0 * q;
                                if ((vr == PrimitiveMath.ZERO) & (vi == PrimitiveMath.ZERO)) {
                                    vr = PrimitiveMath.MACHINE_DOUBLE_ERROR * tmpNorm * (Math.abs(w) + Math.abs(q) + Math.abs(x) + Math.abs(y) + Math.abs(z));
                                }

                                final ComplexNumber tmpX = ComplexNumber.fromRectangularCoordinates((x * r - z * ra + q * sa), (x * s - z * sa - q * ra));
                                final ComplexNumber tmpY = ComplexNumber.fromRectangularCoordinates(vr, vi);

                                final ComplexNumber tmpZ = tmpX.divide(tmpY);

                                aMtrxH[i + tmpDim * (n - 1)] = tmpZ.getReal();
                                aMtrxH[i + tmpDim * n] = tmpZ.getImaginary();

                                if (Math.abs(x) > (Math.abs(z) + Math.abs(q))) {
                                    aMtrxH[(i + 1) + tmpDim * (n - 1)] = (-ra - w * aMtrxH[i + tmpDim * (n - 1)] + q * aMtrxH[i + tmpDim * n]) / x;
                                    aMtrxH[(i + 1) + tmpDim * n] = (-sa - w * aMtrxH[i + tmpDim * n] - q * aMtrxH[i + tmpDim * (n - 1)]) / x;
                                } else {
                                    final ComplexNumber tmpX1 = ComplexNumber.fromRectangularCoordinates((-r - y * aMtrxH[i + tmpDim * (n - 1)]), (-s - y * aMtrxH[i + tmpDim * n]));
                                    final ComplexNumber tmpY1 = ComplexNumber.fromRectangularCoordinates(z, q);

                                    final ComplexNumber tmpZ1 = tmpX1.divide(tmpY1);

                                    aMtrxH[(i + 1) + tmpDim * (n - 1)] = tmpZ1.getReal();
                                    aMtrxH[(i + 1) + tmpDim * n] = tmpZ1.getImaginary();
                                }
                            }

                            // Overflow control

                            t = Math.max(Math.abs(aMtrxH[i + tmpDim * (n - 1)]), Math.abs(aMtrxH[i + tmpDim * n]));
                            if ((PrimitiveMath.MACHINE_DOUBLE_ERROR * t) * t > 1) {
                                for (int j = i; j <= n; j++) {
                                    aMtrxH[j + tmpDim * (n - 1)] = aMtrxH[j + tmpDim * (n - 1)] / t;
                                    aMtrxH[j + tmpDim * n] = aMtrxH[j + tmpDim * n] / t;
                                }
                            }
                        }
                    }
                }
            }

            // Vectors of isolated roots

            for (int i = 0; i < tmpDim; i++) {
                if ((i < 0) | (i > tmpDimMinusOne)) {
                    for (int j = i; j < tmpDim; j++) {
                        tmpV[i][j] = aMtrxH[i + tmpDim * j];
                    }
                }
            }

            // Back transformation to get eigenvectors of original matrix

            for (int j = tmpDim - 1; j >= 0; j--) {
                for (int i = 0; i <= tmpDimMinusOne; i++) {
                    z = PrimitiveMath.ZERO;
                    for (int k = 0; k <= Math.min(j, tmpDimMinusOne); k++) {
                        z = z + tmpV[i][k] * aMtrxH[k + tmpDim * j];
                    }
                    tmpV[i][j] = z;
                }
            }

        }
    }

    protected EvD1(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

}
