/*
 * Copyright © 2003 Optimatika (www.optimatika.se) Permission is hereby granted,
 * free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies of the
 * Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions: The above copyright notice and this
 * permission notice shall be included in all copies or substantial portions of
 * the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO
 * EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.jama.JamaLU;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.IdentityStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.SelectedColumnsStore;
import org.ojalgo.matrix.store.SelectedRowsStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.context.NumberContext;

public abstract class LUDecomposition<N extends Number> extends AbstractDecomposition<N> implements LU<N> {

    public static final class Pivot {

        private final int[] myOrder;
        private int mySign;
        private int myTemp;

        public Pivot(final int aRowDim) {

            super();

            myOrder = MatrixUtils.makeIncreasingRange(0, aRowDim);
            mySign = 1;
        }

        public void change(final int aRow1, final int aRow2) {

            if (aRow1 != aRow2) {

                myTemp = myOrder[aRow1];
                myOrder[aRow1] = myOrder[aRow2];
                myOrder[aRow2] = myTemp;

                mySign = -mySign;

            } else {
                // Why?!
            }
        }

        public int[] getOrder() {
            return myOrder;
        }

        public int signum() {
            return mySign;
        }

    }

    /**
     * <p>
     * Only classes that will act as a delegate to
     * {@linkplain LUDecomposition} should implement this interface. The
     * interface specifications are entirely dictated by that class.
     * </p><p>
     * Do not use it for anything else!
     * </p>
     *
     * @author apete
     */
    public static interface Store<N extends Number> extends PhysicalStore<N> {

        Pivot computeLU(boolean assumeNoPivotingRequired);

    }

    static final class Big extends LUDecomposition<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

    }

    static final class Complex extends LUDecomposition<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

    }

    static final class Primitive extends LUDecomposition<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

    }

    public static final LU<BigDecimal> makeBig() {
        return new Big();
    }

    public static final LU<ComplexNumber> makeComplex() {
        return new Complex();
    }

    public static final LU<Double> makeJama() {
        return new JamaLU();
    }

    public static final LU<Double> makePrimitive() {
        return new Primitive();
    }

    private Pivot myPivot;

    private LUDecomposition.Store<N> myStore;

    protected LUDecomposition(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public boolean compute(final MatrixStore<N> aStore) {
        return this.compute(aStore, false);
    }

    public boolean computeWithoutPivoting(final MatrixStore<N> aStore) {
        return this.compute(aStore, true);
    }

    public boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public MatrixStore<N> getD() {

        final int tmpMinDim = myStore.getMinDim();

        final PhysicalStore<N> retVal = this.getFactory().makeZero(tmpMinDim, tmpMinDim);

        for (int ij = 0; ij < tmpMinDim; ij++) {
            retVal.set(ij, ij, myStore.get(ij, ij));
        }

        return retVal;
    }

    public N getDeterminant() {

        Scalar<N> retVal = this.getFactory().toScalar(myPivot.signum());

        final int tmpDim = myStore.getMinDim();
        for (int ij = 0; ij < tmpDim; ij++) {
            retVal = retVal.multiply(myStore.get(ij, ij));
        }

        return retVal.getNumber();
    }

    public MatrixStore<N> getInverse() {
        return this.solve(this.getFactory().makeEye(myStore.getRowDim(), myStore.getColDim()));
    }

    public MatrixStore<N> getL() {

        final int tmpRowDim = myStore.getRowDim();
        final int tmpColDim = myStore.getMinDim();

        final PhysicalStore<N> retVal = this.getFactory().makeEmpty(tmpRowDim, tmpColDim);

        final N tmpOne = this.getFactory().getStaticOne().getNumber();
        final N tmpZero = this.getFactory().getStaticZero().getNumber();

        for (int i = 0; i < tmpRowDim; i++) {
            for (int j = 0; j < tmpColDim; j++) {
                if (j < i) {
                    retVal.set(i, j, myStore.get(i, j));
                } else if (i == j) {
                    retVal.set(i, j, tmpOne);
                } else {
                    retVal.set(i, j, tmpZero);
                }
            }
        }

        return retVal;
    }

    public MatrixStore<N> getP() {
        //return new PermutationStore<N>(this.getFactory(), myPivot.getOrder());
        return new SelectedColumnsStore<N>(new IdentityStore<N>(this.getFactory(), myPivot.getOrder().length), myPivot.getOrder());
    }

    public int[] getPivotOrder() {
        return myPivot.getOrder();
    }

    public int getRank() {

        int retVal = 0;

        final int tmpMinDim = myStore.getMinDim();
        for (int ij = 0; ij < tmpMinDim; ij++) {
            if (!myStore.toScalar(ij, ij).isZero()) {
                retVal++;
            }
        }

        return retVal;
    }

    public MatrixStore<N> getRowEchelonForm() {

        final int tmpRowDim = myStore.getMinDim();
        final int tmpColDim = myStore.getColDim();

        final PhysicalStore<N> retVal = this.getFactory().makeZero(tmpRowDim, tmpColDim);

        for (int j = 0; j < tmpColDim; j++) {
            for (int i = 0; (i <= j) && (i < tmpRowDim); i++) {
                retVal.set(i, j, myStore.get(i, j));
            }
        }

        return retVal;
    }

    public MatrixStore<N> getU() {

        final int tmpRowDim = myStore.getMinDim();
        final int tmpColDim = myStore.getColDim();

        final PhysicalStore<N> retVal = this.getFactory().makeZero(tmpRowDim, tmpColDim);

        Scalar<N> tmpDiagSclr;
        boolean tmpDiagZero;
        N tmpDiagNmbr;

        final N tmpOne = this.getFactory().getStaticOne().getNumber();

        for (int i = 0; i < tmpRowDim; i++) {
            tmpDiagSclr = myStore.toScalar(i, i);
            tmpDiagZero = tmpDiagSclr.isZero();
            tmpDiagNmbr = tmpDiagSclr.getNumber();
            retVal.set(i, i, tmpOne);
            for (int j = i + 1; !tmpDiagZero && (j < tmpColDim); j++) {
                retVal.set(i, j, myStore.toScalar(i, j).divide(tmpDiagNmbr).getNumber());
            }
        }

        return retVal;
    }

    public final boolean isFullSize() {
        return false;
    }

    public boolean isSolvable() {
        return this.isComputed() && (myStore.getRowDim() == myStore.getColDim()) && !(!this.isSquareAndNotSingular());
    }

    public final boolean isSquareAndNotSingular() {

        boolean retVal = myStore.getRowDim() == myStore.getColDim();

        final int tmpMinDim = myStore.getMinDim();
        for (int ij = 0; retVal && (ij < tmpMinDim); ij++) {
            //System.out.println(ij + " => " + myStore.toScalar(ij, ij));
            retVal &= !myStore.toScalar(ij, ij).isZero();
            //BasicLogger.logDebug(myStore.toScalar(ij, ij).toString());
        }

        return retVal;
    }

    @Override
    public void reset() {

        super.reset();

        myPivot = null;
    }

    /**
     * Solves [this][X] = [aRHS] by first solving
     * <pre>[L][Y] = [aRHS]</pre>
     * and then
     * <pre>[U][X] = [Y]</pre>.
     * 
     * @param aRHS The right hand side
     * @return [X]
     */
    public MatrixStore<N> solve(final MatrixStore<N> aRHS) {

        final LUDecomposition.Store<N> retVal = this.copy(new SelectedRowsStore<N>(aRHS, myPivot.getOrder()));

        retVal.substituteForwards(myStore, true);

        retVal.substituteBackwards(myStore, false);

        return retVal;
    }

    private final boolean compute(final MatrixStore<N> aStore, final boolean assumeNoPivotingRequired) {

        this.reset();

        if ((myStore != null) && (myStore.getRowDim() == aStore.getRowDim()) && (myStore.getColDim() == aStore.getColDim())) {
            myStore.fillMatching(aStore);
        } else {
            myStore = this.copy(aStore);
        }

        myPivot = myStore.computeLU(assumeNoPivotingRequired);

        return this.computed(true);
    }

    private final LUDecomposition.Store<N> copy(final MatrixStore<N> aStore) {
        return (LUDecomposition.Store<N>) this.getFactory().copy(aStore);
    }

}
