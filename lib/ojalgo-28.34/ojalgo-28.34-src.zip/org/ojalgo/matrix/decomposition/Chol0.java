/*
 * Copyright © 2003 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.ConjugatedStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.context.NumberContext;

public abstract class Chol0<N extends Number> extends CholeskyDecomposition<N> {

    static final class Big extends Chol0<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

    }

    static final class Complex extends Chol0<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

    }

    static final class Primitive extends Chol0<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

    }

    private boolean mySPD = false;
    private CholeskyDecomposition.Store<N> myStore;
    private boolean myUpperRightSet = false;

    protected Chol0(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public boolean compute(final MatrixStore<N> aStore) {
        return this.compute(aStore, false);
    }

    public boolean computeWithCheck(final MatrixStore<N> aStore) {
        return this.compute(aStore, true);
    }

    public boolean computeWithoutPivoting(final MatrixStore<N> aStore) {
        return this.compute(aStore, false);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public MatrixStore<N> getD() {

        final int tmpDim = myStore.getMinDim();

        final PhysicalStore<N> retVal = this.getFactory().makeZero(tmpDim, tmpDim);

        for (int ij = 0; ij < tmpDim; ij++) {
            retVal.set(ij, ij, myStore.toScalar(ij, ij).power(2).getNumber());
        }

        return retVal;
    }

    public N getDeterminant() {

        Scalar<N> retVal = this.getFactory().getStaticOne();

        final int tmpDim = myStore.getMinDim();
        for (int ij = 0; ij < tmpDim; ij++) {
            retVal = retVal.multiply(myStore.toScalar(ij, ij).power(2).getNumber());
        }

        return retVal.getNumber();
    }

    public MatrixStore<N> getInverse() {
        return this.solve(this.getFactory().makeEye(myStore.getRowDim(), myStore.getColDim()));
    }

    public MatrixStore<N> getL() {

        final int tmpDim = myStore.getMinDim();

        final PhysicalStore<N> retVal = this.getFactory().makeZero(tmpDim, tmpDim);

        final N tmpStaticOne = this.getFactory().getStaticOne().getNumber();

        N tmpDiagVal;

        for (int j = 0; j < tmpDim; j++) {

            tmpDiagVal = myStore.get(j, j);
            retVal.set(j, j, tmpStaticOne);

            for (int i = j + 1; i < tmpDim; i++) {
                retVal.set(i, j, myStore.toScalar(i, j).divide(tmpDiagVal).getNumber());
            }
        }

        return retVal;
    }

    public MatrixStore<N> getP() {
        final int tmpDim = myStore.getMinDim();
        return this.getFactory().makeEye(tmpDim, tmpDim);
    }

    public int[] getPivotOrder() {
        return MatrixUtils.makeIncreasingRange(0, myStore.getMinDim());
    }

    public MatrixStore<N> getR() {

        final int tmpDim = myStore.getMinDim();

        final PhysicalStore<N> retVal = this.getFactory().makeZero(tmpDim, tmpDim);

        for (int j = 0; j < tmpDim; j++) {
            for (int i = j; i < tmpDim; i++) {
                retVal.set(j, i, myStore.get(i, j));
            }
        }

        return retVal;
    }

    public int getRank() {

        int retVal = 0;

        final int tmpMinDim = myStore.getMinDim();
        for (int ij = 0; ij < tmpMinDim; ij++) {
            if (!myStore.toScalar(ij, ij).isZero()) {
                retVal++;
            }
        }

        return retVal;
    }

    public MatrixStore<N> getRowEchelonForm() {

        final int tmpDim = myStore.getMinDim();

        final PhysicalStore<N> retVal = this.getFactory().makeZero(tmpDim, tmpDim);

        Scalar<N> tmpDiagVal;

        for (int j = 0; j < tmpDim; j++) {

            tmpDiagVal = myStore.toScalar(j, j);
            retVal.set(j, j, tmpDiagVal.getNumber());

            for (int i = j + 1; i < tmpDim; i++) {
                retVal.set(j, i, tmpDiagVal.multiply(myStore.get(i, j)).getNumber());
            }
        }

        return retVal;
    }

    public MatrixStore<N> getU() {
        return new ConjugatedStore<N>(this.getL());
    }

    public final boolean isFullSize() {
        return true;
    }

    public boolean isSolvable() {
        return this.isComputed() && this.isSPD();
    }

    public boolean isSPD() {
        return this.isComputed() && mySPD;
    }

    public final boolean isSquareAndNotSingular() {

        boolean retVal = myStore.getRowDim() == myStore.getColDim();

        final int tmpMinDim = myStore.getMinDim();
        for (int ij = 0; retVal && (ij < tmpMinDim); ij++) {
            retVal &= !myStore.toScalar(ij, ij).isZero();
        }

        return retVal;
    }

    @Override
    public void reset() {

        super.reset();

        myUpperRightSet = false;
    }

    /**
     * Solves [this][X] = [aRHS] by first solving
     * <pre>[L][Y] = [aRHS]</pre>
     * and then
     * <pre>[U][X] = [Y]</pre>.
     * 
     * @param aRHS The right hand side
     * @return [X]
     */
    public MatrixStore<N> solve(final MatrixStore<N> aRHS) {

        final Chol0.Store<N> retVal = this.copy(aRHS);

        retVal.substituteForwards(myStore, false);

        if (!myUpperRightSet) {

            final int tmpDim = myStore.getMinDim();
            for (int j = 0; j < tmpDim; j++) {
                for (int i = j + 1; i < tmpDim; i++) {
                    myStore.set(j, i, myStore.get(i, j));
                }
            }

            myUpperRightSet = true;
        }

        retVal.substituteBackwards(myStore, false);

        return retVal;
    }

    private final boolean compute(final MatrixStore<N> aStore, final boolean checkForSPD) {

        this.reset();

        if ((myStore != null) && (myStore.getRowDim() == aStore.getRowDim()) && (myStore.getColDim() == aStore.getColDim())) {
            myStore.fillMatching(aStore);
        } else {
            myStore = this.copy(aStore);
        }

        mySPD = myStore.computeCholesky(checkForSPD);

        return this.computed(true);
    }

    private final CholeskyDecomposition.Store<N> copy(final MatrixStore<N> aStore) {
        return (CholeskyDecomposition.Store<N>) this.getFactory().copy(aStore);
    }

}
