/*
 * Copyright © 2003 Optimatika (www.optimatika.se) Permission is hereby granted,
 * free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies of the
 * Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions: The above copyright notice and this
 * permission notice shall be included in all copies or substantial portions of
 * the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO
 * EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.jama.JamaQR;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.SelectedRowsStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.context.NumberContext;

public abstract class QRDecomposition<N extends Number> extends AbstractDecomposition<N> implements QR<N> {

    /**
    * <p>
    * Only classes that will act as a delegate to
    * {@linkplain QRDecomposition} should implement this interface. The
    * interface specifications are entirely dictated by that class.
    * </p><p>
    * Do not use it for anything else!
    * </p>
    *
    * @author apete
    */
    public static interface Store<N extends Number> extends PhysicalStore<N> {

        /**
         * @param aFirstTargetCol The first column of "this" to be transformed.
         * @param aHouseholderStore The {@linkplain MatrixStore} where the householder
         * column is stored.
         * @param aHouseholderCol the index of the householder column in aHouseholderStore.
         * @param aColumnArray An array (values not set) for internal/temporary
         * storage of the householder column. Should be of type N[] or double[].
         */
        void applyHouseholder(int aFirstTargetCol, MatrixStore<N> aHouseholderStore, int aHouseholderCol, Object aColumnArray);

        void computeQR();

    }

    static final class Big extends QRDecomposition<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

        @Override
        protected Object makeColumnArray(final int aRowDim) {
            return new BigDecimal[aRowDim];
        }

    }

    static final class Complex extends QRDecomposition<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

        @Override
        protected Object makeColumnArray(final int aRowDim) {
            return new ComplexNumber[aRowDim];
        }

    }

    static final class Primitive extends QRDecomposition<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

        @Override
        protected Object makeColumnArray(final int aRowDim) {
            return new double[aRowDim];
        }

    }

    public static final QR<BigDecimal> makeBig() {
        return new Big();
    }

    public static final QR<ComplexNumber> makeComplex() {
        return new Complex();
    }

    public static final QR<Double> makeJama() {
        return new JamaQR();
    }

    public static final QR<Double> makePrimitive() {
        return new Primitive();
    }

    private QRDecomposition.Store<N> myStore;

    protected QRDecomposition(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public boolean compute(final MatrixStore<N> aStore) {

        this.reset();

        if ((myStore != null) && (myStore.getRowDim() == aStore.getRowDim()) && (myStore.getColDim() == aStore.getColDim())) {
            myStore.fillMatching(aStore);
        } else {
            myStore = this.copy(aStore);
        }

        myStore.computeQR();

        return this.computed(true);
    }

    public boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    /**
     * Return the Householder vectors
     * 
     * @return Lower trapezoidal matrix whose columns define the reflections
     */
    public MatrixStore<N> getH() {

        final int tmpRowDim = myStore.getRowDim();
        final int tmpColDim = myStore.getColDim();

        final PhysicalStore<N> retVal = this.getFactory().makeEye(tmpRowDim, tmpColDim);

        for (int j = 0; j < tmpColDim; j++) {
            for (int i = j + 1; i < tmpRowDim; i++) {
                retVal.set(i, j, myStore.get(i, j));
            }
        }

        return retVal;
    }

    public MatrixStore<N> getInverse() {
        final int tmpDim = myStore.getRowDim();
        return this.solve(this.getFactory().makeEye(tmpDim, tmpDim));
    }

    public MatrixStore<N> getQ() {

        final int tmpRowDim = myStore.getRowDim();
        final int tmpColDim = myStore.getMinDim();

        final QRDecomposition.Store<N> retVal = (QRDecomposition.Store<N>) this.getFactory().makeEye(tmpRowDim, tmpColDim);

        final Object tmpColumnArray = this.makeColumnArray(tmpRowDim);
        for (int j = tmpColDim - 1; j >= 0; j--) {
            retVal.applyHouseholder(j, myStore, j, tmpColumnArray);
        }

        return retVal;
    }

    public MatrixStore<N> getR() {

        final int tmpRowDim = myStore.getMinDim();
        final int tmpColDim = myStore.getColDim();

        final PhysicalStore<N> retVal = this.getFactory().makeZero(tmpRowDim, tmpColDim);

        for (int j = 0; j < tmpColDim; j++) {
            for (int i = 0; (i <= j) && (i < tmpRowDim); i++) {
                retVal.set(i, j, myStore.get(i, j));
            }
        }

        return retVal;
    }

    public int getRank() {

        int retVal = 0;

        Scalar<N> tmpVal;
        for (int ij = 0; ij < myStore.getMinDim(); ij++) {
            tmpVal = myStore.toScalar(ij, ij);
            if (!tmpVal.isZero()) {
                retVal++;
            }
        }

        return retVal;
    }

    /**
     * @see org.ojalgo.matrix.decomposition.QR#isFullColumnRank()
     */
    public boolean isFullColumnRank() {
        return this.getRank() == myStore.getMinDim();
    }

    public final boolean isFullSize() {
        return false;
    }

    public final boolean isSolvable() {
        return this.isComputed() && this.isFullColumnRank();
    }

    /**
     * Solve [A]*[X]=[B] by first solving [Q]*[Y]=[B] and then [R]*[X]=[Y]. [X]
     * minimises the 2-norm of [Q]*[R]*[X]-[B].
     * 
     * @param aRHS The right hand side [B]
     * @return [X]
     */
    public MatrixStore<N> solve(final MatrixStore<N> aRHS) {

        final QRDecomposition.Store<N> retVal = this.copy(aRHS);

        final Object tmpColumnArray = this.makeColumnArray(myStore.getRowDim());
        final int tmpColDim = myStore.getColDim();
        for (int j = 0; j < tmpColDim; j++) {
            retVal.applyHouseholder(0, myStore, j, tmpColumnArray);
        }

        retVal.substituteBackwards(myStore, false);

        if (myStore.getColDim() < myStore.getRowDim()) {
            final int[] tmpRange = MatrixUtils.makeIncreasingRange(0, myStore.getMinDim());
            return new SelectedRowsStore<N>(retVal, tmpRange);
        } else {
            return retVal;
        }
    }

    private final QRDecomposition.Store<N> copy(final MatrixStore<N> aStore) {
        return (QRDecomposition.Store<N>) this.getFactory().copy(aStore);
    }

    /**
     * The input {@linkplain QRDecomposition.Store} in NOT copied!
     */
    protected final boolean compute(final QRDecomposition.Store<N> aStore) {

        this.reset();

        myStore = aStore;
        myStore.computeQR();

        return this.computed(true);
    }

    /**
     * @return L as in R<sup>T</sup>.
     */
    protected final PhysicalStore<N> getL() {

        final int tmpRowDim = myStore.getColDim();
        final int tmpColDim = myStore.getMinDim();

        final PhysicalStore<N> retVal = this.getFactory().makeEmpty(tmpRowDim, tmpColDim);

        N tmpVal;
        for (int i = 0; i < tmpRowDim; i++) {
            for (int j = 0; j < tmpColDim; j++) {
                if (j <= i) {
                    tmpVal = myStore.get(j, i);
                } else {
                    tmpVal = this.getFactory().getStaticZero().getNumber();
                }
                retVal.set(i, j, tmpVal);
            }
        }

        return retVal;
    }

    protected abstract Object makeColumnArray(int aRowDim);

}
