/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.gui.swing;

import java.beans.PropertyChangeListener;
import java.text.Format;
import java.text.ParseException;

import javax.swing.JFormattedTextField;
import javax.swing.SwingConstants;

import org.ojalgo.ProgrammingError;
import org.ojalgo.gui.BasicTextField;
import org.ojalgo.type.context.TypeContext;

public class ContextTextField<T> extends JFormattedTextField implements BasicTextField<T> {

    private static final class ContextFormatter<T> extends AbstractFormatter {

        private final TypeContext<T> myContext;

        public ContextFormatter(TypeContext<T> aContext) {

            super();

            myContext = aContext;
        }

        @SuppressWarnings("unused")
        private ContextFormatter() {
            this(null);
        }

        @Override
        public Object stringToValue(String aString) throws ParseException {
            return myContext.parseObject(aString);
        }

        @Override
        public String valueToString(Object anObject) throws ParseException {
            return myContext.formatString((T) anObject);
        }

    }

    private static final String VALUE = "value";
    private final TypeContext<T> myContext;

    public ContextTextField(T aModelObject, TypeContext<T> aContext) {

        this(aContext);

        this.setModelObject(aModelObject);
    }

    public ContextTextField(TypeContext<T> aContext) {

        super();

        myContext = aContext;

        this.setHorizontalAlignment(SwingConstants.RIGHT);
    }

    @SuppressWarnings("unused")
    private ContextTextField() {

        super();

        myContext = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    @SuppressWarnings("unused")
    private ContextTextField(AbstractFormatter someFormatter) {

        super(someFormatter);

        myContext = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    @SuppressWarnings("unused")
    private ContextTextField(AbstractFormatterFactory someFactory) {

        super(someFactory);

        myContext = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    @SuppressWarnings("unused")
    private ContextTextField(AbstractFormatterFactory someFactory, Object someCurrentValue) {

        super(someFactory, someCurrentValue);

        myContext = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    @SuppressWarnings("unused")
    private ContextTextField(Format someFormat) {

        super(someFormat);

        myContext = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    @SuppressWarnings("unused")
    private ContextTextField(int someColumns) {

        super(someColumns);

        myContext = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    @SuppressWarnings("unused")
    private ContextTextField(Object someValue) {

        super(someValue);

        myContext = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    @SuppressWarnings("unused")
    private ContextTextField(String someText) {

        super(someText);

        myContext = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    public final void addValueChangeListener(PropertyChangeListener aListener) {
        this.addPropertyChangeListener(VALUE, aListener);
    }

    public final void fireValueChange() {
        this.firePropertyChange(VALUE, this.getModelObject(), this.getModelObject());
    }

    @Override
    public AbstractFormatterFactory getFormatterFactory() {
        return new AbstractFormatterFactory() {

            @Override
            public AbstractFormatter getFormatter(JFormattedTextField aTextField) {
                return new ContextFormatter<T>(myContext);
            }
        };
    }

    public final T getModelObject() {
        return (T) this.getValue();
    }

    public final void setModelObject(T aModelObject) {
        this.setValue(aModelObject);
    }

}
