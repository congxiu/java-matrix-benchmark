/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.concurrent;

import org.ojalgo.type.IntCount;

public abstract class ConcurrentStrategy {

    private static final boolean BOOLEAN_FALSE = false;

    private static final int INT_ONE = 1;

    /**
     * The default strategy. Will check if the "count" is larger than
     * the "threshold" and if there are workers available.
     *
     * @author apete
     */
    public static final ConcurrentStrategy BASIC = new ConcurrentStrategy() {

    };

    /**
     * Will use the basic strategy to determine if it should start
     * branching. If it does start it will make use of all workers.
     *
     * @author apete
     */
    public static final ConcurrentStrategy DEEP = new ConcurrentStrategy() {

        @Override
        public boolean shouldBranch(final int aCount, final int aThreshold, final IntCount availableWorkers) {
            if (availableWorkers.modified) {
                return availableWorkers.count > INT_ONE;
            } else {
                return super.shouldBranch(aCount, aThreshold, availableWorkers);
            }
        }
    };

    /**
     * Will use the basic strategy to determine if it should start
     * branching, but it will never branch more than once.
     *
     * @author apete
     */
    public static final ConcurrentStrategy ONCE = new ConcurrentStrategy() {

        @Override
        public boolean shouldBranch(final int aCount, final int aThreshold, final IntCount availableWorkers) {
            if (availableWorkers.modified) {
                return BOOLEAN_FALSE;
            } else {
                return super.shouldBranch(aCount, aThreshold, availableWorkers);
            }
        }
    };

    public ConcurrentStrategy() {
        super();
    }

    public boolean shouldBranch(final int aCount, final int aThreshold, final IntCount availableWorkers) {
        return (aCount > aThreshold) && (availableWorkers.count > INT_ONE);
    }

}
