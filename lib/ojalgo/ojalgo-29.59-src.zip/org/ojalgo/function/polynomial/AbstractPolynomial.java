/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.function.polynomial;

import org.ojalgo.array.Array1D;

abstract class AbstractPolynomial<N extends Number> implements PolynomialFunction<N> {

    private final Array1D<N> myCoefficients;
    private transient AbstractPolynomial<N> myDerivative = null;
    private transient AbstractPolynomial<N> myPrimitive = null;

    @SuppressWarnings("unused")
    private AbstractPolynomial() {
        this(null);
    }

    protected AbstractPolynomial(final Array1D<N> someCoefficients) {

        super();

        myCoefficients = someCoefficients;
    }

    public PolynomialFunction<N> buildDerivative() {

        if (myDerivative == null) {

            final int tmpSize = Math.max(1, myCoefficients.size() - 1);

            myDerivative = this.makeInstance(tmpSize);

            for (int i = 0; i < tmpSize; i++) {
                myDerivative.set(i, this.getDerivativeFactor(i));
            }
        }

        return myDerivative;
    }

    public PolynomialFunction<N> buildPrimitive() {

        if (myPrimitive == null) {

            final int tmpSize = myCoefficients.size() + 1;

            myPrimitive = this.makeInstance(tmpSize);

            for (int i = 0; i < tmpSize; i++) {
                myPrimitive.set(i, this.getPrimitiveFactor(i));
            }
        }

        return myPrimitive;
    }

    public final N getCoefficient(final int aPower) {
        if (aPower < myCoefficients.length) {
            return myCoefficients.get(aPower);
        } else {
            return this.getStaticZero();
        }
    }

    public N getConstant() {
        return this.getCoefficient(0);
    }

    public int getDegree() {
        return myCoefficients.length - 1;
    }

    public final int size() {
        return myCoefficients.length;
    }

    protected double doubleValue(final int aPower) {
        return myCoefficients.doubleValue(aPower);
    }

    protected abstract N getDerivativeFactor(int aPower);

    protected N getNumber(final int aPower) {
        return myCoefficients.get(aPower);
    }

    protected abstract N getPrimitiveFactor(int aPower);

    protected abstract N getStaticZero();

    protected abstract AbstractPolynomial<N> makeInstance(int aSize);

    protected void set(final int aPower, final N aNmbr) {
        myCoefficients.set(aPower, aNmbr);
    }

}
