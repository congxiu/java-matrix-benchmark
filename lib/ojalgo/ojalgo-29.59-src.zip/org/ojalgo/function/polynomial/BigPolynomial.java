/* 
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.function.polynomial;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.ojalgo.array.Array1D;
import org.ojalgo.constant.BigMath;
import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.matrix.decomposition.QR;
import org.ojalgo.matrix.decomposition.QRDecomposition;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.series.NumberSeries;

/**
 * BigPolynomial
 * 
 * @author apete
 */
public class BigPolynomial extends AbstractPolynomial<BigDecimal> {

    public static PolynomialFunction<BigDecimal> estimate(final NumberSeries<BigDecimal> aSeries) {
        return BigPolynomial.estimate(aSeries, aSeries.size());
    }

    /**
     * @see PrimitivePolynomial#estimate(NumberSeries, int)
     */
    public static PolynomialFunction<BigDecimal> estimate(final NumberSeries<BigDecimal> aSeries, final int aSize) {

        final PhysicalStore<BigDecimal> tmpBody = BigDenseStore.FACTORY.makeEmpty(aSeries.size(), aSize);
        final PhysicalStore<BigDecimal> tmpRHS = BigDenseStore.FACTORY.makeEmpty(aSeries.size(), 1);

        int i = 0;
        BigDecimal tmpKey;
        for (final Map.Entry<BigDecimal, BigDecimal> tmpEntry : aSeries.entrySet()) {
            tmpKey = tmpEntry.getKey();
            for (int j = 0; j < aSize; j++) {
                tmpBody.set(i, j, BigFunction.POWER.invoke(tmpKey, j));
            }
            tmpRHS.set(i, 0, tmpEntry.getValue());
            i++;
        }

        final QR<BigDecimal> tmpQR = QRDecomposition.makeBig();
        tmpQR.compute(tmpBody);

        return new BigPolynomial(tmpQR.solve(tmpRHS).copy().asList());
    }

    public BigPolynomial(final Array1D<BigDecimal> someCoefficients) {
        super(someCoefficients);
    }

    public BigPolynomial(final BigDecimal[] someCoefficients) {
        super(Array1D.makeBig(someCoefficients));
    }

    public BigPolynomial(final List<BigDecimal> someCoefficients) {
        super(Array1D.makeBig(someCoefficients.toArray(new BigDecimal[someCoefficients.size()])));
    }

    public BigDecimal integrate(final BigDecimal aFromPoint, final BigDecimal aToPoint) {

        final PolynomialFunction<BigDecimal> tmpPrim = this.buildPrimitive();

        final BigDecimal tmpFromVal = tmpPrim.invoke(aFromPoint);
        final BigDecimal tmpToVal = tmpPrim.invoke(aToPoint);

        return tmpToVal.subtract(tmpFromVal);
    }

    public BigDecimal invoke(final BigDecimal anArg) {

        BigDecimal retVal = this.getConstant();

        final int tmpSize = this.size();

        for (int i = 1; i < tmpSize; i++) {
            retVal = retVal.add(this.getNumber(i).multiply(BigFunction.POWER.invoke(anArg, i)));
        }

        return retVal;
    }

    public double invoke(final double anArg) {
        return this.invoke(new BigDecimal(anArg)).doubleValue();
    }

    @Override
    protected BigDecimal getDerivativeFactor(final int anIndex) {
        final int tmpNextIndex = anIndex + 1;
        return this.getNumber(tmpNextIndex).multiply(new BigDecimal(tmpNextIndex));
    }

    @Override
    protected BigDecimal getPrimitiveFactor(final int anIndex) {
        if (anIndex <= 0) {
            return BigMath.ZERO;
        } else {
            return this.getNumber(anIndex - 1).divide(new BigDecimal(anIndex));
        }
    }

    @Override
    protected BigDecimal getStaticZero() {
        return BigMath.ZERO;
    }

    @Override
    protected AbstractPolynomial<BigDecimal> makeInstance(final int aSize) {
        return new BigPolynomial(Array1D.makeBig(aSize));
    }

}
