/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo;

import java.util.Date;

import org.ojalgo.machine.Hardware;
import org.ojalgo.machine.VirtualMachine;
import org.ojalgo.type.TypeUtils;

public abstract class OjAlgoUtils {

    public static VirtualMachine ENVIRONMENT = null;

    /**
     * Should contain all availabale hardware in ascending "power" order.
     * 
     * Threads# / Cores# / Processors#
     * ===============================
     * INTEL1: 1/1/1
     * MANTA: 2/2/1
     * I7_620M: 4/2/1
     * QXX00: 4/4/1
     * I7_920: 8/4/1
     * SAILFISH: 16/8/2
     * 
     */
    private static final Hardware[] AVAILABLE = new Hardware[] { Hardware.INTEL1, Hardware.MANTA, Hardware.I7_620M, Hardware.QXX00, Hardware.I7_920, Hardware.SAILFISH };

    static {

        final int tmpThreads = Runtime.getRuntime().availableProcessors();
        final long tmpMemory = Runtime.getRuntime().maxMemory();

        for (final Hardware tmpHardware : AVAILABLE) {
            if ((tmpHardware.threads == tmpThreads) && (tmpHardware.memory >= tmpMemory)) {
                ENVIRONMENT = tmpHardware.virtualise();
            }
        }

        if (ENVIRONMENT == null) {
            ENVIRONMENT = Hardware.makeSimple(tmpMemory, tmpThreads).virtualise();
        }
    }

    /**
     * @see Package#getSpecificationVersion()
     */
    public static String getDate() {

        final String tmpManifestValue = OjAlgoUtils.class.getPackage().getSpecificationVersion();

        return tmpManifestValue != null ? tmpManifestValue : TypeUtils.SQL_DATE_FORMAT.format(new Date());
    }

    /**
     * @see Package#getImplementationTitle()
     */
    public static String getTitle() {

        final String tmpManifestValue = OjAlgoUtils.class.getPackage().getImplementationTitle();

        return tmpManifestValue != null ? tmpManifestValue : "ojAlgo";
    }

    /**
     * @see Package#getImplementationVendor()
     */
    public static String getVendor() {

        final String tmpManifestValue = OjAlgoUtils.class.getPackage().getImplementationVendor();

        return tmpManifestValue != null ? tmpManifestValue : "Optimatika";
    }

    /**
     * @see Package#getImplementationVersion()
     */
    public static String getVersion() {

        final String tmpManifestValue = OjAlgoUtils.class.getPackage().getImplementationVersion();

        return tmpManifestValue != null ? tmpManifestValue : "X.X";
    }

    private OjAlgoUtils() {
        super();
    }

}
