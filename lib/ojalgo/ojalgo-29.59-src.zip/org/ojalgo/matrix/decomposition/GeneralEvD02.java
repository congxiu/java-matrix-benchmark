/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import org.ojalgo.ProgrammingError;
import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.matrix.decomposition.DecompositionStore.Factory;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

abstract class GeneralEvD02<N extends Number> extends EigenvalueDecomposition<N> {

    static final class Primitive extends GeneralEvD02<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY, new SymmetricEvD02.Primitive(), new NonsymmetricEvD02.Primitive());
        }

    }

    private final EigenvalueDecomposition<N> myNonsymmetricDelegate;
    private final EigenvalueDecomposition<N> mySymmetricDelegate;
    private boolean mySymmetricOrNot = BOOLEAN_FALSE;

    @SuppressWarnings("unused")
    private GeneralEvD02(final Factory<N> aFactory) {

        this(aFactory, null, null);

        ProgrammingError.throwForIllegalInvocation();
    }

    protected GeneralEvD02(final DecompositionStore.Factory<N> aFactory, final EigenvalueDecomposition<N> aSymmetric, final EigenvalueDecomposition<N> aNonsymmetric) {

        super(aFactory);

        mySymmetricDelegate = aSymmetric;
        myNonsymmetricDelegate = aNonsymmetric;
    }

    public final boolean compute(final Access2D<N> aMtrx, final boolean eigenvaluesOnly) {

        final int tmpDim = aMtrx.getRowDim();

        boolean tmpSymmetric = BOOLEAN_TRUE;

        for (int j = 0; tmpSymmetric && (j < tmpDim); j++) {
            for (int i = j + 1; tmpSymmetric && (i < tmpDim); i++) {
                tmpSymmetric &= TypeUtils.isZero(aMtrx.doubleValue(i, j) - aMtrx.doubleValue(j, i));
            }
        }

        return this.compute(aMtrx, tmpSymmetric, eigenvaluesOnly);
    }

    public boolean equals(final MatrixStore<N> aMtrx, final NumberContext aCntxt) {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.equals(aMtrx, aCntxt);
        } else {
            return myNonsymmetricDelegate.equals(aMtrx, aCntxt);
        }
    }

    public ComplexNumber getDeterminant() {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.getDeterminant();
        } else {
            return myNonsymmetricDelegate.getDeterminant();
        }
    }

    public ComplexNumber getTrace() {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.getTrace();
        } else {
            return myNonsymmetricDelegate.getTrace();
        }
    }

    public boolean isFullSize() {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.isFullSize();
        } else {
            return myNonsymmetricDelegate.isFullSize();
        }
    }

    public boolean isOrdered() {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.isOrdered();
        } else {
            return myNonsymmetricDelegate.isOrdered();
        }
    }

    public boolean isSolvable() {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.isSolvable();
        } else {
            return myNonsymmetricDelegate.isSolvable();
        }
    }

    public boolean isSymmetric() {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.isSymmetric();
        } else {
            return myNonsymmetricDelegate.isSymmetric();
        }
    }

    @Override
    public void reset() {

        super.reset();

        myNonsymmetricDelegate.reset();
        mySymmetricDelegate.reset();

        mySymmetricOrNot = BOOLEAN_FALSE;
    }

    @Override
    public MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.solve(aRHS);
        } else {
            return myNonsymmetricDelegate.solve(aRHS);
        }
    }

    @Override
    protected boolean doNonsymmetric(final Access2D<N> aMtrx, final boolean eigenvaluesOnly) {

        mySymmetricOrNot = BOOLEAN_FALSE;

        return myNonsymmetricDelegate.compute(aMtrx, BOOLEAN_FALSE, eigenvaluesOnly);
    }

    @Override
    protected boolean doSymmetric(final Access2D<N> aMtrx, final boolean eigenvaluesOnly) {

        mySymmetricOrNot = BOOLEAN_TRUE;

        return mySymmetricDelegate.compute(aMtrx, BOOLEAN_TRUE, eigenvaluesOnly);
    }

    @Override
    protected boolean isSmallEnoughToFitInCache() {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.isSmallEnoughToFitInCache();
        } else {
            return myNonsymmetricDelegate.isSmallEnoughToFitInCache();
        }
    }

    @Override
    protected MatrixStore<N> makeD() {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.getD();
        } else {
            return myNonsymmetricDelegate.getD();
        }
    }

    @Override
    protected Array1D<ComplexNumber> makeEigenvalues() {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.getEigenvalues();
        } else {
            return myNonsymmetricDelegate.getEigenvalues();
        }
    }

    @Override
    protected MatrixStore<N> makeInverse() {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.getInverse();
        } else {
            return myNonsymmetricDelegate.getInverse();
        }
    }

    @Override
    protected MatrixStore<N> makeV() {
        if (mySymmetricOrNot) {
            return mySymmetricDelegate.getV();
        } else {
            return myNonsymmetricDelegate.getV();
        }
    }

}
