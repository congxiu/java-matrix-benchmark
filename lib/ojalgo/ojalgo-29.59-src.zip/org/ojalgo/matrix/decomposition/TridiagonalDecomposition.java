/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.ProgrammingError;
import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.context.NumberContext;

/**
 * You create instances of (some subclass of) this class by calling one
 * of the static factory methods: {@linkplain #makeBig()},
 * {@linkplain #makeComplex()} or {@linkplain #makePrimitive()}.
 *
 * @author apete
 */
public abstract class TridiagonalDecomposition<N extends Number> extends InPlaceDecomposition<N> implements Tridiagonal<N> {

    static final class Big extends TridiagonalDecomposition<BigDecimal> {

        Big(final boolean generateInPlaceQ) {
            super(BigDenseStore.FACTORY, generateInPlaceQ);
        }
    }

    static final class Complex extends TridiagonalDecomposition<ComplexNumber> {

        Complex(final boolean generateInPlaceQ) {
            super(ComplexDenseStore.FACTORY, generateInPlaceQ);
        }
    }

    static final class Primitive extends TridiagonalDecomposition<Double> {

        Primitive(final boolean generateInPlaceQ) {
            super(PrimitiveDenseStore.FACTORY, generateInPlaceQ);
        }
    }

    private static final long PRIMITIVE_ELEMENT = 112L; // 4 x 8L

    @SuppressWarnings("unchecked")
    public static final <N extends Number> Tridiagonal<N> make(final Access2D<N> aTypical) {

        final Number tmpNumber = aTypical.get(INT_ZERO, INT_ZERO);

        if (tmpNumber instanceof BigDecimal) {
            return (Tridiagonal<N>) TridiagonalDecomposition.makeBig();
        } else if (tmpNumber instanceof ComplexNumber) {
            return (Tridiagonal<N>) TridiagonalDecomposition.makeComplex();
        } else if (tmpNumber instanceof Double) {
            return (Tridiagonal<N>) TridiagonalDecomposition.makePrimitive();
        } else {
            throw new IllegalArgumentException();
        }
    }

    public static final Tridiagonal<BigDecimal> makeBig() {
        return new TridiagonalDecomposition.Big(BOOLEAN_FALSE);
    }

    public static final Tridiagonal<ComplexNumber> makeComplex() {
        return new TridiagonalDecomposition.Complex(BOOLEAN_FALSE);
    }

    public static final Tridiagonal<Double> makePrimitive() {
        return new TridiagonalDecomposition.Primitive(BOOLEAN_FALSE);
    }

    private transient MatrixStore<N> myD = null;
    private transient DiagonalAccess<N> myDiagonalAccessD = null;
    private boolean myInPlaceQ;
    private transient MatrixStore<N> myQ = null;

    @SuppressWarnings("unused")
    private TridiagonalDecomposition(final DecompositionStore.Factory<N> aFactory) {

        this(aFactory, BOOLEAN_FALSE);

        ProgrammingError.throwForIllegalInvocation();
    }

    protected TridiagonalDecomposition(final DecompositionStore.Factory<N> aFactory, final boolean generateInPlaceQ) {

        super(aFactory);

        myInPlaceQ = generateInPlaceQ;
    }

    public final boolean compute(final Access2D<N> aMtrx) {

        this.reset();

        boolean retVal = BOOLEAN_FALSE;

        try {

            final boolean tmpInPlaceQ = myInPlaceQ;

            final int tmpRowDim = aMtrx.getRowDim(); // Which is also the col-dim.

            final Access2D<N> aTriangularMtrx = this.wrap(aMtrx).builder().triangular(BOOLEAN_FALSE, BOOLEAN_FALSE).build();

            final DecompositionStore<N> tmpInPlace = this.setInPlace(aTriangularMtrx);

            final Householder<N> tmpHouseholder = this.makeHouseholderWorker(tmpRowDim);

            final int tmpLimit = tmpRowDim - INT_TWO;

            for (int ij = INT_ZERO; ij < tmpLimit; ij++) {
                if (tmpInPlace.generateApplyAndCopyHouseholderColumn(ij + INT_ONE, ij, tmpHouseholder)) {
                    tmpInPlace.transformSymmetric(tmpHouseholder);
                }
            }

            if (tmpInPlaceQ) {
                myDiagonalAccessD = this.makeDiagonalAccessD(tmpInPlaceQ);
            }

            retVal = BOOLEAN_TRUE;

        } catch (final Exception anException) {

            BasicLogger.logError(anException.toString());

            this.reset();

            retVal = BOOLEAN_FALSE;
        }

        return this.computed(retVal);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(this.reconstruct(), aStore, aCntxt);
    }

    public final MatrixStore<N> getD() {

        if (myD == null) {
            myD = this.makeD();
        }

        return myD;
    }

    public final MatrixStore<N> getQ() {

        if (myQ == null) {
            myQ = this.makeQ(myInPlaceQ);
        }

        return myQ;
    }

    public final boolean isFullSize() {
        return BOOLEAN_TRUE;
    }

    public final boolean isSolvable() {
        return BOOLEAN_FALSE;
    }

    public MatrixStore<N> reconstruct() {
        return MatrixUtils.reconstruct(this);
    }

    @Override
    public void reset() {

        super.reset();

        myDiagonalAccessD = null;
        myD = null;
        myQ = null;
        myInPlaceQ = BOOLEAN_FALSE;
    }

    @Override
    public final MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        throw new UnsupportedOperationException();
    }

    private final DiagonalAccess<N> makeDiagonalAccessD(final boolean copy) {

        final Array2D<N> tmpArray2D = this.getInPlace().asArray2D();

        Array1D<N> tmpMain = tmpArray2D.sliceDiagonal(INT_ZERO, INT_ZERO);
        Array1D<N> tmpSub = tmpArray2D.sliceDiagonal(INT_ONE, INT_ZERO);

        if (copy) {
            tmpMain = tmpMain.copy();
            tmpSub = tmpSub.copy();
        }

        return new DiagonalAccess<N>(tmpMain, tmpSub, tmpSub, this.getStaticZero());
    }

    protected final DiagonalAccess<N> getDiagonalAccessD() {

        if (myDiagonalAccessD == null) {
            myDiagonalAccessD = this.makeDiagonalAccessD(myInPlaceQ);
        }

        return myDiagonalAccessD;
    }

    protected final MatrixStore<N> makeD() {
        return this.wrap(this.getDiagonalAccessD());
    }

    protected final DecompositionStore<N> makeQ(final boolean generateInPlaceQ) {

        final DecompositionStore<N> tmpStore = this.getInPlace();
        final int tmpDim = tmpStore.getMinDim();

        final DecompositionStore<N> retVal = generateInPlaceQ ? tmpStore : this.makeEye(tmpDim, tmpDim);

        final DecompositionStore.HouseholderReference<N> tmpHouseholderReference = new DecompositionStore.HouseholderReference<N>(tmpStore, BOOLEAN_TRUE);

        if (generateInPlaceQ) {
            retVal.set(tmpDim - INT_ONE, tmpDim - INT_ONE, PrimitiveMath.ONE);
            retVal.set(tmpDim - INT_TWO, tmpDim - INT_TWO, PrimitiveMath.ONE);
            retVal.set(tmpDim - INT_ONE, tmpDim - INT_TWO, PrimitiveMath.ZERO);
        }

        for (int ij = tmpDim - INT_THREE; ij >= INT_ZERO; ij--) {

            tmpHouseholderReference.row = ij + INT_ONE;
            tmpHouseholderReference.col = ij;

            if (!tmpHouseholderReference.isZero()) {
                retVal.transformLeft(tmpHouseholderReference, ij);
            }

            if (generateInPlaceQ) {
                retVal.setToIdentity(ij);
            }
        }

        return retVal;
    }

}
