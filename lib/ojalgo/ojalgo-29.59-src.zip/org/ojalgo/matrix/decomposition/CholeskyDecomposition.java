/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.access.Access2D;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.jama.JamaCholesky;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.context.NumberContext;

/**
 * You create instances of (some subclass of) this class by calling one
 * of the static factory methods: {@linkplain #makeBig()},
 * {@linkplain #makeComplex()}, {@linkplain #makePrimitive()} or
 * {@linkplain #makeJama()}.
 *
 * @author apete
 */
public abstract class CholeskyDecomposition<N extends Number> extends InPlaceDecomposition<N> implements Cholesky<N> {

    static final class Big extends CholeskyDecomposition<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

    }

    static final class Complex extends CholeskyDecomposition<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

    }

    static final class Primitive extends CholeskyDecomposition<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

    }

    private static final long PRIMITIVE_ELEMENT = 112L; // 2 x 8L

    @SuppressWarnings("unchecked")
    public static final <N extends Number> Cholesky<N> make(final Access2D<N> aTypical) {

        final Number tmpNumber = aTypical.get(INT_ZERO, INT_ZERO);

        if (tmpNumber instanceof BigDecimal) {
            return (Cholesky<N>) CholeskyDecomposition.makeBig();
        } else if (tmpNumber instanceof ComplexNumber) {
            return (Cholesky<N>) CholeskyDecomposition.makeComplex();
        } else if (tmpNumber instanceof Double) {
            return (Cholesky<N>) CholeskyDecomposition.makePrimitive();
        } else {
            throw new IllegalArgumentException();
        }
    }

    public static final Cholesky<BigDecimal> makeBig() {
        return new CholeskyDecomposition.Big();
    }

    public static final Cholesky<ComplexNumber> makeComplex() {
        return new CholeskyDecomposition.Complex();
    }

    public static final Cholesky<Double> makeJama() {
        return new JamaCholesky();
    }

    public static final Cholesky<Double> makePrimitive() {
        return new CholeskyDecomposition.Primitive();
    }

    private boolean mySPD = BOOLEAN_FALSE;

    protected CholeskyDecomposition(final DecompositionStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public boolean compute(final Access2D<N> aStore) {

        this.reset();

        mySPD = this.setInPlace(aStore).computeInPlaceCholesky(BOOLEAN_FALSE);

        return this.computed(BOOLEAN_TRUE);
    }

    public boolean computeWithCheck(final MatrixStore<N> aStore) {

        this.reset();

        mySPD = this.setInPlace(aStore).computeInPlaceCholesky(BOOLEAN_TRUE);

        return this.computed(BOOLEAN_TRUE);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public N getDeterminant() {

        final AggregatorFunction<N> tmpAggrFunc = this.getAggregatorCollection().product2();

        this.getInPlace().visitDiagonal(0, 0, tmpAggrFunc);

        return tmpAggrFunc.getNumber();
    }

    public MatrixStore<N> getL() {
        //return new LowerTriangularStore<N>(this.getInPlace(), false);
        return this.getInPlace().builder().triangular(BOOLEAN_FALSE, BOOLEAN_FALSE).build();
    }

    public final boolean isFullSize() {
        return BOOLEAN_TRUE;
    }

    public boolean isSolvable() {
        return this.isComputed() && mySPD;
    }

    public boolean isSPD() {
        return mySPD;
    }

    public MatrixStore<N> reconstruct() {
        return MatrixUtils.reconstruct(this);
    }

    @Override
    public void reset() {

        super.reset();

        mySPD = BOOLEAN_FALSE;
    }

    /**
     * Solves [this][X] = [aRHS] by first solving
     * <pre>[L][Y] = [aRHS]</pre>
     * and then
     * <pre>[U][X] = [Y]</pre>.
     * 
     * @param aRHS The right hand side
     * @return [X]
     */
    @Override
    public MatrixStore<N> solve(final MatrixStore<N> aRHS) {

        final DecompositionStore<N> retVal = this.makeZero(aRHS.getRowDim(), aRHS.getColDim());
        retVal.fillMatching(aRHS);

        final DecompositionStore<N> tmpBody = this.getInPlace();

        retVal.substituteForwards(tmpBody, BOOLEAN_FALSE, BOOLEAN_FALSE);
        retVal.substituteBackwards(tmpBody, BOOLEAN_TRUE);

        return retVal;
    }

    @Override
    protected final MatrixStore<N> makeInverse() {

        final DecompositionStore<N> retVal = this.makeEye(this.getColDim(), this.getRowDim());

        final DecompositionStore<N> tmpBody = this.getInPlace();

        retVal.substituteForwards(tmpBody, BOOLEAN_FALSE, BOOLEAN_TRUE);
        retVal.substituteBackwards(tmpBody, BOOLEAN_TRUE);

        return retVal;
    }

}
