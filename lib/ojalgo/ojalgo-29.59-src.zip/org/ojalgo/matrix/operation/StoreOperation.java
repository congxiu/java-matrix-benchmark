/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.operation;

/**
 * aData array to be updated
 * aRowDim, aFirstCol & aColLimit (or aFirstRow, aRowLimit & aColDim) as needed.
 * other, operation specific, arguments in logical order
 *
 * @author apete
 */
abstract class StoreOperation {

    static final int INT_0000 = 0;
    static final int INT_0001 = 1;
    static final int INT_0002 = 2;
    static final int INT_0004 = 4;
    static final int INT_0008 = 8;
    static final int INT_0016 = 16;
    static final int INT_0032 = 32;
    static final int INT_0064 = 64;
    static final int INT_0128 = 128;
    static final int INT_0256 = 256;
    static final int INT_0512 = 512;
    static final int INT_1024 = 1024;
    static final int INT_2048 = 2048;
    static final int INT_4096 = 4096;
    static final int INT_8192 = 8192;

    protected StoreOperation() {
        super();
    }

}
