/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.store;

import static org.ojalgo.function.implementation.ComplexFunction.*;

import java.util.List;

import org.ojalgo.OjAlgoUtils;
import org.ojalgo.access.Access1D;
import org.ojalgo.access.Access2D;
import org.ojalgo.access.ArrayAccess;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.array.ArrayUtils;
import org.ojalgo.array.ComplexArray;
import org.ojalgo.concurrent.DivideAndConquer;
import org.ojalgo.concurrent.DivideAndMerge;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.Aggregator;
import org.ojalgo.function.aggregator.AggregatorCollection;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.ComplexAggregator;
import org.ojalgo.function.implementation.ComplexFunction;
import org.ojalgo.function.implementation.FunctionSet;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.decomposition.DecompositionStore;
import org.ojalgo.matrix.decomposition.LUDecomposition.Pivot;
import org.ojalgo.matrix.operation.*;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * A {@linkplain ComplexNumber} implementation of {@linkplain PhysicalStore}.
 *
 * @author apete
 */
public final class ComplexDenseStore extends ComplexArray implements PhysicalStore<ComplexNumber>, DecompositionStore<ComplexNumber> {

    public static final DecompositionStore.Factory<ComplexNumber> FACTORY = new DecompositionStore.Factory<ComplexNumber>() {

        public ComplexDenseStore conjugate(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getColDim();
            final int tmpColDim = aSource.getRowDim();

            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim * tmpColDim];

            if (tmpColDim > Conjugate.THRESHOLD) {

                final DivideAndConquer tmpConquerer = new DivideAndConquer(Conjugate.THRESHOLD) {

                    @Override
                    public void conquer(final int aFirst, final int aLimit) {
                        Conjugate.invoke(retValData, tmpRowDim, aFirst, aLimit, aSource);
                    }

                };

                tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

            } else {

                Conjugate.invoke(retValData, tmpRowDim, INT_ZERO, tmpColDim, aSource);
            }

            return new ComplexDenseStore(tmpRowDim, tmpColDim, retValData);
        }

        public ComplexDenseStore copy(final Access2D<? extends Number> aSource) {

            final ComplexDenseStore retVal = new ComplexDenseStore(aSource.getRowDim(), aSource.getColDim());

            retVal.fillMatching(aSource);

            return retVal;
        }

        public ComplexDenseStore copy(final double[][] aSource) {

            final ComplexDenseStore retVal = new ComplexDenseStore(aSource.length, aSource[INT_ZERO].length);

            retVal.fillMatching(ArrayUtils.wrapAccess2D(aSource));

            return retVal;
        }

        public AggregatorCollection<ComplexNumber> getAggregatorCollection() {
            return ComplexAggregator.getCollection();
        }

        public FunctionSet<ComplexNumber> getFunctionSet() {
            return ComplexFunction.getSet();
        }

        public ComplexNumber getNumber(final double aNmbr) {
            return new ComplexNumber(aNmbr);
        }

        public ComplexNumber getNumber(final Number aNmbr) {
            return TypeUtils.toComplexNumber(aNmbr);
        }

        public ComplexNumber getStaticOne() {
            return ComplexNumber.ONE;
        }

        public ComplexNumber getStaticZero() {
            return ComplexNumber.ZERO;
        }

        public PhysicalStore<ComplexNumber> makeColumn(final Access1D<? extends Number> aColumn) {

            final int tmpRowDim = aColumn.size();
            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim];

            for (int i = INT_ZERO; i < tmpRowDim; i++) {
                retValData[i] = TypeUtils.toComplexNumber(aColumn.get(i));
            }

            return new ComplexDenseStore(tmpRowDim, INT_ONE, retValData);
        }

        public ComplexDenseStore makeColumn(final ComplexNumber[] aColumn) {
            return new ComplexDenseStore(aColumn.length, INT_ONE, ArrayUtils.copyOf(aColumn));
        }

        public ComplexDenseStore makeColumn(final double[] aColumn) {

            final int tmpRowDim = aColumn.length;
            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim];

            for (int i = INT_ZERO; i < tmpRowDim; i++) {
                retValData[i] = new ComplexNumber(aColumn[i]);
            }

            return new ComplexDenseStore(tmpRowDim, INT_ONE, retValData);
        }

        public ComplexDenseStore makeColumn(final List<ComplexNumber> aColumn) {

            final int tmpRowDim = aColumn.size();
            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim];

            for (int i = INT_ZERO; i < tmpRowDim; i++) {
                retValData[i] = aColumn.get(i);
            }

            return new ComplexDenseStore(tmpRowDim, INT_ONE, retValData);
        }

        public ComplexDenseStore makeEmpty(final int aRowDim, final int aColDim) {
            return new ComplexDenseStore(aRowDim, aColDim, new ComplexNumber[aRowDim * aColDim]);
        }

        public ComplexDenseStore makeEye(final int aRowDim, final int aColDim) {

            final ComplexDenseStore retVal = this.makeZero(aRowDim, aColDim);

            retVal.myUtility.fillDiagonal(INT_ZERO, INT_ZERO, this.getStaticOne().getNumber());

            return retVal;
        }

        public Householder.Complex makeHouseholderWorker(final int aLength) {
            return new Householder.Complex(aLength);
        }

        public Rotation.Complex makeRotation(final int aLow, final int aHigh, final ComplexNumber aCos, final ComplexNumber aSin) {
            return new Rotation.Complex(aLow, aHigh, aCos, aSin);
        }

        public Rotation.Complex makeRotation(final int aLow, final int aHigh, final double aCos, final double aSin) {
            return this.makeRotation(aLow, aHigh, new ComplexNumber(aCos), new ComplexNumber(aSin));
        }

        public ArrayAccess.Complex makeSimpleArrayWorker(final int aLength) {
            return ArrayAccess.makeComplex(aLength);
        }

        public ComplexDenseStore makeZero(final int aRowDim, final int aColDim) {
            return new ComplexDenseStore(aRowDim, aColDim);
        }

        public ComplexNumber toScalar(final double aNmbr) {
            return new ComplexNumber(aNmbr);
        }

        public ComplexNumber toScalar(final Number aNmbr) {
            return TypeUtils.toComplexNumber(aNmbr);
        }

        public ComplexDenseStore transpose(final Access2D<? extends Number> aSource) {

            final int tmpRowDim = aSource.getColDim();
            final int tmpColDim = aSource.getRowDim();

            final ComplexNumber[] retValData = new ComplexNumber[tmpRowDim * tmpColDim];

            if (tmpColDim > Transpose.THRESHOLD) {

                final DivideAndConquer tmpConquerer = new DivideAndConquer(Transpose.THRESHOLD) {

                    @Override
                    public void conquer(final int aFirst, final int aLimit) {
                        Transpose.invoke(retValData, tmpRowDim, aFirst, aLimit, aSource);
                    }

                };

                tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

            } else {

                Transpose.invoke(retValData, tmpRowDim, INT_ZERO, tmpColDim, aSource);
            }

            return new ComplexDenseStore(tmpRowDim, tmpColDim, retValData);
        }
    };

    static Householder.Complex cast(final Householder<ComplexNumber> aTransf) {
        if (aTransf instanceof Householder.Complex) {
            return (Householder.Complex) aTransf;
        } else if (aTransf instanceof DecompositionStore.HouseholderReference<?>) {
            return ((DecompositionStore.HouseholderReference<ComplexNumber>) aTransf).getComplexWorker().copy(aTransf);
        } else {
            return new Householder.Complex(aTransf);
        }
    }

    static ComplexDenseStore cast(final MatrixStore<ComplexNumber> aStore) {
        if (aStore instanceof ComplexDenseStore) {
            return (ComplexDenseStore) aStore;
        } else {
            return (ComplexDenseStore) FACTORY.copy(aStore);
        }
    }

    static Rotation.Complex cast(final Rotation<ComplexNumber> aTransf) {
        if (aTransf instanceof Rotation.Complex) {
            return (Rotation.Complex) aTransf;
        } else {
            return new Rotation.Complex(aTransf);
        }
    }

    static void doMultiplyBoth(final ComplexNumber[] aProductArray, final Access2D<ComplexNumber> aLeftStore, final Access2D<ComplexNumber> aRightStore) {

        final int tmpRowDim = aLeftStore.getRowDim();

        if (tmpRowDim > MultiplyBoth.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MultiplyBoth.THRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MultiplyBoth.invoke(aProductArray, aFirst, aLimit, aLeftStore, aRightStore);
                }
            };

            tmpConquerer.divide(INT_ZERO, tmpRowDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            MultiplyBoth.invoke(aProductArray, INT_ZERO, tmpRowDim, aLeftStore, aRightStore);
        }
    }

    static void doMultiplyLeft(final ComplexNumber[] aProductArray, final MatrixStore<ComplexNumber> aLeftStore, final ComplexNumber[] aRightArray) {

        final int tmpRowDim = aLeftStore.getRowDim();

        if (tmpRowDim > MultiplyLeft.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MultiplyLeft.THRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MultiplyLeft.invoke(aProductArray, aFirst, aLimit, aLeftStore, aRightArray);
                }
            };

            tmpConquerer.divide(INT_ZERO, tmpRowDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            MultiplyLeft.invoke(aProductArray, INT_ZERO, tmpRowDim, aLeftStore, aRightArray);
        }
    }

    static void doMultiplyRight(final ComplexNumber[] aProductArray, final ComplexNumber[] aLeftArray, final MatrixStore<ComplexNumber> aRightStore) {

        final int tmpColDim = aRightStore.getColDim();

        if (tmpColDim > MultiplyRight.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MultiplyRight.THRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MultiplyRight.invoke(aProductArray, aFirst, aLimit, aLeftArray, aRightStore);
                }
            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            MultiplyRight.invoke(aProductArray, INT_ZERO, tmpColDim, aLeftArray, aRightStore);
        }
    }

    private final int myColDim;
    private final int myRowDim;
    private final Array2D<ComplexNumber> myUtility;

    ComplexDenseStore(final ComplexNumber[] anArray) {

        super(anArray);

        myRowDim = anArray.length;
        myColDim = INT_ONE;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    ComplexDenseStore(final int aLength) {

        super(aLength);

        myRowDim = aLength;
        myColDim = INT_ONE;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    ComplexDenseStore(final int aRowDim, final int aColDim) {

        super(aRowDim * aColDim);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    ComplexDenseStore(final int aRowDim, final int aColDim, final ComplexNumber[] anArray) {

        super(anArray);

        myRowDim = aRowDim;
        myColDim = aColDim;
        myUtility = this.asArray2D(myRowDim, myColDim);
    }

    public ComplexNumber aggregateAll(final Aggregator aVisitor) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > AggregateAll.THRESHOLD) {

            final DivideAndMerge<ComplexNumber> tmpConquerer = new DivideAndMerge<ComplexNumber>(AggregateAll.THRESHOLD) {

                @Override
                public ComplexNumber conquer(final int aFirst, final int aLimit) {

                    final AggregatorFunction<ComplexNumber> tmpAggrFunc = aVisitor.getComplexFunction();

                    ComplexDenseStore.this.visit(tmpRowDim * aFirst, tmpRowDim * aLimit, INT_ONE, tmpAggrFunc);

                    return tmpAggrFunc.getNumber();
                }

                @Override
                public ComplexNumber merge(final ComplexNumber aFirstResult, final ComplexNumber aSecondResult) {
                    return aVisitor.getComplexFunction().merge(aFirstResult, aSecondResult);

                    //                    final AggregatorFunction<ComplexNumber> tmpAggrFunc = aVisitor.getComplexFunction();
                    //
                    //                    tmpAggrFunc.merge(aFirstResult);
                    //                    tmpAggrFunc.merge(aSecondResult);
                    //
                    //                    return tmpAggrFunc.getNumber();
                }
            };

            return tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            final AggregatorFunction<ComplexNumber> tmpAggrFunc = aVisitor.getComplexFunction();

            ComplexDenseStore.this.visit(INT_ZERO, length, INT_ONE, tmpAggrFunc);

            return tmpAggrFunc.getNumber();
        }
    }

    public void applyCholesky(final int aNextIndex, final int aDim, final ArrayAccess<ComplexNumber> aMultipliers) {

        final ComplexNumber[] tmpData = this.data();
        final ComplexNumber[] tmpColumn = ((ArrayAccess.Complex) aMultipliers).data;

        if (aDim - aNextIndex > ApplyCholesky.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(ApplyCholesky.THRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    ApplyCholesky.invoke(tmpData, aDim, aFirst, aLimit, tmpColumn);
                }

            };

            tmpConquerer.divide(aNextIndex, aDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            ApplyCholesky.invoke(tmpData, aDim, aNextIndex, aDim, tmpColumn);
        }
    }

    public void applyLU(final int aPivotRow, final int aRowDim, final int aFirstCol, final int aColDim, final ArrayAccess<ComplexNumber> aMultipliers) {

        final ComplexNumber[] tmpData = this.data();
        final ComplexNumber[] tmpColumn = ((ArrayAccess.Complex) aMultipliers).data;

        if (aColDim - aFirstCol > ApplyLU.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(ApplyLU.THRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    ApplyLU.invoke(tmpData, aPivotRow, aRowDim, aFirst, aLimit, tmpColumn);
                }
            };

            tmpConquerer.divide(aFirstCol, aColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            ApplyLU.invoke(tmpData, aPivotRow, aRowDim, aFirstCol, aColDim, tmpColumn);
        }
    }

    public Array2D<ComplexNumber> asArray2D() {
        return myUtility;
    }

    public Array1D<ComplexNumber> asList() {
        return myUtility.asArray1D();
    }

    public final MatrixStore.Builder<ComplexNumber> builder() {
        return new MatrixStore.Builder<ComplexNumber>(this);
    }

    public void caxpy(final ComplexNumber aSclrA, final int aColX, final int aColY, final int aFirstRow) {
        CAXPY.invoke(this.data(), aSclrA, this.data(), aColX, aColY, aFirstRow, myRowDim);
    }

    public boolean computeInPlaceCholesky(final boolean checkForSPD) {

        // true if (Symmetric) Positive Definite 
        boolean retVal = myRowDim == myColDim;

        final int tmpDim = myRowDim;

        final ComplexNumber[] tmpData = this.data();
        int tmpIndex;

        // Check for symmetry, maybe
        if (retVal && checkForSPD) {
            for (int j = INT_ZERO; retVal && (j < tmpDim); j++) {
                for (int i = j + INT_ONE; retVal && (i < tmpDim); i++) {
                    retVal &= tmpData[i + j * tmpDim].subtract(tmpData[j + i * tmpDim]).isZero();
                }
            }
        }

        final ArrayAccess.Complex tmpMultipliers = ArrayAccess.makeComplex(tmpDim);
        final ComplexNumber[] tmpColumn = tmpMultipliers.data;
        ComplexNumber tmpVal;

        // Main loop - along the diagonal
        for (int ij = INT_ZERO; retVal && (ij < tmpDim); ij++) {

            // "Pivot" element
            tmpVal = tmpData[tmpIndex = ij + ij * tmpDim];

            if ((tmpVal.getReal() > PrimitiveMath.ZERO) && (tmpVal.getImaginary() == PrimitiveMath.ZERO)) {

                tmpColumn[ij] = tmpData[tmpIndex] = tmpVal = ComplexFunction.SQRT.invoke(tmpVal);

                // Calculate multipliers and copy to local column
                // Current column, below the diagonal
                this.divideAndCopyColumn(ij + INT_ONE, ij, tmpVal, tmpMultipliers);

                // Remaining columns, below the diagonal
                this.applyCholesky(ij + INT_ONE, tmpDim, tmpMultipliers);

            } else {

                retVal = BOOLEAN_FALSE;
            }
        }

        return retVal;
    }

    public Pivot computeInPlaceLU(final boolean assumeNoPivotingRequired) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;
        final int tmpMinDim = Math.min(tmpRowDim, tmpColDim);

        final Pivot retVal = new Pivot(tmpRowDim);

        final ComplexNumber[] tmpData = this.data();
        int tmpIndex;

        int tmpPivotRowIndex;

        final ArrayAccess.Complex tmpMultipliers = ArrayAccess.makeComplex(tmpRowDim);
        ComplexNumber tmpNmbr;
        double tmpVal;

        // Main loop - along the diagonal
        for (int ij = INT_ZERO; ij < tmpMinDim; ij++) {

            final int tmpPivotRow = ij;
            final int tmpFirstCol = ij + INT_ONE;

            if (!assumeNoPivotingRequired) {
                // Find next pivot row
                tmpVal = tmpData[tmpIndex = ij + tmpRowDim * ij].getModulus();
                tmpPivotRowIndex = ij;
                for (int i = ij + INT_ONE; i < tmpRowDim; i++) {
                    if (tmpData[++tmpIndex].getModulus() > tmpVal) {
                        tmpVal = tmpData[tmpIndex].getModulus();
                        tmpPivotRowIndex = i;
                    }
                }
                // Pivot?
                if (tmpPivotRowIndex != ij) {
                    myUtility.exchangeRows(tmpPivotRowIndex, ij);
                    retVal.change(tmpPivotRowIndex, ij);
                }
            }

            // Do the calculations...

            // "Pivot" element
            tmpNmbr = tmpData[tmpIndex = ij + tmpRowDim * ij];
            if (!tmpNmbr.isZero()) {

                // Calculate multipliers and copy to local column
                // Current column, below the diagonal
                this.divideAndCopyColumn(ij + INT_ONE, ij, tmpNmbr, tmpMultipliers);

                // Apply transformations to everything below and to the right of the pivot element
                this.applyLU(tmpPivotRow, tmpRowDim, tmpFirstCol, tmpColDim, tmpMultipliers);

            } else {

                tmpData[tmpIndex] = ComplexNumber.ZERO;
            }
        }

        return retVal;
    }

    public Array1D<ComplexNumber> computeInPlaceSchur(final PhysicalStore<ComplexNumber> aTransformationCollector, final boolean eigenvalue) {
        throw new UnsupportedOperationException();
    }

    public ComplexDenseStore conjugate() {
        return (ComplexDenseStore) FACTORY.conjugate(this);
    }

    public ComplexDenseStore copy() {
        return new ComplexDenseStore(myRowDim, myColDim, this.copyOfData());
    }

    public void divideAndCopyColumn(final int aRow, final int aCol, final ComplexNumber aNumerator, final ArrayAccess<ComplexNumber> aDestination) {

        final ComplexNumber[] tmpDestination = ((ArrayAccess.Complex) aDestination).data;

        final ComplexNumber[] tmpData = this.data();
        final int tmpRowDim = myRowDim;

        int tmpIndex = aRow + aCol * tmpRowDim;
        for (int i = aRow; i < tmpRowDim; i++) {
            tmpDestination[i] = tmpData[tmpIndex] = tmpData[tmpIndex].divide(aNumerator);
            tmpIndex++;
        }
    }

    public double doubleValue(final int aRow, final int aCol) {
        return this.doubleValue(aRow + aCol * myRowDim);
    }

    public boolean equals(final MatrixStore<ComplexNumber> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(this, aStore, aCntxt);
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(final Object anObj) {
        if (anObj instanceof MatrixStore) {
            return this.equals((MatrixStore<ComplexNumber>) anObj, TypeUtils.EQUALS_NUMBER_CONTEXT);
        } else {
            return super.equals(anObj);
        }
    }

    public void exchangeColumns(final int aColA, final int aColB) {
        myUtility.exchangeColumns(aColA, aColB);
    }

    public void exchangeRows(final int aRowA, final int aRowB) {
        myUtility.exchangeRows(aRowA, aRowB);
    }

    public void fillAll(final ComplexNumber aNmbr) {
        myUtility.fillAll(aNmbr);
    }

    public void fillByMultiplying(final MatrixStore<ComplexNumber> aLeftStore, final MatrixStore<ComplexNumber> aRightStore) {

        final ComplexNumber[] tmpProductData = this.data();

        if (aRightStore instanceof ComplexDenseStore) {

            ComplexDenseStore.doMultiplyLeft(tmpProductData, aLeftStore, ComplexDenseStore.cast(aRightStore).data());

        } else if (aLeftStore instanceof ComplexDenseStore) {

            ComplexDenseStore.doMultiplyRight(tmpProductData, ComplexDenseStore.cast(aLeftStore).data(), aRightStore);

        } else {

            ComplexDenseStore.doMultiplyBoth(tmpProductData, aLeftStore, aRightStore);
        }
    }

    public void fillColumn(final int aRow, final int aCol, final ComplexNumber aNmbr) {
        myUtility.fillColumn(aRow, aCol, aNmbr);
    }

    public void fillDiagonal(final int aRow, final int aCol, final ComplexNumber aNmbr) {
        myUtility.fillDiagonal(aRow, aCol, aNmbr);
    }

    public void fillMatching(final Access2D<? extends Number> aSource2D) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > Copy.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(Copy.THRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    Copy.invoke(ComplexDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aSource2D);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            Copy.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aSource2D);
        }
    }

    public void fillMatching(final ComplexNumber aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final MatrixStore<ComplexNumber> aRightArg) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > FillMatchingRight.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(FillMatchingRight.THRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    ComplexDenseStore.this.fill(tmpRowDim * aFirst, tmpRowDim * aLimit, aLeftArg, aFunc, aRightArg);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            this.fill(INT_ZERO, tmpRowDim * tmpColDim, aLeftArg, aFunc, aRightArg);
        }
    }

    public void fillMatching(final MatrixStore<ComplexNumber> aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final ComplexNumber aRightArg) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > FillMatchingLeft.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(FillMatchingLeft.THRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    ComplexDenseStore.this.fill(tmpRowDim * aFirst, tmpRowDim * aLimit, aLeftArg, aFunc, aRightArg);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            this.fill(INT_ZERO, tmpRowDim * tmpColDim, aLeftArg, aFunc, aRightArg);
        }
    }

    public void fillMatching(final MatrixStore<ComplexNumber> aLeftArg, final BinaryFunction<ComplexNumber> aFunc, final MatrixStore<ComplexNumber> aRightArg) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > FillMatchingBoth.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(FillMatchingBoth.THRESHOLD) {

                @Override
                protected void conquer(final int aFirst, final int aLimit) {
                    ComplexDenseStore.this.fill(tmpRowDim * aFirst, tmpRowDim * aLimit, aLeftArg, aFunc, aRightArg);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            this.fill(INT_ZERO, tmpRowDim * tmpColDim, aLeftArg, aFunc, aRightArg);
        }
    }

    public void fillRow(final int aRow, final int aCol, final ComplexNumber aNmbr) {
        myUtility.fillRow(aRow, aCol, aNmbr);
    }

    public boolean generateApplyAndCopyHouseholderColumn(final int aRow, final int aCol, final Householder<ComplexNumber> aDestination) {
        return GenerateApplyAndCopyHouseholderColumn.invoke(this.data(), myRowDim, aRow, aCol, (Householder.Complex) aDestination);
    }

    public boolean generateApplyAndCopyHouseholderRow(final int aRow, final int aCol, final Householder<ComplexNumber> aDestination) {
        return GenerateApplyAndCopyHouseholderRow.invoke(this.data(), myRowDim, aRow, aCol, (Householder.Complex) aDestination);
    }

    public ComplexNumber get(final int aRow, final int aCol) {
        return myUtility.get(aRow, aCol);
    }

    public int getColDim() {
        return myColDim;
    }

    public PhysicalStore.Factory<ComplexNumber> getFactory() {
        return FACTORY;
    }

    public int getIndexOfLargestInColumn(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInColumn(aRow, aCol);
    }

    public int getIndexOfLargestInRow(final int aRow, final int aCol) {
        return myUtility.getIndexOfLargestInRow(aRow, aCol);
    }

    public int getMinDim() {
        return Math.min(myRowDim, myColDim);
    }

    public int getRowDim() {
        return myRowDim;
    }

    @Override
    public int hashCode() {
        return MatrixUtils.hashCode(this);
    }

    public boolean isAbsolute(final int aRow, final int aCol) {
        return myUtility.isAbsolute(aRow, aCol);
    }

    public boolean isLowerLeftShaded() {
        return BOOLEAN_FALSE;
    }

    public boolean isReal(final int aRow, final int aCol) {
        return myUtility.isReal(aRow, aCol);
    }

    public boolean isUpperRightShaded() {
        return BOOLEAN_FALSE;
    }

    public boolean isZero(final int aRow, final int aCol) {
        return myUtility.isZero(aRow, aCol);
    }

    public void maxpy(final ComplexNumber aSclrA, final MatrixStore<ComplexNumber> aMtrxX) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > MAXPY.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(MAXPY.THRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    MAXPY.invoke(ComplexDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aSclrA, aMtrxX);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            MAXPY.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aSclrA, aMtrxX);
        }
    }

    public void modifyAll(final UnaryFunction<ComplexNumber> aFunc) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > ModifyAll.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(ModifyAll.THRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    ComplexDenseStore.this.modify(tmpRowDim * aFirst, tmpRowDim * aLimit, INT_ONE, aFunc);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            this.modify(tmpRowDim * INT_ZERO, tmpRowDim * tmpColDim, INT_ONE, aFunc);
        }
    }

    public void modifyColumn(final int aRow, final int aCol, final UnaryFunction<ComplexNumber> aFunc) {
        myUtility.modifyColumn(aRow, aCol, aFunc);
    }

    public void modifyDiagonal(final int aRow, final int aCol, final UnaryFunction<ComplexNumber> aFunc) {
        myUtility.modifyDiagonal(aRow, aCol, aFunc);
    }

    public void modifyRow(final int aRow, final int aCol, final UnaryFunction<ComplexNumber> aFunc) {
        myUtility.modifyRow(aRow, aCol, aFunc);
    }

    public MatrixStore<ComplexNumber> multiplyLeft(final MatrixStore<ComplexNumber> aStore) {

        final ComplexDenseStore retVal = (ComplexDenseStore) FACTORY.makeZero(aStore.getRowDim(), myColDim);

        ComplexDenseStore.doMultiplyLeft(retVal.data(), aStore, this.data());

        return retVal;
    }

    public MatrixStore<ComplexNumber> multiplyRight(final MatrixStore<ComplexNumber> aStore) {

        final ComplexDenseStore retVal = (ComplexDenseStore) FACTORY.makeZero(myRowDim, aStore.getColDim());

        ComplexDenseStore.doMultiplyRight(retVal.data(), this.data(), aStore);

        return retVal;
    }

    public void raxpy(final ComplexNumber aSclrA, final int aRowX, final int aRowY, final int aFirstCol) {
        RAXPY.invoke(this.data(), aSclrA, this.data(), aRowX, aRowY, aFirstCol, myColDim);
    }

    public void rotateRight(final int aLow, final int aHigh, final double aCos, final double aSin) {
        RotateRight.invoke(this.data(), myRowDim, aLow, aHigh, FACTORY.getNumber(aCos), FACTORY.getNumber(aSin));
    }

    public void set(final int aRow, final int aCol, final ComplexNumber aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void set(final int aRow, final int aCol, final double aNmbr) {
        myUtility.set(aRow, aCol, aNmbr);
    }

    public void setToIdentity(final int aCol) {
        myUtility.set(aCol, aCol, ComplexNumber.ONE);
        myUtility.fillColumn(aCol + INT_ONE, aCol, ComplexNumber.ZERO);
    }

    public void substituteBackwards(final Access2D<ComplexNumber> aBody, final boolean transposed) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > SubstituteBackwards.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(SubstituteBackwards.THRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    SubstituteBackwards.invoke(ComplexDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aBody, transposed);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            SubstituteBackwards.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aBody, transposed);
        }
    }

    public void substituteForwards(final Access2D<ComplexNumber> aBody, final boolean onesOnDiagonal, final boolean zerosAboveDiagonal) {

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > SubstituteForwards.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(SubstituteForwards.THRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    SubstituteForwards.invoke(ComplexDenseStore.this.data(), tmpRowDim, aFirst, aLimit, aBody, onesOnDiagonal, zerosAboveDiagonal);
                }

            };

            tmpConquerer.divide(INT_ZERO, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            SubstituteForwards.invoke(this.data(), tmpRowDim, INT_ZERO, tmpColDim, aBody, onesOnDiagonal, zerosAboveDiagonal);
        }
    }

    public Scalar<ComplexNumber> toScalar(final int aRow, final int aCol) {
        return myUtility.toScalar(aRow, aCol);
    }

    public void transformLeft(final Householder<ComplexNumber> aTransf, final int aFirstCol) {

        final Householder.Complex tmpTransf = ComplexDenseStore.cast(aTransf);

        final ComplexNumber[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > HouseholderLeft.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(HouseholderLeft.THRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    HouseholderLeft.invoke(tmpData, tmpRowDim, aFirst, aLimit, tmpTransf);
                }

            };

            tmpConquerer.divide(aFirstCol, tmpColDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            HouseholderLeft.invoke(tmpData, tmpRowDim, aFirstCol, tmpColDim, tmpTransf);
        }
    }

    public void transformLeft(final Rotation<ComplexNumber> aTransf) {

        final Rotation.Complex tmpTransf = ComplexDenseStore.cast(aTransf);

        final int tmpLow = tmpTransf.low;
        final int tmpHigh = tmpTransf.high;

        if (tmpLow != tmpHigh) {
            if ((tmpTransf.cos != null) && (tmpTransf.sin != null)) {
                RotateLeft.invoke(this.data(), myColDim, tmpLow, tmpHigh, tmpTransf.cos, tmpTransf.sin);
            } else {
                myUtility.exchangeRows(tmpLow, tmpHigh);
            }
        } else {
            if (tmpTransf.cos != null) {
                myUtility.modifyRow(tmpLow, INT_ZERO, MULTIPLY, tmpTransf.cos);
            } else if (tmpTransf.sin != null) {
                myUtility.modifyRow(tmpLow, INT_ZERO, DIVIDE, tmpTransf.sin);
            } else {
                myUtility.modifyRow(tmpLow, INT_ZERO, NEGATE);
            }
        }
    }

    public void transformRight(final Householder<ComplexNumber> aTransf, final int aFirstRow) {

        final Householder.Complex tmpTransf = ComplexDenseStore.cast(aTransf);

        final ComplexNumber[] tmpData = this.data();

        final int tmpRowDim = myRowDim;
        final int tmpColDim = myColDim;

        if (tmpColDim > HouseholderRight.THRESHOLD) {

            final DivideAndConquer tmpConquerer = new DivideAndConquer(HouseholderRight.THRESHOLD) {

                @Override
                public void conquer(final int aFirst, final int aLimit) {
                    HouseholderRight.invoke(tmpData, aFirst, aLimit, tmpColDim, tmpTransf);
                }

            };

            tmpConquerer.divide(aFirstRow, tmpRowDim, OjAlgoUtils.ENVIRONMENT.countThreads());

        } else {

            HouseholderRight.invoke(tmpData, aFirstRow, tmpRowDim, tmpColDim, tmpTransf);
        }
    }

    public void transformRight(final Rotation<ComplexNumber> aTransf) {

        final Rotation.Complex tmpTransf = ComplexDenseStore.cast(aTransf);

        final int tmpLow = tmpTransf.low;
        final int tmpHigh = tmpTransf.high;

        if (tmpLow != tmpHigh) {
            if ((tmpTransf.cos != null) && (tmpTransf.sin != null)) {
                RotateRight.invoke(this.data(), myRowDim, tmpLow, tmpHigh, tmpTransf.cos, tmpTransf.sin);
            } else {
                myUtility.exchangeColumns(tmpLow, tmpHigh);
            }
        } else {
            if (tmpTransf.cos != null) {
                myUtility.modifyColumn(INT_ZERO, tmpHigh, MULTIPLY, tmpTransf.cos);
            } else if (tmpTransf.sin != null) {
                myUtility.modifyColumn(INT_ZERO, tmpHigh, DIVIDE, tmpTransf.sin);
            } else {
                myUtility.modifyColumn(INT_ZERO, tmpHigh, NEGATE);
            }
        }
    }

    public void transformSymmetric(final Householder<ComplexNumber> aTransf) {
        HouseholderSymmetric.invoke(this.data(), ComplexDenseStore.cast(aTransf), new ComplexNumber[aTransf.size()]);
    }

    public ComplexDenseStore transpose() {
        return (ComplexDenseStore) FACTORY.transpose(this);
    }

    public void tred2(final ArrayAccess<ComplexNumber> mainDiagonal, final ArrayAccess<ComplexNumber> offDiagonal, final boolean yesvecs) {
        throw new UnsupportedOperationException();
    }

    public void visitAll(final AggregatorFunction<ComplexNumber> aVisitor) {
        myUtility.visitAll(aVisitor);
    }

    public void visitColumn(final int aRow, final int aCol, final AggregatorFunction<ComplexNumber> aVisitor) {
        myUtility.visitColumn(aRow, aCol, aVisitor);
    }

    public void visitDiagonal(final int aRow, final int aCol, final AggregatorFunction<ComplexNumber> aVisitor) {
        myUtility.visitDiagonal(aRow, aCol, aVisitor);
    }

    public void visitRow(final int aRow, final int aCol, final AggregatorFunction<ComplexNumber> aVisitor) {
        myUtility.visitRow(aRow, aCol, aVisitor);
    }

}
