/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.type.context;

import java.io.Serializable;
import java.text.Format;
import java.text.ParseException;

import org.ojalgo.ProgrammingError;

public abstract class TypeContext<T> implements Serializable {

    /**
     * Use 'Non-Breaking SPace' character instead of ardinary 'space' character.
     */
    public static final boolean NBSP = true;

    private Format myFormat;

    @SuppressWarnings("unused")
    private TypeContext() {
        this(null);
    }

    protected TypeContext(final Format aFormat) {

        super();

        myFormat = aFormat;

        ProgrammingError.throwIfNull(myFormat);
    }

    public abstract T enforce(T anObject);

    public final String formatString(final T anObject) {

        this.configureFormat(myFormat, anObject);

        if (NBSP) {
            return myFormat.format(anObject).replace((char) 32, (char) 160);
        } else {
            return myFormat.format(anObject);
        }
    }

    public final Format getFormat() {
        return myFormat;
    }

    /**
     * First calls {@linkplain #parseObject(String)} and then {@linkplain #enforce(Object)}.
     */
    public final T parseAndEnforce(final String aString) {
        return this.enforce(this.parseObject(aString));
    }

    @SuppressWarnings("unchecked")
    public final T parseObject(final String aString) {
        try {
            return (T) myFormat.parseObject(NBSP ? aString.replace((char) 160, (char) 32) : aString);
        } catch (final ParseException anException) {
            return this.handleParseException(aString);
        }
    }

    public final void setFormat(final Format aFormat) {
        myFormat = aFormat;
    }

    protected abstract void configureFormat(Format aFormat, T anObject);

    protected abstract T handleParseException(String aString);

}
