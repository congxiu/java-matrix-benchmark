/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.random.process;

import java.util.List;

import org.ojalgo.access.Access1D;
import org.ojalgo.access.Access2D;
import org.ojalgo.access.ArrayAccess;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.function.aggregator.Aggregator;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.random.Distribution;
import org.ojalgo.random.MultidimensionalGaussian;
import org.ojalgo.random.SampleSet;

public final class MultidimensionalProcess implements RandomProcess<Distribution> {

    static final class Simulator {

        private final ArrayAccess.Primitive myInitialState;
        private final MultidimensionalProcess myProcess;

        @SuppressWarnings("unused")
        private Simulator() {
            this(null);
        }

        Simulator(final MultidimensionalProcess aProcess) {

            super();

            myProcess = aProcess;

            myInitialState = ArrayAccess.makePrimitive(myProcess.getDimension());
            for (int p = 0; p < myInitialState.length; p++) {
                myInitialState.set(p, aProcess.getProcess(p).getValue());
            }
        }

        SampleSet[] simulate(final int aNumberOfRealisations, final int aNumberOfSteps, final double aStepSize) {

            final SampleSet[] retVal = new SampleSet[aNumberOfSteps];

            final Array2D<Double> tmpRealisationValues = Array2D.makePrimitive(aNumberOfRealisations, aNumberOfSteps);

            for (int r = 0; r < aNumberOfRealisations; r++) {
                for (int s = 0; s < aNumberOfSteps; s++) {
                    tmpRealisationValues.set(r, s, myProcess.step(aStepSize));
                }
                myProcess.setValue(myInitialState);
            }

            for (int s = 0; s < aNumberOfSteps; s++) {
                retVal[s] = SampleSet.wrap(tmpRealisationValues.sliceColumn(0, s));
            }

            return retVal;
        }
    }

    private final Aggregator myAggregator;
    private final MultidimensionalGaussian myGenerator;
    private final AbstractProcess<?>[] myProcesses;

    public MultidimensionalProcess(final List<? extends AbstractProcess<?>> someProcs) {
        this(someProcs, PrimitiveDenseStore.FACTORY.makeEye(someProcs.size(), someProcs.size()));
    }

    public MultidimensionalProcess(final List<? extends AbstractProcess<?>> someProcs, final Access2D<?> aCorrelationsMatrix) {
        this(someProcs, aCorrelationsMatrix, Aggregator.SUM);
    }

    public MultidimensionalProcess(final List<? extends AbstractProcess<?>> someProcs, final Access2D<?> aCorrelationsMatrix, final Aggregator anAggregator) {

        super();

        myProcesses = someProcs.toArray(new AbstractProcess[someProcs.size()]);
        myGenerator = new MultidimensionalGaussian(aCorrelationsMatrix);
        myAggregator = anAggregator;
    }

    public MultidimensionalProcess(final List<? extends AbstractProcess<?>> someProcs, final Aggregator anAggregator) {
        this(someProcs, PrimitiveDenseStore.FACTORY.makeEye(someProcs.size(), someProcs.size()), anAggregator);
    }

    @SuppressWarnings("unused")
    private MultidimensionalProcess() {
        this(null, null, null);
    }

    public Distribution getDistribution(final double aStepSize) {
        throw new UnsupportedOperationException();
    }

    public ArrayAccess.Primitive getValue() {

        final ArrayAccess.Primitive retVal = ArrayAccess.makePrimitive(myProcesses.length);

        for (int p = 0; p < myProcesses.length; p++) {
            retVal.set(p, myProcesses[p].getValue());
        }

        return retVal;
    }

    public void setValue(final Access1D<?> aValue) {
        for (int p = 0; p < myProcesses.length; p++) {
            myProcesses[p].setValue(aValue.doubleValue(p));
        }
    }

    public SampleSet[] simulate(final int aNumberOfRealisations, final int aNumberOfSteps, final double aStepSize) {

        final Simulator tmpSimulator = new Simulator(this);

        return tmpSimulator.simulate(aNumberOfRealisations, aNumberOfSteps, aStepSize);
    }

    public double step(final double aStepSize) {

        final Array1D<Double> tmpSteps = myGenerator.generate();

        for (int p = 0; p < myProcesses.length; p++) {
            tmpSteps.set(p, myProcesses[p].step(aStepSize, tmpSteps.doubleValue(p)));
        }

        final AggregatorFunction<Double> tmpAggrFunc = myAggregator.getPrimitiveFunction();

        tmpSteps.visitAll(tmpAggrFunc);

        return tmpAggrFunc.doubleValue();
    }

    int getDimension() {
        return myProcesses.length;
    }

    double getExpected(final int index, final double aStepSize) {
        return myProcesses[index].getExpected(aStepSize);
    }

    AbstractProcess<?> getProcess(final int index) {
        return myProcesses[index];
    }

    double getStandardDeviation(final int index, final double aStepSize) {
        return myProcesses[index].getStandardDeviation(aStepSize);
    }

    double getValue(final int index) {
        return myProcesses[index].getValue();
    }

    double getVariance(final int index, final double aStepSize) {
        return myProcesses[index].getVariance(aStepSize);
    }

    void setValue(final int index, final double newValue) {
        myProcesses[index].setValue(newValue);
    }

    SampleSet[] simulate(final int index, final int aNumberOfRealisations, final int aNumberOfSteps, final double aStepSize) {
        return myProcesses[index].simulate(aNumberOfRealisations, aNumberOfSteps, aStepSize);
    }

}
