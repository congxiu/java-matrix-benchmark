/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.series;

import java.math.BigDecimal;
import java.util.TreeMap;

import org.ojalgo.constant.PrimitiveMath;

public class SeriesInterpolator<K extends Comparable<K>, V extends Number> {

    private CoordinationSet<K, V> myCoordinatedSet = null;
    private final TreeMap<BigDecimal, String> myKeys = new TreeMap<BigDecimal, String>();
    private final CoordinationSet<K, V> myOriginalSet = new CoordinationSet<K, V>();

    public SeriesInterpolator() {
        super();
    }

    public void addSeries(final BigDecimal aKey, final BasicTimeSeries<K, V> aSeries) {
        myKeys.put(aKey, aSeries.getName());
        myOriginalSet.put(aSeries);
        myCoordinatedSet = null;
    }

    public void addSeries(final long aKey, final BasicTimeSeries<K, V> aSeries) {
        this.addSeries(new BigDecimal(aKey), aSeries);
    }

    public TimeInMillisSeries<BigDecimal> getCombination(final BigDecimal anInputKey) {

        final TimeInMillisSeries<BigDecimal> retVal = new TimeInMillisSeries<BigDecimal>();

        if (myCoordinatedSet == null) {
            myCoordinatedSet = myOriginalSet.copy();
            myCoordinatedSet.prune();
        }

        BigDecimal tmpLowerKey = null;
        BigDecimal tmpUpperKey = null;
        for (final BigDecimal tmpIterKey : myKeys.keySet()) {
            if (tmpLowerKey != null) {
                if ((tmpIterKey.compareTo(tmpLowerKey) == 1) && (tmpIterKey.compareTo(anInputKey) == -1)) {
                    tmpLowerKey = tmpIterKey;
                }
            } else {
                if (tmpIterKey.compareTo(anInputKey) != 1) {
                    tmpLowerKey = tmpIterKey;
                }
            }
            if (tmpUpperKey != null) {
                if ((tmpIterKey.compareTo(tmpUpperKey) == -1) && (tmpIterKey.compareTo(anInputKey) == 1)) {
                    tmpUpperKey = tmpIterKey;
                }
            } else {
                if (tmpIterKey.compareTo(anInputKey) != -1) {
                    tmpUpperKey = tmpIterKey;
                }
            }
        }

        final long[] tmpSeriesKeys = ((BasicTimeSeries<K, V>) myCoordinatedSet.values().toArray()[0]).getPrimitiveKeys();
        double tmpFactor;
        double[] tmpSeriesValues;

        if ((tmpLowerKey == null) && (tmpUpperKey != null)) {

            tmpFactor = anInputKey.doubleValue() / tmpUpperKey.doubleValue();

            tmpSeriesValues = myCoordinatedSet.get(myKeys.get(tmpUpperKey)).getPrimitiveValues();
            for (int i = 0; i < tmpSeriesValues.length; i++) {
                tmpSeriesValues[i] *= tmpFactor;
            }

        } else if ((tmpLowerKey != null) && (tmpUpperKey == null)) {

            tmpFactor = anInputKey.doubleValue() / tmpLowerKey.doubleValue();

            tmpSeriesValues = myCoordinatedSet.get(myKeys.get(tmpLowerKey)).getPrimitiveValues();
            for (int i = 0; i < tmpSeriesValues.length; i++) {
                tmpSeriesValues[i] *= tmpFactor;
            }

        } else if ((tmpLowerKey != null) && (tmpUpperKey != null) && tmpLowerKey.equals(tmpUpperKey)) {

            tmpSeriesValues = myCoordinatedSet.get(myKeys.get(tmpLowerKey)).getPrimitiveValues();

        } else {

            final double[] tmpLowerValues = myCoordinatedSet.get(myKeys.get(tmpLowerKey)).getPrimitiveValues();
            final double[] tmpUpperValues = myCoordinatedSet.get(myKeys.get(tmpUpperKey)).getPrimitiveValues();

            tmpFactor = (anInputKey.doubleValue() - tmpLowerKey.doubleValue()) / (tmpUpperKey.doubleValue() - tmpLowerKey.doubleValue());

            tmpSeriesValues = new double[tmpSeriesKeys.length];

            for (int i = 0; i < tmpSeriesValues.length; i++) {
                tmpSeriesValues[i] = tmpFactor * tmpUpperValues[i] + (PrimitiveMath.ONE - tmpFactor) * tmpLowerValues[i];
            }
        }

        for (int i = 0; i < tmpSeriesKeys.length; i++) {
            retVal.put(tmpSeriesKeys[i], new BigDecimal(tmpSeriesValues[i]));
        }

        return retVal;
    }

}
