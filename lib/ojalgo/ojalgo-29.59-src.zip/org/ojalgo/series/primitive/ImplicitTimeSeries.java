/* 
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
package org.ojalgo.series.primitive;

import java.util.Calendar;

import org.ojalgo.type.CalendarDateUnit;
import org.ojalgo.type.TimeFilter;

public final class ImplicitTimeSeries extends PrimitiveTimeSeries {

    private final TimeFilter myFilter;
    private final Calendar myFirst;

    public ImplicitTimeSeries(final Calendar aFirst, final CalendarDateUnit aResolution, final PrimitiveSeries aValueSeries) {

        super(aValueSeries);

        myFirst = aFirst;
        myFilter = new TimeFilter(aResolution);
    }

    @Override
    public ImplicitTimeSeries add(final double aValue) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.add(aValue));
    }

    @Override
    public final ImplicitTimeSeries add(final PrimitiveSeries aSeries) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.add(aSeries));
    }

    @Override
    public ImplicitTimeSeries copy() {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.copy());
    }

    @Override
    public final ImplicitTimeSeries differences() {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.differences());
    }

    @Override
    public ImplicitTimeSeries divide(final double aValue) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.divide(aValue));
    }

    @Override
    public final ImplicitTimeSeries divide(final PrimitiveSeries aSeries) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.divide(aSeries));
    }

    @Override
    public PrimitiveSeries exp() {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.exp());
    }

    @Override
    public final Calendar first() {
        return myFirst;
    }

    @Override
    public long getAverageStepSize() {
        return myFilter.getResolution().size();
    }

    @Override
    public final long[] keys() {

        final long[] retVal = new long[this.size()];

        Calendar tmpCal = myFirst;
        retVal[0] = tmpCal.getTimeInMillis();
        for (int t = 1; t < retVal.length; t++) {
            tmpCal = myFilter.step(tmpCal);
            retVal[t] = tmpCal.getTimeInMillis();
        }
        return retVal;
    }

    @Override
    public final Calendar last() {
        return myFilter.step(myFirst, this.size() - 1);
    }

    @Override
    public PrimitiveSeries log() {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.log());
    }

    @Override
    public final ImplicitTimeSeries multiply(final double aFactor) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.multiply(aFactor));
    }

    @Override
    public ImplicitTimeSeries multiply(final PrimitiveSeries aSeries) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.multiply(aSeries));
    }

    @Override
    public final ImplicitTimeSeries quotients() {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.quotients());
    }

    public final CalendarDateUnit resolution() {
        return myFilter.getResolution();
    }

    @Override
    public final ImplicitTimeSeries runningProduct(final double initialValue) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.runningProduct(initialValue));
    }

    @Override
    public final ImplicitTimeSeries runningSum(final double initialValue) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.runningSum(initialValue));
    }

    @Override
    public ImplicitTimeSeries subtract(final double aValue) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.subtract(aValue));
    }

    @Override
    public ImplicitTimeSeries subtract(final PrimitiveSeries aSeries) {
        return new ImplicitTimeSeries(this.first(), this.resolution(), super.subtract(aSeries));
    }

}
