/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.List;

import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.matrix.BasicMatrix;

/**
 * Black-Litterman Modifier
 *
 * @author apete
 */
abstract class BLModifier extends EquilibriumModel {

    private final BlackLittermanModel myBlackLittermanModel;
    private final BasicMatrix myStrategicWeights;

    @SuppressWarnings("unused")
    private BLModifier(final MarketEquilibrium aMarketEquilibrium) {

        super(aMarketEquilibrium);

        myBlackLittermanModel = null;
        myStrategicWeights = null;
    }

    protected BLModifier(final BlackLittermanModel aBlackLittermanModel, final BasicMatrix someStrategicWeights) {

        super(aBlackLittermanModel.getMarketEquilibrium());

        myBlackLittermanModel = aBlackLittermanModel;
        myStrategicWeights = someStrategicWeights;
        this.calibrate(myStrategicWeights, myBlackLittermanModel.getOriginalReturns());
    }

    protected BLModifier(final BlackLittermanModel aBlackLittermanModel, final FinancePortfolio aStrategicPortfolio) {
        this(aBlackLittermanModel, aStrategicPortfolio.getWeights());
    }

    protected BLModifier(final BlackLittermanModel aBlackLittermanModel, final List<BigDecimal> someStrategicWeights) {
        this(aBlackLittermanModel, FACTORY.makeColumnVector(someStrategicWeights));
    }

    /**
     * Inverse Risk Aversion Conversion Factor
     */
    public final BigDecimal getChangeMultiplier() {
        return BigFunction.DIVIDE.invoke(myBlackLittermanModel.getRiskAversion(), this.getRiskAversion());
    }

    public final BigDecimal getConformance() {

        final BasicMatrix tmpTheoreticalStrategicWeights = this.calculateEquilibriumWeights(myBlackLittermanModel.getOriginalReturns());

        BigDecimal retVal = myStrategicWeights.multiplyVectors(tmpTheoreticalStrategicWeights).toBigDecimal();
        retVal = BigFunction.DIVIDE.invoke(retVal, myStrategicWeights.getFrobeniusNorm().toBigDecimal());
        retVal = BigFunction.DIVIDE.invoke(retVal, tmpTheoreticalStrategicWeights.getFrobeniusNorm().toBigDecimal());

        return retVal;
    }

    @Override
    protected final BasicMatrix calculateAssetReturns() {
        return myBlackLittermanModel.calculateAssetReturns();
    }

    final BlackLittermanModel getBlackLittermanModel() {
        return myBlackLittermanModel;
    }

    final BasicMatrix getStrategicWeights() {
        return myStrategicWeights;
    }

}
