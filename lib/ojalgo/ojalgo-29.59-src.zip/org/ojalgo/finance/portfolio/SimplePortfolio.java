/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.ojalgo.access.Access2D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.PreconfiguredSecond;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.random.process.GeometricBrownianMotion;
import org.ojalgo.random.process.MultidimensionalProcess;
import org.ojalgo.random.process.RandomProcess;

public final class SimplePortfolio extends FinancePortfolio {

    private final Access2D<?> myCorrelations;
    private transient Double myMeanReturn;
    private transient Double myReturnVariance;
    private final List<SimpleAsset> mySimpleAssets;
    private transient List<BigDecimal> myWeights;

    public SimplePortfolio(final Access2D<?> aCorrelationsMatrix, final List<SimpleAsset> someAssets) {

        super();

        if ((someAssets.size() != aCorrelationsMatrix.getRowDim()) || (someAssets.size() != aCorrelationsMatrix.getColDim())) {
            throw new IllegalArgumentException("Input dimensions don't match!");
        }

        myCorrelations = aCorrelationsMatrix;
        mySimpleAssets = someAssets;
    }

    public SimplePortfolio(final List<SimpleAsset> someAssets) {
        this(PrimitiveDenseStore.FACTORY.makeEye(someAssets.size(), someAssets.size()), someAssets);
    }

    @SuppressWarnings("unused")
    private SimplePortfolio() {
        this(null, null);
    }

    public RandomProcess<?> forecast(final boolean multidimensional) {

        if (multidimensional) {

            final List<GeometricBrownianMotion> tmpAssetProcesses = new ArrayList<GeometricBrownianMotion>(mySimpleAssets.size());

            for (final SimpleAsset tmpAsset : mySimpleAssets) {
                tmpAssetProcesses.add(tmpAsset.forecast());
            }

            return new MultidimensionalProcess(tmpAssetProcesses, myCorrelations);

        } else {

            return this.forecast();
        }
    }

    public double getCorrelation(final int aRow, final int aCol) {
        return myCorrelations.doubleValue(aRow, aCol);
    }

    @Override
    public double getMeanReturn() {

        if (myMeanReturn == null) {

            double tmpVal = PrimitiveMath.ZERO;
            for (final SimpleAsset tmpAsset : mySimpleAssets) {
                tmpVal += (tmpAsset.getWeight().doubleValue() * tmpAsset.getMeanReturn());
            }
            myMeanReturn = tmpVal;
        }

        return myMeanReturn;
    }

    @Override
    public double getReturnVariance() {

        if (myReturnVariance == null) {

            final int tmpSize = mySimpleAssets.size();

            final PhysicalStore<Double> tmpCovaris = PrimitiveDenseStore.FACTORY.copy(myCorrelations);
            final PhysicalStore<Double> tmpWeights = PrimitiveDenseStore.FACTORY.makeZero(tmpSize, 1);

            SimpleAsset tmpAsset;
            for (int ij = 0; ij < tmpSize; ij++) {

                tmpAsset = mySimpleAssets.get(ij);

                tmpWeights.set(ij, 0, tmpAsset.getWeight().doubleValue());

                final PreconfiguredSecond<Double> tmpFunc = new PreconfiguredSecond<Double>(PrimitiveFunction.MULTIPLY, tmpAsset.getVolatility());
                tmpCovaris.modifyRow(ij, 0, tmpFunc);
                tmpCovaris.modifyColumn(0, ij, tmpFunc);
            }

            myReturnVariance = tmpCovaris.multiplyLeft(tmpWeights.transpose()).multiplyRight(tmpWeights).doubleValue(0, 0);
        }

        return myReturnVariance;
    }

    @Override
    public List<BigDecimal> getWeights() {

        if (myWeights == null) {

            myWeights = new ArrayList<BigDecimal>(mySimpleAssets.size());

            for (final SimpleAsset tmpAsset : mySimpleAssets) {
                myWeights.add(tmpAsset.getWeight());
            }
        }

        return myWeights;
    }

    @Override
    protected void reset() {

        myMeanReturn = null;
        myReturnVariance = null;
        myWeights = null;
    }

}
