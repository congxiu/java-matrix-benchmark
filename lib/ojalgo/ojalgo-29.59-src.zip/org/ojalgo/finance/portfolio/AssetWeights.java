/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.type.TypeUtils;

/**
 * Only contains/specifies the portfolio's asset weights.
 * 
 * Return, risk variance and all those things are equal to 0.0.
 *
 * @author apete
 */
public final class AssetWeights extends FinancePortfolio {

    private final ArrayList<BigDecimal> myWeights;

    public AssetWeights(final List<? extends Number> someWeights) {
        this(someWeights.toArray(new Number[someWeights.size()]));
    }

    public AssetWeights(final Number... someWeights) {

        super();

        myWeights = new ArrayList<BigDecimal>();

        for (final Number tmpNumber : someWeights) {
            myWeights.add(TypeUtils.toBigDecimal(tmpNumber, WEIGHT_CONTEXT));
        }
    }

    @SuppressWarnings("unused")
    private AssetWeights() {
        this(new ArrayList<BigDecimal>());
    }

    @Override
    public double getMeanReturn() {
        return PrimitiveMath.ZERO;
    }

    @Override
    public double getReturnVariance() {
        return PrimitiveMath.ZERO;
    }

    @Override
    public double getVolatility() {
        return PrimitiveMath.ZERO;
    }

    @Override
    public List<BigDecimal> getWeights() {
        return myWeights;
    }

    @Override
    protected void reset() {
        ;
    }

}
