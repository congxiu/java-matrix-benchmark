/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;
import java.util.List;

import org.ojalgo.matrix.BasicMatrix;

public final class StrategicTransformation extends BLModifier {

    public StrategicTransformation(final BlackLittermanModel aBlackLittermanModel, final BasicMatrix someStrategicWeights) {
        super(aBlackLittermanModel, someStrategicWeights);
    }

    public StrategicTransformation(final BlackLittermanModel aBlackLittermanModel, final FinancePortfolio aStrategicPortfolio) {
        super(aBlackLittermanModel, aStrategicPortfolio);
    }

    public StrategicTransformation(final BlackLittermanModel aBlackLittermanModel, final List<BigDecimal> someStrategicWeights) {
        super(aBlackLittermanModel, someStrategicWeights);
    }

    @Override
    protected BasicMatrix calculateAssetWeights() {

        MarkowitzModel tmpMarkowitzModel = new MarkowitzModel(this.getMarketEquilibrium(), this.getBlackLittermanModel().getOriginalReturns());
        tmpMarkowitzModel.setShortingAllowed(false);

        final BasicMatrix tmpPreferredStrategicWeights = tmpMarkowitzModel.calculateAssetWeights();

        final BasicMatrix tmpLowerLimits = tmpPreferredStrategicWeights.subtract(this.getStrategicWeights());
        final List<BasicMatrix> tmpViewsColumns = this.getBlackLittermanModel().getViewPortfolios().toListOfColumns();

        tmpMarkowitzModel = new MarkowitzModel(this.getMarketEquilibrium(), this.getBlackLittermanModel().calculateAssetReturns());
        tmpMarkowitzModel.setShortingAllowed(false);

        BasicMatrix tmpViewsColumn;
        for (int i = 0; i < tmpViewsColumns.size(); i++) {

            tmpViewsColumn = tmpViewsColumns.get(i);

            if (tmpViewsColumn.getFrobeniusNorm().isZero()) {
                tmpMarkowitzModel.setLowerLimit(i, tmpPreferredStrategicWeights.toBigDecimal(i, 0));
                tmpMarkowitzModel.setUpperLimit(i, tmpPreferredStrategicWeights.toBigDecimal(i, 0));
            } else {
                tmpMarkowitzModel.setLowerLimit(i, tmpLowerLimits.toBigDecimal(i, 0));
            }
        }

        final BasicMatrix tmpPreferredModifiedWeights = tmpMarkowitzModel.calculateAssetWeights();

        final BasicMatrix tmpChanges = tmpPreferredModifiedWeights.subtract(tmpPreferredStrategicWeights);
        return this.getStrategicWeights().add(tmpChanges);
    }
}
