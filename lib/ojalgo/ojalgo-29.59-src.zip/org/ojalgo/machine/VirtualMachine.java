/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.machine;

import org.ojalgo.ProgrammingError;
import org.ojalgo.access.Access2D;
import org.ojalgo.netio.BasicLogger;

public final class VirtualMachine extends AbstractMachine {

    private static final String SPACE = " ";

    /**
     * The dimension (size) of the largest square matrix that will fit
     * in an L2 cache.
     */
    public final int dim;

    /**
     * The largest number of matrix elements that will fit in an L2 cache
     */
    public final int elements;

    private final Hardware myHardware;
    private final Runtime myRuntime;

    @SuppressWarnings("unused")
    private VirtualMachine(final BasicMachine[] someLevels) {

        super(someLevels);

        myRuntime = null;
        myHardware = null;

        elements = INT_0000;

        dim = INT_0000;

        ProgrammingError.throwForIllegalInvocation();
    }

    VirtualMachine(final Runtime aRuntime, final Hardware aHardware) {

        super(aRuntime, aHardware);

        myRuntime = aRuntime;
        myHardware = aHardware;

        elements = (int) (cache / LONG_0008);

        dim = (int) Math.sqrt(elements);
    }

    public void collectGarbage() {

        long tmpIsFree = myRuntime.freeMemory();
        long tmpWasFree;

        do {
            tmpWasFree = tmpIsFree;
            myRuntime.gc();
            try {
                Thread.sleep(10L);
            } catch (final InterruptedException anException) {
                BasicLogger.logError(anException.getMessage());
            }
            tmpIsFree = myRuntime.freeMemory();
        } while (tmpIsFree > tmpWasFree);

        myRuntime.runFinalization();
    }

    /**
     * The dimension (as in {@linkplain Access2D#getRowDim()} and/or
     * {@linkplain Access2D#getColDim()}) of a matrix (anything 2D) that
     * will fit in an L2 cache unit given the input element size.
     */
    public int getCacheDim(final long anElementSize) {
        return (int) Math.sqrt((cache - LONG_0016) / anElementSize);
    }

    public int getMaxNewObjects(final long anObjectSize) {

        final long tmpMax = myRuntime.maxMemory();
        final long tmpTotal = myRuntime.totalMemory();
        final long tmpFree = myRuntime.freeMemory();

        return (int) ((tmpMax - tmpTotal + tmpFree) / anObjectSize);
    }

    @Override
    public String toString() {
        return super.toString() + SPACE + myHardware.toString();
    }

}
