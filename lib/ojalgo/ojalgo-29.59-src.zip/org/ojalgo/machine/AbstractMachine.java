/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.machine;

import org.ojalgo.type.IntCount;

abstract class AbstractMachine extends BasicMachine {

    static final int INT_0000 = 0;
    static final int INT_0001 = 1;
    static final int INT_0002 = 2;
    static final int INT_0003 = 3;
    static final int INT_0004 = 4;
    static final int INT_0008 = 8;
    static final int INT_0016 = 16;
    static final int INT_1024 = 1024;
    static final long LONG_0000 = 0L;
    static final long LONG_0001 = 1L;
    static final long LONG_0003 = 3L;
    static final long LONG_0004 = 4L;
    static final long LONG_0008 = 8L;
    static final long LONG_0012 = 12L;
    static final long LONG_0016 = 16L;
    static final long LONG_0032 = 32L;
    static final long LONG_0256 = 256L;
    static final long LONG_1024 = 1024L;

    /**
     * The size of one L2 cache unit in bytes. If no L2 cache is
     * specified then this will be equal to <code>memory</code>.
     */
    public final long cache;
    /**
     * The total number of processor cores.
     */
    public final int cores;
    /**
     * The number of L3 cache units. (It is assumed there is 1 L3 cache
     * unit per processor.) If no L3 cache is specified then this will
     * be equal to <code>units</code>.
     */
    public final int processors;
    /**
     * The number of L2 cache units. If no L2 cache is specified then
     * this will be equal to <code>1</code>.
     */
    public final int units;

    @SuppressWarnings("unused")
    private AbstractMachine(final long aMemory, final int aThreads) {

        super(aMemory, aThreads);

        throw new IllegalArgumentException();
    }

    /**
     * <code>new MemoryThreads[] { SYSTEM, L3, L2, L1 }</code>
     * or
     * <code>new MemoryThreads[] { SYSTEM, L2, L1 }</code>
     * or in worst case
     * <code>new MemoryThreads[] { SYSTEM, L1 }</code>
     */
    protected AbstractMachine(final BasicMachine[] someLevels) {

        super(someLevels[INT_0000].memory, someLevels[INT_0000].threads);

        cache = someLevels[(someLevels.length - INT_0002)].memory;

        cores = threads / someLevels[(someLevels.length - INT_0001)].threads;
        units = threads / someLevels[(someLevels.length - INT_0002)].threads;

        processors = threads / someLevels[INT_0001].threads;
    }

    protected AbstractMachine(final Runtime aRuntime, final Hardware aHardware) {

        super(aRuntime.maxMemory(), aRuntime.availableProcessors());

        cache = aHardware.cache;

        cores = aHardware.cores;
        units = aHardware.units;

        processors = aHardware.processors;
    }

    public IntCount countCores() {
        return new IntCount(cores);
    }

    public IntCount countProcessors() {
        return new IntCount(processors);
    }

    public IntCount countThreads() {
        return new IntCount(threads);
    }

    public IntCount countUnits() {
        return new IntCount(units);
    }

    public boolean isMultiCore() {
        return cores > INT_0001;
    }

    public boolean isMultiProcessor() {
        return processors > INT_0001;
    }

    public boolean isMultiThread() {
        return threads > INT_0001;
    }

    public boolean isMultiUnit() {
        return units > INT_0001;
    }

}
