/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.machine;

import java.util.Arrays;

import org.ojalgo.ProgrammingError;

/**
 * <ul>
 * <li>
 * The first element in the array should correspond to total system
 * resources; the total amount of RAM and the total number of
 * threads (Typically the same as what is returned by
 * {@linkplain Runtime#availableProcessors()}).
 * </li><li>
 * The last element in the array should describe the L1 cache.
 * Typically Intel processors have 32k L1 cache and AMD 64k. 1 or
 * maybe 2 threads use/share this cache.
 * </li><li>
 * Caches, all levels except L1, are described between the first
 * and last elements in descending order (L3 cache comes before L2
 * cache). Specify the size of the cache and the number of threads
 * using/sharing the cache. (Do not worry about how
 * many cache units there are - describe one unit.)
 * </li><li>
 * The array must have at least 2 elements. You must describe the
 * total system resources and the L1 cache. It is strongly
 * recommended to also describe the L2 cache. The L3 cache, if it
 * exists, is less important to describe. The derived attributes
 * <code>processors</code>, <code>cores</code> and <code>units</code>
 * may be incorrectly calculated if you fail to specify the caches.
 * Known issue: If you have more than one processor, nut no L3
 * cache; the <code>processors</code> attribute will be incorrectly
 * set 1. A workaround that currently works is to define an L3
 * cache anyway and set the memory/size of that cache to 0bytes.
 * This workoround may stop working in the future. 
 * </li><li>
 * <code>new MemoryThreads[] { SYSTEM, L3, L2, L1 }</code>
 * or
 * <code>new MemoryThreads[] { SYSTEM, L2, L1 }</code>
 * or
 * <code>new MemoryThreads[] { SYSTEM, L1 }</code>
 * </li>
 * <ul>
 *
 * @author apete
 */
public final class Hardware extends AbstractMachine {

    /**
     * Peter Abeles's (EJML) Intel Core i7-620M laptop
     *      
     * 1 processor
     * 2 cores per processor
     * 2 threads per core
     * Total 4 threads
     * 
     * 8GB RAM
     * 4MB L3 cache per processor
     * 256kB L2 cache per core
     * 32kB L1 cache per core
     */
    public static final Hardware I7_620M = new Hardware(new BasicMachine[] { new BasicMachine(AbstractMachine.LONG_0008 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0004), new BasicMachine(AbstractMachine.LONG_0004 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0004), new BasicMachine(AbstractMachine.LONG_0256 * AbstractMachine.LONG_1024, AbstractMachine.INT_0002), new BasicMachine(AbstractMachine.LONG_0032 * AbstractMachine.LONG_1024, AbstractMachine.INT_0002) });
    /**
     * Holger Arndt's (UJMP) Intel Core i7-920 server
     * 
     * 1 processor
     * 4 cores per processor
     * 2 threads per core
     * Total 8 threads
     * 
     * 8GB RAM
     * 8MB L3 cache per processor
     * 256kB L2 cache per core
     * 32kB L1 cache per core
     */
    public static final Hardware I7_920 = new Hardware(new BasicMachine[] { new BasicMachine(AbstractMachine.LONG_0008 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0008), new BasicMachine(AbstractMachine.LONG_0008 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0008), new BasicMachine(AbstractMachine.LONG_0256 * AbstractMachine.LONG_1024, AbstractMachine.INT_0002), new BasicMachine(AbstractMachine.LONG_0032 * AbstractMachine.LONG_1024, AbstractMachine.INT_0002) });
    /**
     * 1 processor
     * 1 core per processor
     * 1 thread per core
     * Total 1 threads
     * 
     * 1GB RAM
     * 1MB L2 cache per processor
     * 32kB L1 cache per core
     */
    public static final Hardware INTEL1 = new Hardware(new BasicMachine[] { new BasicMachine(AbstractMachine.LONG_0001 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0001), new BasicMachine(AbstractMachine.LONG_0001 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0001), new BasicMachine(AbstractMachine.LONG_0032 * AbstractMachine.LONG_1024, AbstractMachine.INT_0001) });
    /**
     * 1 processor
     * 2 cores per processor
     * 1 thread per core
     * Total 2 threads
     * 
     * 4GB RAM (MANTA: 3GB, B5950053: 3.5GB)
     * 4MB L2 cache per processor (MANTA: 4MB, B5950053: 6MB)
     * 32kB L1 cache per core
     */
    public static final Hardware MANTA = new Hardware(new BasicMachine[] { new BasicMachine(AbstractMachine.LONG_0004 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0002), new BasicMachine(AbstractMachine.LONG_0004 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0002), new BasicMachine(AbstractMachine.LONG_0032 * AbstractMachine.LONG_1024, AbstractMachine.INT_0001) });
    /**
     * Peter Abeles' (EJML) Q9400 and Q6600 machines.
     * 
     * 1 processor
     * 4 cores per processor
     * 1 thread per core
     * Total 4 threads
     * 
     * 8GB RAM (Q6600: 8GB, Q9400: 3GB)
     * 3MB L2 cache per 2 cores  (Q6600: 2x4MB, Q9400: 2x3MB)
     * 32kB L1 cache per core
     */
    public static final Hardware QXX00 = new Hardware(new BasicMachine[] { new BasicMachine(AbstractMachine.LONG_0008 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0004), new BasicMachine(AbstractMachine.LONG_0003 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0002), new BasicMachine(AbstractMachine.LONG_0032 * AbstractMachine.LONG_1024, AbstractMachine.INT_0001) });
    /**
     * 2 processors
     * 4 cores per processor
     * 2 threads per core
     * Total 16 threads
     * 
     * 12GB RAM
     * 8MB L3 cache per processor
     * 256kB L2 cache per core
     * 32kB L1 cache per core
     */
    public static final Hardware SAILFISH = new Hardware(new BasicMachine[] { new BasicMachine(AbstractMachine.LONG_0012 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0016), new BasicMachine(AbstractMachine.LONG_0008 * AbstractMachine.LONG_1024 * AbstractMachine.LONG_1024, AbstractMachine.INT_0008), new BasicMachine(AbstractMachine.LONG_0256 * AbstractMachine.LONG_1024, AbstractMachine.INT_0002), new BasicMachine(AbstractMachine.LONG_0032 * AbstractMachine.LONG_1024, AbstractMachine.INT_0002) });

    private static final String COLON_SPACE = ": ";

    public static Hardware makeSimple(final long systemRAM, final int systemThreads) {
        return new Hardware(new BasicMachine[] { new BasicMachine(systemRAM, systemThreads), new BasicMachine(AbstractMachine.LONG_0032 * AbstractMachine.LONG_1024, AbstractMachine.INT_0001) });
    }

    private final BasicMachine[] myLevels;

    /**
     * <code>new MemoryThreads[] { SYSTEM, L3, L2, L1 }</code>
     * or
     * <code>new MemoryThreads[] { SYSTEM, L2, L1 }</code>
     * or in worst case
     * <code>new MemoryThreads[] { SYSTEM, L1 }</code>
     */
    public Hardware(final BasicMachine[] someLevels) {

        super(someLevels);

        myLevels = someLevels.clone();
    }

    @SuppressWarnings("unused")
    private Hardware(final Runtime aRuntime, final Hardware aHardware) {

        super(aRuntime, aHardware);

        myLevels = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    public boolean isL2Specified() {
        return myLevels.length > AbstractMachine.INT_0002;
    }

    public boolean isL3Specified() {
        return myLevels.length > AbstractMachine.INT_0003;
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + Hardware.COLON_SPACE + Arrays.toString(myLevels);
    }

    public final VirtualMachine virtualise() {
        return new VirtualMachine(Runtime.getRuntime(), this);
    }

}
