/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.List;

import org.ojalgo.ProgrammingError;
import org.ojalgo.access.Access1D;
import org.ojalgo.access.Access2D;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.BigAggregator;
import org.ojalgo.function.multiary.CompoundFunction;
import org.ojalgo.function.multiary.LinearFunction;
import org.ojalgo.function.multiary.MultiaryFunction;
import org.ojalgo.function.multiary.QuadraticFunction;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.type.context.NumberContext;

/**
 * Expression
 * 
 * @author apete
 */
public final class Expression extends ModelEntity<Expression> implements MultiaryFunction<BigDecimal> {

    static Expression makeCompound(final String aName, final Access2D<?> someQuadraticParams, final Access1D<?> someLinearParams) {

        final QuadraticFunction<BigDecimal> tmpQuad = QuadraticFunction.makeBig(someQuadraticParams);
        final LinearFunction<BigDecimal> tmpLin = LinearFunction.makeBig(someLinearParams);

        final CompoundFunction<BigDecimal> tmpFunc = new CompoundFunction<BigDecimal>(tmpQuad, tmpLin);

        return new Expression(aName, tmpFunc);
    }

    static Expression makeCompound(final String aName, final int aDim) {

        final QuadraticFunction<BigDecimal> tmpQuad = QuadraticFunction.makeBig(aDim);
        final LinearFunction<BigDecimal> tmpLin = LinearFunction.makeBig(aDim);

        final CompoundFunction<BigDecimal> tmpFunc = new CompoundFunction<BigDecimal>(tmpQuad, tmpLin);

        return new Expression(aName, tmpFunc);
    }

    static Expression makeLinear(final String aName, final Access1D<?> someLinearParams) {

        final LinearFunction<BigDecimal> tmpLin = LinearFunction.makeBig(someLinearParams);

        final CompoundFunction<BigDecimal> tmpFunc = new CompoundFunction<BigDecimal>(null, tmpLin);

        return new Expression(aName, tmpFunc);
    }

    static Expression makeLinear(final String aName, final int aDim) {

        final LinearFunction<BigDecimal> tmpLin = LinearFunction.makeBig(aDim);

        final CompoundFunction<BigDecimal> tmpFunc = new CompoundFunction<BigDecimal>(null, tmpLin);

        return new Expression(aName, tmpFunc);
    }

    static Expression makeQuadratic(final String aName, final Access2D<?> someQuadraticParams) {

        final QuadraticFunction<BigDecimal> tmpQuad = QuadraticFunction.makeBig(someQuadraticParams);

        final CompoundFunction<BigDecimal> tmpFunc = new CompoundFunction<BigDecimal>(tmpQuad, null);

        return new Expression(aName, tmpFunc);
    }

    static Expression makeQuadratic(final String aName, final int aDim) {

        final QuadraticFunction<BigDecimal> tmpQuad = QuadraticFunction.makeBig(aDim);

        final CompoundFunction<BigDecimal> tmpFunc = new CompoundFunction<BigDecimal>(tmpQuad, null);

        return new Expression(aName, tmpFunc);
    }

    private transient BigDecimal myAdjustmentFactor;
    private final CompoundFunction<BigDecimal> myFunction;

    @SuppressWarnings("unused")
    private Expression(final String aName) {
        this(aName, null);
    }

    Expression(final String aName, final CompoundFunction<BigDecimal> aFunction) {

        super(aName);

        myFunction = aFunction;

        ProgrammingError.throwIfNull(myFunction);
    }

    public int dim() {
        return myFunction.dim();
    }

    public final BigDecimal getAdjustedLinearFactor(final int aVar) {
        return myFunction.getLinearFactor(aVar).multiply(this.getAdjustmentFactor());
    }

    public final BigDecimal getAdjustedQuadraticFactor(final int aVar1, final int aVar2) {
        return myFunction.getQuadraticFactor(aVar1, aVar2).multiply(this.getAdjustmentFactor());
    }

    @Override
    public BigDecimal getAdjustmentFactor() {

        if (myAdjustmentFactor == null) {

            final AggregatorFunction<BigDecimal> tmpLargestAggr = BigAggregator.getCollection().largest();
            final AggregatorFunction<BigDecimal> tmpSmallestAggr = BigAggregator.getCollection().smallest();

            if (this.hasLinear()) {
                this.getLinear().getFactors().visitAll(tmpLargestAggr);
                this.getLinear().getFactors().visitAll(tmpSmallestAggr);
            }

            if (this.hasQuadratic()) {
                this.getQuadratic().getFactors().visitAll(tmpLargestAggr);
                this.getQuadratic().getFactors().visitAll(tmpSmallestAggr);
            }

            if (this.getLowerLimit() != null) {
                tmpLargestAggr.invoke(this.getLowerLimit());
                tmpSmallestAggr.invoke(this.getLowerLimit());
            }

            if (this.getUpperLimit() != null) {
                tmpLargestAggr.invoke(this.getUpperLimit());
                tmpSmallestAggr.invoke(this.getUpperLimit());
            }

            final int tmpExponent = OptimisationUtils.getAdjustmentFactorExponent(tmpLargestAggr, tmpSmallestAggr);

            myAdjustmentFactor = BigDecimal.TEN.pow(tmpExponent, MathContext.DECIMAL32);
        }

        return myAdjustmentFactor;
    }

    public BigDecimal getConstant() {
        return myFunction.getConstant();
    }

    public LinearFunction<BigDecimal> getLinear() {
        return myFunction.getLinear();
    }

    public BigDecimal getLinearFactor(final int aVar) {
        return myFunction.getLinearFactor(aVar);
    }

    public QuadraticFunction<BigDecimal> getQuadratic() {
        return myFunction.getQuadratic();
    }

    public BigDecimal getQuadraticFactor(final int aVar1, final int aVar2) {
        return myFunction.getQuadraticFactor(aVar1, aVar2);
    }

    public boolean hasConstant() {
        return myFunction.hasConstant();
    }

    public boolean hasLinear() {
        return myFunction.hasLinear();
    }

    public boolean hasQuadratic() {
        return myFunction.hasQuadratic();
    }

    public final BigDecimal invoke(final Access1D<?> anArg) {
        return myFunction.invoke(anArg);
    }

    public BigDecimal invoke(final BigDecimal[] aSolution) {
        return myFunction.invoke(aSolution);
    }

    public BigDecimal invoke(final double[] aSolution) {
        return myFunction.invoke(aSolution);
    }

    public BigDecimal invoke(final List<BigDecimal> aSolution) {
        return myFunction.invoke(aSolution);
    }

    public void setConstant(final BigDecimal aValue) {
        myFunction.setConstant(aValue);
    }

    public void setLinearFactor(final int aVar, final BigDecimal aValue) {
        myFunction.setLinearFactor(aVar, aValue);
    }

    public void setQuadraticFactor(final int aVar1, final int aVar2, final BigDecimal aValue) {
        myFunction.setQuadraticFactor(aVar1, aVar2, aValue);
    }

    public CompoundFunction<Double> toPrimitiveFunction() {

        QuadraticFunction<Double> tmpQuadratic;
        if (this.hasQuadratic()) {
            tmpQuadratic = QuadraticFunction.makePrimitiveCopy(this.getQuadratic());
        } else {
            tmpQuadratic = null;
        }

        LinearFunction<Double> tmpLinear;
        if (this.hasLinear()) {
            tmpLinear = LinearFunction.makePrimitiveCopy(this.getLinear());
        } else {
            tmpLinear = null;
        }

        return new CompoundFunction<Double>(tmpQuadratic, tmpLinear);
    }

    public boolean validateSolution(final BigDecimal[] aSolution, final NumberContext aContext) {
        try {
            return this.validate(this.invoke(aSolution), aContext);
        } catch (final ModelValidationException anException) {
            System.err.println(anException.toString());
            return false;
        }
    }

    public boolean validateSolution(final double[] aSolution, final NumberContext aContext) {
        try {
            return this.validate(this.invoke(aSolution), aContext);
        } catch (final ModelValidationException anException) {
            System.err.println(anException.toString());
            return false;
        }
    }

    public boolean validateSolution(final List<BigDecimal> aSolution, final NumberContext aContext) {
        try {
            return this.validate(this.invoke(aSolution), aContext);
        } catch (final ModelValidationException anException) {
            System.err.println(anException.toString());
            return false;
        }
    }

    protected void appendMiddlePart(final StringBuilder aStringBuilder, final List<BigDecimal> aCurrentState) {

        aStringBuilder.append(this.getName());
        aStringBuilder.append(": ");
        aStringBuilder.append(OptimisationUtils.DISPLAY.enforce(this.invoke(aCurrentState)));

        if (this.isObjective()) {
            aStringBuilder.append(" (");
            aStringBuilder.append(OptimisationUtils.DISPLAY.enforce(this.getContributionWeight()));
            aStringBuilder.append(")");
        }
    }

    final void appendToString(final StringBuilder aStringBuilder, final List<BigDecimal> aCurrentState) {

        this.appendLeftPart(aStringBuilder);
        if (aCurrentState != null) {
            this.appendMiddlePart(aStringBuilder, aCurrentState);
        } else {
            this.appendMiddlePart(aStringBuilder);
        }
        this.appendRightPart(aStringBuilder);
    }

    BigDecimal invoke(final MatrixStore<BigDecimal> aSolution) {
        return myFunction.invoke(aSolution);
    }

    boolean validateSolution(final MatrixStore<BigDecimal> aSolution, final NumberContext aContext) {
        try {
            return this.validate(this.invoke(aSolution), aContext);
        } catch (final ModelValidationException anException) {
            BasicLogger.logError(anException.toString());
            return false;
        }
    }
}
