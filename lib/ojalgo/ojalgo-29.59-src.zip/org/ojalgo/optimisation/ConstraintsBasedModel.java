/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation;

import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

import org.ojalgo.matrix.BasicMatrix;
import org.ojalgo.type.context.NumberContext;

public abstract class ConstraintsBasedModel<C extends ModelEntity<C> & Constraint, M extends ConstraintsBasedModel<C, M>> extends AbstractModel {

    private final HashMap<String, C> myConstraints = new HashMap<String, C>();

    protected ConstraintsBasedModel() {
        super();
    }

    protected ConstraintsBasedModel(final C[] someConstraints) {

        super();

        for (final C tmpConstraint : someConstraints) {
            myConstraints.put(tmpConstraint.getName(), tmpConstraint);
        }
    }

    protected ConstraintsBasedModel(final Set<? extends C> someConstraints) {

        super();

        for (final C tmpConstraint : someConstraints) {
            myConstraints.put(tmpConstraint.getName(), tmpConstraint);
        }
    }

    public boolean validateComposition() throws ModelValidationException {
        // TODO Auto-generated method stub
        return false;
    }

    public boolean validateSolution(final BasicMatrix aSolution, final NumberContext aContext) {
        // TODO Auto-generated method stub
        return false;
    }

    public boolean validateSolution(final NumberContext aContext) {
        // TODO Auto-generated method stub
        return false;
    }

    protected C addConstraint(final C aConstraint) {
        return myConstraints.put(aConstraint.getName(), aConstraint);
    }

    protected C getConstraint(final String aConstraintName) {
        return myConstraints.get(aConstraintName);
    }

    protected Collection<C> getConstraints() {
        return myConstraints.values();
    }
}
