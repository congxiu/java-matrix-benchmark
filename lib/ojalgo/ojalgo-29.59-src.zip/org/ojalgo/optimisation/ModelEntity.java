/* 
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation;

import java.math.BigDecimal;

import org.ojalgo.ProgrammingError;
import org.ojalgo.type.context.NumberContext;

/**
 * ModelEntity
 *
 * @author apete
 */
public abstract class ModelEntity<ME extends ModelEntity<ME>> implements Constraint, Objective, Comparable<ME> {

    private BigDecimal myContributionWeight = null;
    private BigDecimal myLowerLimit = null;
    private final String myName;
    private BigDecimal myUpperLimit = null;

    @SuppressWarnings("unused")
    private ModelEntity() {

        super();

        myName = null;

        ProgrammingError.throwForIllegalInvocation();
    }

    protected ModelEntity(final String aName) {

        super();

        myName = aName;

        ProgrammingError.throwIfNull(myName);
    }

    public int compareTo(final ME obj) {
        return myName.compareTo(obj.getName());
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {

        boolean retVal = false;

        if (obj instanceof ModelEntity<?>) {
            if (this.getClass().equals(obj.getClass())) {
                if (this.getName().equals(((ModelEntity<?>) obj).getName())) {
                    retVal = true;
                }
            }
        }

        return retVal;
    }

    public final BigDecimal getAdjustedLowerLimit() {
        return this.getLowerLimit().multiply(this.getAdjustmentFactor());
    }

    public final BigDecimal getAdjustedUpperLimit() {
        return this.getUpperLimit().multiply(this.getAdjustmentFactor());
    }

    public abstract BigDecimal getAdjustmentFactor();

    /**
     * @see org.ojalgo.optimisation.Objective#getContributionWeight()
     */
    public BigDecimal getContributionWeight() {
        return myContributionWeight;
    }

    /**
     * @see org.ojalgo.optimisation.Constraint#getLowerLimit()
     */
    public BigDecimal getLowerLimit() {
        return myLowerLimit;
    }

    public final String getName() {
        return myName;
    }

    /**
     * @see org.ojalgo.optimisation.Constraint#getUpperLimit()
     */
    public BigDecimal getUpperLimit() {
        return myUpperLimit;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return myName.hashCode();
    }

    /**
     * @see org.ojalgo.optimisation.Constraint#isConstraint()
     */
    public boolean isConstraint() {
        return this.isLowerLimitSet() || this.isUpperLimitSet();
    }

    public final boolean isContributionWeightSet() {
        return myContributionWeight != null;
    }

    /**
     * @see org.ojalgo.optimisation.Constraint#isEqualityConstraint()
     */
    public boolean isEqualityConstraint() {
        return this.isLowerLimitSet() && this.isUpperLimitSet() && (myLowerLimit.compareTo(myUpperLimit) == 0);
    }

    /**
     * @see org.ojalgo.optimisation.Constraint#isLowerConstraint()
     */
    public boolean isLowerConstraint() {
        return this.isLowerLimitSet() && !this.isEqualityConstraint();
    }

    public final boolean isLowerLimitSet() {
        return myLowerLimit != null;
    }

    /**
     * @see org.ojalgo.optimisation.Objective#isObjective()
     */
    public boolean isObjective() {
        return this.isContributionWeightSet() && (myContributionWeight.signum() != 0);
    }

    /**
     * @see org.ojalgo.optimisation.Constraint#isUpperConstraint()
     */
    public boolean isUpperConstraint() {
        return this.isUpperLimitSet() && !this.isEqualityConstraint();
    }

    public final boolean isUpperLimitSet() {
        return myUpperLimit != null;
    }

    @SuppressWarnings("unchecked")
    public final ME level(final BigDecimal aLowerAndUpperLimit) {
        this.setLowerLimit(aLowerAndUpperLimit);
        this.setUpperLimit(aLowerAndUpperLimit);
        return (ME) this;
    }

    @SuppressWarnings("unchecked")
    public final ME lower(final BigDecimal aLowerLimit) {
        this.setLowerLimit(aLowerLimit);
        return (ME) this;
    }

    /**
     * @see org.ojalgo.optimisation.Objective#setContributionWeight(java.math.BigDecimal)
     */
    public void setContributionWeight(final BigDecimal aContributionWeight) {
        myContributionWeight = aContributionWeight;
    }

    /**
     * @see org.ojalgo.optimisation.Constraint#setLowerLimit(java.math.BigDecimal)
     */
    public void setLowerLimit(final BigDecimal aLowerLimit) {
        myLowerLimit = aLowerLimit;
    }

    /**
     * @see org.ojalgo.optimisation.Constraint#setUpperLimit(java.math.BigDecimal)
     */
    public void setUpperLimit(final BigDecimal anUpperLimit) {
        myUpperLimit = anUpperLimit;
    }

    @Override
    public final String toString() {

        final StringBuilder retVal = new StringBuilder();

        this.appendToString(retVal);

        return retVal.toString();
    }

    @SuppressWarnings("unchecked")
    public final ME upper(final BigDecimal anUpperLimit) {
        this.setUpperLimit(anUpperLimit);
        return (ME) this;
    }

    public boolean validateConfiguration() throws ModelValidationException {

        if (myName == null) {
            throw new ModelValidationException("Model entities must have a name!");
        }

        if ((myLowerLimit != null) && (myUpperLimit != null)) {
            if ((myLowerLimit.compareTo(myUpperLimit) == 1) || (myUpperLimit.compareTo(myLowerLimit) == -1)) {
                throw new ModelValidationException(this.toString() + " The lower limit (if it exists) must be smaller than or equal to the upper limit (if it exists)!");
            }
        }

        if ((myContributionWeight != null) && (myContributionWeight.signum() == 0)) {
            throw new ModelValidationException(this.toString() + " The contribution weight (if it exists) should not be zero!");
        }

        return true;
    }

    @SuppressWarnings("unchecked")
    public final ME weight(final BigDecimal aContributionWeight) {
        this.setContributionWeight(aContributionWeight);
        return (ME) this;
    }

    protected void appendLeftPart(final StringBuilder aStringBuilder) {
        if (this.isLowerConstraint() || this.isEqualityConstraint()) {
            aStringBuilder.append(OptimisationUtils.DISPLAY.enforce(this.getLowerLimit()).toPlainString());
            aStringBuilder.append(" <= ");
        }
    }

    protected void appendMiddlePart(final StringBuilder aStringBuilder) {

        aStringBuilder.append(this.getName());

        if (this.isObjective()) {
            aStringBuilder.append(" (");
            aStringBuilder.append(OptimisationUtils.DISPLAY.enforce(this.getContributionWeight()).toPlainString());
            aStringBuilder.append(")");
        }
    }

    protected void appendRightPart(final StringBuilder aStringBuilder) {
        if (this.isUpperConstraint() || this.isEqualityConstraint()) {
            aStringBuilder.append(" <= ");
            aStringBuilder.append(OptimisationUtils.DISPLAY.enforce(this.getUpperLimit()).toPlainString());
        }
    }

    protected final boolean validate(final BigDecimal aValue, final NumberContext aContext) throws ModelValidationException {

        if (aValue != null) {

            BigDecimal tmpLimit = null;

            if (((tmpLimit = this.getLowerLimit()) != null) && (aContext.enforce(aValue.subtract(tmpLimit)).signum() == -1)) {
                throw new ModelValidationException(aValue + " ! " + this.toString());
            }

            if (((tmpLimit = this.getUpperLimit()) != null) && (aContext.enforce(aValue.subtract(tmpLimit)).signum() == 1)) {
                throw new ModelValidationException(aValue + " ! " + this.toString());
            }
        }

        return true;
    }

    final void appendToString(final StringBuilder aStringBuilder) {
        this.appendLeftPart(aStringBuilder);
        this.appendMiddlePart(aStringBuilder);
        this.appendRightPart(aStringBuilder);
    }

}
