/* 
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
package org.ojalgo.optimisation.quadratic;

import java.math.BigDecimal;

import org.ojalgo.RecoverableCondition;
import org.ojalgo.constant.BigMath;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.AboveBelowStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.RowsStore;
import org.ojalgo.optimisation.State;
import org.ojalgo.type.IndexSelector;
import org.ojalgo.type.TypeUtils;

/**
 * @author apete
 */
class ActiveSetSolver extends QuadraticSolver {

    private final IndexSelector myActivator;
    private final PhysicalStore<Double> myLI;

    ActiveSetSolver(final QuadraticSolver.Builder aBuilder) {

        super(aBuilder);

        final Matrices<?> tmpMatrices = this.getMatrices();
        if (tmpMatrices.hasInequalityConstraints()) {
            myActivator = new IndexSelector(tmpMatrices.countInequalityConstraints());
            myLI = FACTORY.makeZero(tmpMatrices.countInequalityConstraints(), 1);
        } else {
            myActivator = new IndexSelector(0);
            myLI = FACTORY.makeZero(0, 1);
        }

        int tmpIterationsLimit = Math.max(tmpMatrices.getAI().getRowDim(), tmpMatrices.getAI().getColDim());
        tmpIterationsLimit = (int) (9.0 + Math.sqrt(tmpIterationsLimit));
        tmpIterationsLimit = tmpIterationsLimit * tmpIterationsLimit;

        options.iterationsLimit = tmpIterationsLimit;
    }

    private QuadraticSolver buildIterationSolver() {

        MatrixStore<Double> tmpSubAE = null;
        MatrixStore<Double> tmpSubBE = null;
        final MatrixStore<Double> tmpSubQ = this.getMatrices().getQ();
        final MatrixStore<Double> tmpSubC = this.getMatrices().getC();

        final int[] tmpActivator = myActivator.getIncluded();

        if (tmpActivator.length == 0) {
            if (this.getMatrices().hasEqualityConstraints()) {
                tmpSubAE = this.getMatrices().getAE();
                tmpSubBE = this.getMatrices().getBE();
            } else {
                tmpSubAE = null;
                tmpSubBE = null;
            }
        } else {
            if (this.getMatrices().hasEqualityConstraints()) {
                tmpSubAE = new AboveBelowStore<Double>(this.getMatrices().getAE(), new RowsStore<Double>(this.getMatrices().getAI(), tmpActivator));
                tmpSubBE = new AboveBelowStore<Double>(this.getMatrices().getBE(), new RowsStore<Double>(this.getMatrices().getBI(), tmpActivator));
            } else {
                tmpSubAE = new RowsStore<Double>(this.getMatrices().getAI(), tmpActivator);
                tmpSubBE = new RowsStore<Double>(this.getMatrices().getBI(), tmpActivator);
            }
        }

        return new Builder(tmpSubQ, tmpSubC).equalities(tmpSubAE, tmpSubBE).build();
    }

    /**
     * Find the minimum (largest negative) lagrange multiplier - for the
     * active inequalities - to potentially deactivate.
     */
    private int suggestConstraintToExclude() {

        int retVal = -1;

        final int[] tmpIncluded = myActivator.getIncluded();

        BigDecimal tmpMin = BigMath.VERY_POSITIVE;
        BigDecimal tmpVal;

        final MatrixStore<Double> tmpLI = this.getMatrices().getLI(tmpIncluded);

        //            BasicLogger.logDebug("LI(incl): {} - to potentially deactivate", FACTORY.copy(tmpLI));
        //            BasicLogger.logDebug("LI(excl): {}", FACTORY.copy(this.getMatrices().getLI(myActivator.getExcluded())));

        for (int i = 0; i < tmpLI.getRowDim(); i++) {

            tmpVal = options.solutionContext.toBigDecimal(tmpLI.doubleValue(i, 0));

            if ((tmpVal.signum() < 0) && (tmpVal.compareTo(tmpMin) < 0)) {
                tmpMin = tmpVal;
                retVal = i;
            }
        }

        return retVal >= 0 ? tmpIncluded[retVal] : retVal;
    }

    /**
     * Find minimum (largest negative) slack - for the inactive
     * inequalities - to potentially activate. Negative slack means the
     * constraint is violated. Need to make sure it is enforced by
     * activating it.
     */
    private int suggestConstraintToInclude() {

        int retVal = -1;

        final int[] tmpExcluded = myActivator.getExcluded();

        BigDecimal tmpMin = BigMath.VERY_POSITIVE;
        BigDecimal tmpVal;

        final MatrixStore<Double> tmpSI = this.getMatrices().getSI(tmpExcluded);

        //            BasicLogger.logDebug("SI(excl): {} - to potentially activate.", FACTORY.copy(tmpSI));
        //            BasicLogger.logDebug("SI(incl): {}", FACTORY.copy(this.getMatrices().getSI(myActivator.getIncluded())));

        for (int i = 0; i < tmpSI.getRowDim(); i++) {

            tmpVal = options.solutionContext.toBigDecimal(tmpSI.doubleValue(i, 0));

            if ((tmpVal.signum() < 0) && (tmpVal.compareTo(tmpMin) < 0)) {
                tmpMin = tmpVal;
                retVal = i;
            }
        }

        return retVal >= 0 ? tmpExcluded[retVal] : retVal;
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void initialise() {

        //        if ((this.getMatrices().getX() == null) && (this.getMatrices().getAI() != null) && (this.getMatrices().getAE() != null)) {
        //
        //            final int tmpVars = this.getMatrices().countVariables();
        //            final int tmpCountInequalityConstraints = this.getMatrices().countInequalityConstraints();
        //
        //            final LinearSolver.Builder tmpInitBuilder = new LinearSolver.Builder(new MergedColumnsStore<Double>(this.getMatrices().getC(), ZeroStore.makePrimitive(tmpCountInequalityConstraints, 1)));
        //
        //            final MatrixStore.Builder<Double> tmpAE = MatrixStore.Builder.makePrimitiveIdentity(tmpCountInequalityConstraints);
        //            tmpAE.left(this.getMatrices().getAI()).above(this.getMatrices().getAE());
        //
        //            final MatrixStore<Double> tmpBE = new MergedColumnsStore<Double>(this.getMatrices().getBE(), this.getMatrices().getBI());
        //
        //            tmpInitBuilder.equalities(tmpAE.build(), tmpBE);
        //
        //            final LinearSolver tmpInitSolver = tmpInitBuilder.build();
        //            final Result tmpInitResult = tmpInitSolver.solve();
        //            if (tmpInitResult.getState().isNotLessThan(State.FEASIBLE)) {
        //                this.getMatrices().setX(tmpInitResult.getSolution().getRows(MatrixUtils.makeRange(tmpVars)).toPrimitiveStore());
        //            } else {
        //                if (true) {
        //                    BasicLogger.logDebug("LP solver failed!");
        //                }
        //            }
        //        }

        if (this.getMatrices().hasInequalityConstraints()) {

            if (this.getMatrices().getX() != null) {

                final PhysicalStore<Double> tmpSlackMtrx = this.getMatrices().getSI();

                double tmpSlack;
                for (int i = 0; i < tmpSlackMtrx.getRowDim(); i++) {

                    tmpSlack = tmpSlackMtrx.doubleValue(i, 0);

                    if (TypeUtils.isZero(tmpSlack)) {
                        myActivator.include(i);
                    }
                }
            }
        }
    }

    @Override
    protected boolean needsAnotherIteration() {

        //            BasicLogger.logDebug();
        //            BasicLogger.logDebug("NeedsAnotherIteration?");
        //            BasicLogger.logDebug(myActivator.toString());

        int tmpToInclude = -1;
        int tmpToExclude = -1;

        if (this.getMatrices().hasInequalityConstraints()) {
            tmpToInclude = this.suggestConstraintToInclude();
            tmpToExclude = this.suggestConstraintToExclude();
        }

        //            BasicLogger.logDebug("Suggested to include: {}", tmpToInclude);
        //            BasicLogger.logDebug("Suggested to exclude: {}", tmpToExclude);

        if (tmpToExclude == -1) {
            if (tmpToInclude == -1) {

                // Suggested to do nothing

                this.setState(State.OPTIMAL);
                return false;

            } else {

                // Only suggested to include

                if (tmpToInclude != myActivator.getLastExcluded()) {
                    myActivator.include(tmpToInclude);
                } else {
                    myActivator.grow();
                }

                this.setState(State.ITERATION);
                return true;

            }
        } else {
            if (tmpToInclude == -1) {

                // Only suggested to exclude

                if (tmpToExclude != myActivator.getLastIncluded()) {
                    myActivator.exclude(tmpToExclude);
                } else {
                    myActivator.shrink();
                }

                this.setState(State.ITERATION);
                return true;

            } else {

                // Suggested both to exclude and include

                if ((tmpToInclude != myActivator.getLastExcluded()) && (tmpToExclude != myActivator.getLastIncluded())) {

                    myActivator.exclude(tmpToExclude);
                    myActivator.include(tmpToInclude);

                    myActivator.shrink();
                    myActivator.grow();

                } else {

                    myActivator.exclude(tmpToExclude);
                    myActivator.include(tmpToInclude);
                }

                this.setState(State.ITERATION);
                return true;
            }
        }
    }

    @Override
    protected void performIteration() throws RecoverableCondition {

        final QuadraticSolver tmpSolver = this.buildIterationSolver();
        final Result tmpResult = tmpSolver.solve();

        final int[] tmpActivator = myActivator.getIncluded();

        final Matrices<?> tmpMatrices = this.getMatrices();
        if (tmpResult.getState().isNotLessThan(State.FEASIBLE)) {

            tmpMatrices.setX(tmpSolver.getMatrices().getX());

            final int tmpAERowDim = tmpMatrices.countEqualityConstraints();

            final int[] tmpSelectorLE = MatrixUtils.makeIncreasingRange(0, tmpAERowDim);
            tmpMatrices.setLE(new RowsStore<Double>(tmpSolver.getMatrices().getLE(), tmpSelectorLE));

            for (int i = 0; i < tmpActivator.length; i++) {
                myLI.set(tmpActivator[i], 0, tmpSolver.getMatrices().getLE().doubleValue(tmpAERowDim + i, 0));
            }
            tmpMatrices.setLI(myLI);

            this.setState(State.ITERATION);

        } else if (tmpActivator.length >= 1) {

            myActivator.shrink();

            this.performIteration();

        } else {

            tmpMatrices.setX(null);
            tmpMatrices.setLE(null);
            tmpMatrices.setLI(null);

            this.setState(State.INFEASIBLE);

            throw new RecoverableCondition("Not able to solve this problem!");
        }

    }

}
