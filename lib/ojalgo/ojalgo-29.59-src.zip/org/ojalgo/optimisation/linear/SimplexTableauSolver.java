/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation.linear;

import static org.ojalgo.constant.PrimitiveMath.*;
import static org.ojalgo.function.implementation.PrimitiveFunction.*;

import java.util.Arrays;

import org.ojalgo.function.PreconfiguredSecond;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.PrimitiveMatrix;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.ZeroStore;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.optimisation.OptimisationModel;
import org.ojalgo.optimisation.State;
import org.ojalgo.type.context.NumberContext;

/**
 * SimplexTableauSolver
 *
 * @author apete
 */
final class SimplexTableauSolver extends LinearSolver {

    static final class PivotPoint {

        int row = -1;
        int col = -1;

        PivotPoint() {

            super();

            this.reset();
        }

        void reset() {
            row = -1;
            col = -1;
        }

    }

    private static final boolean DEBUG = false;

    private int myObjectiveRow; // myCountConstraints+1 in Phase1 and myCountConstraints in Phase2
    private int myPivotCol;
    private int myPivotRow;
    private final int[] myBasis;
    private final PhysicalStore<Double> myTransposedTableau;

    SimplexTableauSolver(final Builder aBuilder) {
        this(aBuilder, new int[0]);
    }

    @SuppressWarnings("unchecked")
    SimplexTableauSolver(final LinearSolver.Builder aBuilder, final int[] suggestedPartialBasis) {

        super(aBuilder);

        final int tmpConstraintsCount = this.countConstraints();

        final MatrixStore.Builder<Double> tmpTableauBuilder = ZeroStore.makePrimitive(1, 1).builder();
        tmpTableauBuilder.left(aBuilder.getC().transpose());

        if (tmpConstraintsCount >= 1) {
            tmpTableauBuilder.above(aBuilder.getAE(), aBuilder.getBE());
        }
        tmpTableauBuilder.below(1);
        myTransposedTableau = tmpTableauBuilder.build().transpose();

        myObjectiveRow = tmpConstraintsCount + 1; // Phase1 objective function row

        for (int i = 0; i < tmpConstraintsCount; i++) {
            myTransposedTableau.caxpy(NEG, i, myObjectiveRow, 0);
        }

        myBasis = MatrixUtils.makeIncreasingRange(-tmpConstraintsCount, tmpConstraintsCount);

        options.iterationsLimit = myTransposedTableau.size();

        if (DEBUG && this.isTableauPrintable()) {
            this.printTableau("Tableau Created");
        }
    }

    @SuppressWarnings("unused")
    public Result solve() {

        while (this.needsAnotherIteration()) {

            this.performIteration(myPivotRow, myPivotCol);

            if (DEBUG && this.isTableauPrintable()) {
                this.printTableau("Tableau Iteration");
            }
        }

        return new Result(this.getState(), this.extractSolution(), this.getIterationsCount());
    }

    public Result solve(final OptimisationModel aValidationModel) {

        this.setValidationModel(aValidationModel);

        return this.solve();
    }

    private int countBasicArtificials() {
        int retVal = 0;
        final int tmpLength = myBasis.length;
        for (int i = 0; i < tmpLength; i++) {
            if (myBasis[i] < 0) {
                retVal++;
            }
        }
        return retVal;
    }

    private PhysicalStore<Double> extractSolution() {

        final int tmpVariablesCount = this.countVariables();

        final PhysicalStore<Double> retVal = PrimitiveDenseStore.FACTORY.makeZero(tmpVariablesCount, 1);

        int tmpIndex;
        final int tmpLength = myBasis.length;
        for (int i = 0; i < tmpLength; i++) {
            tmpIndex = myBasis[i];
            if (tmpIndex >= 0) {
                retVal.set(tmpIndex, 0, myTransposedTableau.doubleValue(tmpVariablesCount, i));
            }
        }

        return retVal;
    }

    private int findColumnInRow(final int aRow) {

        int retVal = -1;

        double tmpVal;
        double tmpMinVal = -options.problemContext.getError();

        int tmpCol;
        final int[] tmpExcluded = this.getExcluded();

        for (int e = 0; e < tmpExcluded.length; e++) {
            tmpCol = tmpExcluded[e];
            tmpVal = myTransposedTableau.doubleValue(tmpCol, aRow);
            if (tmpVal < tmpMinVal) {
                retVal = tmpCol;
                tmpMinVal = tmpVal;
                if (DEBUG) {
                    BasicLogger.logDebug("Col: {}\t=>\tReduced Contribution Weight: {}.", tmpCol, tmpVal);
                }
            }
        }

        return retVal;
    }

    private int findNextPivotRow() {

        int retVal = -1;
        double tmpNumer, tmpDenom, tmpRatio;
        double tmpMinRatio = MAX_VALUE;

        final NumberContext tmpProblemContext = options.problemContext;

        final int tmpDenomCol = myPivotCol;
        final int tmpNumerCol = this.countVariables();

        final int tmpLimit = this.countConstraints();
        for (int i = 0; i < tmpLimit; i++) {

            tmpDenom = myTransposedTableau.doubleValue(tmpDenomCol, i);

            if (!tmpProblemContext.isZero(tmpDenom)) {

                tmpNumer = myTransposedTableau.doubleValue(tmpNumerCol, i);
                tmpRatio = tmpNumer / tmpDenom;

                if ((tmpRatio >= ZERO) && (tmpRatio < tmpMinRatio) && !(tmpProblemContext.isZero(tmpRatio) && (tmpDenom < ZERO))) {
                    retVal = i;
                    tmpMinRatio = tmpRatio;

                    if (DEBUG && this.isTableauPrintable()) {
                        BasicLogger.logDebug("Row: {}\t=>\tRatio: {},\tNumerator/RHS: {}, \tDenominator/Pivot: {}.", i, tmpRatio, tmpNumer, tmpDenom);
                    }
                }
            }
        }

        return retVal;
    }

    private int[] getRowsWithArticialBasics() {
        final int[] retVal = new int[this.countBasicArtificials()];
        int tmpInd = 0;
        for (int i = 0; i < myBasis.length; i++) {
            if (myBasis[i] < 0) {
                retVal[tmpInd] = i;
                tmpInd++;
            }
        }
        return retVal;
    }

    private final boolean isTableauPrintable() {
        return myTransposedTableau.size() <= HUNDRED;
    }

    private final void printTableau(final String aMessage) {
        BasicLogger.DEBUG.print(aMessage);
        BasicLogger.DEBUG.print("; Basics: " + Arrays.toString(myBasis));
        MatrixUtils.printToStream(BasicLogger.DEBUG, myTransposedTableau.transpose(), options.printContext);
    }

    @Override
    protected boolean needsAnotherIteration() {

        if (DEBUG) {
            BasicLogger.logDebug();
            BasicLogger.logDebug("Needs Another Iteration?");
        }

        myPivotCol = this.findNextPivotCol();
        myPivotRow = -1;

        boolean retVal = myPivotCol != -1;

        if (!retVal && (myObjectiveRow > this.countConstraints())) {

            if (DEBUG) {
                BasicLogger.logDebug("Switching to Phase2.");
            }

            int tmpCol = -1;
            final int[] tmpRows = this.getRowsWithArticialBasics();
            for (int i = 0; (tmpCol == -1) && (i < tmpRows.length); i++) {
                if (options.problemContext.isZero(myTransposedTableau.doubleValue(this.countVariables(), tmpRows[i]))) {
                    tmpCol = this.findColumnInRow(this.countConstraints());
                    if (tmpCol != -1) {
                        myPivotCol = tmpCol;
                        myPivotRow = tmpRows[i];
                        if (myPivotRow != -1) {
                            this.performIteration(myPivotRow, myPivotCol);
                        }
                    }
                }
            }

            if (DEBUG && this.isTableauPrintable()) {
                this.printTableau("Cleaned Phase1 Tableau");
            }

            final double tmpPhaseOneValue = myTransposedTableau.doubleValue(this.countVariables(), myObjectiveRow);

            if (options.solutionContext.isZero(tmpPhaseOneValue)) {

                if (DEBUG) {
                    BasicLogger.logDebug("Left Phase1 with {} artificial variable(s) in the basis.", this.countBasicArtificials());
                }

                myObjectiveRow = this.countConstraints();

                retVal = (myPivotCol = this.findNextPivotCol()) != -1;

            } else {

                myPivotCol = -1;
                myPivotRow = -1;

                this.setState(State.INFEASIBLE);

                retVal = false;
            }
        }

        if (retVal) {

            retVal = (myPivotRow = this.findNextPivotRow()) != -1;

            if (!retVal) {
                this.setState(State.UNBOUNDED);
            }

        } else if (myObjectiveRow == this.countConstraints()) {

            this.setState(State.OPTIMAL);
        }

        if (DEBUG) {
            if (retVal) {
                BasicLogger.logDebug("Row: {},\tExit: {},\tColumn/Enter: {}.", myPivotRow, myBasis[myPivotRow], myPivotCol);
            } else {
                BasicLogger.logDebug("No more iterations needed/possible.");
            }
        }

        return retVal;
    }

    int findNextPivotCol() {

        int retVal = -1;

        if (myObjectiveRow > this.countConstraints()) { // Phase1

            retVal = this.findColumnInRow(myObjectiveRow);

        } else { // Phase2

            // If there are still artificial variables in the basis
            final int[] tmpArtificialRows = this.getRowsWithArticialBasics();
            if (tmpArtificialRows.length > 0) {
                if (DEBUG) {
                    BasicLogger.logDebug("Still {} artificial variable(s) in the basis.", tmpArtificialRows.length);
                }
                for (int i = 0; (retVal == -1) && (i < tmpArtificialRows.length); i++) {
                    retVal = this.findColumnInRow(tmpArtificialRows[i]);
                }
            }

            // The normal objective row
            if (retVal == -1) {
                retVal = this.findColumnInRow(myObjectiveRow);
            }
        }

        return retVal;
    }

    void performIteration(final int aPivotRow, final int aPivotCol) {

        double tmpPivotElement = myTransposedTableau.doubleValue(aPivotCol, aPivotRow);

        if (Math.abs(tmpPivotElement) < ONE) {
            myTransposedTableau.modifyColumn(0, aPivotRow, new PreconfiguredSecond<Double>(DIVIDE, tmpPivotElement));
        } else if (tmpPivotElement != ONE) {
            myTransposedTableau.modifyColumn(0, aPivotRow, new PreconfiguredSecond<Double>(MULTIPLY, ONE / tmpPivotElement));
        }

        if (DEBUG) {
            BasicLogger.logDebug("Pivot Element Before: {} and After: {}.", tmpPivotElement, myTransposedTableau.doubleValue(aPivotCol, aPivotRow));
        }

        for (int i = 0; i <= myObjectiveRow; i++) {
            if (i != aPivotRow) {

                tmpPivotElement = myTransposedTableau.doubleValue(aPivotCol, i);

                if (!options.problemContext.isZero(tmpPivotElement)) {
                    myTransposedTableau.caxpy(-tmpPivotElement, aPivotRow, i, 0);
                }
            }
        }

        final int tmpOld = myBasis[aPivotRow];
        if (tmpOld >= 0) {
            this.exclude(tmpOld);
        }
        final int tmpNew = aPivotCol;
        if (tmpNew >= 0) {
            this.include(tmpNew);
        }
        myBasis[aPivotRow] = aPivotCol;

        if (DEBUG) {

            final OptimisationModel tmpModel = this.getValidationModel();

            if ((tmpModel != null) && (myObjectiveRow == this.countConstraints())) { // Only if in Phase2
                if (!tmpModel.validateSolution(new PrimitiveMatrix(this.extractSolution()), options.solutionContext)) {
                    this.setState(State.FAILED);
                }
            }
        }
    }
}
