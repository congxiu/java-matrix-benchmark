/*
 * Copyright 2003-2011 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation;

import static org.ojalgo.constant.PrimitiveMath.*;

import java.util.concurrent.atomic.AtomicInteger;

import org.ojalgo.ProgrammingError;
import org.ojalgo.RecoverableCondition;
import org.ojalgo.function.PreconfiguredSecond;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.function.aggregator.PrimitiveAggregator;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.PrimitiveMatrix;
import org.ojalgo.matrix.decomposition.LU;
import org.ojalgo.matrix.decomposition.LUDecomposition;
import org.ojalgo.matrix.store.ColumnsStore;
import org.ojalgo.matrix.store.LeftRightStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.RowsStore;
import org.ojalgo.type.context.NumberContext;

public abstract class GenericSolver implements OptimisationSolver {

    @SuppressWarnings("unchecked")
    public static abstract class Matrices<M extends Matrices<M>> {

        private static final int LENGTH = 9;

        /**
         * {[AE], [BE], [Q], [C], [AI], [BI], [X], [LE], [LI]}
         */
        private final MatrixStore<Double>[] myMatrices = new MatrixStore[LENGTH];

        protected Matrices() {
            super();
        }

        protected Matrices(final Matrices<?> aMatrices) {
            this(aMatrices.getArray());
        }

        protected Matrices(final MatrixStore<Double>[] aMtrxArr) {

            super();

            final int tmpMinLength = Math.min(LENGTH, aMtrxArr.length);

            for (int i = 0; i < tmpMinLength; i++) {
                myMatrices[i] = aMtrxArr[i];
            }

            this.configure();
        }

        /**
         * Will rescale problem parameters to minimise rounding and
         * representation errors.
         */
        public final M balance() {

            if (this.hasEqualityConstraints()) {
                this.balanceEqualityConstraints();
            }

            if (this.hasInequalityConstraints()) {
                this.balanceInequalityConstraints();
            }

            if (this.hasObjective()) {
                this.balanceObjective();
            }

            return (M) this;
        }

        public final int countEqualityConstraints() {
            return (this.getAE() != null) ? this.getAE().getRowDim() : 0;
        }

        public final int countInequalityConstraints() {
            return (this.getAI() != null) ? this.getAI().getRowDim() : 0;
        }

        public final int countVariables() {

            int retVal = -1;

            if (this.getAE() != null) {
                retVal = this.getAE().getColDim();
            } else if (this.getAI() != null) {
                retVal = this.getAI().getColDim();
            } else if (this.getQ() != null) {
                retVal = this.getQ().getRowDim();
            } else if (this.getC() != null) {
                retVal = this.getC().getRowDim();
            } else {
                throw new ProgrammingError("Cannot deduce the number of variables!");
            }

            return retVal;
        }

        /**
         * Will remove redundant equality constraints.
         * @deprecated Doesn't work!
         */
        @Deprecated
        public final M eliminate() {

            final int tmpColDim = this.getAE().getColDim();

            MatrixStore<Double> tmpVal = new LeftRightStore<Double>(this.getAE(), this.getBE());

            final LU<Double> tmpLU = LUDecomposition.makePrimitive();
            tmpLU.compute(tmpVal);

            tmpVal = tmpLU.getU();

            final MatrixStore<Double> tmpAE = new ColumnsStore<Double>(tmpVal, MatrixUtils.makeIncreasingRange(0, tmpColDim));
            final MatrixStore<Double> tmpBE = new ColumnsStore<Double>(tmpVal, MatrixUtils.makeRange(tmpColDim));

            this.setAE(tmpAE);
            this.setBE(tmpBE);

            this.configure();

            return (M) this;
        }

        public final M equalities(final MatrixStore<Double> AE, final MatrixStore<Double> BE) {

            this.setAE(AE);
            this.setBE(BE);

            this.configure();

            return (M) this;
        }

        /**
         * [AE][X] == [BE]
         */
        public final MatrixStore<Double> getAE() {
            return myMatrices[0];
        }

        /**
         * [AE][X] == [BE]
         */
        public final MatrixStore<Double> getAE(final int... aColSelector) {
            return new ColumnsStore<Double>(this.getAE(), aColSelector);
        }

        /**
         * [AI][X] <= [BI]
         */
        public final MatrixStore<Double> getAI() {
            return myMatrices[4];
        }

        /**
         * [AI][X] <= [BI]
         */
        public final MatrixStore<Double> getAI(final int... aColSelector) {
            return new ColumnsStore<Double>(this.getAI(), aColSelector);
        }

        /**
         * [AE][X] == [BE]
         */
        public final MatrixStore<Double> getBE() {
            return myMatrices[1];
        }

        /**
         * [AI][X] <= [BI]
         */
        public final MatrixStore<Double> getBI() {
            return myMatrices[5];
        }

        /**
         * Linear objective: [C]
         */
        public final MatrixStore<Double> getC() {
            return myMatrices[3];
        }

        /**
         * Linear objective: [C]
         */
        public final MatrixStore<Double> getC(final int... aRowSelector) {
            return new RowsStore<Double>(myMatrices[3], aRowSelector);
        }

        /**
         * Lagrange multipliers / dual variables for Equalities
         */
        public final MatrixStore<Double> getLE() {
            return myMatrices[7];
        }

        /**
         * Lagrange multipliers / dual variables for Inequalities
         */
        public final MatrixStore<Double> getLI() {
            return myMatrices[8];
        }

        /**
         * Lagrange multipliers / dual variables for selected inequalities
         */
        public final MatrixStore<Double> getLI(final int[] aRowSelector) {
            return new RowsStore<Double>(this.getLI(), aRowSelector);
        }

        /**
         * Quadratic objective: [Q]
         */
        public final MatrixStore<Double> getQ() {
            return myMatrices[2];
        }

        /**
         * Slack for Equalities: [SE] = [BE] - [AE][X]
         */
        public final PhysicalStore<Double> getSE() {

            PhysicalStore<Double> retVal = null;

            if ((this.getAE() != null) && (this.getBE() != null) && (this.getX() != null)) {

                retVal = this.getBE().copy();

                retVal.fillMatching(retVal, PrimitiveFunction.SUBTRACT, this.getAE().multiplyRight(this.getX()));
            }

            return retVal;
        }

        /**
         * Slack for Inequalities: [SI] = [BI] - [AI][X]
         */
        public final PhysicalStore<Double> getSI() {

            PhysicalStore<Double> retVal = null;

            if ((this.getAI() != null) && (this.getBI() != null) && (this.getX() != null)) {

                retVal = this.getBI().copy();

                retVal.fillMatching(retVal, PrimitiveFunction.SUBTRACT, this.getAI().multiplyRight(this.getX()));
            }

            return retVal;
        }

        /**
         * Selected Slack for Inequalities
         */
        public final MatrixStore<Double> getSI(final int... aRowSelector) {
            return new RowsStore<Double>(this.getSI(), aRowSelector);
        }

        /**
         * Solution / Variables: [X]
         */
        public final MatrixStore<Double> getX() {
            return myMatrices[6];
        }

        public final boolean hasEqualityConstraints() {
            return (this.getAE() != null) && (this.getAE().getRowDim() > 0);
        }

        public final boolean hasInequalityConstraints() {
            return (this.getAI() != null) && (this.getAI().getRowDim() > 0);
        }

        public final boolean hasObjective() {
            return (this.getQ() != null) || (this.getC() != null);
        }

        public final M inequalities(final MatrixStore<Double> AI, final MatrixStore<Double> BI) {

            this.setAI(AI);
            this.setBI(BI);

            this.configure();

            return (M) this;
        }

        public final M objective(final MatrixStore<Double> C) {

            this.setC(C);

            this.configure();

            return (M) this;
        }

        public final M objective(final MatrixStore<Double> Q, final MatrixStore<Double> C) {

            this.setQ(Q);
            this.setC(C);

            this.configure();

            return (M) this;
        }

        /**
         * Will round to the specified scale (number of decimals) on all
         * matrices.
         */
        public final M round(final int aScale) {

            PhysicalStore<Double> tmpMtrx;
            for (int i = 0; i < this.myMatrices.length; i++) {
                if (this.myMatrices[i] != null) {
                    tmpMtrx = this.myMatrices[i].copy();
                    tmpMtrx.modifyAll(NumberContext.getGeneral(aScale).getPrimitiveRoundFunction());
                    this.myMatrices[i] = tmpMtrx;
                }
            }

            return (M) this;
        }

        public final void setLE(final MatrixStore<Double> aMtrx) {
            myMatrices[7] = aMtrx;
        }

        public final void setLI(final MatrixStore<Double> aMtrx) {
            myMatrices[8] = aMtrx;
        }

        public final void setX(final MatrixStore<Double> aMtrx) {
            myMatrices[6] = aMtrx;
        }

        @Override
        public final String toString() {

            final StringBuilder retVal = new StringBuilder("<" + this.getClass().getSimpleName() + ">");

            retVal.append("\n[AE] = " + (this.getAE() != null ? new PrimitiveMatrix(this.getAE()) : "?"));

            retVal.append("\n[BE] = " + (this.getBE() != null ? new PrimitiveMatrix(this.getBE()) : "?"));

            retVal.append("\n[Q] = " + (this.getQ() != null ? new PrimitiveMatrix(this.getQ()) : "?"));

            retVal.append("\n[C] = " + (this.getC() != null ? new PrimitiveMatrix(this.getC()) : "?"));

            retVal.append("\n[AI] = " + (this.getAI() != null ? new PrimitiveMatrix(this.getAI()) : "?"));

            retVal.append("\n[BI] = " + (this.getBI() != null ? new PrimitiveMatrix(this.getBI()) : "?"));

            retVal.append("\n[X] = " + (this.getX() != null ? new PrimitiveMatrix(this.getX()) : "?"));

            retVal.append("\n[LE] = " + (this.getLE() != null ? new PrimitiveMatrix(this.getLE()) : "?"));

            retVal.append("\n[LI] = " + (this.getLI() != null ? new PrimitiveMatrix(this.getLI()) : "?"));

            retVal.append("\n[SE] = " + (this.getSE() != null ? new PrimitiveMatrix(this.getSE()) : "?"));

            retVal.append("\n[SI] = " + (this.getSI() != null ? new PrimitiveMatrix(this.getSI()) : "?"));

            retVal.append("\n</" + this.getClass().getSimpleName() + ">");

            return retVal.toString();
        }

        private final void balanceEqualityConstraints() {

            final PhysicalStore<Double> tmpBody = this.getAE().copy();
            final PhysicalStore<Double> tmpRHS = this.getBE().copy();

            this.balanceRows(tmpBody, tmpRHS, true);

            this.setAE(tmpBody);
            this.setBE(tmpRHS);

            this.configure();
        }

        private final void balanceInequalityConstraints() {

            final PhysicalStore<Double> tmpBody = this.getAI().copy();
            final PhysicalStore<Double> tmpRHS = this.getBI().copy();

            this.balanceRows(tmpBody, tmpRHS, false);

            this.setAI(tmpBody);
            this.setBI(tmpRHS);

            this.configure();
        }

        private final double balanceMatrices(final PhysicalStore<Double>[] someMatrices) {

            final AggregatorFunction<Double> tmpLargestAggr = PrimitiveAggregator.getCollection().largest();
            final AggregatorFunction<Double> tmpSmallestAggr = PrimitiveAggregator.getCollection().smallest();

            for (final PhysicalStore<Double> tmpMatrix : someMatrices) {
                if (tmpMatrix != null) {
                    tmpMatrix.visitAll(tmpLargestAggr);
                    tmpMatrix.visitAll(tmpSmallestAggr);
                }
            }

            final double tmpExponent = OptimisationUtils.getAdjustmentFactorExponent(tmpLargestAggr, tmpSmallestAggr);
            final double tmpFactor = Math.pow(TEN, tmpExponent);

            final UnaryFunction<Double> tmpModifier = new PreconfiguredSecond<Double>(PrimitiveFunction.MULTIPLY, tmpFactor);

            for (final PhysicalStore<Double> tmpMatrix : someMatrices) {
                if (tmpMatrix != null) {
                    tmpMatrix.modifyAll(tmpModifier);
                }
            }

            return tmpFactor;
        }

        private final void balanceObjective() {

            final PhysicalStore<Double>[] tmpMatrices = new PhysicalStore[2];

            if (this.getQ() != null) {
                tmpMatrices[0] = this.getQ().copy();
            }
            if (this.getC() != null) {
                tmpMatrices[1] = this.getC().copy();
            }

            this.balanceMatrices(tmpMatrices);

            this.objective(tmpMatrices[0], tmpMatrices[1]);
        }

        private final void balanceRows(final PhysicalStore<Double> tmpBody, final PhysicalStore<Double> tmpRHS, final boolean assertPositiveRHS) {

            final AggregatorFunction<Double> tmpLargestAggr = PrimitiveAggregator.getCollection().largest();
            final AggregatorFunction<Double> tmpSmallestAggr = PrimitiveAggregator.getCollection().smallest();

            double tmpExponent;
            double tmpFactor;

            UnaryFunction<Double> tmpModifier;

            for (int i = 0; i < tmpBody.getRowDim(); i++) {

                tmpLargestAggr.reset();
                tmpSmallestAggr.reset();

                tmpBody.visitRow(i, 0, tmpLargestAggr);
                tmpBody.visitRow(i, 0, tmpSmallestAggr);

                tmpRHS.visitRow(i, 0, tmpLargestAggr);
                tmpRHS.visitRow(i, 0, tmpSmallestAggr);

                tmpExponent = OptimisationUtils.getAdjustmentFactorExponent(tmpLargestAggr, tmpSmallestAggr);
                tmpFactor = Math.pow(TEN, tmpExponent);
                if (assertPositiveRHS && (Math.signum(tmpRHS.doubleValue(i, 0)) < ZERO)) {
                    tmpFactor = -tmpFactor;
                }

                tmpModifier = new PreconfiguredSecond<Double>(PrimitiveFunction.MULTIPLY, tmpFactor);

                tmpBody.modifyRow(i, 0, tmpModifier);
                tmpRHS.modifyRow(i, 0, tmpModifier);
            }
        }

        private final void configure() {

            if (this.hasEqualityConstraints()) {

                if (this.getAE() == null) {
                    throw new ProgrammingError("AE cannot be null!");
                } else if (this.getAE().getColDim() != this.countVariables()) {
                    throw new ProgrammingError("AE has the wrong number of columns!");
                } else if (this.getBE() == null) {
                    this.setBE(PrimitiveDenseStore.FACTORY.makeZero(this.getAE().getRowDim(), 1));
                } else if (this.getAE().getRowDim() != this.getBE().getRowDim()) {
                    throw new ProgrammingError("AE and BE do not have the same number of rows!");
                } else if (this.getBE().getColDim() != 1) {
                    throw new ProgrammingError("BE must have precisely one column!");
                }

            } else {

                this.setAE(null);
                this.setBE(null);
            }

            if (this.hasObjective()) {

                if ((this.getQ() != null) && ((this.getQ().getRowDim() != this.countVariables()) || (this.getQ().getColDim() != this.countVariables()))) {
                    throw new ProgrammingError("Q has the wrong number of rows and/or columns!");
                }

                if (this.getC() == null) {
                    this.setC(PrimitiveDenseStore.FACTORY.makeZero(this.countVariables(), 1));
                } else if ((this.getC().getRowDim() != this.countVariables()) || (this.getC().getColDim() != 1)) {
                    throw new ProgrammingError("C has the wrong number of rows and/or columns!");
                }

            } else {

                this.setQ(null);
                this.setC(null);
            }

            if (this.hasInequalityConstraints()) {

                if (this.getAI() == null) {
                    throw new ProgrammingError("AI cannot be null!");
                } else if (this.getAI().getColDim() != this.countVariables()) {
                    throw new ProgrammingError("AI has the wrong number of columns!");
                } else if (this.getBI() == null) {
                    this.setBI(PrimitiveDenseStore.FACTORY.makeZero(this.getAI().getRowDim(), 1));
                } else if (this.getAI().getRowDim() != this.getBI().getRowDim()) {
                    throw new ProgrammingError("AI and BI do not have the same number of rows!");
                } else if (this.getBI().getColDim() != 1) {
                    throw new ProgrammingError("BI must have precisely one column!");
                }

            } else {

                this.setAI(null);
                this.setBI(null);
            }
        }

        private final void setAE(final MatrixStore<Double> aMtrx) {
            myMatrices[0] = aMtrx;
        }

        private final void setAI(final MatrixStore<Double> aMtrx) {
            myMatrices[4] = aMtrx;
        }

        private final void setBE(final MatrixStore<Double> aMtrx) {
            myMatrices[1] = aMtrx;
        }

        private final void setBI(final MatrixStore<Double> aMtrx) {
            myMatrices[5] = aMtrx;
        }

        private final void setC(final MatrixStore<Double> aMtrx) {
            myMatrices[3] = aMtrx;
        }

        private final void setQ(final MatrixStore<Double> aMtrx) {
            myMatrices[2] = aMtrx;
        }

        protected final MatrixStore<Double>[] getArray() {
            return myMatrices;
        }

    }

    public final OptimisationSolver.Options options = new OptimisationSolver.Options();
    private final AtomicInteger myIterationsCount = new AtomicInteger(0);
    private long myResetTime;
    private State myState = State.NEW;
    private OptimisationModel myValidationModel = null;

    protected GenericSolver() {
        super();
    }

    protected final int getIterationsCount() {
        return myIterationsCount.get();
    }

    protected final State getState() {
        return myState;
    }

    protected final OptimisationModel getValidationModel() {
        return myValidationModel;
    }

    /**
     * Should be called after a completed iteration. The iterations count
     * is not "1" untill the first iteration is completed.
     */
    protected final int incrementIterationsCount() throws RecoverableCondition {

        final int retVal = myIterationsCount.incrementAndGet();

        if (retVal > options.iterationsLimit) {
            throw new RecoverableCondition("Too many iterations!");
        }

        return retVal;
    }

    /**
     * Should be called at the start of an iteration (before it starts)
     * to check if you should abort instead. Will return false if either
     * the iterations count or the execution time has reached their
     * respective limits.
     */
    protected final boolean isOkToContinue() {
        return (myIterationsCount.get() < options.iterationsLimit) && (System.currentTimeMillis() - myResetTime < options.timeLimit);
    }

    protected final boolean isValidationModelSet() {
        return myValidationModel != null;
    }

    abstract protected boolean needsAnotherIteration();

    protected final void resetIterationsCount() {
        myIterationsCount.set(0);
        myResetTime = System.currentTimeMillis();
    }

    protected final void setState(final State aState) {
        myState = aState;
    }

    protected final void setValidationModel(final OptimisationModel aValidationModel) {
        myValidationModel = aValidationModel;
    }

    protected final boolean validateSolution(final MatrixStore<Double> aSolution, final NumberContext aContext) {
        return myValidationModel.validateSolution(new PrimitiveMatrix(aSolution), aContext);
    }

}
