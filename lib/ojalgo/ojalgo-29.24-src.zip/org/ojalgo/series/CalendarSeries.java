/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.series;

import java.awt.Color;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.SortedMap;

import org.ojalgo.type.CalendarDateUnit;
import org.ojalgo.type.TimeFilter;

public class CalendarSeries<N extends Number> extends AbstractTimeSeries<Calendar, N> {

    private final TimeFilter myFilter;

    public CalendarSeries(final CalendarDateUnit aResolution) {

        super(aResolution);

        myFilter = new TimeFilter(aResolution);
    }

    CalendarSeries(final Map<Long, N> aDelegate, final CalendarDateUnit aResolution) {

        super(aDelegate, aResolution);

        myFilter = new TimeFilter(aResolution);
    }

    CalendarSeries(final TimeInMillisSeries<N> aDelegate, final CalendarDateUnit aResolution) {

        super(aDelegate, aResolution);

        myFilter = new TimeFilter(aResolution);
    }

    @Override
    public CalendarSeries<N> colour(final Color aPaint) {
        return (CalendarSeries<N>) super.colour(aPaint);
    }

    public CalendarSeries<N> headMap(final Calendar aToKey) {

        final SortedMap<Long, N> tmpMap = this.getInternalHeadMap(this.convertToTimeInMillis(aToKey));

        return new CalendarSeries<N>(tmpMap, this.getResolution()).name(this.getName()).colour(this.getColour());
    }

    @Override
    public CalendarSeries<N> name(final String aName) {
        return (CalendarSeries<N>) super.name(aName);
    }

    @Override
    public CalendarSeries<N> resample(final Calendar aFirstKey, final Calendar aLastKey, final CalendarDateUnit aResolution) {
        return (CalendarSeries<N>) super.resample(aFirstKey, aLastKey, aResolution);
    }

    @Override
    public CalendarSeries<N> resample(final CalendarDateUnit aResolution) {
        return (CalendarSeries<N>) super.resample(aResolution);
    }

    public Calendar step(final Calendar anExternalKey) {

        final Calendar retVal = new GregorianCalendar();
        retVal.setTime(anExternalKey.getTime());

        final CalendarDateUnit tmpResolution = this.getResolution();

        int tmpFied = Calendar.YEAR;

        switch (tmpResolution) {

        case MONTH:

            tmpFied = Calendar.MONTH;

            break;

        case WEEK:

            tmpFied = Calendar.WEEK_OF_YEAR;

            break;

        case DAY:

            tmpFied = Calendar.DAY_OF_MONTH;

            break;

        case HOUR:

            tmpFied = Calendar.HOUR_OF_DAY;

            break;

        case MINUTE:

            tmpFied = Calendar.MINUTE;

            break;

        case SECOND:

            tmpFied = Calendar.SECOND;

            break;

        default:

            break;
        }

        retVal.setLenient(true);
        retVal.add(tmpFied, 1);

        //        BasicLogger.logDebug("{} => {}", anExternalKey.getTime(), retVal.getTime());

        return retVal;
    }

    public CalendarSeries<N> subMap(final Calendar aFromKey, final Calendar aToKey) {

        final SortedMap<Long, N> tmpMap = this.getInternalSubMap(this.convertToTimeInMillis(aFromKey), this.convertToTimeInMillis(aToKey));

        return new CalendarSeries<N>(tmpMap, this.getResolution()).name(this.getName()).colour(this.getColour());
    }

    public CalendarSeries<N> tailMap(final Calendar aFromKey) {

        final SortedMap<Long, N> tmpMap = this.getInternalTailMap(this.convertToTimeInMillis(aFromKey));

        return new CalendarSeries<N>(tmpMap, this.getResolution()).name(this.getName()).colour(this.getColour());
    }

    @Override
    protected Long convertToTimeInMillis(final Calendar anExternalKey) {
        return myFilter.toTimeInMillis(anExternalKey);
    }

    @Override
    protected CalendarSeries<N> make(final CalendarDateUnit aResolution) {
        return new CalendarSeries<N>(aResolution).name(this.getName()).colour(this.getColour());
    }

    @Override
    protected Calendar toExternalKey(final Long aTimeInMillis) {
        return TimeFilter.makeCalendar(aTimeInMillis);
    }

}
