/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.series;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.*;

import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.ParameterFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.series.primitive.DataSeries;
import org.ojalgo.series.primitive.PrimitiveTimeSeries;
import org.ojalgo.type.CalendarDateUnit;
import org.ojalgo.type.keyvalue.MapEntry;

abstract class AbstractTimeSeries<K extends Comparable<K>, V extends Number> extends AbstractMap<K, V> implements BasicTimeSeries<K, V> {

    private final TimeInMillisSeries<V> myTimeInMillisSeries;
    private final CalendarDateUnit myResolution;

    private static final SimpleDateFormat KEY_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    @SuppressWarnings("unused")
    private AbstractTimeSeries() {

        super();

        myTimeInMillisSeries = new TimeInMillisSeries<V>();
        myResolution = CalendarDateUnit.MILLIS;
    }

    protected AbstractTimeSeries(final CalendarDateUnit aResolution) {

        super();

        myTimeInMillisSeries = new TimeInMillisSeries<V>();
        myResolution = aResolution;
    }

    protected AbstractTimeSeries(final Map<Long, V> aDelegate, final CalendarDateUnit aResolution) {

        super();

        myTimeInMillisSeries = new TimeInMillisSeries<V>(aDelegate);
        myResolution = aResolution;
    }

    protected AbstractTimeSeries(final TimeInMillisSeries<V> aDelegate, final CalendarDateUnit aResolution) {

        super();

        myTimeInMillisSeries = aDelegate;
        myResolution = aResolution;
    }

    @Override
    public final void clear() {
        myTimeInMillisSeries.clear();
    }

    public BasicSeries<K, V> colour(final Color aPaint) {
        this.setColour(aPaint);
        return this;
    }

    public final Comparator<? super K> comparator() {
        return null;
    }

    public final void complete() {

        K tmpKey = this.firstKey();
        V tmpVal = null;

        V tmpPatch = this.firstValue();

        final K tmpLastKey = this.lastKey();
        while (tmpKey.compareTo(tmpLastKey) <= 0) {

            tmpVal = this.get(tmpKey);

            if (tmpVal != null) {
                tmpPatch = tmpVal;
            } else {
                this.put(tmpKey, tmpPatch);
            }

            tmpKey = this.step(tmpKey);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public final boolean containsKey(final Object aKey) {
        return myTimeInMillisSeries.containsKey(this.convertToTimeInMillis((K) aKey));
    }

    @Override
    public final boolean containsValue(final Object aValue) {
        return myTimeInMillisSeries.containsValue(aValue);
    }

    @Override
    public final Set<Entry<K, V>> entrySet() {

        final Set<Long> tmpInternalKeySet = this.getInternalKetSet();

        return new AbstractSet<Entry<K, V>>() {

            @Override
            public void clear() {
                tmpInternalKeySet.clear();
            }

            @Override
            public boolean contains(final Object someO) {
                return tmpInternalKeySet.contains(AbstractTimeSeries.this.convertToTimeInMillis((K) someO));
            }

            @Override
            public Iterator<Entry<K, V>> iterator() {

                final Iterator<Long> tmpInternalKeySetIterator = tmpInternalKeySet.iterator();

                return new Iterator<Entry<K, V>>() {

                    public boolean hasNext() {
                        return tmpInternalKeySetIterator.hasNext();
                    }

                    public Entry<K, V> next() {
                        return new MapEntry<K, V>(AbstractTimeSeries.this, AbstractTimeSeries.this.toExternalKey(tmpInternalKeySetIterator.next()));
                    }

                    public void remove() {
                        tmpInternalKeySetIterator.remove();
                    };
                };
            }

            @Override
            public boolean remove(final Object someO) {
                return tmpInternalKeySet.remove(AbstractTimeSeries.this.convertToTimeInMillis((K) someO));
            }

            @Override
            public int size() {
                return tmpInternalKeySet.size();
            }

        };

    }

    public final K firstKey() {
        return this.toExternalKey(myTimeInMillisSeries.firstKey());
    }

    public final V firstValue() {
        return myTimeInMillisSeries.firstValue();
    }

    @Override
    public final V get(final Object aKey) {
        return myTimeInMillisSeries.get(this.convertToTimeInMillis((K) aKey));
    }

    public final long getAverageStepSize() {
        return this.getTimeInMillisSeries().getAverageStepSize();
    }

    public final Color getColour() {
        return myTimeInMillisSeries.getColour();
    }

    public DataSeries getDataSeries() {
        return myTimeInMillisSeries.getDataSeries();
    }

    public final String getName() {
        return myTimeInMillisSeries.getName();
    }

    public final long[] getPrimitiveKeys() {

        final long[] retVal = new long[this.size()];

        int i = 0;
        for (final Long tmpKey : this.getInternalKetSet()) {
            retVal[i] = tmpKey;
            i++;
        }

        return retVal;
    }

    public PrimitiveTimeSeries getPrimitiveTimeSeries() {
        return new PrimitiveTimeSeries(this.getPrimitiveKeys(), this.getDataSeries());
    }

    public final double[] getPrimitiveValues() {

        final double[] retVal = new double[myTimeInMillisSeries.size()];

        int i = 0;
        for (final V tmpValue : myTimeInMillisSeries.values()) {
            retVal[i] = tmpValue.doubleValue();
            i++;
        }

        return retVal;
    }

    public final CalendarDateUnit getResolution() {
        return myResolution;
    }

    public final TimeInMillisSeries<V> getTimeInMillisSeries() {
        return myTimeInMillisSeries;
    }

    @Override
    public final boolean isEmpty() {
        return myTimeInMillisSeries.isEmpty();
    }

    public final K lastKey() {
        return this.toExternalKey(myTimeInMillisSeries.lastKey());
    }

    public final V lastValue() {
        return myTimeInMillisSeries.lastValue();
    }

    public final void modify(final BasicSeries<K, V> aLeftArg, final BinaryFunction<V> aFunc) {
        K tmpKey;
        V tmpLeftArg;
        for (final Map.Entry<K, V> tmpEntry : this.entrySet()) {
            tmpKey = tmpEntry.getKey();
            tmpLeftArg = aLeftArg.get(tmpKey);
            if (tmpLeftArg != null) {
                this.put(tmpKey, aFunc.invoke(tmpLeftArg, tmpEntry.getValue()));
            } else {
                this.remove(tmpKey);
            }
        }
    }

    public final void modify(final BinaryFunction<V> aFunc, final BasicSeries<K, V> aRightArg) {
        K tmpKey;
        V tmpRightArg;
        for (final Map.Entry<K, V> tmpEntry : this.entrySet()) {
            tmpKey = tmpEntry.getKey();
            tmpRightArg = aRightArg.get(tmpKey);
            if (tmpRightArg != null) {
                this.put(tmpKey, aFunc.invoke(tmpEntry.getValue(), tmpRightArg));
            } else {
                this.remove(tmpKey);
            }
        }
    }

    public final void modify(final BinaryFunction<V> aFunc, final V aRightArg) {
        myTimeInMillisSeries.modify(aFunc, aRightArg);
    }

    public final void modify(final ParameterFunction<V> aFunc, final int aParam) {
        myTimeInMillisSeries.modify(aFunc, aParam);
    }

    public final void modify(final UnaryFunction<V> aFunc) {
        myTimeInMillisSeries.modify(aFunc);
    }

    public final void modify(final V aLeftArg, final BinaryFunction<V> aFunc) {
        myTimeInMillisSeries.modify(aLeftArg, aFunc);
    }

    public BasicSeries<K, V> name(final String aName) {
        this.setName(aName);
        return this;
    }

    @Override
    public final V put(final K aKey, final V aValue) {
        return myTimeInMillisSeries.put(this.convertToTimeInMillis(aKey), aValue);
    }

    @Override
    public final V remove(final Object aKey) {
        return myTimeInMillisSeries.remove(this.convertToTimeInMillis((K) aKey));
    }

    public BasicTimeSeries<K, V> resample(final CalendarDateUnit aResolution) {

        final BasicTimeSeries<K, V> retVal = this.make(aResolution);
        retVal.putAll(this);

        return retVal;
    }

    public BasicTimeSeries<K, V> resample(final K aFirstKey, final K aLastKey, final CalendarDateUnit aResolution) {

        final AbstractTimeSeries<K, V> retVal = (AbstractTimeSeries<K, V>) this.make(aResolution);

        final SortedMap<K, V> tmpSubMap = this.subMap(aFirstKey, aLastKey);

        retVal.putAll(tmpSubMap);

        return retVal;
    }

    public final void setColour(final Color aPaint) {
        myTimeInMillisSeries.setColour(aPaint);
    }

    public final void setName(final String aName) {
        myTimeInMillisSeries.setName(aName);
    }

    @Override
    public final int size() {
        return myTimeInMillisSeries.size();
    }

    @Override
    public final String toString() {

        K tmpKey;

        final StringBuilder retVal = new StringBuilder();

        retVal.append(this.getClass().getSimpleName());
        retVal.append('@');
        retVal.append(Integer.toHexString(this.hashCode()));
        retVal.append(": Name=");
        retVal.append(this.getName());
        retVal.append(", Size=");
        retVal.append(this.size());
        retVal.append(", FirstKey=");
        tmpKey = this.firstKey();
        if (tmpKey instanceof Calendar) {
            retVal.append(KEY_FORMAT.format(((Calendar) tmpKey).getTime()));
        } else if (tmpKey instanceof Date) {
            retVal.append(KEY_FORMAT.format(((Date) tmpKey)));
        } else {
            retVal.append(tmpKey);
        }
        retVal.append(", LastKey=");
        tmpKey = this.lastKey();
        if (tmpKey instanceof Calendar) {
            retVal.append(KEY_FORMAT.format(((Calendar) tmpKey).getTime()));
        } else if (tmpKey instanceof Date) {
            retVal.append(KEY_FORMAT.format(((Date) tmpKey)));
        } else {
            retVal.append(tmpKey);
        }

        retVal.append(", Resolution=");
        retVal.append(this.getResolution());

        return retVal.toString();
    }

    protected abstract Long convertToTimeInMillis(K anExternalKey);

    protected final SortedMap<Long, V> getInternalHeadMap(final Long toKey) {
        return myTimeInMillisSeries.headMap(toKey);
    }

    protected final Set<Long> getInternalKetSet() {
        return myTimeInMillisSeries.keySet();
    }

    protected final SortedMap<Long, V> getInternalSubMap(final Long fromKey, final Long toKey) {
        return myTimeInMillisSeries.subMap(fromKey, toKey);
    }

    protected final SortedMap<Long, V> getInternalTailMap(final Long fromKey) {
        return myTimeInMillisSeries.tailMap(fromKey);
    }

    protected abstract BasicTimeSeries<K, V> make(CalendarDateUnit aResolution);

    protected abstract K toExternalKey(Long aTimeInMillis);

}
