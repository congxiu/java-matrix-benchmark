/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.transformation;

import java.math.BigDecimal;

import org.ojalgo.array.Array1D;
import org.ojalgo.constant.BigMath;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.matrix.decomposition.DecompositionStore;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.TypeUtils;

public final class Householder<N extends Number> extends Object {

    public static final class Big extends Object {

        public BigDecimal beta;
        public int first;
        public final BigDecimal[] vector;

        public Big(final DecompositionStore.HouseholderReference<BigDecimal> aTransf) {

            this(aTransf.size());

            this.copy(aTransf);
        }

        public Big(final Householder<BigDecimal> aTransf) {

            this(aTransf.size());

            this.copy(aTransf);
        }

        public Big(final int aDim) {

            super();

            vector = new BigDecimal[aDim];
            beta = BigMath.ZERO;
            first = 0;
        }

        @SuppressWarnings("unused")
        private Big() {
            this(0);
        }

        public final Householder.Big copy(final DecompositionStore.HouseholderReference<BigDecimal> aSource) {

            final DecompositionStore<BigDecimal> tmpStore = aSource.getStore();
            final int tmpRow = aSource.row;
            final int tmpCol = aSource.col;
            final int tmpSize = aSource.size();

            final BigDecimal[] tmpVector = vector;
            BigDecimal tmpVal, tmpVal2 = BigMath.ONE;
            if (aSource.isColumn()) {
                tmpVector[tmpRow] = BigMath.ONE;
                for (int i = tmpRow + 1; i < tmpSize; i++) {
                    tmpVal = tmpStore.get(i, tmpCol);
                    tmpVal2 = BigFunction.ADD.invoke(tmpVal2, BigFunction.MULTIPLY.invoke(tmpVal, tmpVal));
                    tmpVector[i] = tmpVal;
                }
                first = tmpRow;
            } else {
                tmpVector[tmpCol] = BigMath.ONE;
                for (int j = tmpCol + 1; j < tmpSize; j++) {
                    tmpVal = tmpStore.get(tmpRow, j);
                    tmpVal2 = BigFunction.ADD.invoke(tmpVal2, BigFunction.MULTIPLY.invoke(tmpVal, tmpVal));
                    tmpVector[j] = tmpVal;
                }
                first = tmpCol;
            }

            beta = BigFunction.DIVIDE.invoke(BigMath.TWO, tmpVal2);

            return this;
        }

        public final Householder.Big copy(final DecompositionStore.HouseholderReference<BigDecimal> aSource, final BigDecimal aPrecalculatedBeta) {

            final DecompositionStore<BigDecimal> tmpStore = aSource.getStore();
            final int tmpRow = aSource.row;
            final int tmpCol = aSource.col;
            final int tmpSize = aSource.size();

            final BigDecimal[] tmpVector = vector;
            if (aSource.isColumn()) {
                tmpVector[tmpRow] = BigMath.ONE;
                for (int i = tmpRow + 1; i < tmpSize; i++) {
                    tmpVector[i] = tmpStore.get(i, tmpCol);
                }
                first = tmpRow;
            } else {
                tmpVector[tmpCol] = BigMath.ONE;
                for (int j = tmpCol + 1; j < tmpSize; j++) {
                    tmpVector[j] = tmpStore.get(tmpRow, j);
                }
                first = tmpCol;
            }

            beta = aPrecalculatedBeta;

            return this;
        }

        public final Householder.Big copy(final Householder<BigDecimal> aSource) {

            first = aSource.first();

            final BigDecimal[] tmpVector = vector;
            BigDecimal tmpVal, tmpVal2 = BigMath.ZERO;
            final int tmpSize = aSource.size();
            for (int i = aSource.first(); i < tmpSize; i++) {
                tmpVal = aSource.getNumber(BigDenseStore.FACTORY, i);
                tmpVal2 = BigFunction.ADD.invoke(tmpVal2, BigFunction.MULTIPLY.invoke(tmpVal, tmpVal));
                tmpVector[i] = tmpVal;
            }

            beta = BigFunction.DIVIDE.invoke(BigMath.TWO, tmpVal2);

            return this;
        }

    }

    public static final class Complex extends Object {

        public ComplexNumber beta;
        public int first;
        public final ComplexNumber[] vector;

        public Complex(final DecompositionStore.HouseholderReference<ComplexNumber> aTransf) {

            this(aTransf.size());

            this.copy(aTransf);
        }

        public Complex(final Householder<ComplexNumber> aTransf) {

            this(aTransf.size());

            this.copy(aTransf);
        }

        public Complex(final int aDim) {

            super();

            vector = new ComplexNumber[aDim];
            beta = ComplexNumber.ZERO;
            first = 0;
        }

        @SuppressWarnings("unused")
        private Complex() {
            this(0);
        }

        public final Householder.Complex copy(final DecompositionStore.HouseholderReference<ComplexNumber> aSource) {

            final DecompositionStore<ComplexNumber> tmpStore = aSource.getStore();
            final int tmpRow = aSource.row;
            final int tmpCol = aSource.col;
            final int tmpSize = aSource.size();

            final ComplexNumber[] tmpVector = vector;
            ComplexNumber tmpNmbr;
            double tmpVal, tmpVal2 = PrimitiveMath.ONE;
            if (aSource.isColumn()) {
                tmpVector[tmpRow] = ComplexNumber.ONE;
                for (int i = tmpRow + 1; i < tmpSize; i++) {
                    tmpNmbr = tmpStore.get(i, tmpCol);
                    tmpVal = tmpNmbr.getModulus();
                    tmpVal2 += tmpVal * tmpVal;
                    tmpVector[i] = tmpNmbr;
                }
                first = tmpRow;
            } else {
                tmpVector[tmpCol] = ComplexNumber.ONE;
                for (int j = tmpCol + 1; j < tmpSize; j++) {
                    tmpNmbr = tmpStore.get(tmpRow, j);
                    tmpVal = tmpNmbr.getModulus();
                    tmpVal2 += tmpVal * tmpVal;
                    tmpVector[j] = tmpNmbr;
                }
                first = tmpCol;
            }

            beta = new ComplexNumber(PrimitiveMath.TWO / tmpVal2);

            return this;
        }

        public final Householder.Complex copy(final DecompositionStore.HouseholderReference<ComplexNumber> aSource, final ComplexNumber aPrecalculatedBeta) {

            final DecompositionStore<ComplexNumber> tmpStore = aSource.getStore();
            final int tmpRow = aSource.row;
            final int tmpCol = aSource.col;
            final int tmpSize = aSource.size();

            final ComplexNumber[] tmpVector = vector;
            if (aSource.isColumn()) {
                tmpVector[tmpRow] = ComplexNumber.ONE;
                for (int i = tmpRow + 1; i < tmpSize; i++) {
                    tmpVector[i] = tmpStore.get(i, tmpCol);
                }
                first = tmpRow;
            } else {
                tmpVector[tmpCol] = ComplexNumber.ONE;
                for (int j = tmpCol + 1; j < tmpSize; j++) {
                    tmpVector[j] = tmpStore.get(tmpRow, j);
                }
                first = tmpCol;
            }

            beta = aPrecalculatedBeta;

            return this;
        }

        public final Householder.Complex copy(final Householder<ComplexNumber> aSource) {

            first = aSource.first();

            final ComplexNumber[] tmpVector = vector;
            ComplexNumber tmpNmbr;
            double tmpVal, tmpVal2 = PrimitiveMath.ZERO;
            final int tmpSize = aSource.size();
            for (int i = aSource.first(); i < tmpSize; i++) {
                tmpNmbr = aSource.getNumber(ComplexDenseStore.FACTORY, i);
                tmpVal = tmpNmbr.getModulus();
                tmpVal2 += tmpVal * tmpVal;
                tmpVector[i] = tmpNmbr;
            }

            beta = new ComplexNumber(PrimitiveMath.TWO / tmpVal2);

            return this;
        }

    }

    public static final class Primitive extends Object {

        public double beta;
        public int first;
        public final double[] vector;

        public Primitive(final DecompositionStore.HouseholderReference<Double> aTransf) {

            this(aTransf.size());

            this.copy(aTransf);
        }

        public Primitive(final Householder<Double> aTransf) {

            this(aTransf.size());

            this.copy(aTransf);
        }

        public Primitive(final int aDim) {

            super();

            vector = new double[aDim];
            beta = PrimitiveMath.ZERO;
            first = 0;
        }

        @SuppressWarnings("unused")
        private Primitive() {
            this(0);
        }

        public final Householder.Primitive copy(final DecompositionStore.HouseholderReference<Double> aSource) {

            final DecompositionStore<Double> tmpStore = aSource.getStore();
            final int tmpRow = aSource.row;
            final int tmpCol = aSource.col;
            final int tmpSize = aSource.size();

            final double[] tmpVector = vector;
            double tmpVal, tmpVal2 = PrimitiveMath.ONE;
            if (aSource.isColumn()) {
                tmpVector[tmpRow] = PrimitiveMath.ONE;
                for (int i = tmpRow + 1; i < tmpSize; i++) {
                    tmpVal = tmpStore.doubleValue(i, tmpCol);
                    tmpVal2 += tmpVal * tmpVal;
                    tmpVector[i] = tmpVal;
                }
                first = tmpRow;
            } else {
                tmpVector[tmpCol] = PrimitiveMath.ONE;
                for (int j = tmpCol + 1; j < tmpSize; j++) {
                    tmpVal = tmpStore.doubleValue(tmpRow, j);
                    tmpVal2 += tmpVal * tmpVal;
                    tmpVector[j] = tmpVal;
                }
                first = tmpCol;
            }

            beta = PrimitiveMath.TWO / tmpVal2;

            return this;
        }

        public final Householder.Primitive copy(final DecompositionStore.HouseholderReference<Double> aSource, final double aPrecalculatedBeta) {

            final DecompositionStore<Double> tmpStore = aSource.getStore();
            final int tmpRow = aSource.row;
            final int tmpCol = aSource.col;
            final int tmpSize = aSource.size();

            final double[] tmpVector = vector;
            if (aSource.isColumn()) {
                tmpVector[tmpRow] = PrimitiveMath.ONE;
                for (int i = tmpRow + 1; i < tmpSize; i++) {
                    tmpVector[i] = tmpStore.doubleValue(i, tmpCol);
                }
                first = tmpRow;
            } else {
                tmpVector[tmpCol] = PrimitiveMath.ONE;
                for (int j = tmpCol + 1; j < tmpSize; j++) {
                    tmpVector[j] = tmpStore.doubleValue(tmpRow, j);
                }
                first = tmpCol;
            }

            beta = aPrecalculatedBeta;

            return this;
        }

        public final Householder.Primitive copy(final Householder<Double> aSource) {

            first = aSource.first();

            final double[] tmpVector = vector;
            double tmpVal, tmpVal2 = PrimitiveMath.ZERO;
            final int tmpSize = aSource.size();
            for (int i = aSource.first(); i < tmpSize; i++) {
                tmpVal = aSource.doubleValue(i);
                tmpVal2 += tmpVal * tmpVal;
                tmpVector[i] = tmpVal;
            }

            beta = PrimitiveMath.TWO / tmpVal2;

            return this;
        }

        public final boolean set(final DecompositionStore.HouseholderReference<Double> aSource) {

            final DecompositionStore<Double> tmpStore = aSource.getStore();
            final int tmpRow = aSource.row;
            final int tmpCol = aSource.col;
            final int tmpSize = aSource.size();

            final double[] tmpVector = vector;
            double tmpVal, tmpVal2 = PrimitiveMath.ONE;
            if (aSource.isColumn()) {
                tmpVector[tmpRow] = PrimitiveMath.ONE;
                for (int i = tmpRow + 1; i < tmpSize; i++) {
                    tmpVal = tmpStore.doubleValue(i, tmpCol);
                    tmpVal2 += tmpVal * tmpVal;
                    tmpVector[i] = tmpVal;
                }
                first = tmpRow;
            } else {
                tmpVector[tmpCol] = PrimitiveMath.ONE;
                for (int j = tmpCol + 1; j < tmpSize; j++) {
                    tmpVal = tmpStore.doubleValue(tmpRow, j);
                    tmpVal2 += tmpVal * tmpVal;
                    tmpVector[j] = tmpVal;
                }
                first = tmpCol;
            }

            beta = PrimitiveMath.TWO / tmpVal2;

            return !TypeUtils.isZero(tmpVal2 - PrimitiveMath.ONE);
        }

        @Override
        public String toString() {

            final StringBuilder retVal = new StringBuilder("{");

            final int tmpFirst = first;
            final int tmpLength = vector.length;
            for (int i = 0; i < tmpFirst; i++) {
                retVal.append(PrimitiveMath.ZERO);
                retVal.append(", ");
            }
            for (int i = first; i < tmpLength; i++) {
                retVal.append(vector[i]);
                if (i + 1 < tmpLength) {
                    retVal.append(", ");
                }
            }
            retVal.append("}");

            return retVal.toString();
        }

    }

    public static Householder<BigDecimal> makeBig(final BigDecimal[] allVectorElements) {
        return new Householder<BigDecimal>(0, false, Array1D.makeBig(allVectorElements));
    }

    public static Householder<BigDecimal> makeBig(final int aNumberOfLeadingZeros, final boolean aLeadingOneOrNot, final BigDecimal[] theRemainingVectorElements) {
        return new Householder<BigDecimal>(aNumberOfLeadingZeros, aLeadingOneOrNot, Array1D.makeBig(theRemainingVectorElements));
    }

    public static Householder<ComplexNumber> makeComplex(final ComplexNumber[] allVectorElements) {
        return new Householder<ComplexNumber>(0, false, Array1D.makeComplex(allVectorElements));
    }

    public static Householder<ComplexNumber> makeComplex(final int aNumberOfLeadingZeros, final boolean aLeadingOneOrNot, final ComplexNumber[] theRemainingVectorElements) {
        return new Householder<ComplexNumber>(aNumberOfLeadingZeros, aLeadingOneOrNot, Array1D.makeComplex(theRemainingVectorElements));
    }

    public static Householder<Double> makePrimitive(final double[] allVectorElements) {
        return new Householder<Double>(0, false, Array1D.makePrimitive(allVectorElements));
    }

    public static Householder<Double> makePrimitive(final int aNumberOfLeadingZeros, final boolean aLeadingOneOrNot, final double[] theRemainingVectorElements) {
        return new Householder<Double>(aNumberOfLeadingZeros, aLeadingOneOrNot, Array1D.makePrimitive(theRemainingVectorElements));
    }

    private final boolean myOne;
    private final Array1D<N> myRemaining;
    private final int myZeros;

    public Householder(final int aNumberOfLeadingZeros, final boolean aLeadingOneOrNot, final Array1D<N> theRemainingVectorElements) {

        super();

        myZeros = aNumberOfLeadingZeros;
        myOne = aLeadingOneOrNot;
        myRemaining = theRemainingVectorElements;
    }

    public final double doubleValue(final int anIndex) {
        if (anIndex < myZeros) {
            return PrimitiveMath.ZERO;
        } else if (myOne && (anIndex == myZeros)) {
            return PrimitiveMath.ONE;
        } else {
            return myRemaining.doubleValue(myOne ? anIndex - 1 - myZeros : anIndex - myZeros);
        }
    }

    /**
     * @return The index of the first non-zero Householder vector element.
     */
    public final int first() {
        return myZeros;
    }

    public final N getNumber(final PhysicalStore.Factory<N> aFactory, final int anIndex) {
        if (anIndex < myZeros) {
            return aFactory.getStaticZero().getNumber();
        } else if (myOne && (anIndex == myZeros)) {
            return aFactory.getStaticOne().getNumber();
        } else {
            return myRemaining.get(myOne ? anIndex - 1 - myZeros : anIndex - myZeros);
        }
    }

    /**
    * @return The size/length of the Householder vector.
    */
    public final int size() {
        return myOne ? myZeros + 1 + myRemaining.length : myZeros + myRemaining.length;
    }

    public final Scalar<N> toScalar(final PhysicalStore.Factory<N> aFactory, final int anIndex) {
        if (anIndex < myZeros) {
            return aFactory.getStaticZero();
        } else if (myOne && (anIndex == myZeros)) {
            return aFactory.getStaticOne();
        } else {
            return myRemaining.toScalar(myOne ? anIndex - 1 - myZeros : anIndex - myZeros);
        }
    }

    @Override
    public String toString() {

        final StringBuilder retVal = new StringBuilder("{");

        retVal.append(this.doubleValue(0));

        final int tmpSize = this.size();
        for (int i = 1; i < tmpSize; i++) {
            retVal.append(", ");
            retVal.append(this.doubleValue(i));
        }
        retVal.append("}");

        return retVal.toString();
    }

}
