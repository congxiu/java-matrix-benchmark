/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.matrix.decomposition.LUDecomposition.Pivot;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.scalar.ComplexNumber;

/**
 * <p>
 * Only classes that will act as a delegate to a {@linkplain MatrixDecomposition}
 * implementation from this package should implement this interface. The
 * interface specifications are entirely dictated by the classes in this
 * package.
 * </p><p>
 * Do not use it for anything else!
 * </p>
 *
 * @author apete
 */
public interface DecompositionStore<N extends Number> extends PhysicalStore<N> {

    public static final class HouseholderReference<N extends Number> {

        public int col = 0;
        public int row = 0;

        private transient Householder.Big myBigWorkCopy = null;
        private final boolean myColumn;
        private transient Householder.Complex myComplexWorkCopy = null;
        private transient Householder.Primitive myPrimitiveWorkCopy = null;
        private final DecompositionStore<N> myStore;

        public HouseholderReference(final DecompositionStore<N> aStore) {
            this(aStore, true);
        }

        public HouseholderReference(final DecompositionStore<N> aStore, final boolean aColumn) {

            super();

            myStore = aStore;
            myColumn = aColumn;
        }

        @SuppressWarnings("unused")
        private HouseholderReference() {
            this(null, true);
        }

        public final Householder<N> extract() {
            if (myColumn) {
                return new Householder<N>(row, true, myStore.asArray2D().sliceColumn(row + 1, col));
            } else {
                return new Householder<N>(col, true, myStore.asArray2D().sliceRow(row, col + 1));
            }
        }

        public final Householder.Big getBigWorkCopy() {
            if (myBigWorkCopy == null) {
                if (myColumn) {
                    myBigWorkCopy = new Householder.Big(myStore.getRowDim());
                } else {
                    myBigWorkCopy = new Householder.Big(myStore.getColDim());
                }
            }
            return myBigWorkCopy;
        }

        public final Householder.Complex getComplexWorkCopy() {
            if (myComplexWorkCopy == null) {
                if (myColumn) {
                    myComplexWorkCopy = new Householder.Complex(myStore.getRowDim());
                } else {
                    myComplexWorkCopy = new Householder.Complex(myStore.getColDim());
                }
            }
            return myComplexWorkCopy;
        }

        public final Householder.Primitive getPrimitiveWorkCopy() {
            if (myPrimitiveWorkCopy == null) {
                if (myColumn) {
                    myPrimitiveWorkCopy = new Householder.Primitive(myStore.getRowDim());
                } else {
                    myPrimitiveWorkCopy = new Householder.Primitive(myStore.getColDim());
                }
            }
            return myPrimitiveWorkCopy;
        }

        public final DecompositionStore<N> getStore() {
            return myStore;
        }

        public final boolean isColumn() {
            return myColumn;
        }

        public final boolean isRow() {
            return !myColumn;
        }

        public final boolean isZero() {
            if (myColumn) {
                return myStore.asArray2D().sliceColumn(row + 1, col).isAllZeros();
            } else {
                return myStore.asArray2D().sliceRow(row, col + 1).isAllZeros();
            }
        }

        public final int size() {
            if (myColumn) {
                return myStore.getRowDim();
            } else {
                return myStore.getColDim();
            }
        }

        @Override
        public String toString() {

            if (myColumn) {

                final StringBuilder retVal = new StringBuilder("{");

                for (int i = 0; i < row; i++) {
                    retVal.append(PrimitiveMath.ZERO);
                    retVal.append(", ");
                }
                retVal.append(PrimitiveMath.ONE);
                for (int i = row + 1; i < myStore.getRowDim(); i++) {
                    retVal.append(", ");
                    retVal.append(myStore.doubleValue(i, col));
                }
                retVal.append("}");

                return retVal.toString();

            } else {

                final StringBuilder retVal = new StringBuilder("{");

                for (int j = 0; j < col; j++) {
                    retVal.append(PrimitiveMath.ZERO);
                    retVal.append(", ");
                }
                retVal.append(PrimitiveMath.ONE);
                for (int j = col + 1; j < myStore.getColDim(); j++) {
                    retVal.append(", ");
                    retVal.append(myStore.doubleValue(row, j));
                }
                retVal.append("}");

                return retVal.toString();

            }

        }

    }

    Array2D<N> asArray2D();

    void computeInPlaceBidiagonal(boolean normalAspectRatio);

    boolean computeInPlaceCholesky(boolean checkForSPD);

    void computeInPlaceHessenberg(final boolean upper);

    Pivot computeInPlaceLU(boolean assumeNoPivotingRequired);

    void computeInPlaceQR();

    Array1D<ComplexNumber> computeInPlaceSchur(PhysicalStore<N> aTransformationCollector, boolean eigenvalue);

    void computeInPlaceTridiagonal();

    /**
     * Will solve the equation system [A][X]=[B] where:
     * <ul>
     * <li>[aBody][this]=[this] is [A][X]=[B] ("this" is the right hand
     * side, and it will be overwritten with the solution).</li>
     * <li>[A] is upper/right triangular</li>
     * </ul>
     * 
     * @param aBody The equation system body parameters [A]
     * @param transposed true if the upper/right part of aBody is
     * actually stored in the lower/left part of the matrix.
     */
    void substituteBackwards(Access2D<N> aBody, boolean transposed);

    /**
     * Will solve the equation system [A][X]=[B] where:
     * <ul>
     * <li>[aBody][this]=[this] is [A][X]=[B] ("this" is the right hand
     * side, and it will be overwritten with the solution).</li>
     * <li>[A] is lower/left triangular</li>
     * </ul>
     * 
     * @param aBody The equation system body parameters [A]
     * @param onesOnDiagonal true if aBody as ones on the diagonal
     */
    void substituteForwards(Access2D<N> aBody, boolean onesOnDiagonal, Access2D<N> aRHS, boolean zerosAboveDiagonal);

    void transformLeft(final DecompositionStore.HouseholderReference<N> aTransf, final int aFirstCol);

    void transformRight(final DecompositionStore.HouseholderReference<N> aTransf, final int aFirstRow);

}
