/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.context.NumberContext;

public abstract class BidiagonalDecomposition<N extends Number> extends InPlaceDecomposition<N> implements Bidiagonal<N> {

    static final class Big extends BidiagonalDecomposition<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

    }

    static final class Complex extends BidiagonalDecomposition<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

    }

    static final class Primitive extends BidiagonalDecomposition<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

    }

    public static final Bidiagonal<BigDecimal> makeBig() {
        return new BidiagonalDecomposition.Big();
    }

    public static final Bidiagonal<ComplexNumber> makeComplex() {
        return new BidiagonalDecomposition.Complex();
    }

    public static final Bidiagonal<Double> makePrimitive() {
        return new BidiagonalDecomposition.Primitive();
    }

    protected BidiagonalDecomposition(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public final boolean compute(final Access2D<N> aStore) {

        this.copyStore(aStore).computeInPlaceBidiagonal(this.isAspectRatioNormal());

        return this.computed(true);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public final MatrixStore<N> getD() {
        return this.getStore().builder().bidiagonal(this.isAspectRatioNormal(), false).build();
    }

    @Override
    public final MatrixStore<N> getInverse() {
        throw new UnsupportedOperationException();
    }

    public final MatrixStore<N> getQ1() {

        final DecompositionStore<N> tmpStore = this.getStore();
        final int tmpRowDim = tmpStore.getRowDim();
        final int tmpColDim = tmpStore.getMinDim();

        final DecompositionStore<N> retVal = this.makeEye(tmpRowDim, tmpColDim);

        final DecompositionStore.HouseholderReference<N> tmpHouseholderReference = new DecompositionStore.HouseholderReference<N>(tmpStore, true);

        if (this.isAspectRatioNormal()) {
            for (int ij = tmpColDim - 1; ij >= 0; ij--) {
                tmpHouseholderReference.row = ij;
                tmpHouseholderReference.col = ij;
                retVal.transformLeft(tmpHouseholderReference, ij);
            }
        } else {
            for (int ij = tmpColDim - 2; ij >= 0; ij--) {
                tmpHouseholderReference.row = ij + 1;
                tmpHouseholderReference.col = ij;
                retVal.transformLeft(tmpHouseholderReference, ij);
            }
        }

        return retVal;
    }

    public final MatrixStore<N> getQ2() {

        final DecompositionStore<N> tmpStore = this.getStore();
        final int tmpRowDim = tmpStore.getColDim();
        final int tmpColDim = tmpStore.getMinDim();

        final DecompositionStore<N> retVal = this.makeEye(tmpRowDim, tmpColDim);

        final DecompositionStore.HouseholderReference<N> tmpHouseholderReference = new DecompositionStore.HouseholderReference<N>(tmpStore, false);

        if (this.isAspectRatioNormal()) {
            for (int ij = tmpColDim - 2; ij >= 0; ij--) {
                tmpHouseholderReference.row = ij;
                tmpHouseholderReference.col = ij + 1;
                retVal.transformLeft(tmpHouseholderReference, ij);
            }
        } else {
            for (int ij = tmpColDim - 1; ij >= 0; ij--) {
                tmpHouseholderReference.row = ij;
                tmpHouseholderReference.col = ij;
                retVal.transformLeft(tmpHouseholderReference, ij);
            }
        }

        return retVal;
    }

    public final boolean isFullSize() {
        return false;
    }

    public final boolean isSolvable() {
        return this.isComputed();
    }

    public MatrixStore<N> reconstruct() {
        return MatrixUtils.reconstruct(this);
    }

    @Override
    public final MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        throw new UnsupportedOperationException();
    }

    final DiagonalAccess<N> getDiagonalAccessD() {

        final Array2D<N> tmpArray2D = this.getStore().asArray2D();

        final Array1D<N> tmpMain = tmpArray2D.sliceDiagonal(0, 0);
        Array1D<N> tmpSuper;
        Array1D<N> tmpSub;

        if (this.isAspectRatioNormal()) {
            tmpSuper = tmpArray2D.sliceDiagonal(0, 1);
            tmpSub = tmpSuper;
        } else {
            tmpSub = tmpArray2D.sliceDiagonal(1, 0);
            tmpSuper = tmpSub;
        }

        return new DiagonalAccess<N>(tmpMain, tmpSub, tmpSub, this.getStaticZero());
    }

}
