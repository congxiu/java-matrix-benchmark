/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.access.Access2D;
import org.ojalgo.function.aggregator.AggregatorFunction;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.jama.JamaCholesky;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.LowerTriangularStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.context.NumberContext;

public abstract class CholeskyDecomposition<N extends Number> extends InPlaceDecomposition<N> implements Cholesky<N> {

    static final class Big extends CholeskyDecomposition<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

    }

    static final class Complex extends CholeskyDecomposition<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

    }

    static final class Primitive extends CholeskyDecomposition<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

    }

    public static final Cholesky<BigDecimal> makeBig() {
        return new CholeskyDecomposition.Big();
    }

    public static final Cholesky<ComplexNumber> makeComplex() {
        return new CholeskyDecomposition.Complex();
    }

    public static final Cholesky<Double> makeJama() {
        return new JamaCholesky();
    }

    public static final Cholesky<Double> makePrimitive() {
        return new CholeskyDecomposition.Primitive();
    }

    private boolean mySPD = false;

    protected CholeskyDecomposition(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public boolean compute(final Access2D<N> aStore) {

        mySPD = this.copyStore(aStore).computeInPlaceCholesky(false);

        return this.computed(true);
    }

    public boolean computeWithCheck(final MatrixStore<N> aStore) {

        mySPD = this.copyStore(aStore).computeInPlaceCholesky(true);

        return this.computed(true);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public N getDeterminant() {

        final AggregatorFunction<N> tmpAggrFunc = this.getAggregatorCollection().product2();

        this.getStore().visitDiagonal(0, 0, tmpAggrFunc);

        return tmpAggrFunc.getNumber();
    }

    public MatrixStore<N> getInverse() {

        final DecompositionStore<N> retVal = this.makeEye(this.getColDim(), this.getRowDim());

        final DecompositionStore<N> tmpBody = this.getStore();

        retVal.substituteForwards(tmpBody, false, retVal, true);
        retVal.substituteBackwards(tmpBody, true);

        return retVal;
    }

    public MatrixStore<N> getL() {
        return new LowerTriangularStore<N>(this.getStore(), false);
    }

    public final boolean isFullSize() {
        return true;
    }

    public boolean isSolvable() {
        return this.isComputed() && mySPD;
    }

    public boolean isSPD() {
        return mySPD;
    }

    public MatrixStore<N> reconstruct() {
        return MatrixUtils.reconstruct(this);
    }

    @Override
    public void reset() {

        super.reset();

        mySPD = false;
    }

    /**
     * Solves [this][X] = [aRHS] by first solving
     * <pre>[L][Y] = [aRHS]</pre>
     * and then
     * <pre>[U][X] = [Y]</pre>.
     * 
     * @param aRHS The right hand side
     * @return [X]
     */
    public MatrixStore<N> solve(final MatrixStore<N> aRHS) {

        final DecompositionStore<N> retVal = this.makeZero(aRHS.getRowDim(), aRHS.getColDim());

        final DecompositionStore<N> tmpBody = this.getStore();

        retVal.substituteForwards(tmpBody, false, aRHS, false);
        retVal.substituteBackwards(tmpBody, true);

        return retVal;
    }

}
