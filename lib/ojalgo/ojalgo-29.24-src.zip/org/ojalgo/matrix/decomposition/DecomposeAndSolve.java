/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.util.concurrent.Callable;

import org.ojalgo.matrix.store.MatrixStore;

public final class DecomposeAndSolve<N extends Number> implements Callable<DecomposeAndSolve<N>> {

    private final MatrixDecomposition<N> myDecomposition;

    private MatrixStore<N> myBody = null;
    private MatrixStore<N> myRHS = null;
    private MatrixStore<N> mySolution = null;

    public DecomposeAndSolve(final MatrixDecomposition<N> aDecomposition) {

        super();

        myDecomposition = aDecomposition;
    }

    DecomposeAndSolve(final MatrixDecomposition<N> aDecomposition, final MatrixStore<N> aBody, final MatrixStore<N> aRHS) {

        this(aDecomposition);

        myBody = aBody;
        myRHS = aRHS;
    }

    public DecomposeAndSolve<N> call() throws Exception {

        if (!myDecomposition.isComputed() && (myBody != null)) {
            myDecomposition.compute(myBody);
        }

        if ((mySolution == null) && (myRHS != null) && myDecomposition.isSolvable()) {
            mySolution = myDecomposition.solve(myRHS);
        }

        return this;
    }

    /**
     * equation system body
     */
    public final MatrixStore<N> getBody() {
        return myBody;
    }

    /**
     * equation system right hand side
     */
    public final MatrixStore<N> getRHS() {
        return myRHS;
    }

    /**
     * equation system solution
     */
    public final MatrixStore<N> getSolution() {
        return mySolution;
    }

    /**
     * equation system body
     */
    public final void setBody(final MatrixStore<N> aBody) {
        myBody = aBody;
        myDecomposition.reset();
        mySolution = null;
    }

    /**
     * equation system right hand side
     */
    public final void setRHS(final MatrixStore<N> aRHS) {
        myRHS = aRHS;
        mySolution = null;
    }

}
