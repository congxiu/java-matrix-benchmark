/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import org.ojalgo.access.Access2D;
import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * New implementation that delegates to Eigenvalue.
 * 
 * Same as SVD1 but with computeInPlaceBidiagonal.
 *
 * @author apete
 */
abstract class SVDnew2<N extends Number & Comparable<N>> extends SingularValueDecomposition<N> {

    static final class Primitive extends SVDnew2<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY, (EigenvalueDecomposition<Double>) EigenvalueDecomposition.makePrimitive());
        }

        @Override
        protected DiagonalAccess<Double> makeTridiagonal(final DiagonalAccess<Double> aBidiagonal, final boolean aNormalAspectRatio) {

            final int tmpMinDim = aBidiagonal.getMinDim();

            final Array1D<Double> tmpMain = Array1D.makePrimitive(tmpMinDim);
            final Array1D<Double> tmpOff = Array1D.makePrimitive(tmpMinDim - 1);

            final Array1D<Double> tmpPrim = aBidiagonal.mainDiagonal;
            final Array1D<Double> tmpSeco = aNormalAspectRatio ? aBidiagonal.superdiagonal : aBidiagonal.subdiagonal;

            double tmpThisPrim, tmpLastPrim, tmpLastSeco;

            tmpThisPrim = tmpPrim.doubleValue(0);
            tmpMain.set(0, tmpThisPrim * tmpThisPrim);

            for (int ij = 1; ij < tmpMinDim; ij++) {

                tmpLastPrim = tmpThisPrim;
                tmpThisPrim = tmpPrim.doubleValue(ij);

                tmpLastSeco = tmpSeco.doubleValue(ij - 1);

                tmpMain.set(ij, (tmpThisPrim * tmpThisPrim) + (tmpLastSeco * tmpLastSeco));
                tmpOff.set(ij - 1, tmpLastPrim * tmpLastSeco);
            }

            return DiagonalAccess.makePrimitive(tmpMain, tmpOff, tmpOff);
        }
    }

    private final EigenvalueDecomposition<N> myDelegateEigenvalue;
    private DecompositionStore<N> myInPlaceBidiagonal;
    private DiagonalAccess<N> mySimilar;
    private final N myZero;

    @SuppressWarnings("unused")
    private SVDnew2(final PhysicalStore.Factory<N> aFactory) {
        this(aFactory, null);
    }

    protected SVDnew2(final PhysicalStore.Factory<N> aFactory, final EigenvalueDecomposition<N> aDelegate) {

        super(aFactory);

        myDelegateEigenvalue = aDelegate;

        myZero = aFactory.getStaticZero().getNumber();
    }

    public final boolean compute(final Access2D<N> aStore) {

        this.reset();

        final boolean tmpNormalAspectRatio = this.aspectRatioNormal(aStore.getRowDim() >= aStore.getColDim());

        myInPlaceBidiagonal = this.copy(aStore);
        myInPlaceBidiagonal.computeInPlaceBidiagonal(tmpNormalAspectRatio);

        final Array2D<N> tmpArray2D = myInPlaceBidiagonal.asArray2D();

        final Array1D<N> tmpMain = tmpArray2D.sliceDiagonal(0, 0);

        if (tmpNormalAspectRatio) {
            final Array1D<N> tmpSuper = tmpArray2D.sliceDiagonal(0, 1);
            mySimilar = new DiagonalAccess<N>(tmpMain, tmpSuper, null, this.getStaticZero());
        } else {
            final Array1D<N> tmpSub = tmpArray2D.sliceDiagonal(1, 0);
            mySimilar = new DiagonalAccess<N>(tmpMain, null, tmpSub, this.getStaticZero());
        }

        myDelegateEigenvalue.computeTridiagonal(this.makeTridiagonal(mySimilar, tmpNormalAspectRatio));

        return this.computed(true);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public final MatrixStore<N> getD() {

        final Array1D<ComplexNumber> tmpEigenvalues = myDelegateEigenvalue.getEigenvalues();

        final int tmpDim = tmpEigenvalues.length;

        final PhysicalStore<N> retVal = this.makeZero(tmpDim, tmpDim);

        double tmpVal;
        for (int ij = 0; ij < tmpDim; ij++) {
            tmpVal = tmpEigenvalues.get(ij).getReal();
            if (tmpVal > PrimitiveMath.ZERO) {
                retVal.set(ij, ij, Math.sqrt(tmpVal));
            }
        }

        //    BasicLogger.logDebug("D", retVal);

        return retVal;
    }

    public final MatrixStore<N> getQ1() {

        final DecompositionStore<N> tmpV = (DecompositionStore<N>) myDelegateEigenvalue.getV().copy();

        final boolean tmpAspectRatioNormal = this.isAspectRatioNormal();

        if (tmpAspectRatioNormal) {
            this.solve(tmpV, this.getD(), mySimilar);

            //    BasicLogger.logDebug("ModifiedV", tmpV);

        } else {

            //    BasicLogger.logDebug("Plain V", tmpV);

        }

        final DecompositionStore.HouseholderReference<N> tmpReference = new DecompositionStore.HouseholderReference<N>(myInPlaceBidiagonal, true);

        final int tmpRowDim = myInPlaceBidiagonal.getRowDim();
        final int tmpColDim = myInPlaceBidiagonal.getMinDim();

        final DecompositionStore<N> tmpEye = this.makeEye(tmpRowDim, tmpColDim);

        if (this.isAspectRatioNormal()) {

            for (int ij = tmpColDim - 1; ij >= 0; ij--) {
                tmpReference.row = ij;
                tmpReference.col = ij;
                //                BasicLogger.logDebug("Applying from {}: {}", ij, tmpReference);
                tmpEye.transformLeft(tmpReference, ij);
                //                BasicLogger.logDebug("Increment", tmpEye.multiplyRight(tmpV));
            }
        } else {
            for (int ij = tmpColDim - 2; ij >= 0; ij--) {
                tmpReference.row = ij + 1;
                tmpReference.col = ij;
                //      BasicLogger.logDebug("Applying from {}: {}", ij, tmpReference);
                tmpEye.transformLeft(tmpReference, ij);
                //      BasicLogger.logDebug("Increment", tmpEye.multiplyRight(tmpV));
            }
        }

        return tmpEye.multiplyRight(tmpV);
    }

    public final MatrixStore<N> getQ2() {

        final DecompositionStore<N> tmpV = (DecompositionStore<N>) myDelegateEigenvalue.getV().copy();

        final boolean tmpAspectRatioNormal = this.isAspectRatioNormal();

        if (!tmpAspectRatioNormal) {
            this.solve(tmpV, this.getD(), mySimilar.transpose());

            //  BasicLogger.logDebug("Modified V", tmpV);

        } else {

            //     BasicLogger.logDebug("Plain V", tmpV);

        }

        final DecompositionStore.HouseholderReference<N> tmpReference = new DecompositionStore.HouseholderReference<N>(myInPlaceBidiagonal, false);

        final int tmpRowDim = myInPlaceBidiagonal.getColDim();
        final int tmpColDim = myInPlaceBidiagonal.getMinDim();

        final DecompositionStore<N> tmpEye = this.makeEye(tmpRowDim, tmpColDim);

        if (this.isAspectRatioNormal()) {
            for (int ij = tmpColDim - 2; ij >= 0; ij--) {
                tmpReference.row = ij;
                tmpReference.col = ij + 1;
                //                BasicLogger.logDebug("Applying from {}: {}", ij, tmpReference);
                tmpEye.transformLeft(tmpReference, ij);
                //                BasicLogger.logDebug("Increment", tmpEye.multiplyRight(tmpV));
            }
        } else {
            for (int ij = tmpColDim - 1; ij >= 0; ij--) {
                tmpReference.row = ij;
                tmpReference.col = ij;
                //                BasicLogger.logDebug("Applying from {}: {}", ij, tmpReference);
                tmpEye.transformLeft(tmpReference, ij);
                //                BasicLogger.logDebug("Increment", tmpEye.multiplyRight(tmpV));
            }
        }

        return tmpEye.multiplyRight(tmpV);
    }

    public final Array1D<Double> getSingularValues() {

        final Array1D<ComplexNumber> tmpEigenvalues = myDelegateEigenvalue.getEigenvalues();

        final int tmpDim = tmpEigenvalues.length;

        final Array1D<Double> retVal = Array1D.makePrimitive(tmpDim);
        double tmpVal;
        for (int ij = 0; ij < tmpDim; ij++) {
            tmpVal = tmpEigenvalues.get(ij).getReal();
            if (tmpVal > PrimitiveMath.ZERO) {
                retVal.set(ij, Math.sqrt(tmpVal));
            }
        }
        retVal.sortDescending();

        return retVal;
    }

    public final boolean isFullSize() {
        return false;
    }

    public final boolean isOrdered() {
        return true;
    }

    public final boolean isSolvable() {
        return this.isComputed();
    }

    @Override
    public final void reset() {

        super.reset();

        if (myDelegateEigenvalue != null) {
            myDelegateEigenvalue.reset();
        }

        myInPlaceBidiagonal = null;
        mySimilar = null;
    }

    public final MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        return this.getInverse().multiplyRight(aRHS);
    }

    /**
     * Will solve the equation system [aV][aD][X]=[aSimilar]<sup>T</sup> and overwrite the solution [X] to [aV].
     */
    private void solve(final PhysicalStore<N> aV, final MatrixStore<N> aD, final DiagonalAccess<N> aSimilar) {

        final int tmpDim = aV.getRowDim();
        final int tmpLim = tmpDim - 1;

        double tmpSingular;
        for (int j = 0; j < tmpDim; j++) {
            tmpSingular = aD.doubleValue(j, j);
            if (TypeUtils.isZero(tmpSingular)) {
                for (int i = 0; i < tmpDim; i++) {
                    aV.set(i, j, myZero);
                }
            } else {
                for (int i = 0; i < tmpLim; i++) {
                    aV.set(i, j, (aSimilar.doubleValue(i, i) * aV.doubleValue(i, j) + aSimilar.doubleValue(i, i + 1) * aV.doubleValue(i + 1, j)) / tmpSingular);
                }
                aV.set(tmpLim, j, (aSimilar.doubleValue(tmpLim, tmpLim) * aV.doubleValue(tmpLim, j)) / tmpSingular);
            }
        }
    }

    protected abstract DiagonalAccess<N> makeTridiagonal(DiagonalAccess<N> aBidiagonal, boolean aNormalAspectRatio);

}
