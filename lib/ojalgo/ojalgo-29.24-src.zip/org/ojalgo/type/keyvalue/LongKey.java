/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.type.keyvalue;

import java.io.Serializable;

import org.ojalgo.netio.ASCII;

public final class LongKey<V extends Object> extends Object implements Comparable<LongKey<V>>, Serializable, Cloneable {

    public final long key;
    public final V value;

    public LongKey(final long aKey, final V aValue) {

        super();

        key = aKey;
        value = aValue;
    }

    public LongKey(final Long aKey, final V aValue) {

        super();

        key = aKey != null ? aKey : 0l;
        value = aValue;
    }

    LongKey() {
        this(0l, null);
    }

    public final int compareTo(final LongKey<V> aReference) {
        return (key < aReference.key ? -1 : (key == aReference.key ? 0 : 1));
    }

    @Override
    public final boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        final LongKey<V> other = (LongKey<V>) obj;
        if (key != other.key) {
            return false;
        }
        return true;
    }

    @Override
    public final int hashCode() {
        return (int) (key ^ (key >>> 32));
    }

    @Override
    public final String toString() {
        return String.valueOf(key) + String.valueOf(ASCII.EQUALS) + String.valueOf(value);
    }

    @Override
    protected final Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

}
