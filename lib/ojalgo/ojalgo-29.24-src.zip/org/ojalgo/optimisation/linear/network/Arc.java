/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation.linear.network;

import org.ojalgo.ProgrammingError;
import org.ojalgo.optimisation.Variable;

/**
 * Arc
 *
 * @author apete
 */
public final class Arc extends Variable {

    private final Node myOrigin;
    private final Node myDestination;

    public Arc(final Node anOrigin, final Node aDestination) {

        super(anOrigin.getName() + "-" + aDestination.getName());

        myOrigin = anOrigin;
        myDestination = aDestination;
    }

    public Arc(final String aName, final Node anOrigin, final Node aDestination) {

        super(aName + ":" + anOrigin.getName() + "-" + aDestination.getName());

        myOrigin = anOrigin;
        myDestination = aDestination;
    }

    @SuppressWarnings("unused")
    private Arc(final String aName) {

        this(null, null);

        ProgrammingError.throwForIllegalInvocation();
    }

    public final Node getDestination() {
        return myDestination;
    }

    public final Node getOrigin() {
        return myOrigin;
    }

}
