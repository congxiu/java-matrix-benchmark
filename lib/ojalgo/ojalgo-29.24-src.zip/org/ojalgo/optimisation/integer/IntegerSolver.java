/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation.integer;

import static org.ojalgo.constant.PrimitiveMath.*;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.ojalgo.ProgrammingError;
import org.ojalgo.RecoverableCondition;
import org.ojalgo.concurrent.ConcurrentExecutor;
import org.ojalgo.function.multiary.CompoundFunction;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.SelectedRowsStore;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.optimisation.GenericSolver;
import org.ojalgo.optimisation.OptimisationModel;
import org.ojalgo.optimisation.OptimisationSolver;
import org.ojalgo.optimisation.State;

/**
 * IntegerSolver
 *
 * @author apete
 */
public abstract class IntegerSolver extends GenericSolver {

    public static final class Builder extends GenericSolver.Matrices<Builder> implements OptimisationSolver.Builder<IntegerSolver> {

        private final ExpressionsBasedModel<?> myModel;

        public Builder(final ExpressionsBasedModel<?> aModel) {

            super();

            myModel = aModel;
        }

        @SuppressWarnings("unused")
        private Builder() {

            super();

            myModel = null;

            ProgrammingError.throwForIllegalInvocation();
        }

        @SuppressWarnings("unused")
        private Builder(final Matrices<?> aMatrices) {

            super(aMatrices);

            myModel = null;

            ProgrammingError.throwForIllegalInvocation();
        }

        @SuppressWarnings("unused")
        private Builder(final MatrixStore<Double>[] aMtrxArr) {

            super(aMtrxArr);

            myModel = null;

            ProgrammingError.throwForIllegalInvocation();
        }

        public IntegerSolver build() {
            if (myModel.isAnyExpressionQuadratic()) {
                return new QuadraticIntegerSolver(myModel);
            } else {
                return new LinearIntegerSolver(myModel);
            }
        }

    }

    static final class IntermediateResult extends OptimisationSolver.Result implements Comparable<IntermediateResult> {

        private final double myValue; //Objective Function Value

        private IntermediateResult(final State aState, final MatrixStore<Double> aSolution, final int anIterationCount) {

            super(aState, aSolution, anIterationCount);

            myValue = Double.NaN;

            ProgrammingError.throwForIllegalInvocation();
        }

        IntermediateResult(final double aValue, final MatrixStore<Double> aSolution, final int anIterationCount) {

            super(State.ITERATION, aSolution, anIterationCount);

            myValue = aValue;
        }

        IntermediateResult(final OptimisationSolver.Result aResult) {

            super(aResult.getState(), aResult.getSolution().toPrimitiveStore(), aResult.getIterationsCount());

            myValue = NaN;
        }

        public int compareTo(final IntermediateResult anotherResult) {

            final double tmpReference = anotherResult.getValue();

            if (myValue > tmpReference) {
                return 1;
            } else if (myValue < tmpReference) {
                return -1;
            } else {
                return 0;
            }
        }

        @Override
        public String toString() {
            return myValue + " <= " + super.toString();
        }

        final double getValue() {
            return myValue;
        }

    }

    static IntermediateResult solve(final ExpressionsBasedModel<?> aModel, final IntegerSolver aSolver) {

        //            BasicLogger.logDebug("IntegerIterationModel");
        //            BasicLogger.logDebug(aModel.toString());

        if (aSolver.isOkToContinue()) {

            final OptimisationSolver.Result tmpResult = aModel.getDefaultSolver().solve();
            try {
                aSolver.incrementIterationsCount();
            } catch (final RecoverableCondition anException) {
                anException.printStackTrace();
            }

            if (tmpResult.getState().isNotLessThan(State.OPTIMAL)) {
                // Solved to optimality!

                final PhysicalStore<Double> tmpSolution = tmpResult.getSolution().toPrimitiveStore();

                final int tmpBranchIndex = aSolver.identifyNonIntegerVariable(tmpSolution);
                final double tmpSolutionValue = aSolver.evaluateSolution(tmpSolution);

                if (tmpBranchIndex == -1) {
                    // Integer solution! Store it among the others, and stop this branch!

                    //           BasicLogger.logDebug("Integer solution! Store it among the others, and stop this branch!");

                    final IntermediateResult tmpArg0 = new IntermediateResult(tmpSolutionValue, tmpSolution, aSolver.getIterationsCount());

                    aSolver.add(tmpArg0);

                    final IntermediateResult tmpInterRes = aSolver.getBestResultSoFar();

                    if (tmpInterRes != null) {
                        if (aModel.isMinimisation()) {
                            aModel.getObjectiveExpression().setUpperLimit(aSolver.options.problemContext.toBigDecimal(tmpInterRes.getValue()));
                        } else {
                            aModel.getObjectiveExpression().setLowerLimit(aSolver.options.problemContext.toBigDecimal(tmpInterRes.getValue()));
                        }
                    }

                } else {
                    // Not an Integer Solution

                    final double tmpVariableValue = tmpSolution.doubleValue(tmpBranchIndex, 0);

                    //    BasicLogger.logDebug("Not an Integer Solution: " + tmpSolutionValue + ", branching on " + tmpBranchIndex + " @ " + tmpVariableValue);

                    if (aSolver.isGoodEnoughToContinueBranching(tmpSolutionValue)) {
                        // Still hope for a better integer solution

                        final BigDecimal tmpUpperLimitForLowerBranch = new BigDecimal(Math.floor(tmpVariableValue));
                        final BigDecimal tmpLowerLimitForUpperBranch = new BigDecimal(Math.ceil(tmpVariableValue));

                        //        BasicLogger.logDebug("<= {} & {} <=", tmpUpperLimitForLowerBranch, tmpLowerLimitForUpperBranch);

                        final boolean tmpBranchInSeparateThread = ConcurrentExecutor.INSTANCE.isProcessorAvailable();

                        if (tmpBranchInSeparateThread) {

                            final Future<?> tmpLowerBranchProblem = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                                public void run() {

                                    final ExpressionsBasedModel<?> tmpLowerBranchModel = aModel.copy();
                                    tmpLowerBranchModel.setUpperLimitOnVariable(tmpBranchIndex, tmpUpperLimitForLowerBranch);

                                    IntegerSolver.solve(tmpLowerBranchModel, aSolver);
                                }
                            });

                            final Future<?> tmpUpperBranchProblem = ConcurrentExecutor.INSTANCE.submit(new Runnable() {

                                public void run() {

                                    final ExpressionsBasedModel<?> tmpUpperBranchModel = aModel.copy();
                                    tmpUpperBranchModel.setLowerLimitOnVariable(tmpBranchIndex, tmpLowerLimitForUpperBranch);
                                    IntegerSolver.solve(tmpUpperBranchModel, aSolver);
                                }
                            });

                            try {
                                tmpLowerBranchProblem.get();
                                tmpUpperBranchProblem.get();
                            } catch (final InterruptedException anException) {
                                anException.printStackTrace();
                            } catch (final ExecutionException anException) {
                                anException.printStackTrace();
                            }

                        } else {

                            final BigDecimal tmpOldLowerLimit = aModel.getVariable(tmpBranchIndex).getLowerLimit();
                            final BigDecimal tmpOldUpperLimit = aModel.getVariable(tmpBranchIndex).getUpperLimit();

                            final ExpressionsBasedModel<?> tmpLowerBranchModel = aModel;
                            tmpLowerBranchModel.setUpperLimitOnVariable(tmpBranchIndex, tmpUpperLimitForLowerBranch);
                            IntegerSolver.solve(tmpLowerBranchModel, aSolver);
                            tmpLowerBranchModel.setUpperLimitOnVariable(tmpBranchIndex, tmpOldUpperLimit);

                            final ExpressionsBasedModel<?> tmpUpperBranchModel = aModel;
                            tmpUpperBranchModel.setLowerLimitOnVariable(tmpBranchIndex, tmpLowerLimitForUpperBranch);
                            IntegerSolver.solve(tmpUpperBranchModel, aSolver);
                            tmpUpperBranchModel.setLowerLimitOnVariable(tmpBranchIndex, tmpOldLowerLimit);
                        }

                    } else {

                        //     BasicLogger.logDebug("Can't find better integer solutions - stop this branch!");

                    }
                }
            } else {

                //  BasicLogger.logDebug("Failed to solve problem - stop this branch!");

            }
        } else {

            //    BasicLogger.logDebug("Reached iterations or time limit - stop!");

        }

        return aSolver.getBestResultSoFar();
    }

    private final boolean[] myIntegers;

    private final SortedSet<IntermediateResult> myIntermediateResults = Collections.synchronizedSortedSet(new TreeSet<IntermediateResult>());

    private final ExpressionsBasedModel<?> myModel;
    private final CompoundFunction<Double> myObjectiveFunction;

    protected IntegerSolver(final ExpressionsBasedModel<?> aModel) {

        super();

        myModel = aModel;
        myIntegers = aModel.getIntegers();
        myObjectiveFunction = aModel.getObjectiveExpression().toPrimitiveFunction();
    }

    public final Result solve() {

        this.resetIterationsCount();

        IntegerSolver.solve(myModel.copy().relax(), this);

        return new Result(this.getBestResultSoFar(), State.OPTIMAL);
    }

    public Result solve(final OptimisationModel aValidationModel) {

        this.resetIterationsCount();

        IntegerSolver.solve(myModel.copy().relax(), this);

        return new Result(this.getBestResultSoFar(), State.OPTIMAL);
    }

    protected final double evaluateSolution(final MatrixStore<Double> anArg) {

        final int[] tmpIndeces = MatrixUtils.makeIncreasingRange(0, myModel.countVariables());

        return myObjectiveFunction.invoke(new SelectedRowsStore<Double>(anArg, tmpIndeces)).doubleValue();
    }

    @Override
    protected boolean needsAnotherIteration() {
        // TODO Auto-generated method stub
        return false;
    }

    synchronized boolean add(final IntermediateResult aResult) {

        //    BasicLogger.logDebug("Latest solution: {}", aResult);

        final boolean retVal = myIntermediateResults.add(aResult);
        final IntermediateResult tmpBestResultSoFar = this.getBestResultSoFar();

        //    BasicLogger.logDebug("Best solution  : {}", tmpBestResultSoFar);

        return retVal;
    }

    synchronized IntermediateResult getBestResultSoFar() {
        if (myIntermediateResults.size() == 0) {
            return null;
        } else if (myModel.isMaximisation()) {
            return myIntermediateResults.last();
        } else if (myModel.isMinimisation()) {
            return myIntermediateResults.first();
        } else {
            return null;
        }
    }

    synchronized int identifyNonIntegerVariable(final MatrixStore<Double> aSolution) {

        int retVal = -1;

        final double tmpTolerance = options.solutionContext.getError();

        double tmpValue;
        double tmpFraction;
        double tmpMaxFraction = ZERO;

        for (int i = 0; i < myIntegers.length; i++) {

            tmpValue = aSolution.doubleValue(i, 0);
            tmpFraction = Math.abs(tmpValue - Math.rint(tmpValue));

            if (myIntegers[i] && !(tmpFraction <= tmpTolerance) && (tmpFraction > tmpMaxFraction)) {
                retVal = i;
                tmpMaxFraction = tmpFraction;
            }
        }

        return retVal;
    }

    synchronized boolean isGoodEnoughToContinueBranching(final double aValue) {

        final IntermediateResult tmpResult = this.getBestResultSoFar();

        if (tmpResult == null) {
            return true;
        } else {
            if (myModel.isMinimisation()) {
                return (aValue < tmpResult.getValue());
            } else {
                return (aValue > tmpResult.getValue());
            }
        }
    }

}
