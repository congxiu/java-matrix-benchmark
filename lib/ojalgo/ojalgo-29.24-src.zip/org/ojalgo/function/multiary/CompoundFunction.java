/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.function.multiary;

import java.math.BigDecimal;

import org.ojalgo.access.Access1D;
import org.ojalgo.access.Access2D;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PhysicalStore.Factory;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;

public final class CompoundFunction<N extends Number> extends AbstractMultiary<N> {

    public static CompoundFunction<BigDecimal> makeBig(final Access2D<? extends Number> someQuadParams, final Access1D<? extends Number> someLinearParams) {
        final QuadraticFunction<BigDecimal> tmpQuadratic = QuadraticFunction.makeBig(someQuadParams);
        final LinearFunction<BigDecimal> tmpLinear = LinearFunction.makeBig(someLinearParams);
        return new CompoundFunction<BigDecimal>(tmpQuadratic, tmpLinear);
    }

    public static CompoundFunction<BigDecimal> makeBig(final int aDim) {
        final QuadraticFunction<BigDecimal> tmpQuadratic = QuadraticFunction.makeBig(aDim);
        final LinearFunction<BigDecimal> tmpLinear = LinearFunction.makeBig(aDim);
        return new CompoundFunction<BigDecimal>(tmpQuadratic, tmpLinear);
    }

    public static CompoundFunction<BigDecimal> makeBigCopy(final CompoundFunction<? extends Number> aCompound) {
        final QuadraticFunction<BigDecimal> tmpQuadratic = QuadraticFunction.makeBigCopy(aCompound.getQuadratic());
        final LinearFunction<BigDecimal> tmpLinear = LinearFunction.makeBigCopy(aCompound.getLinear());
        return new CompoundFunction<BigDecimal>(tmpQuadratic, tmpLinear);
    }

    public static CompoundFunction<ComplexNumber> makeComplex(final Access2D<? extends Number> someQuadParams, final Access1D<? extends Number> someLinearParams) {
        final QuadraticFunction<ComplexNumber> tmpQuadratic = QuadraticFunction.makeComplex(someQuadParams);
        final LinearFunction<ComplexNumber> tmpLinear = LinearFunction.makeComplex(someLinearParams);
        return new CompoundFunction<ComplexNumber>(tmpQuadratic, tmpLinear);
    }

    public static CompoundFunction<ComplexNumber> makeComplex(final int aDim) {
        final QuadraticFunction<ComplexNumber> tmpQuadratic = QuadraticFunction.makeComplex(aDim);
        final LinearFunction<ComplexNumber> tmpLinear = LinearFunction.makeComplex(aDim);
        return new CompoundFunction<ComplexNumber>(tmpQuadratic, tmpLinear);
    }

    public static CompoundFunction<ComplexNumber> makeComplexCopy(final CompoundFunction<? extends Number> aCompound) {
        final QuadraticFunction<ComplexNumber> tmpQuadratic = QuadraticFunction.makeComplexCopy(aCompound.getQuadratic());
        final LinearFunction<ComplexNumber> tmpLinear = LinearFunction.makeComplexCopy(aCompound.getLinear());
        return new CompoundFunction<ComplexNumber>(tmpQuadratic, tmpLinear);
    }

    public static CompoundFunction<Double> makePrimitive(final Access2D<? extends Number> someQuadParams, final Access1D<? extends Number> someLinearParams) {
        final QuadraticFunction<Double> tmpQuadratic = QuadraticFunction.makePrimitive(someQuadParams);
        final LinearFunction<Double> tmpLinear = LinearFunction.makePrimitive(someLinearParams);
        return new CompoundFunction<Double>(tmpQuadratic, tmpLinear);
    }

    public static CompoundFunction<Double> makePrimitive(final int aDim) {
        final QuadraticFunction<Double> tmpQuadratic = QuadraticFunction.makePrimitive(aDim);
        final LinearFunction<Double> tmpLinear = LinearFunction.makePrimitive(aDim);
        return new CompoundFunction<Double>(tmpQuadratic, tmpLinear);
    }

    public static CompoundFunction<Double> makePrimitiveCopy(final CompoundFunction<? extends Number> aCompound) {
        final QuadraticFunction<Double> tmpQuadratic = QuadraticFunction.makePrimitiveCopy(aCompound.getQuadratic());
        final LinearFunction<Double> tmpLinear = LinearFunction.makePrimitiveCopy(aCompound.getLinear());
        return new CompoundFunction<Double>(tmpQuadratic, tmpLinear);
    }

    private N myConstant;
    private LinearFunction<N> myLinear;
    private QuadraticFunction<N> myQuadratic;

    public CompoundFunction(final QuadraticFunction<N> aQuadratic, final LinearFunction<N> aLinear) {

        super();

        myQuadratic = aQuadratic;
        myLinear = aLinear;
    }

    @SuppressWarnings("unused")
    private CompoundFunction() {
        this((QuadraticFunction<N>) null, (LinearFunction<N>) null);
    }

    CompoundFunction(final PhysicalStore<N> aQuadratic, final PhysicalStore<N> aLinear) {

        super();

        myQuadratic = new QuadraticFunction<N>(aQuadratic);
        myLinear = new LinearFunction<N>(aLinear);
    }

    public int dim() {
        if (myQuadratic != null) {
            return myQuadratic.dim();
        } else {
            return myLinear.dim();
        }

    }

    public N getConstant() {
        return myConstant;
    }

    public LinearFunction<N> getLinear() {
        return myLinear;
    }

    public N getLinearFactor(final int aVar) {
        return myLinear.getFactor(aVar);
    }

    public QuadraticFunction<N> getQuadratic() {
        return myQuadratic;
    }

    public N getQuadraticFactor(final int aVar1, final int aVar2) {
        return myQuadratic.getFactor(aVar1, aVar2);
    }

    public boolean hasConstant() {
        return (myConstant != null);
    }

    public boolean hasLinear() {
        return (myLinear != null);
    }

    public boolean hasQuadratic() {
        return (myQuadratic != null);
    }

    @Override
    public N invoke(final MatrixStore<N> anArg) {

        Scalar<N> retVal = this.getFactory().getStaticZero();

        if (myConstant != null) {
            retVal = retVal.add(myConstant);
        }

        if (myLinear != null) {
            retVal = retVal.add(myLinear.invoke(anArg));
        }

        if (myQuadratic != null) {
            retVal = retVal.add(myQuadratic.invoke(anArg));
        }

        return retVal.getNumber();
    }

    public void setConstant(final N aConstant) {
        myConstant = aConstant;
    }

    public void setLinearFactor(final int aVar, final N aValue) {
        myLinear.setFactor(aVar, aValue);
    }

    public void setQuadraticFactor(final int aVar1, final int aVar2, final N aValue) {
        myQuadratic.setFactor(aVar1, aVar2, aValue);
    }

    @Override
    protected Factory<N> getFactory() {
        if (myQuadratic != null) {
            return myQuadratic.getFactory();
        } else if (myLinear != null) {
            return myLinear.getFactory();
        } else {
            return null;
        }
    }

}
