/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.data;

import java.io.BufferedReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import org.ojalgo.ProgrammingError;
import org.ojalgo.netio.ResourceLocator;
import org.ojalgo.series.CalendarSeries;
import org.ojalgo.series.DateSeries;
import org.ojalgo.type.CalendarDateUnit;
import org.ojalgo.type.colour.Colour;

abstract class DataSource {

    static void copy(final List<DatePrice> aSource, final CalendarSeries<BigDecimal> aDestination) {
        for (final DatePrice tmpDatePrice : aSource) {
            final GregorianCalendar tmpCalendar = new GregorianCalendar();
            tmpCalendar.setTime(tmpDatePrice.getDate());
            aDestination.put(tmpCalendar, tmpDatePrice.getPrice());
        }
    }

    static void copy(final List<DatePrice> aSource, final DateSeries<BigDecimal> aDestination) {
        for (final DatePrice tmpDatePrice : aSource) {
            aDestination.put(tmpDatePrice.getDate(), tmpDatePrice.getPrice());
        }
    }

    private final ResourceLocator myResourceLocator = new ResourceLocator();
    private final String mySymbol;
    private final CalendarDateUnit myTimeUnit;

    @SuppressWarnings("unused")
    private DataSource() {

        this(null, null);

        ProgrammingError.throwForIllegalInvocation();
    }

    protected DataSource(final String aSymbol, final CalendarDateUnit aTimeUnit) {

        super();

        mySymbol = aSymbol;
        myTimeUnit = aTimeUnit;
    }

    public DateSeries<BigDecimal> getPriceSeries() {
        return this.getPriceSeries(myResourceLocator.getStreamReader());
    }

    public DateSeries<BigDecimal> getPriceSeries(final BufferedReader aReader) {

        final DateSeries<BigDecimal> retVal = new DateSeries<BigDecimal>(myTimeUnit).name(mySymbol).colour(Colour.random());

        final List<DatePrice> tmpHistoricalPrices = this.getHistoricalPrices(aReader);

        DataSource.copy(tmpHistoricalPrices, retVal);

        return retVal;
    }

    public String getSymbol() {
        return mySymbol;
    }

    public CalendarDateUnit getTimeUnit() {
        return myTimeUnit;
    }

    protected String addQueryParameter(final String aKey, final String aValue) {
        return myResourceLocator.addQueryParameter(aKey, aValue);
    }

    protected abstract DatePrice parse(String aLine);

    protected void setHost(final String aHost) {
        myResourceLocator.setHost(aHost);
    }

    protected void setPath(final String aPath) {
        myResourceLocator.setPath(aPath);
    }

    List<DatePrice> getHistoricalPrices() {
        return this.getHistoricalPrices(myResourceLocator.getStreamReader());
    }

    List<DatePrice> getHistoricalPrices(final BufferedReader aReader) {

        final ArrayList<DatePrice> retVal = new ArrayList<DatePrice>();

        if (aReader != null) {
            String tmpLine;
            DatePrice tmpHistPrice;
            try {
                tmpLine = aReader.readLine();

                //   BasicLogger.logDebug(tmpLine);

                while ((tmpLine = aReader.readLine()) != null) {

                    //    BasicLogger.logDebug(tmpLine);

                    tmpHistPrice = this.parse(tmpLine);
                    retVal.add(tmpHistPrice);
                }
                aReader.close();
            } catch (final IOException anException) {
                anException.printStackTrace();
            }
        } else {
            retVal.add(DatePrice.DEFAULT);
        }

        return retVal;
    }

}
