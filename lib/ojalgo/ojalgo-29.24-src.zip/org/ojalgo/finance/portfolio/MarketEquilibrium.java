/*
 * Copyright 2003-2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.finance.portfolio;

import java.math.BigDecimal;

import org.ojalgo.ProgrammingError;
import org.ojalgo.array.ArrayUtils;
import org.ojalgo.function.implementation.BigFunction;
import org.ojalgo.matrix.BasicMatrix;

/**
 * MarketEquilibrium translates between the market portfolio weights
 * and the equilibrium excess returns. The only things needed to do
 * those translations are the covariance matrix and the risk aversion
 * factor - that's what you need to supply when you instantiate this
 * class.
 *
 * @see #calculateReturns(BasicMatrix)
 * @see #calculateWeights(BasicMatrix)
 * 
 * @author apete
 */
public class MarketEquilibrium {

    private static final String SYMBOL = "Asset_";

    /**
     * Calculates the portfolio return using the input portfolio weights and
     * returns.
     */
    public static BigDecimal calculatePortfolioReturn(final BasicMatrix aWeightsVctr, final BasicMatrix aReturnsVctr) {
        return aWeightsVctr.multiplyVectors(aReturnsVctr).toBigDecimal();
    }

    private static String[] makeSymbols(final int aDim) {

        final String[] retVal = new String[aDim];

        for (int i = 0; i < retVal.length; i++) {
            retVal[i] = SYMBOL + Integer.toString(i);
        }

        return retVal;
    }

    private final BasicMatrix myCovariances;
    private BigDecimal myRiskAversion;
    private final String[] mySymbols;

    public MarketEquilibrium(final BasicMatrix aCovariances, final BigDecimal aRiskAversion) {
        this(MarketEquilibrium.makeSymbols(aCovariances.getRowDim()), aCovariances, aRiskAversion);
    }

    public MarketEquilibrium(final String[] someInstrumentNames, final BasicMatrix aCovariances, final BigDecimal aRiskAversion) {

        super();

        mySymbols = ArrayUtils.copyOf(someInstrumentNames);
        myCovariances = aCovariances;
        myRiskAversion = aRiskAversion;
    }

    @SuppressWarnings("unused")
    private MarketEquilibrium() {

        this(null, null, null);

        ProgrammingError.throwForIllegalInvocation();
    }

    MarketEquilibrium(final MarketEquilibrium aMarket) {
        this(aMarket.getSymbols(), aMarket.getCovariances(), aMarket.getRiskAversion());
    }

    /**
     * Calculates the portfolio variance using the input portfolio weights.
     */
    public BigDecimal calculatePortfolioVariance(final BasicMatrix aWeightsVctr) {

        BasicMatrix tmpLeft;
        BasicMatrix tmpRight;

        if (aWeightsVctr.getColDim() == 1) {
            tmpLeft = aWeightsVctr.transpose();
            tmpRight = aWeightsVctr;
        } else {
            tmpLeft = aWeightsVctr;
            tmpRight = aWeightsVctr.transpose();
        }

        return myCovariances.multiplyRight(tmpRight).multiplyLeft(tmpLeft).toBigDecimal(0, 0);
    }

    /**
     * If the input vector of portfolio weights are the market portfolio
     * weights then the ouput is the equilibrium excess returns.
     */
    public BasicMatrix calculateReturns(final BasicMatrix aWeightsVctr) {
        return myCovariances.multiplyRight(aWeightsVctr.multiply(myRiskAversion));
    }

    /**
     * If the input vector of returns are the equilibrium excess returns
     * then the output is the market portfolio weights. This is
     * unconstrained optimisation - there are no constraints on the
     * resulting instrument weights.
     */
    public BasicMatrix calculateWeights(final BasicMatrix aReturnsVctr) {
        return myCovariances.solve(aReturnsVctr).divide(myRiskAversion);
    }

    public MarketEquilibrium copy() {
        return new MarketEquilibrium(this);
    }

    public BasicMatrix getCovariances() {
        return myCovariances;
    }

    /**
     * Will calculate the risk aversion factor that is the best fit for
     * an observed pair of market portfolio weights and equilibrium/historical
     * excess returns.
     */
    public BigDecimal getImpliedRiskAversion(final BasicMatrix aWeightsVctr, final BasicMatrix aReturnsVctr) {

        BasicMatrix tmpLHS = myCovariances.multiplyRight(aWeightsVctr);
        final BasicMatrix tmpTranspose = tmpLHS.transpose();

        tmpLHS = tmpLHS.multiplyLeft(tmpTranspose);
        final BasicMatrix tmpRHS = aReturnsVctr.multiplyLeft(tmpTranspose);

        return BigFunction.DIVIDE.invoke(tmpRHS.toBigDecimal(0, 0), tmpLHS.toBigDecimal(0, 0));
    }

    public BigDecimal getRiskAversion() {
        return myRiskAversion;
    }

    public String[] getSymbols() {
        return ArrayUtils.copyOf(mySymbols);
    }

    /**
     * Will set the risk aversion factor to the best fit for an observed
     * pair of market portfolio weights and equilibrium/historical excess
     * returns.
     */
    public void setRiskAversion(final BasicMatrix aWeightsVctr, final BasicMatrix aReturnsVctr) {
        myRiskAversion = this.getImpliedRiskAversion(aWeightsVctr, aReturnsVctr);
    }

    public void setRiskAversion(final BigDecimal aFactor) {
        myRiskAversion = aFactor;
    }

}
