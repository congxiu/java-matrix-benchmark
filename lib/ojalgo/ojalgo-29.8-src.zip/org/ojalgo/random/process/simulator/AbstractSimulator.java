/* 
 * Copyright © 2010 Optimatika (www.optimatika.se)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE. 
 */
package org.ojalgo.random.process.simulator;

import static org.ojalgo.constant.PrimitiveMath.*;

import org.ojalgo.array.Array2D;
import org.ojalgo.random.SampleSet;
import org.ojalgo.random.process.RandomProcess;

abstract class AbstractSimulator<P extends RandomProcess> implements ProcessSimulator {

    private final P myProcess;

    @SuppressWarnings("unused")
    private AbstractSimulator() {
        this(null);
    }

    protected AbstractSimulator(final P aProcess) {

        super();

        myProcess = aProcess;
    }

    public SampleSet[] simulate(final int aNumberOfRealisations, final double aStepSize, final int aNumberOfSimulationSteps) {

        final SampleSet[] retVal = new SampleSet[aNumberOfSimulationSteps];

        final Array2D<Double> tmpRealisationValues = Array2D.makePrimitive(aNumberOfRealisations, aNumberOfSimulationSteps);

        for (int r = 0; r < aNumberOfRealisations; r++) {
            this.restoreInitialState();
            for (int s = 0; s < aNumberOfSimulationSteps; s++) {
                this.getProcess().step(aStepSize);
                tmpRealisationValues.set(r, s, this.getProcess().getCurrentValue());
            }
        }

        for (int s = 0; s < aNumberOfSimulationSteps; s++) {
            retVal[s] = new SampleSet(tmpRealisationValues.sliceColumn(0, s));
        }

        return retVal;
    }

    public SampleSet[] simulate(final int aNumberOfRealisations, final int aNumberOfSimulationSteps) {
        return this.simulate(aNumberOfRealisations, ONE, aNumberOfSimulationSteps);
    }

    protected final P getProcess() {
        return myProcess;
    }

    protected abstract void restoreInitialState();

}
