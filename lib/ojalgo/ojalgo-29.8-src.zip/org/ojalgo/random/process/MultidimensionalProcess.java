/*
 * Copyright © 2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.random.process;

import static org.ojalgo.constant.PrimitiveMath.*;

import java.util.List;

import org.ojalgo.matrix.decomposition.Cholesky;
import org.ojalgo.matrix.decomposition.CholeskyDecomposition;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;

/**
 * @author apete
 */
public class MultidimensionalProcess implements RandomProcess {

    private final MatrixStore<Double> myCholeskiedCorrelationsMatrix;
    private final DiffusionProcess[] myProcesses;

    public MultidimensionalProcess(final MatrixStore<Double> aCorrelationsMatrix, final DiffusionProcess[] someProcesses) {

        super();

        final Cholesky<Double> tmpCholesky = CholeskyDecomposition.makePrimitive();

        tmpCholesky.compute(aCorrelationsMatrix);

        myCholeskiedCorrelationsMatrix = tmpCholesky.getL();
        myProcesses = someProcesses;

        tmpCholesky.reset();
    }

    public MultidimensionalProcess(final MatrixStore<Double> aCorrelationsMatrix, final List<DiffusionProcess> someProcesses) {
        this(aCorrelationsMatrix, someProcesses.toArray(new DiffusionProcess[someProcesses.size()]));
    }

    @SuppressWarnings("unused")
    private MultidimensionalProcess() {
        this(null, (DiffusionProcess[]) null);
    }

    public int dim() {
        return myProcesses.length;
    }

    public double getCurrentValue() {

        double retVal = ZERO;

        final int tmpLength = myProcesses.length;
        for (int i = 0; i < tmpLength; i++) {
            retVal += myProcesses[i].getCurrentValue();
        }

        return retVal;
    }

    public DiffusionProcess getDiffusionProcess(final int index) {
        return myProcesses[index];
    }

    public double step() {
        return this.step(ONE);
    }

    public double step(final double aStepSize) {

        final int tmpLength = myProcesses.length;

        final PhysicalStore<Double> tmpSteps = PrimitiveDenseStore.FACTORY.makeEmpty(tmpLength, 1);

        for (int i = 0; i < tmpLength; i++) {
            tmpSteps.set(i, 0, myProcesses[i].generateStep(aStepSize));
        }

        final MatrixStore<Double> tmpCorreSteps = tmpSteps.multiplyLeft(myCholeskiedCorrelationsMatrix);

        double retVal = ZERO;
        for (int i = 0; i < tmpLength; i++) {
            retVal = Math.hypot(retVal, myProcesses[i].updateState(tmpCorreSteps.doubleValue(i, 0)));
        }

        return retVal;
    }

}
