/*
 * Copyright © 2005 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.random.process;

import static org.ojalgo.constant.PrimitiveMath.*;

import org.ojalgo.random.SampleSet;
import org.ojalgo.series.TimeInMillisSeries;
import org.ojalgo.type.CalendarDateUnit;

/**
 * Diffusion process defined by a stochastic differential equation
 * 
 * dX = r X dt + s X dW
 *
 * @author apete
 */
public class DiffusionProcess implements RandomProcess {

    private static WienerProcess WIENER = new WienerProcess();

    /**
     * @param aSampleSet Some sampled data
     * @param aStepSize The number of millis inbetween each sample
     * @param aTimeUnit You have to specify with what unit the process
     * will meassure time. 
     */
    public static DiffusionProcess estimate(final SampleSet aSampleSet, final long aStepSize, final CalendarDateUnit aTimeUnit) {

        // The time between to keys expressed in terms of the specified time meassure and unit.
        final double tmpStepSize = (double) aStepSize / (double) aTimeUnit.size();

        final double tmpExp = aSampleSet.getMean();
        final double tmpVar = aSampleSet.getVariance();

        final double tmpDiff = Math.sqrt(tmpVar / tmpStepSize);
        final double tmpDrift = (tmpExp / tmpStepSize) + ((tmpDiff * tmpDiff) / TWO);

        return new DiffusionProcess(tmpDrift, tmpDiff);
    }

    /**
     * @param aSeries A series of observations, each with a timestamp,
     * that should be evenly spaced. 
     * @param aTimeUnit You have to specify with what unit the process
     * will meassure time. 
     */
    public static DiffusionProcess estimate(final TimeInMillisSeries<?> aSeries, final CalendarDateUnit aTimeUnit) {

        final SampleSet tmpSampleSet = SampleSet.makeUsingLogarithmicChanges(aSeries);

        final long tmpStepSize = aSeries.getAverageStepSize();

        return DiffusionProcess.estimate(tmpSampleSet, tmpStepSize, aTimeUnit);
    }

    private double myCurrentValue = ONE;
    private double myDiffusionFunction;
    private double myLocalDrift;

    public DiffusionProcess(final double aLocalDrift, final double aDiffusionFunction) {

        super();

        myLocalDrift = aLocalDrift;
        myDiffusionFunction = aDiffusionFunction;
    }

    public DiffusionProcess(final double aReturn, final double aVariance, final double aHorizon) {

        super();

        myLocalDrift = ZERO;
        myDiffusionFunction = ZERO;

        this.setVariance(aVariance, aHorizon);
        this.setExpected(aReturn, aHorizon);
    }

    @SuppressWarnings("unused")
    private DiffusionProcess() {
        this(ZERO, ZERO);
    }

    /**
     * @param aConvertionFactor A step size change factor.
     */
    public DiffusionProcess convert(final double aConvertionFactor) {

        final double tmpDrift = myLocalDrift * aConvertionFactor;
        final double tmpDiff = myDiffusionFunction * Math.sqrt(aConvertionFactor);

        return new DiffusionProcess(tmpDrift, tmpDiff);
    }

    /**
     * @deprecated v30 Use {@link #convert(double)} instead
     */
    @Deprecated
    public DiffusionProcess createNewWithChangedStepSize(final double aConvertionFactor) {
        return this.convert(aConvertionFactor);
    }

    public double getCurrentValue() {
        return myCurrentValue;
    }

    public double getDeviationValue(final double aHorizon) {
        return myCurrentValue * this.getStandardDeviation(aHorizon);
    }

    public double getDiffusionFunction() {
        return myDiffusionFunction;
    }

    /**
     * Expected relative change (+/- some percentage)
     */
    public double getExpected(final double aHorizon) {
        return Math.expm1((myLocalDrift - HALF * myDiffusionFunction * myDiffusionFunction) * aHorizon);
    }

    public double getExpectedValue(final double aHorizon) {
        return myCurrentValue * (ONE + this.getExpected(aHorizon));
    }

    public double getLocalDrift() {
        return myLocalDrift;
    }

    public double getStandardDeviation(final double aHorizon) {
        return myDiffusionFunction * Math.sqrt(aHorizon);
    }

    public double getVariance(final double aHorizon) {
        return myDiffusionFunction * myDiffusionFunction * aHorizon;
    }

    public void setCurrentValue(final double aCurrentValue) {
        myCurrentValue = aCurrentValue;
    }

    public void setDiffusionFunction(final double aDiffusionFunction) {
        myDiffusionFunction = aDiffusionFunction;
    }

    public void setExpected(final double aReturn, final double aHorizon) {
        myLocalDrift = Math.log1p(aReturn) / aHorizon + HALF * myDiffusionFunction * myDiffusionFunction;
    }

    public void setLocalDrift(final double aLocalDrift) {
        myLocalDrift = aLocalDrift;
    }

    /**
     * Will update both the diffusion function and the local drift.
     * 
     * @see #getDiffusionFunction()
     * @see #getLocalDrift()
     */
    public void setStandardDeviation(final double aStandardDeviation, final double aHorizon) {

        final double tmpExpected = this.getExpected(aHorizon);

        myDiffusionFunction = aStandardDeviation / Math.sqrt(aHorizon);

        this.setExpected(tmpExpected, aHorizon);
    }

    /**
     * Will update both the diffusion function and the local drift.
     * 
     * @see #getDiffusionFunction()
     * @see #getLocalDrift()
     */
    public void setVariance(final double aVariance, final double aHorizon) {

        final double tmpExpected = this.getExpected(aHorizon);

        myDiffusionFunction = Math.sqrt(aVariance / aHorizon);

        this.setExpected(tmpExpected, aHorizon);
    }

    public double step() {
        return this.step(ONE);
    }

    public double step(final double aStepSize) {
        return this.updateState(this.generateStep(aStepSize));
    }

    double generateStep(final double aStepCount) {
        return myLocalDrift * aStepCount + myDiffusionFunction * WIENER.step(aStepCount);
    }

    double updateState(final double aGeneratedStep) {

        final double retVal = myCurrentValue * aGeneratedStep;

        myCurrentValue += retVal;

        return retVal;
    }

}
