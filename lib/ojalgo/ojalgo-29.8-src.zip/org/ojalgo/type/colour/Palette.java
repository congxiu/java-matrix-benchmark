/*
 * Copyright © 2004 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.type.colour;


/**
 * Colour Palette
 * 
 * @author apete
 */
public class Palette {

    public static final Colour BLACK = new Colour(0, 0, 0);
    public static final Colour BLUE = new Colour(0, 0, 255);
    public static final Colour CYAN = new Colour(0, 255, 255);
    public static final Colour DARK_BLUE = new Colour(0x00, 0x00, 0xC0);
    public static final Colour DARK_CYAN = new Colour(0x00, 0xC0, 0xC0);
    public static final Colour DARK_GRAY = new Colour(64, 64, 64);
    public static final Colour DARK_GREEN = new Colour(0x00, 0xC0, 0x00);
    public static final Colour DARK_MAGENTA = new Colour(0xC0, 0x00, 0xC0);
    public static final Colour DARK_RED = new Colour(0xc0, 0x00, 0x00);
    public static final Colour DARK_YELLOW = new Colour(0xC0, 0xC0, 0x00);
    public static final Colour GRAY = new Colour(128, 128, 128);
    public static final Colour GREEN = new Colour(0, 255, 0);
    public static final Colour LIGHT_BLUE = new Colour(0x40, 0x40, 0xFF);
    public static final Colour LIGHT_CYAN = new Colour(0x40, 0xFF, 0xFF);
    public static final Colour LIGHT_GRAY = new Colour(192, 192, 192);
    public static final Colour LIGHT_GREEN = new Colour(0x40, 0xFF, 0x40);
    public static final Colour LIGHT_MAGENTA = new Colour(0xFF, 0x40, 0xFF);
    public static final Colour LIGHT_RED = new Colour(0xFF, 0x40, 0x40);
    public static final Colour LIGHT_YELLOW = new Colour(0xFF, 0xFF, 0x40);
    public static final Colour MAGENTA = new Colour(255, 0, 255);
    public static final Colour ORANGE = new Colour(255, 200, 0);
    public static final Colour PALE_BLUE = new Colour(0xEE, 0xEE, 0xFF);
    public static final Colour PALE_CYAN = new Colour(0xEE, 0xFF, 0xFF);
    public static final Colour PALE_GREEN = new Colour(0xEE, 0xFF, 0xEE);
    public static final Colour PALE_MAGENTA = new Colour(0xFF, 0xEE, 0xFF);
    public static final Colour PALE_RED = new Colour(0xFF, 0xEE, 0xEE);
    public static final Colour PALE_YELLOW = new Colour(0xFF, 0xFF, 0xEE);
    public static final Colour PINK = new Colour(255, 175, 175);
    public static final Colour RED = new Colour(255, 0, 0);
    public static final Colour VERY_DARK_BLUE = new Colour(0x00, 0x00, 0x80);
    public static final Colour VERY_DARK_CYAN = new Colour(0x00, 0x80, 0x80);
    public static final Colour VERY_DARK_GREEN = new Colour(0x00, 0x80, 0x00);
    public static final Colour VERY_DARK_MAGENTA = new Colour(0x80, 0x00, 0x80);
    public static final Colour VERY_DARK_RED = new Colour(0x80, 0x00, 0x00);
    public static final Colour VERY_DARK_YELLOW = new Colour(0x80, 0x80, 0x00);
    public static final Colour VERY_LIGHT_BLUE = new Colour(0x80, 0x80, 0xFF);
    public static final Colour VERY_LIGHT_CYAN = new Colour(0x80, 0xFF, 0xFF);
    public static final Colour VERY_LIGHT_GREEN = new Colour(0x80, 0xFF, 0x80);
    public static final Colour VERY_LIGHT_MAGENTA = new Colour(0xFF, 0x80, 0xFF);
    public static final Colour VERY_LIGHT_RED = new Colour(0xFF, 0x80, 0x80);
    public static final Colour VERY_LIGHT_YELLOW = new Colour(0xFF, 0xFF, 0x80);
    public static final Colour WHITE = new Colour(255, 255, 255);
    public static final Colour YELLOW = new Colour(255, 255, 0);

    private static final Palette INSTANCE = new Palette();

    public static Palette getInstance() {
        return INSTANCE;
    }

    private Palette() {
        super();
    }

    public Colour getBlack() {
        return BLACK;
    }

    public Colour getBlue() {
        return BLUE;
    }

    public Colour getCyan() {
        return CYAN;
    }

    public Colour getDarkBlue() {
        return DARK_BLUE;
    }

    public Colour getDarkCyan() {
        return DARK_CYAN;
    }

    public Colour getDarkGray() {
        return DARK_GRAY;
    }

    public Colour getDarkGreen() {
        return DARK_GREEN;
    }

    public Colour getDarkMagenta() {
        return DARK_MAGENTA;
    }

    public Colour getDarkRed() {
        return DARK_RED;
    }

    public Colour getDarkYellow() {
        return DARK_YELLOW;
    }

    public Colour getGray() {
        return GRAY;
    }

    public Colour getGreen() {
        return GREEN;
    }

    public Colour getLightBlue() {
        return LIGHT_BLUE;
    }

    public Colour getLightCyan() {
        return LIGHT_CYAN;
    }

    public Colour getLightGray() {
        return LIGHT_GRAY;
    }

    public Colour getLightGreen() {
        return LIGHT_GREEN;
    }

    public Colour getLightMagenta() {
        return LIGHT_MAGENTA;
    }

    public Colour getLightRed() {
        return LIGHT_RED;
    }

    public Colour getLightYellow() {
        return LIGHT_YELLOW;
    }

    public Colour getMagenta() {
        return MAGENTA;
    }

    public Colour getMediumBlue() {
        return BLUE;
    }

    public Colour getMediumCyan() {
        return CYAN;
    }

    public Colour getMediumGray() {
        return GRAY;
    }

    public Colour getMediumGreen() {
        return GREEN;
    }

    public Colour getMediumMagenta() {
        return MAGENTA;
    }

    public Colour getMediumRed() {
        return RED;
    }

    public Colour getMediumYellow() {
        return YELLOW;
    }

    public Colour getOrange() {
        return ORANGE;
    }

    public Colour getPaleBlue() {
        return PALE_BLUE;
    }

    public Colour getPaleCyan() {
        return PALE_CYAN;
    }

    public Colour getPaleGreen() {
        return PALE_GREEN;
    }

    public Colour getPaleMagenta() {
        return PALE_MAGENTA;
    }

    public Colour getPaleRed() {
        return PALE_RED;
    }

    public Colour getPaleYellow() {
        return PALE_YELLOW;
    }

    public Colour getPink() {
        return PINK;
    }

    public Colour getRed() {
        return RED;
    }

    public Colour getVeryDarkBlue() {
        return VERY_DARK_BLUE;
    }

    public Colour getVeryDarkCyan() {
        return VERY_DARK_CYAN;
    }

    public Colour getVeryDarkGreen() {
        return VERY_DARK_GREEN;
    }

    public Colour getVeryDarkMagenta() {
        return VERY_DARK_MAGENTA;
    }

    public Colour getVeryDarkRed() {
        return VERY_DARK_RED;
    }

    public Colour getVeryDarkYellow() {
        return VERY_DARK_YELLOW;
    }

    public Colour getVeryLightBlue() {
        return VERY_LIGHT_BLUE;
    }

    public Colour getVeryLightCyan() {
        return VERY_LIGHT_CYAN;
    }

    public Colour getVeryLightGreen() {
        return VERY_LIGHT_GREEN;
    }

    public Colour getVeryLightMagenta() {
        return VERY_LIGHT_MAGENTA;
    }

    public Colour getVeryLightRed() {
        return VERY_LIGHT_RED;
    }

    public Colour getVeryLightYellow() {
        return VERY_LIGHT_YELLOW;
    }

    public Colour getWhite() {
        return WHITE;
    }

    public Colour getYellow() {
        return YELLOW;
    }

}