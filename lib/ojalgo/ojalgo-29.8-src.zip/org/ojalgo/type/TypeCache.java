package org.ojalgo.type;

import java.util.Timer;
import java.util.TimerTask;

public abstract class TypeCache<T> {

    private static final Timer TIMER = new Timer("TypeCache-Daemon", true);

    private transient T myCachedObject;
    private volatile boolean myForcePurge;

    public TypeCache(final long aPurgeIntervalMeassure, final CalendarDateUnit aPurgeIntervalUnit) {

        super();

        TIMER.schedule(new TimerTask() {

            @Override
            public void run() {
                myForcePurge = false;
            }

        }, 0L, aPurgeIntervalMeassure * aPurgeIntervalUnit.size());
    }

    private TypeCache() {
        this(8L, CalendarDateUnit.HOUR);
    }

    public final T getCachedObject() {

        if ((myCachedObject == null) || myForcePurge) {

            myCachedObject = this.recreateCache();

            myForcePurge = false;
        }

        return myCachedObject;
    }

    protected abstract T recreateCache();

}
