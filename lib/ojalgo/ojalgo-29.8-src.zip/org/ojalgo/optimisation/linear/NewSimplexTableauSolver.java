/*
 * Copyright © 2009 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation.linear;

import static org.ojalgo.constant.PrimitiveMath.*;
import static org.ojalgo.function.implementation.PrimitiveFunction.*;

import java.util.Arrays;

import org.ojalgo.function.PreconfiguredSecond;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.PrimitiveMatrix;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.ZeroStore;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.optimisation.OptimisationModel;
import org.ojalgo.optimisation.State;
import org.ojalgo.type.IndexSelector;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * SimplexTableauSolver
 *
 * @author apete
 */
final class NewSimplexTableauSolver extends LinearSolver {

    private static int[] initialPivots(final LinearSolver.Builder aBuilder) {

        final int[] retVal = new int[aBuilder.countEqualityConstraints()];

        Arrays.fill(retVal, -1);

        return retVal;
    }

    private final int myCountConstraints;
    private final int myCountVariables;
    private int myLastRow; // myCountConstraints+1 in Phase1 and myCountConstraints in Phase2
    private int myPivotCol;
    private int myPivotRow;
    private final int[] myPivots;
    private final PhysicalStore<Double> myTransposedTableau;

    @SuppressWarnings("unused")
    private NewSimplexTableauSolver(final Builder aBuilder, final IndexSelector aBasisSelector) {
        this(aBuilder, aBasisSelector.getIncluded());
    }

    @SuppressWarnings("unchecked")
    NewSimplexTableauSolver(final LinearSolver.Builder aBuilder, final int[] suggestedPivots) {

        super(aBuilder, NewSimplexTableauSolver.initialPivots(aBuilder));

        myCountConstraints = this.countConstraints();
        myCountVariables = this.countVariables();

        final MatrixStore.Builder<Double> tmpTableauBuilder = ZeroStore.makePrimitive(1, 1).builder();
        tmpTableauBuilder.left(aBuilder.getC().transpose());
        if (myCountConstraints >= 1) {
            tmpTableauBuilder.above(aBuilder.getAE(), aBuilder.getBE());
        }
        tmpTableauBuilder.below(1);
        myTransposedTableau = tmpTableauBuilder.build().transpose();

        myLastRow = myCountConstraints + 1; // Phase1 objective function row
        for (int i = 0; i < myCountConstraints; i++) {
            myTransposedTableau.caxpy(NEG, i, myLastRow, 0);
        }

        myPivots = MatrixUtils.makeIncreasingRange(-myCountConstraints, myCountConstraints);

        if (DEBUG && this.isTableauPrintable()) {
            this.printTableau("Tableau Created");
        }

        options.iterationsLimit = myTransposedTableau.size();
    }

    public Result solve() {

        // Maybe I can use the original pivots from the builder
        //        for (int i = 0; i < myPivots.length; i++) {
        //            myPivotRow = i;
        //            myPivotCol = myPivots[i];
        //            this.performIteration();
        //        }
        //
        //        if (DEBUG && this.isTableauPrintable()) {
        //            this.printTableau("Tableau Prepared");
        //        }

        while (this.needsAnotherIteration()) {

            this.performIteration();

            if (DEBUG && this.isTableauPrintable()) {
                this.printTableau("Tableau Iteration");
            }
        }

        if (DEBUG && this.isTableauPrintable()) {
            this.printTableau("Final (Phase2) Tableau");
        }

        return new Result(this.getState(), this.extractSolution(), this.getIterationsCount());
    }

    public Result solve(final OptimisationModel aValidationModel) {

        this.setValidationModel(aValidationModel);

        return this.solve();
    }

    private int countBasicArtificials() {
        int retVal = 0;
        for (int i = 0; i < myPivots.length; i++) {
            if (myPivots[i] < 0) {
                retVal++;
            }
        }
        return retVal;
    }

    private PhysicalStore<Double> extractSolution() {

        final PhysicalStore<Double> retVal = PrimitiveDenseStore.FACTORY.makeZero(myCountVariables, 1);

        int tmpIndex;
        for (int i = 0; i < myPivots.length; i++) {
            tmpIndex = myPivots[i];
            if (tmpIndex >= 0) {
                retVal.set(tmpIndex, 0, myTransposedTableau.doubleValue(myCountVariables, i));
            }
        }

        return retVal;
    }

    private int findColumnInRow(final int aRow) {

        int retVal = -1;

        final PhysicalStore<Double> tmpTransposedTableau = myTransposedTableau;
        double tmpVal;
        double tmpMinVal = -options.problemContext.getError();

        int tmpCol;
        final int[] tmpExcluded = this.getExcluded();
        final int tmpPhase2Limit = tmpExcluded.length;
        for (int j = 0; j < tmpPhase2Limit; j++) {
            tmpCol = 0 + tmpExcluded[j];
            tmpVal = tmpTransposedTableau.doubleValue(tmpCol, aRow);
            if (tmpVal < tmpMinVal) {
                retVal = tmpCol;
                tmpMinVal = tmpVal;
                if (DEBUG) {
                    BasicLogger.logDebug("Col: {}\t=>\tReduced Contribution Weight: {}.", tmpCol, tmpVal);
                }
            }
        }

        return retVal;
    }

    private int findNextPivotCol() {

        int retVal = -1;
        double tmpVal;
        double tmpMinVal = -options.problemContext.getError();
        //double tmpMinVal = -MACHINE_DOUBLE_ERROR;

        final int tmpRow = myLastRow;
        int tmpCol;
        final PhysicalStore<Double> tmpTransposedTableau = myTransposedTableau;
        if (tmpRow > myCountConstraints) { // if in Phase1

            for (int j = 0; j < myCountVariables; j++) {
                tmpCol = j;
                tmpVal = tmpTransposedTableau.doubleValue(tmpCol, tmpRow);
                if (tmpVal < tmpMinVal) {
                    retVal = tmpCol;
                    tmpMinVal = tmpVal;
                    if (DEBUG) {
                        BasicLogger.logDebug("Col: {}\t=>\tReduced Contribution Weight: {}.", tmpCol, tmpVal);
                    }
                }
            }

        } else { // else in Phase2

            // If there are still artificial variables in the basis
            final int[] tmpRows = this.getRowsWithArticialBasics();
            for (int i = 0; (retVal == -1) && (i < tmpRows.length); i++) {
                retVal = this.findColumnInRow(tmpRows[i]);
            }

            // The normal objective row
            if (retVal == -1) {
                retVal = this.findColumnInRow(tmpRow);
            }
        }

        return retVal;
    }

    private int findNextPivotRow() {

        int retVal = -1;
        double tmpNumer, tmpDenom, tmpRatio;
        double tmpMinRatio = MAX_VALUE;

        final NumberContext tmpProblemContext = options.problemContext;

        final int tmpDenomCol = myPivotCol;
        final int tmpNumerCol = this.countVariables();

        final int tmpLimit = this.countConstraints();
        for (int i = 0; i < tmpLimit; i++) {

            tmpDenom = myTransposedTableau.doubleValue(tmpDenomCol, i);

            if (!tmpProblemContext.isZero(tmpDenom)) {

                tmpNumer = myTransposedTableau.doubleValue(tmpNumerCol, i);
                tmpRatio = tmpNumer / tmpDenom;

                if ((tmpRatio >= ZERO) && (tmpRatio < tmpMinRatio) && !(tmpProblemContext.isZero(tmpRatio) && (tmpDenom < ZERO))) {
                    retVal = i;
                    tmpMinRatio = tmpRatio;
                    if (DEBUG) {
                        BasicLogger.logDebug("Row: {}\t=>\tRatio: {},\tNumerator/RHS: {}, \tDenominator/Pivot: {}.", i, tmpRatio, tmpNumer, tmpDenom);
                    }
                }
            }
        }

        return retVal;
    }

    private int[] getRowsWithArticialBasics() {
        final int[] retVal = new int[this.countBasicArtificials()];
        int tmpInd = 0;
        for (int i = 0; i < myPivots.length; i++) {
            if (myPivots[i] < 0) {
                retVal[tmpInd] = i;
                tmpInd++;
            }
        }
        return retVal;
    }

    private final boolean isTableauPrintable() {
        return ((this.countConstraints() * this.countVariables()) <= HUNDRED);
    }

    private void performIteration() {

        double tmpPivotColVal = myTransposedTableau.doubleValue(myPivotCol, myPivotRow);

        if (DEBUG) {
            BasicLogger.logDebug("Pivot Element Before: {}.", myTransposedTableau.doubleValue(myPivotCol, myPivotRow));
        }

        if (Math.abs(tmpPivotColVal) < ONE) {
            myTransposedTableau.modifyColumn(0, myPivotRow, new PreconfiguredSecond<Double>(DIVIDE, tmpPivotColVal));
        } else if (tmpPivotColVal != ONE) {
            myTransposedTableau.modifyColumn(0, myPivotRow, new PreconfiguredSecond<Double>(MULTIPLY, ONE / tmpPivotColVal));
        }

        for (int i = 0; i <= myLastRow; i++) {
            if (i != myPivotRow) {

                tmpPivotColVal = myTransposedTableau.doubleValue(myPivotCol, i);

                if (!options.problemContext.isZero(tmpPivotColVal)) {
                    myTransposedTableau.caxpy(-tmpPivotColVal, myPivotRow, i, 0);
                }
            }
        }

        final int tmpOld = myPivots[myPivotRow];
        if (tmpOld >= 0) {
            this.exclude(tmpOld);
        }
        final int tmpNew = myPivotCol;
        if (tmpNew >= 0) {
            this.include(tmpNew);
        }
        myPivots[myPivotRow] = myPivotCol;

        if (DEBUG) {

            BasicLogger.logDebug("Pivot Element After : {}.", myTransposedTableau.doubleValue(myPivotCol, myPivotRow));
            BasicLogger.logDebug("Still {} artificial variable(s) in the basis.", this.countBasicArtificials());

            final OptimisationModel tmpModel = this.getValidationModel();

            if ((tmpModel != null) && (myLastRow == myCountConstraints)) { // Only if in Phase2
                if (!tmpModel.validateSolution(new PrimitiveMatrix(this.extractSolution()), TypeUtils.EQUALS_NUMBER_CONTEXT)) {
                    this.setState(State.FAILED);
                }
            }
        }
    }

    private final void printTableau(final String aMessage) {
        BasicLogger.DEBUG.print(aMessage);
        BasicLogger.DEBUG.print("; Basics: " + Arrays.toString(myPivots));
        MatrixUtils.printToStream(BasicLogger.DEBUG, myTransposedTableau.transpose(), options.printContext);
    }

    @Override
    protected boolean needsAnotherIteration() {

        if (DEBUG) {
            BasicLogger.logDebug();
            BasicLogger.logDebug("Needs Another Iteration?");
        }

        myPivotRow = -1;

        boolean retVal = (myPivotCol = this.findNextPivotCol()) != -1;

        if (!retVal && (myLastRow > myCountConstraints)) {

            if (DEBUG && this.isTableauPrintable()) {
                this.printTableau("Last Phase1 Tableau, switching to Phase2");
            }

            //            int tmpCol = -1;
            //            final int[] tmpRows = this.getRowsWithArticialBasics();
            //            for (int i = 0; (tmpCol == -1) && (i < tmpRows.length); i++) {
            //                tmpCol = this.findColumnInRow(tmpRows[i]);
            //                if (tmpCol != -1) {
            //                    myPivotCol = tmpCol;
            //                    myPivotRow = this.findNextPivotRow();
            //                    if (myPivotRow != -1) {
            //                        this.performIteration();
            //                    }
            //                }
            //            }
            //
            //            if (DEBUG && this.isTableauPrintable()) {
            //                this.printTableau("Cleaned Phase1 Tableau");
            //            }

            final double tmpPhaseOneValue = myTransposedTableau.doubleValue(myCountVariables, myLastRow);

            if (options.solutionContext.isZero(tmpPhaseOneValue)) {

                if (DEBUG) {
                    BasicLogger.logDebug("Left Phase1 with {} artificial variable(s) in the basis.", this.countBasicArtificials());
                }

                myLastRow = myCountConstraints;

                retVal = (myPivotCol = this.findNextPivotCol()) != -1;

            } else {

                myPivotCol = -1;
                myPivotRow = -1;

                this.setState(State.INFEASIBLE);

                retVal = false;
            }
        }

        if (retVal) {

            retVal = (myPivotRow = this.findNextPivotRow()) != -1;

            if (!retVal) {
                this.setState(State.UNBOUNDED);
            }

        } else if (myLastRow == myCountConstraints) {

            this.setState(State.OPTIMAL);
        }

        if (DEBUG) {
            if (retVal) {
                BasicLogger.logDebug("Row: {},\tExit: {},\tColumn/Enter: {}.", myPivotRow, myPivots[myPivotRow], myPivotCol);
            } else {
                BasicLogger.logDebug("No more iterations needed/possible.");
            }
        }

        return retVal;
    }

}
