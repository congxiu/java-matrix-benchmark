/*
 * Copyright © 2009 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.optimisation.linear;

import static org.ojalgo.constant.PrimitiveMath.*;
import static org.ojalgo.function.implementation.PrimitiveFunction.*;

import java.util.Arrays;

import org.ojalgo.function.PreconfiguredSecond;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.PrimitiveMatrix;
import org.ojalgo.matrix.store.IdentityStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.SingleStore;
import org.ojalgo.matrix.store.TransposedStore;
import org.ojalgo.matrix.store.ZeroStore;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.optimisation.OptimisationModel;
import org.ojalgo.optimisation.State;
import org.ojalgo.type.IndexSelector;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

/**
 * SimplexTableauSolver
 *
 * @author apete
 */
final class OldSimplexTableauSolver extends LinearSolver {

    private final int myArtificialsCount;
    private int myFirstCol; // 0 in phase I and myNumberOfArtificials in phase II.
    private int myLastRow; // myNumberOfContraints+1 in phase I and myNumberOfContraints in phase II
    private final int[] myPivots;
    private int myPivotRow;
    private int myPivotCol;
    private final PhysicalStore<Double> myTransposedTableau;

    @SuppressWarnings("unused")
    private OldSimplexTableauSolver(final Builder aBuilder, final IndexSelector aBasisSelector) {
        this(aBuilder, aBasisSelector.getIncluded());
    }

    @SuppressWarnings("unchecked")
    OldSimplexTableauSolver(final LinearSolver.Builder aBuilder, final int[] aPivots) {

        super(aBuilder, aPivots);

        myArtificialsCount = this.countBasisDeficit();

        final int tmpConstraintsCount = this.countConstraints();
        final int tmpArtificialsCount = myArtificialsCount;

        final MatrixStore.Builder<Double> tmpTableauBuilder = new MatrixStore.Builder<Double>(ZeroStore.makePrimitive(1, 1));
        tmpTableauBuilder.left(new TransposedStore<Double>(aBuilder.getC()));

        if (aBuilder.hasEqualityConstraints()) {
            tmpTableauBuilder.above(aBuilder.getAE(), aBuilder.getBE());
        }

        if (tmpArtificialsCount > 0) {

            tmpTableauBuilder.left(IdentityStore.makePrimitive(tmpArtificialsCount));

            final MatrixStore<Double> tmpSingleOne = SingleStore.makePrimitive(ONE);
            final MatrixStore<Double>[] tmpArtficialObjFunc = new MatrixStore[tmpArtificialsCount];
            Arrays.fill(tmpArtficialObjFunc, tmpSingleOne);
            tmpTableauBuilder.below(tmpArtficialObjFunc);

            myPivots = new int[aPivots.length];
            int tmpPivot;
            for (int i = 0; i < aPivots.length; i++) {
                tmpPivot = aPivots[i];
                if (tmpPivot < 0) {
                    myPivots[i] = i;
                } else {
                    myPivots[i] = tmpArtificialsCount + tmpPivot;
                }
            }

            myFirstCol = 0;
            myLastRow = tmpConstraintsCount + 1;

        } else {

            myPivots = aPivots;

            myFirstCol = 0;
            myLastRow = tmpConstraintsCount;
        }

        myTransposedTableau = tmpTableauBuilder.build().transpose();

        if (DEBUG && this.isTableauPrintable()) {
            this.printTableau("Tableau Created");
        }

        options.iterationsLimit = myTransposedTableau.size();
    }

    public Result solve() {

        for (int i = 0; i < myPivots.length; i++) {
            myPivotRow = i;
            myPivotCol = myPivots[i];
            this.performIteration();
        }

        if (DEBUG && this.isTableauPrintable()) {
            this.printTableau("Tableau Prepared");
        }

        while (this.needsAnotherIteration()) {

            this.performIteration();

            if (DEBUG && this.isTableauPrintable()) {
                this.printTableau("Tableau Iteration");
            }
        }

        if (DEBUG && this.isTableauPrintable()) {
            this.printTableau("Final (Phase2) Tableau");
        }

        return new Result(this.getState(), this.extractSolution(), this.getIterationsCount());
    }

    public Result solve(final OptimisationModel aValidationModel) {

        this.setValidationModel(aValidationModel);

        return this.solve();
    }

    private int countBasicisArtificials() {
        int retVal = 0;
        for (int i = 0; i < myPivots.length; i++) {
            if (myPivots[i] < myArtificialsCount) {
                retVal++;
            }
        }
        return retVal;
    }

    private PhysicalStore<Double> extractSolution() {

        final PhysicalStore<Double> retVal = PrimitiveDenseStore.FACTORY.makeZero(this.countVariables(), 1);

        int tmpIndex;
        for (int i = 0; i < myPivots.length; i++) {
            tmpIndex = myPivots[i] - myArtificialsCount;
            if (tmpIndex >= 0) {
                retVal.set(tmpIndex, 0, myTransposedTableau.doubleValue(myArtificialsCount + this.countVariables(), i));
            }
        }

        return retVal;
    }

    private int findColumnInRow(final int aRow) {

        int retVal = -1;

        final PhysicalStore<Double> tmpTransposedTableau = myTransposedTableau;
        final int tmpArtificialsCount = myArtificialsCount;

        double tmpVal;
        double tmpMinVal = -options.problemContext.getError();

        int tmpCol;
        final int[] tmpExcluded = this.getExcluded();
        final int tmpPhase2Limit = tmpExcluded.length;
        for (int j = 0; j < tmpPhase2Limit; j++) {
            tmpCol = tmpArtificialsCount + tmpExcluded[j];
            tmpVal = tmpTransposedTableau.doubleValue(tmpCol, aRow);
            if (tmpVal < tmpMinVal) {
                retVal = tmpCol;
                tmpMinVal = tmpVal;
                if (DEBUG) {
                    BasicLogger.logDebug("Col: {}\t=>\tReduced Contribution Weight: {}.", tmpCol, tmpVal);
                }
            }
        }

        return retVal;
    }

    private int findNextPivotCol() {

        int retVal = -1;
        double tmpVal;
        double tmpMinVal = -options.problemContext.getError();
        //double tmpMinVal = -MACHINE_DOUBLE_ERROR;

        final int tmpRow = myLastRow;
        int tmpCol;
        final PhysicalStore<Double> tmpTransposedTableau = myTransposedTableau;
        final int tmpArtificialsCount = myArtificialsCount;

        if (tmpRow > this.countConstraints()) { // if in Phase1

            final int tmpPhase1Limit = tmpArtificialsCount + this.countVariables();
            for (int j = myFirstCol; j < tmpPhase1Limit; j++) {
                tmpCol = j;
                tmpVal = tmpTransposedTableau.doubleValue(tmpCol, tmpRow);
                if (tmpVal < tmpMinVal) {
                    retVal = tmpCol;
                    tmpMinVal = tmpVal;
                    if (DEBUG) {
                        BasicLogger.logDebug("Col: {}\t=>\tReduced Contribution Weight: {}.", tmpCol, tmpVal);
                    }
                }
            }

        } else { // else in Phase2

            // If there are still artificial variables in the basis
            final int[] tmpRows = this.getRowsWithArticialBasics();
            for (int i = 0; (retVal == -1) && (i < tmpRows.length); i++) {
                retVal = this.findColumnInRow(tmpRows[i]);
            }

            // The normal objective row
            if (retVal == -1) {
                retVal = this.findColumnInRow(tmpRow);
            }
        }

        return retVal;
    }

    private int findNextPivotRow() {

        int retVal = -1;
        double tmpNumer, tmpDenom, tmpRatio;
        double tmpMinRatio = MAX_VALUE;

        final NumberContext tmpProblemContext = options.problemContext;

        final int tmpDenomCol = myPivotCol;
        final int tmpNumerCol = myArtificialsCount + this.countVariables();

        final int tmpLimit = this.countConstraints();
        for (int i = 0; i < tmpLimit; i++) {

            tmpDenom = myTransposedTableau.doubleValue(tmpDenomCol, i);

            if (!tmpProblemContext.isZero(tmpDenom)) {

                tmpNumer = myTransposedTableau.doubleValue(tmpNumerCol, i);
                tmpRatio = tmpNumer / tmpDenom;

                if ((tmpRatio >= ZERO) && (tmpRatio < tmpMinRatio) && !(tmpProblemContext.isZero(tmpRatio) && (tmpDenom < ZERO))) {
                    retVal = i;
                    tmpMinRatio = tmpRatio;
                    if (DEBUG) {
                        BasicLogger.logDebug("Row: {}\t=>\tRatio: {},\tNumerator/RHS: {}, \tDenominator/Pivot: {}.", i, tmpRatio, tmpNumer, tmpDenom);
                    }
                }
            }
        }

        return retVal;
    }

    private int[] getRowsWithArticialBasics() {
        final int[] retVal = new int[this.countBasicisArtificials()];
        int tmpInd = 0;
        for (int i = 0; i < myPivots.length; i++) {
            if (myPivots[i] < myArtificialsCount) {
                retVal[tmpInd] = i;
                tmpInd++;
            }
        }
        return retVal;
    }

    private final boolean isTableauPrintable() {
        return ((this.countConstraints() * this.countVariables()) <= THOUSAND);
    }

    private void performIteration() {

        if (DEBUG) {
            BasicLogger.logDebug("Pivot Element Before: {}.", myTransposedTableau.doubleValue(myPivotCol, myPivotRow));
        }

        double tmpVal = myTransposedTableau.doubleValue(myPivotCol, myPivotRow);

        if (Math.abs(tmpVal) < ONE) {
            myTransposedTableau.modifyColumn(myFirstCol, myPivotRow, new PreconfiguredSecond<Double>(DIVIDE, tmpVal));
        } else if (tmpVal != ONE) {
            myTransposedTableau.modifyColumn(myFirstCol, myPivotRow, new PreconfiguredSecond<Double>(MULTIPLY, ONE / tmpVal));
        }

        for (int i = 0; i <= myLastRow; i++) {
            if (i != myPivotRow) {

                tmpVal = myTransposedTableau.doubleValue(myPivotCol, i);

                if (!options.problemContext.isZero(tmpVal)) {
                    myTransposedTableau.caxpy(-tmpVal, myPivotRow, i, myFirstCol);
                }
            }
        }

        final int tmpOld = myPivots[myPivotRow] - myArtificialsCount;
        if (tmpOld >= 0) {
            this.exclude(tmpOld);
        }
        final int tmpNew = myPivotCol - myArtificialsCount;
        if (tmpNew >= 0) {
            this.include(tmpNew);
        }
        myPivots[myPivotRow] = myPivotCol;

        if (DEBUG) {

            BasicLogger.logDebug("Pivot Element After : {}.", myTransposedTableau.doubleValue(myPivotCol, myPivotRow));
            BasicLogger.logDebug("Still {} artificial variable(s) in the basis.", this.countBasicisArtificials());

            final OptimisationModel tmpModel = this.getValidationModel();

            if ((tmpModel != null) && (myLastRow == this.countConstraints())) { // Only if in Phase2
                if (!tmpModel.validateSolution(new PrimitiveMatrix(this.extractSolution()), TypeUtils.EQUALS_NUMBER_CONTEXT)) {
                    this.setState(State.FAILED);
                }
            }
        }
    }

    private void printTableau(final String aMessage) {
        BasicLogger.DEBUG.print(aMessage);
        BasicLogger.DEBUG.print("; Basics: " + Arrays.toString(myPivots));
        MatrixUtils.printToStream(BasicLogger.DEBUG, myTransposedTableau.transpose(), options.printContext);
    }

    @Override
    protected boolean needsAnotherIteration() {

        if (DEBUG) {
            BasicLogger.logDebug();
            BasicLogger.logDebug("Needs Another Iteration?");
        }

        myPivotRow = -1;

        boolean retVal = (myPivotCol = this.findNextPivotCol()) != -1;

        if (!retVal && (myLastRow > this.countConstraints())) {

            // Switching to Phase2

            if (DEBUG && this.isTableauPrintable()) {
                this.printTableau("Last Phase1 Tableau");
            }

            int tmpCol = -1;
            final int[] tmpRows = this.getRowsWithArticialBasics();
            for (int i = 0; (tmpCol == -1) && (i < tmpRows.length); i++) {
                tmpCol = this.findColumnInRow(tmpRows[i]);
                if (tmpCol != -1) {
                    myPivotCol = tmpCol;
                    myPivotRow = this.findNextPivotRow();
                    if (myPivotRow != -1) {
                        this.performIteration();
                    }
                }
            }

            if (DEBUG && this.isTableauPrintable()) {
                this.printTableau("Cleaned Phase1 Tableau");
            }

            final double tmpPhaseOneValue = myTransposedTableau.doubleValue(myArtificialsCount + this.countVariables(), myLastRow);

            if (options.solutionContext.isZero(tmpPhaseOneValue)) {

                if (DEBUG) {
                    BasicLogger.logDebug("Left Phase1 with {} artificial variable(s) in the basis.", this.countBasicisArtificials());
                }

                myFirstCol = myArtificialsCount;
                myLastRow = this.countConstraints();

                retVal = (myPivotCol = this.findNextPivotCol()) != -1;

            } else {

                myPivotCol = -1;
                myPivotRow = -1;

                this.setState(State.INFEASIBLE);

                retVal = false;
            }
        }

        if (retVal) {

            retVal = (myPivotRow = this.findNextPivotRow()) != -1;

            if (!retVal) {
                this.setState(State.UNBOUNDED);
            }

        } else if (myLastRow == this.countConstraints()) {

            this.setState(State.OPTIMAL);
        }

        if (DEBUG) {
            if (retVal) {
                BasicLogger.logDebug("Row: {},\tExit: {},\tColumn/Enter: {}.", myPivotRow, myPivots[myPivotRow], myPivotCol);
            } else {
                BasicLogger.logDebug("No more iterations needed/possible.");
            }
        }

        return retVal;
    }

}
