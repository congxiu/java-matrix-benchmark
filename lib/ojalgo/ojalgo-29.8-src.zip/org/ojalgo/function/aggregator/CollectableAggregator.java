/*
 * Copyright © 2009 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.function.aggregator;

import java.math.BigDecimal;

import org.ojalgo.scalar.ComplexNumber;

public enum CollectableAggregator {

    CARDINALITY;

    public final AggregatorFunction<BigDecimal> getBigFunction() {

        switch (this) {

        case CARDINALITY:

            return BigAggregator.CARDINALITY.get().reset();

        default:

            return null;
        }
    }

    public final AggregatorFunction<ComplexNumber> getComplexFunction() {

        switch (this) {

        case CARDINALITY:

            return ComplexAggregator.CARDINALITY.get().reset();

        default:

            return null;
        }
    }

    @SuppressWarnings("unchecked")
    public final <N extends Number> AggregatorFunction<N> getFunction(final Class<?> aType) {
        if (double.class.isAssignableFrom(aType) || Double.class.isAssignableFrom(aType)) {
            return (AggregatorFunction<N>) this.getPrimitiveFunction();
        } else if (ComplexNumber.class.isAssignableFrom(aType)) {
            return (AggregatorFunction<N>) this.getComplexFunction();
        } else if (BigDecimal.class.isAssignableFrom(aType)) {
            return (AggregatorFunction<N>) this.getBigFunction();
        } else {
            return null;
        }
    }

    public final AggregatorFunction<Double> getPrimitiveFunction() {

        switch (this) {

        case CARDINALITY:

            return PrimitiveAggregator.CARDINALITY.get().reset();

        default:

            return null;
        }
    }

}
