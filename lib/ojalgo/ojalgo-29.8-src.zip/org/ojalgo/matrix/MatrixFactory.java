/*
 * Copyright © 2009 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.ojalgo.ProgrammingError;
import org.ojalgo.access.Access2D;
import org.ojalgo.matrix.store.IdentityStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.MergedColumnsStore;
import org.ojalgo.matrix.store.MergedRowsStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.ZeroStore;
import org.ojalgo.random.RandomNumber;

/**
 * <p>
 * MatrixFactory creates instances of classes that implement the
 * {@linkplain org.ojalgo.matrix.BasicMatrix} interface and have a 
 * constructor that takes a MatrixStore as input.
 * </p><p>
 * MatrixFactory uses reflection to call the constructor.
 * This takes slightly longer than calling the matrix' constructors directly.
 * If you need to instantiate a large number of small matrices; using DefaultFactory
 * may not be your best alternative. In that case you should consider coding
 * a different MatrixFactory implementation. In the vast majority of cases
 * you do not need to worry about this.
 * </p>
 * 
 * @author apete
 */
public final class MatrixFactory<N extends Number> implements BasicMatrix.Factory {

    private static Constructor<? extends BasicMatrix> getConstructor(final Class<? extends BasicMatrix> aTemplate) {
        try {
            return aTemplate.getConstructor(MatrixStore.class);
        } catch (final SecurityException anException) {
            return null;
        } catch (final NoSuchMethodException anException) {
            return null;
        }
    }

    private final Constructor<? extends BasicMatrix> myConstructor;

    private final PhysicalStore.Factory<N> myPhysical;

    @SuppressWarnings("unused")
    private MatrixFactory() {

        this(null, null);

        ProgrammingError.throwForIllegalInvocation();
    }

    MatrixFactory(final Class<? extends BasicMatrix> aTemplate, final PhysicalStore.Factory<N> aPhysical) {

        super();

        myPhysical = aPhysical;
        myConstructor = MatrixFactory.getConstructor(aTemplate);
    }

    public BasicMatrix copy(final Access2D<? extends Number> aSource) {
        return this.instantiate(myPhysical.copy(aSource));
    }

    public BasicMatrix copy(final double[][] aSource) {
        return this.instantiate(myPhysical.copy(aSource));
    }

    public final BasicMatrix instantiate(final MatrixStore<N> aStore) {
        try {
            return myConstructor.newInstance(aStore);
        } catch (final IllegalArgumentException anException) {
            throw new ProgrammingError(anException);
        } catch (final InstantiationException anException) {
            throw new ProgrammingError(anException);
        } catch (final IllegalAccessException anException) {
            throw new ProgrammingError(anException);
        } catch (final InvocationTargetException anException) {
            throw new ProgrammingError(anException);
        }
    }

    public BasicMatrix makeColumnVector(final List<? extends Number> aColumn) {

        final PhysicalStore<N> tmpStore = myPhysical.makeEmpty(aColumn.size(), 1);

        for (int i = 0; i < aColumn.size(); i++) {
            tmpStore.set(i, 0, myPhysical.getNumber(aColumn.get(i)));
        }

        return this.instantiate(tmpStore);
    }

    public BasicMatrix makeEye(final int aRowDim, final int aColDim) {

        final int tmpMinDim = Math.min(aRowDim, aColDim);

        MatrixStore<N> retVal = new IdentityStore<N>(myPhysical, tmpMinDim);

        if (aRowDim > tmpMinDim) {
            retVal = new MergedColumnsStore<N>(retVal, new ZeroStore<N>(myPhysical, aRowDim - tmpMinDim, aColDim));
        } else if (aColDim > tmpMinDim) {
            retVal = new MergedRowsStore<N>(retVal, new ZeroStore<N>(myPhysical, aRowDim, aColDim - tmpMinDim));
        }

        return this.instantiate(retVal);
    }

    public BasicMatrix makeRandom(final int aRowDim, final int aColDim, final RandomNumber aRndm) {

        final PhysicalStore<N> tmpStore = myPhysical.makeEmpty(aRowDim, aColDim);

        for (int i = 0; i < aRowDim; i++) {
            for (int j = 0; j < aColDim; j++) {
                tmpStore.set(i, j, aRndm.doubleValue());
            }
        }

        return this.instantiate(tmpStore);
    }

    public BasicMatrix makeRowVector(final List<? extends Number> aRow) {

        final PhysicalStore<N> tmpStore = myPhysical.makeEmpty(aRow.size(), 1);

        for (int i = 0; i < aRow.size(); i++) {
            tmpStore.set(0, i, myPhysical.getNumber(aRow.get(i)));
        }

        return this.instantiate(tmpStore);
    }

    public BasicMatrix makeZero(final int aRowDim, final int aColDim) {
        return this.instantiate(myPhysical.makeZero(aRowDim, aColDim));
    }

    protected final PhysicalStore.Factory<N> getPhysical() {
        return myPhysical;
    }

}
