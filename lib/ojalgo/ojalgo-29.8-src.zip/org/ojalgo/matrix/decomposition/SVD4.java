/*
 * Copyright © 2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.ojalgo.array.Array1D;
import org.ojalgo.array.Array2D;
import org.ojalgo.constant.PrimitiveMath;
import org.ojalgo.function.implementation.PrimitiveFunction;
import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.netio.BasicLogger;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.TypeUtils;
import org.ojalgo.type.context.NumberContext;

;

/**
 * Householder to bidiagonal, and then Givens to diagonal.
 *
 * @author apete
 */
abstract class SVD4<N extends Number & Comparable<N>> extends SingularValueDecomposition<N> {

    static final class Big extends SVD4<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

        @Override
        protected DiagonalAccess<BigDecimal> extractSimilar(final PhysicalStore<BigDecimal> aStore, final boolean aNormalAspectRatio) {
            // TODO Auto-generated method stub
            return null;
        }

        protected Array1D<BigDecimal> makeWarkCopyArray(final int aDim) {
            return Array1D.makeBig(aDim);
        }

        @Override
        protected Rotation<BigDecimal> transformLeft(final DiagonalAccess<BigDecimal> aSimilar, final int aLowInd, final int aHighInd) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        protected Rotation<BigDecimal> transformRight(final DiagonalAccess<BigDecimal> aSimilar, final int aLowInd, final int aHighInd) {
            // TODO Auto-generated method stub
            return null;
        }

    }
    static final class Complex extends SVD4<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

        @Override
        protected DiagonalAccess<ComplexNumber> extractSimilar(final PhysicalStore<ComplexNumber> aStore, final boolean aNormalAspectRatio) {
            // TODO Auto-generated method stub
            return null;
        }

        protected Array1D<ComplexNumber> makeWarkCopyArray(final int aDim) {
            return Array1D.makeComplex(aDim);
        }

        @Override
        protected Rotation<ComplexNumber> transformLeft(final DiagonalAccess<ComplexNumber> aSimilar, final int aLowInd, final int aHighInd) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        protected Rotation<ComplexNumber> transformRight(final DiagonalAccess<ComplexNumber> aSimilar, final int aLowInd, final int aHighInd) {
            // TODO Auto-generated method stub
            return null;
        }

    }
    static final class Primitive extends SVD4<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

        @Override
        protected DiagonalAccess<Double> extractSimilar(final PhysicalStore<Double> aStore, final boolean aNormalAspectRatio) {

            final Array2D<Double> tmpArray2D = ((PrimitiveDenseStore) aStore).asArray2D();

            final Array1D<Double> tmpMain = tmpArray2D.sliceDiagonal(0, 0);

            if (aNormalAspectRatio) {

                final Array1D<Double> tmpSuper = tmpArray2D.sliceDiagonal(0, 1);

                return DiagonalAccess.makePrimitive(tmpMain, tmpSuper, Array1D.makePrimitive(tmpSuper.length));

            } else {

                final Array1D<Double> tmpSub = tmpArray2D.sliceDiagonal(1, 0);

                return DiagonalAccess.makePrimitive(tmpMain, Array1D.makePrimitive(tmpSub.length), tmpSub);
            }
        }

        protected Array1D<Double> makeWarkCopyArray(final int aDim) {
            return Array1D.makePrimitive(aDim);
        }

        @Override
        protected Rotation<Double> transformLeft(final DiagonalAccess<Double> aSimilar, final int aLowInd, final int aHighInd) {

            final Array1D<Double> tmpMain = aSimilar.mainDiagonal;
            final Array1D<Double> tmpSuper = aSimilar.superdiagonal;
            final Array1D<Double> tmpSub = aSimilar.subdiagonal;

            final double a00 = tmpMain.doubleValue(aLowInd);
            final double a10 = tmpSub.doubleValue(aLowInd);
            final double a11 = tmpMain.doubleValue(aHighInd);

            double t; // tan, cot or something temporary

            final double cg; // cos Givens
            final double sg; // sin Givens

            if (TypeUtils.isZero(a10)) {
                cg = Math.signum(a00);
                sg = PrimitiveMath.ZERO;
            } else if (TypeUtils.isZero(a00)) {
                sg = Math.signum(a10);
                cg = PrimitiveMath.ZERO;
            } else if (Math.abs(a10) > Math.abs(a00)) {
                t = a00 / a10; // cot
                sg = Math.signum(a10) / PrimitiveFunction.SQRT1PX2.invoke(t);
                cg = sg * t;
            } else {
                t = a10 / a00; // tan
                cg = Math.signum(a00) / PrimitiveFunction.SQRT1PX2.invoke(t);
                sg = cg * t;
            }

            tmpMain.set(aLowInd, cg * a00 + sg * a10);
            tmpSuper.set(aLowInd, sg * a11);
            tmpSub.set(aLowInd, PrimitiveMath.ZERO);
            tmpMain.set(aHighInd, cg * a11);

            return new Rotation<Double>(aLowInd, aHighInd, cg, sg);
        }

        @Override
        protected Rotation<Double> transformRight(final DiagonalAccess<Double> aSimilar, final int aLowInd, final int aHighInd) {

            final Array1D<Double> tmpMain = aSimilar.mainDiagonal;
            final Array1D<Double> tmpSuper = aSimilar.superdiagonal;
            final Array1D<Double> tmpSub = aSimilar.subdiagonal;

            final double a00 = tmpMain.doubleValue(aLowInd);
            final double a01 = tmpSuper.doubleValue(aLowInd);
            final double a11 = tmpMain.doubleValue(aHighInd);

            double t; // tan, cot or something temporary

            final double cg; // cos Givens
            final double sg; // sin Givens

            if (TypeUtils.isZero(-a01)) {
                cg = Math.signum(a00);
                sg = PrimitiveMath.ZERO;
            } else if (TypeUtils.isZero(a00)) {
                sg = Math.signum(-a01);
                cg = PrimitiveMath.ZERO;
            } else if (Math.abs(-a01) > Math.abs(a00)) {
                t = a00 / -a01; // cot
                sg = Math.signum(-a01) / PrimitiveFunction.SQRT1PX2.invoke(t);
                cg = sg * t;
            } else {
                t = -a01 / a00; // tan
                cg = Math.signum(a00) / PrimitiveFunction.SQRT1PX2.invoke(t);
                sg = cg * t;
            }

            tmpMain.set(aLowInd, a00 * cg + a01 * -sg);
            tmpSuper.set(aLowInd, PrimitiveMath.ZERO);
            tmpSub.set(aLowInd, a11 * -sg);
            tmpMain.set(aHighInd, a11 * cg);

            return new Rotation<Double>(aLowInd, aHighInd, cg, sg);
        }

    }

    private transient PhysicalStore<N> myD;
    private transient PhysicalStore<N> myQ1;
    private Householder<N>[] myQ1Householders;
    private final List<Rotation<N>> myQ1Rotations = new ArrayList<Rotation<N>>();
    private transient PhysicalStore<N> myQ2;
    private Householder<N>[] myQ2Householders;
    private final List<Rotation<N>> myQ2Rotations = new ArrayList<Rotation<N>>();
    private DiagonalAccess<N> mySimilar;
    private Array1D<Double> mySingularValues;

    protected SVD4(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    @SuppressWarnings("unchecked")
    public final boolean compute(final MatrixStore<N> aStore) {

        this.reset();

        final int tmpRowDim = aStore.getRowDim();
        final int tmpMinDim = aStore.getMinDim();
        final int tmpColDim = aStore.getColDim();

        final boolean tmpNormalAspectRatio = tmpRowDim >= tmpColDim;

        final PhysicalStore<N> tmpD = this.copy(aStore);

        final Householder[] tmpQ1Householders = myQ1Householders = new Householder[tmpMinDim];
        final Householder[] tmpQ2Householders = myQ2Householders = new Householder[tmpMinDim];

        Householder<N> tmpHouseholder;
        for (int ij = 0; ij < tmpMinDim; ij++) {

            if (tmpNormalAspectRatio) {

                tmpHouseholder = tmpD.generateHouseholderColumn(ij, ij);
                tmpD.transformLeft(tmpHouseholder, ij + 1);
                tmpQ1Householders[ij] = tmpHouseholder;

                tmpHouseholder = tmpD.generateHouseholderRow(ij, ij + 1);
                tmpD.transformRight(tmpHouseholder, ij + 1);
                tmpQ2Householders[ij] = tmpHouseholder;

            } else {

                tmpHouseholder = tmpD.generateHouseholderRow(ij, ij);
                tmpD.transformRight(tmpHouseholder, ij + 1);
                tmpQ2Householders[ij] = tmpHouseholder;

                tmpHouseholder = tmpD.generateHouseholderColumn(ij + 1, ij);
                tmpD.transformLeft(tmpHouseholder, ij + 1);
                tmpQ1Householders[ij] = tmpHouseholder;
            }
        }

        mySimilar = this.extractSimilar(tmpD, tmpNormalAspectRatio);
        final Array1D<N> tmpMain = mySimilar.mainDiagonal;
        final Array1D<N> tmpSuper = mySimilar.superdiagonal;
        final Array1D<N> tmpSub = mySimilar.subdiagonal;

        mySingularValues = Array1D.makePrimitive(tmpMinDim);

        int iter = 0;
        if (DEBUG) {
            BasicLogger.logDebug("New4 Init D", this.copy(mySimilar));
        }

        boolean tmpNotAllZeros = true;
        boolean tmpUpperNotZeros = tmpNormalAspectRatio;

        final int tmpDimLim = tmpMinDim - 1;
        final int tmpIterLim = tmpRowDim * tmpColDim * tmpMinDim;
        for (int l = 0; tmpNotAllZeros && (l < tmpIterLim); l++) {

            tmpNotAllZeros = false;

            for (int ij = 0; ij < tmpDimLim; ij++) {

                if (tmpUpperNotZeros && !tmpSuper.isZero(ij)) {

                    tmpNotAllZeros = true;

                    myQ2Rotations.add(this.transformRight(mySimilar, ij, ij + 1));

                } else if (!tmpUpperNotZeros && !tmpSub.isZero(ij)) {

                    tmpNotAllZeros = true;

                    myQ1Rotations.add(this.transformLeft(mySimilar, ij, ij + 1).invert());
                }

                if (DEBUG) {
                    BasicLogger.logDebug("New4 Iter D " + ++iter, this.copy(mySimilar));
                }
            }

            tmpUpperNotZeros = !tmpUpperNotZeros;
        }

        Scalar<N> tmpScalar;
        double tmpSingularValue;
        for (int ij = 0; ij < tmpMinDim; ij++) {

            tmpScalar = tmpMain.toScalar(ij);

            if (tmpScalar.isZero()) {

                tmpSingularValue = PrimitiveMath.ZERO;

            } else if (tmpScalar.isAbsolute()) {

                tmpSingularValue = tmpScalar.getReal();

            } else {

                final N tmpSignum = tmpScalar.signum().getNumber();
                tmpSingularValue = tmpScalar.divide(tmpSignum).getModulus();

                tmpMain.set(ij, tmpSingularValue);
                myQ2Rotations.add(new Rotation<N>(ij, ij, tmpSignum, tmpSignum));
            }

            mySingularValues.set(ij, tmpSingularValue);
        }

        mySingularValues.sortDescending();

        return this.computed(!tmpNotAllZeros);
    }

    public final boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public final MatrixStore<N> getD() {

        if (myD == null) {

            final int tmpMinDim = mySimilar.getMinDim();

            myD = this.makeZero(tmpMinDim, tmpMinDim);

            for (int ij = 0; ij < tmpMinDim; ij++) {
                myD.set(ij, ij, mySimilar.get(ij, ij));
            }
        }

        return myD;
    }

    public final MatrixStore<N> getQ1() {

        if (myQ1 == null) {

            final Householder<N>[] tmpHouseholders = myQ1Householders;
            final List<Rotation<N>> tmpRotations = myQ1Rotations;

            final int tmpRowDim = tmpHouseholders[0].size();
            final int tmpColDim = tmpHouseholders.length;
            final int tmpRotDim = tmpRotations.size();

            myQ1 = this.makeEye(tmpRowDim, tmpColDim);

            for (int j = tmpColDim - 1; j >= 0; j--) {
                myQ1.transformLeft(tmpHouseholders[j], j);
            }

            for (int r = 0; r < tmpRotDim; r++) {
                myQ1.transformRight(tmpRotations.get(r));
            }
        }

        return myQ1;
    }

    public final MatrixStore<N> getQ2() {

        if (myQ2 == null) {

            final Householder<N>[] tmpHouseholders = myQ2Householders;
            final List<Rotation<N>> tmpRotations = myQ2Rotations;

            final int tmpRowDim = tmpHouseholders[0].size();
            final int tmpColDim = tmpHouseholders.length;
            final int tmpRotDim = tmpRotations.size();

            myQ2 = this.makeEye(tmpRowDim, tmpColDim);

            for (int j = tmpColDim - 1; j >= 0; j--) {
                myQ2.transformLeft(tmpHouseholders[j], j);
            }

            for (int r = 0; r < tmpRotDim; r++) {
                myQ2.transformRight(tmpRotations.get(r));
            }
        }

        return myQ2;
    }

    public final Array1D<Double> getSingularValues() {
        return mySingularValues;
    }

    public final boolean isFullSize() {
        return false;
    }

    public boolean isOrdered() {
        return false;
    }

    public boolean isSolvable() {
        return this.isComputed();
    }

    @Override
    public final void reset() {

        super.reset();

        myQ1 = null;
        myD = null;
        myQ2 = null;

        mySingularValues = null;

        mySimilar = null;

        myQ1Householders = null;
        myQ2Householders = null;

        myQ1Rotations.clear();
        myQ2Rotations.clear();
    }

    public final MatrixStore<N> solve(final MatrixStore<N> aRHS) {
        return this.getInverse().multiplyRight(aRHS);
    }

    protected abstract DiagonalAccess<N> extractSimilar(PhysicalStore<N> aStore, boolean aNormalAspectRatio);

    protected abstract Rotation<N> transformLeft(DiagonalAccess<N> aSimilar, int aLowInd, int aHighInd);

    protected abstract Rotation<N> transformRight(DiagonalAccess<N> aSimilar, int aLowInd, int aHighInd);

}
