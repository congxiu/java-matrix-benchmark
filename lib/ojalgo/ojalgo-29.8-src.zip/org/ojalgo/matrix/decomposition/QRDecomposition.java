/*
 * Copyright © 2003 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.jama.JamaQR;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.matrix.store.SelectedRowsStore;
import org.ojalgo.matrix.store.UpperTriangularStore;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.scalar.Scalar;
import org.ojalgo.type.context.NumberContext;

public abstract class QRDecomposition<N extends Number> extends InPlaceDecomposition<N> implements QR<N> {

    static final class Big extends QRDecomposition<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

    }

    static final class Complex extends QRDecomposition<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

    }

    static final class Primitive extends QRDecomposition<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

    }

    public static final QR<BigDecimal> makeBig() {
        return new Big();
    }

    public static final QR<ComplexNumber> makeComplex() {
        return new Complex();
    }

    public static final QR<Double> makeJama() {
        return new JamaQR();
    }

    public static final QR<Double> makePrimitive() {
        return new Primitive();
    }

    protected QRDecomposition(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public boolean compute(final MatrixStore<N> aStore) {

        this.copyInPlace(aStore);

        this.getStore().computeInPlaceQR();

        return this.computed(true);
    }

    public boolean equals(final MatrixStore<N> aStore, final NumberContext aCntxt) {
        return MatrixUtils.equals(aStore, this, aCntxt);
    }

    public MatrixStore<N> getInverse() {
        final int tmpDim = this.getRowDim();
        return this.solve(this.makeEye(tmpDim, tmpDim));
    }

    public MatrixStore<N> getQ() {

        final DecompositionStore<N> tmpStore = this.getStore();
        final int tmpRowDim = tmpStore.getRowDim();
        final int tmpColDim = tmpStore.getMinDim();

        final DecompositionStore<N> retVal = this.makeEye(tmpRowDim, tmpColDim);

        final Householder.Reference<N> tmpReference = new Householder.Reference<N>(tmpStore, true);

        for (int j = tmpColDim - 1; j >= 0; j--) {
            tmpReference.row = j;
            tmpReference.col = j;
            retVal.transformLeft(tmpReference, j);
        }

        return retVal;
    }

    public MatrixStore<N> getR() {
        return new UpperTriangularStore<N>(this.getStore(), false);
    }

    public int getRank() {

        int retVal = 0;

        Scalar<N> tmpVal;
        for (int ij = 0; ij < this.getStore().getMinDim(); ij++) {
            tmpVal = this.getStore().toScalar(ij, ij);
            if (!tmpVal.isZero()) {
                retVal++;
            }
        }

        return retVal;
    }

    public final List<Householder<N>> getTransformations() {

        final DecompositionStore<N> tmpStore = this.getStore();
        final int tmpMinDim = tmpStore.getMinDim();

        final ArrayList<Householder<N>> retVal = new ArrayList<Householder<N>>(tmpMinDim);

        final Householder.Reference<N> tmpReference = new Householder.Reference<N>(this.getStore(), true);
        for (int ij = 0; ij < tmpMinDim; ij++) {
            tmpReference.row = ij;
            tmpReference.col = ij;
            retVal.add(tmpReference.extract());
        }

        return retVal;
    }

    /**
     * @see org.ojalgo.matrix.decomposition.QR#isFullColumnRank()
     */
    public boolean isFullColumnRank() {
        return this.getRank() == this.getMinDim();
    }

    public final boolean isFullSize() {
        return false;
    }

    public final boolean isSolvable() {
        return this.isComputed() && this.isFullColumnRank();
    }

    public MatrixStore<N> reconstruct() {
        return MatrixUtils.reconstruct(this);
    }

    /**
     * Solve [A]*[X]=[B] by first solving [Q]*[Y]=[B] and then [R]*[X]=[Y]. [X]
     * minimises the 2-norm of [Q]*[R]*[X]-[B].
     * 
     * @param aRHS The right hand side [B]
     * @return [X]
     */
    public MatrixStore<N> solve(final MatrixStore<N> aRHS) {

        final DecompositionStore<N> tmpStore = this.getStore();
        final int tmpRowDim = tmpStore.getRowDim();
        final int tmpColDim = tmpStore.getColDim();

        final DecompositionStore<N> retVal = this.copy(aRHS);

        final Householder.Reference<N> tmpReference = new Householder.Reference<N>(tmpStore, true);

        final int tmpLimit = tmpStore.getMinDim();
        for (int j = 0; j < tmpLimit; j++) {
            tmpReference.row = j;
            tmpReference.col = j;
            retVal.transformLeft(tmpReference, 0);
        }

        retVal.substituteBackwards(tmpStore, false, false);

        if (tmpColDim < tmpRowDim) {
            final int[] tmpRange = MatrixUtils.makeIncreasingRange(0, tmpColDim);
            return new SelectedRowsStore<N>(retVal, tmpRange);
        } else {
            return retVal;
        }
    }

    /**
     * The input {@linkplain DecompositionStore} in NOT copied!
     */
    protected final boolean compute(final DecompositionStore<N> aStore) {

        this.setInPlace(aStore);

        this.getStore().computeInPlaceQR();

        return this.computed(true);
    }

    /**
     * @return L as in R<sup>T</sup>.
     */
    protected final PhysicalStore<N> getL() {

        final int tmpRowDim = this.getColDim();
        final int tmpColDim = this.getMinDim();

        final PhysicalStore<N> retVal = this.makeEmpty(tmpRowDim, tmpColDim);

        N tmpVal;
        for (int i = 0; i < tmpRowDim; i++) {
            for (int j = 0; j < tmpColDim; j++) {
                if (j <= i) {
                    tmpVal = this.getStore().get(j, i);
                } else {
                    tmpVal = this.getStaticZero().getNumber();
                }
                retVal.set(i, j, tmpVal);
            }
        }

        return retVal;

    }

}
