/*
 * Copyright © 2010 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.decomposition;

import java.math.BigDecimal;

import org.ojalgo.matrix.MatrixUtils;
import org.ojalgo.matrix.store.BigDenseStore;
import org.ojalgo.matrix.store.ComplexDenseStore;
import org.ojalgo.matrix.store.MatrixStore;
import org.ojalgo.matrix.store.PhysicalStore;
import org.ojalgo.matrix.store.PrimitiveDenseStore;
import org.ojalgo.scalar.ComplexNumber;
import org.ojalgo.type.context.NumberContext;

public abstract class BidiagonalDecomposition<N extends Number> extends InPlaceDecomposition<N> implements Bidiagonal<N> {

    static final class Big extends BidiagonalDecomposition<BigDecimal> {

        Big() {
            super(BigDenseStore.FACTORY);
        }

        public boolean equals(final MatrixStore<BigDecimal> aStore, final NumberContext aCntxt) {
            // TODO Auto-generated method stub
            return false;
        }

        public MatrixStore<BigDecimal> getD() {
            // TODO Auto-generated method stub
            return null;
        }

        public MatrixStore<BigDecimal> getInverse() {
            // TODO Auto-generated method stub
            return null;
        }

        public MatrixStore<BigDecimal> getQ1() {
            // TODO Auto-generated method stub
            return null;
        }

        public MatrixStore<BigDecimal> getQ2() {
            // TODO Auto-generated method stub
            return null;
        }

        public boolean isFullSize() {
            // TODO Auto-generated method stub
            return false;
        }

        public boolean isSolvable() {
            // TODO Auto-generated method stub
            return false;
        }

        public MatrixStore<BigDecimal> solve(final MatrixStore<BigDecimal> aRHS) {
            // TODO Auto-generated method stub
            return null;
        }

    }

    static final class Complex extends BidiagonalDecomposition<ComplexNumber> {

        Complex() {
            super(ComplexDenseStore.FACTORY);
        }

        public boolean equals(final MatrixStore<ComplexNumber> aStore, final NumberContext aCntxt) {
            // TODO Auto-generated method stub
            return false;
        }

        public MatrixStore<ComplexNumber> getD() {
            // TODO Auto-generated method stub
            return null;
        }

        public MatrixStore<ComplexNumber> getInverse() {
            // TODO Auto-generated method stub
            return null;
        }

        public MatrixStore<ComplexNumber> getQ1() {
            // TODO Auto-generated method stub
            return null;
        }

        public MatrixStore<ComplexNumber> getQ2() {
            // TODO Auto-generated method stub
            return null;
        }

        public boolean isFullSize() {
            // TODO Auto-generated method stub
            return false;
        }

        public boolean isSolvable() {
            // TODO Auto-generated method stub
            return false;
        }

        public MatrixStore<ComplexNumber> solve(final MatrixStore<ComplexNumber> aRHS) {
            // TODO Auto-generated method stub
            return null;
        }

    }

    static final class Primitive extends BidiagonalDecomposition<Double> {

        Primitive() {
            super(PrimitiveDenseStore.FACTORY);
        }

        public boolean equals(final MatrixStore<Double> aStore, final NumberContext aCntxt) {
            // TODO Auto-generated method stub
            return false;
        }

        public MatrixStore<Double> getD() {
            // TODO Auto-generated method stub
            return null;
        }

        public MatrixStore<Double> getInverse() {
            // TODO Auto-generated method stub
            return null;
        }

        public MatrixStore<Double> getQ1() {
            // TODO Auto-generated method stub
            return null;
        }

        public MatrixStore<Double> getQ2() {
            // TODO Auto-generated method stub
            return null;
        }

        public boolean isFullSize() {
            // TODO Auto-generated method stub
            return false;
        }

        public boolean isSolvable() {
            // TODO Auto-generated method stub
            return false;
        }

        public MatrixStore<Double> solve(final MatrixStore<Double> aRHS) {
            // TODO Auto-generated method stub
            return null;
        }

    }

    protected BidiagonalDecomposition(final PhysicalStore.Factory<N> aFactory) {
        super(aFactory);
    }

    public final boolean compute(final MatrixStore<N> aStore) {

        this.copyInPlace(aStore);

        this.getStore().computeInPlaceBidiagonal(this.isAspectRatioNormal());

        return this.computed(true);
    }

    public MatrixStore<N> reconstruct() {
        return MatrixUtils.reconstruct(this);
    }

}
