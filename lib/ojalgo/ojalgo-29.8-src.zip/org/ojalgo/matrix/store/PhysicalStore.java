/*
 * Copyright © 2003 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.store;

import java.io.Serializable;
import java.util.List;

import org.ojalgo.access.Access1D;
import org.ojalgo.access.Access2D;
import org.ojalgo.function.BinaryFunction;
import org.ojalgo.function.UnaryFunction;
import org.ojalgo.function.aggregator.AggregatorCollection;
import org.ojalgo.function.implementation.FunctionSet;
import org.ojalgo.matrix.transformation.Householder;
import org.ojalgo.matrix.transformation.Rotation;
import org.ojalgo.scalar.Scalar;

/**
 * <p>
 * PhysicalStore:s, as opposed to MatrixStore:s, are mutable. The vast
 * majorty of the methods defined here return void and none return
 * {@linkplain PhysicalStore} or {@linkplain MatrixStore}.
 * </p><p>
 * This interface and its implementations are central to ojAlgo.
 * </p>
 *
 * @author apete
 */
public interface PhysicalStore<N extends Number> extends MatrixStore<N> {

    public static interface Factory<N extends Number> extends Serializable {

        PhysicalStore<N> conjugate(Access2D<? extends Number> aSource);

        PhysicalStore<N> copy(Access2D<? extends Number> aSource);

        PhysicalStore<N> copy(double[][] aSource);

        AggregatorCollection<N> getAggregatorCollection();

        FunctionSet<N> getFunctionSet();

        N getNumber(double aNmbr);

        N getNumber(Number aNmbr);

        Scalar<N> getStaticOne();

        Scalar<N> getStaticZero();

        PhysicalStore<N> makeColumn(Access1D<? extends Number> aColumn);

        PhysicalStore<N> makeColumn(double[] aColumn);

        PhysicalStore<N> makeColumn(List<N> aColumn);

        PhysicalStore<N> makeColumn(N[] aColumn);

        PhysicalStore<N> makeEmpty(int aRowDim, int aColDim);

        PhysicalStore<N> makeEye(int aRowDim, int aColDim);

        PhysicalStore<N> makeZero(int aRowDim, int aColDim);

        Scalar<N> toScalar(double aNmbr);

        Scalar<N> toScalar(Number aNmbr);

        PhysicalStore<N> transpose(Access2D<? extends Number> aSource);

    }

    /**
     * @return The elements of the physical store as a fixed size
     * (1 dimensional) list. The elements may be accessed either row or
     * colomn major.
     */
    List<N> asList();

    /**
     * <p>
     * <b>c</b>olumn <b>a</b> * <b>x</b> <b>p</b>lus <b>y</b>
     * </p>
     * [this(*,aColY)] = aSclrA [this(*,aColX)] + [this(*,aColY)]
     */
    void caxpy(final N aSclrA, final int aColX, final int aColY, final int aFirstRow);

    void exchangeColumns(int aColA, int aColB);

    void exchangeRows(int aRowA, int aRowB);

    void fillAll(N aNmbr);

    void fillByMultiplying(final MatrixStore<N> aLeftArg, final MatrixStore<N> aRightArg);

    void fillColumn(int aRow, int aCol, N aNmbr);

    void fillDiagonal(int aRow, int aCol, N aNmbr);

    void fillMatching(Access2D<N> aSource2D);

    /**
     * <p>
     * Will replace the elements of [this] with the results of element
     * wise invocation of the input binary funtion:
     * </p>
     * <code>this(i,j) = aFunc.invoke(aLeftArg(i,j),aRightArg(i,j))</code>
     */
    void fillMatching(MatrixStore<N> aLeftArg, BinaryFunction<N> aFunc, MatrixStore<N> aRightArg);

    /**
     * <p>
     * Will replace the elements of [this] with the results of element
     * wise invocation of the input binary funtion:
     * </p>
     * <code>this(i,j) = aFunc.invoke(aLeftArg(i,j),aRightArg))</code>
     */
    void fillMatching(MatrixStore<N> aLeftArg, BinaryFunction<N> aFunc, N aRightArg);

    /**
     * <p>
     * Will replace the elements of [this] with the results of element
     * wise invocation of the input binary funtion:
     * </p>
     * <code>this(i,j) = aFunc.invoke(aLeftArg,aRightArg(i,j))</code>
     */
    void fillMatching(N aLeftArg, BinaryFunction<N> aFunc, MatrixStore<N> aRightArg);

    void fillRow(int aRow, int aCol, N aNmbr);

    /**
     * @deprecated v29
     */
    @Deprecated
    Householder<N> generateHouseholderColumn(int newI, int newIj);

    /**
     * @deprecated v29
     */
    @Deprecated
    Householder<N> generateHouseholderRow(int newIj, int newI);

    int getIndexOfLargestInColumn(final int aRow, final int aCol);

    int getIndexOfLargestInRow(final int aRow, final int aCol);

    /**
     * <p>
     * <b>m</b>atrix <b>a</b> * <b>x</b> <b>p</b>lus <b>y</b>
     * </p>
     * [this] = aSclrA [aMtrxX] + [this]
     */
    void maxpy(final N aSclrA, final MatrixStore<N> aMtrxX);

    void modifyAll(UnaryFunction<N> aFunc);

    void modifyColumn(int aRow, int aCol, UnaryFunction<N> aFunc);

    void modifyDiagonal(int aRow, int aCol, UnaryFunction<N> aFunc);

    void modifyRow(int aRow, int aCol, UnaryFunction<N> aFunc);

    /**
     * <p>
     * <b>r</b>ow <b>a</b> * <b>x</b> <b>p</b>lus <b>y</b>
     * </p>
     * [this(aRowY,*)] = aSclrA [this(aRowX,*)] + [this(aRowY,*)]
     */
    void raxpy(final N aSclrA, final int aRowX, final int aRowY, final int aFirstCol);

    void set(int aRow, int aCol, double aNmbr);

    void set(int aRow, int aCol, N aNmbr);

    /**
     * Will solve the equation system [A][X]=[B] where:
     * <ul>
     * <li>[aBody][this]=[this] is [A][X]=[B] ("this" is the right hand
     * side, and it will be overwritten with the solution).</li>
     * <li>[A] is upper/right triangular</li>
     * </ul>
     * 
     * @param aBody The equation system body parameters [A]
     * @param assumeOne true if aBody as ones on the diagonal
     * @param transposed true if the upper/right part of aBody is
     * actually stored in the lower/left part of the matrix.
     */
    void substituteBackwards(Access2D<N> aBody, boolean assumeOne, boolean transposed);

    /**
     * Will solve the equation system [A][X]=[B] where:
     * <ul>
     * <li>[aBody][this]=[this] is [A][X]=[B] ("this" is the right hand
     * side, and it will be overwritten with the solution).</li>
     * <li>[A] is lower/left triangular</li>
     * </ul>
     * 
     * @param aBody The equation system body parameters [A]
     * @param assumeOne true if aBody as ones on the diagonal
     * @param transposed true if the lower/left part of aBody is
     * actually stored in the upper/right part of the matrix.
     */
    void substituteForwards(Access2D<N> aBody, boolean assumeOne, boolean transposed);

    void transformLeft(Householder<N> aTransf, int aFirstCol);

    /**
     * <p>
     * As in {@link MatrixStore#multiplyLeft(MatrixStore)} where the
     * left/parameter matrix is a plane rotation.
     * </p><p>
     * Multiplying by a plane rotation from the left means that [this]
     * gets two of its rows updated to new combinations of those two (current)
     * rows.
     * </p><p>
     * There are two ways to transpose/invert a rotation. Either you negate
     * the angle or you interchange the two indeces that define the rotation
     * plane.
     * </p>
     * @see #transformRight(Rotation)
     */
    void transformLeft(Rotation<N> aTransf);

    void transformRight(Householder<N> aTransf, int aFirstRow);

    /**
     * <p>
     * As in {@link MatrixStore#multiplyRight(MatrixStore)} where the
     * right/parameter matrix is a plane rotation.
     * </p><p>
     * Multiplying by a plane rotation from the right means that [this]
     * gets two of its columns updated to new combinations of those two
     * (current) columns.
     * </p><p>
     * There result is undefined if the two input indeces are the same
     * (in which case the rotation plane is undefined).
     * </p>
     * @see #transformLeft(Rotation)
     */
    void transformRight(Rotation<N> aTransf);

}
